<?php
$url = parse_url(@urldecode($_POST['AppRequest']));
//----------------------------------------
if (file_exists("config/config.inc.php")):
    require "config/config.inc.php";
endif;
require "handlers/app_autoloader.php";
$SMBEngine = new SMBEngine();
$detect = new Detect;
//----------------------------------------
$AppAuth = new Auth_Access();
@$checkAuth = @$AppAuth->AppAuthChecker();
//----------------------------------------
if (@$url['scheme'] != 'https' && @$url['scheme'] != "http"):
    die('Connection Error! Try Again.');
endif;
@$host = $url['host'];
@$path = $url['path'];
@$query = $url['query'];
@$frags = $url['fragment'];
@$fp = fsockopen($host, 80);
if (!$fp):
    @$connection_error = 1;
else:
    if (@$checkAuth !== NULL):
        echo '<script>location.replace("' . $SMBEngine->dashboard . '")</script>';
    else:
        echo '<script>var authPath = "' . $SMBEngine->webRoot . 'auth/' . '";</script>';
        require '../auth/login.php';
    endif;
endif;
exit;