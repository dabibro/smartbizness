<?php
/**
 * Created by PhpStorm.
 * User: Dauda Ibrahim
 * Date: 6/21/2020
 * Time: 6:48 PM
 */

class smartBiz extends AppConfig
{
    protected $api_path = "";

    public function __construct()
    {
        $res = $this->initials();
    }

    public function LaunchEngine()
    {
        $api_path = $this->api_path = $this->srv_protocol . $this->srv . $this->webRoot . 'api/';
        $curl = curl_init();
        $reqArray = array('launch_app' => 1);
        curl_setopt_array($curl, array(
            CURLOPT_URL => $this->api_path,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HEADER => 0,
            CURLOPT_CUSTOMREQUEST => "POST",
            CURLOPT_POSTFIELDS => $reqArray
        ));
        $response = curl_exec($curl);
        $err = curl_error($curl);
        if ($err) {
            die('Internal server error contact support team: ' . $err);
        }
        $getResponse = json_decode($response, true);
        if ($getResponse['success'] != '1') {
            die('Internal server error contact support team' . $err);
        } else {
            echo base64_decode($getResponse['smartBiz']);
        }
    }


}