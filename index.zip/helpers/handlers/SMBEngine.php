<?php
/**
 * Created by PhpStorm.
 * User: Dauda Ibrahim
 * Date: 6/21/2020
 * Time: 9:56 PM
 */

class SMBEngine extends AppConfig {
	public $dropDownList;
	public $gps_tracker;

	public function __construct() {
		$this->initials();
		$this->resources();
	}

	public function fileTempParse( $filename, $varParam ) {
		ob_start();
		if ( $varParam != null ):
			extract( $varParam );
		endif;
		include( $filename );
		$content = ob_get_contents();
		ob_end_clean();

		return $content;
	}

	public function LaunchCore() {
		$biz               = new BIZConfig;
		$this->gps_tracker = $biz->gps_tracker;
		$tmpFile           = "../dashboard/startup.php";
		$startup           = $this->parseAdminTemp( $tmpFile );
		$response          = [ "success" => 1, "SMBCore" => base64_encode( $startup ) ];

		return $response;
	}

	public function parseAdminTemp( $filename ) {
		ob_start();
		include( $filename );
		$content = ob_get_contents();
		ob_end_clean();

		return $content;
	}

	//-------------------------------------------------

	public function verify_input( $data ) {
		$data = trim( $data );
		$data = stripslashes( $data );
		$data = htmlspecialchars( $data );
		$data = $this->escape_string( $data );

		return $data;
	}

	public function escape_string( $value ) {
		$search  = array( "\\", "\x00", "\n", "\r", "'", '"', "\x1a" );
		$replace = array( "\\\\", "\\0", "\\n", "\\r", "\'", '\"', "\\Z" );

		return str_replace( $search, $replace, $value );
	}

	public function base64_url_encryption( $input, $type = null ) {
		if ( $type == null ) {
			return strtr( base64_encode( $input ), '+/=', '._-' );
		} else {
			return base64_decode( strtr( $input, '._-', '+/=' ) );
		}
	}

	public function sixRandomNumbers() {
		return $random_id = rand( round( ceil( rand( 101, 255 ) ) ), 255 ) . rand( round( ceil( rand( 255, 999 ) ) ), 500 );
	}

	public function generateAppId( $prefix = '', $suffix = '', $length = '', $pattern = '' ) {
		$genId = $prefix . ( $this->generate_random_string( $length, $pattern ) ) . $suffix;

		return $genId;
	}

	public function generate_random_string( $strength = 6, $patter = '' ) {
		if ( $patter != '' ) {
			$input = $patter;
		} else {
			$input = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
		}
		$input_length  = strlen( $input );
		$random_string = '';
		for ( $i = 0; $i < $strength; $i ++ ) {
			$random_character = $input[ mt_rand( 0, $input_length - 1 ) ];
			$random_string    .= $random_character;
		}

		return $random_string;
	}

	public function truncateContent( $text, $length ) {
		$length = abs( (int) $length );
		if ( strlen( $text ) > $length ) {
			$text = preg_replace( "/^(.{1,$length})(\s.*|$)/s", '\\1...', $text );
		}

		return ( $text );
	}

	public function valueSign( $value ) {
		if ( $value < 0 ) {
			return '(' . str_replace( '-', '', $value ) . ')';
		} else {
			return $value;
		}
	}

	//-------------------------------------------------

	public function dropDownList( $itemKey = null, $itemLabel = null, $selected = null ) {
		$select = "";
		if ( isset( $itemKey ) && $itemKey != null ) {
			if ( ! empty( $itemLabel ) ):
				if ( isset( $selected ) && $selected != "" ):
					if ( $selected == $itemKey ): $select = " selected";endif;
				endif;
				$this->dropDownList = "<option value='" . $itemKey . "' " . $select . ">" . $itemLabel . "</option>";
			else:
				if ( $selected == $itemKey ): $select = " selected";endif;
				$this->dropDownList = "<option value='" . $itemKey . "' " . $select . " >" . $itemKey . "</option>";
			endif;

			return $this->dropDownList;
		}
	}

	//-------------------------------------------------
	public function getLocation( $tbl = null, $id = null ) {
		if ( $tbl != "" && $id != "" ) {
			if ( $tbl === "CN" ): $tbl = "app_countries";
			elseif ( $tbl === "S" ): $tbl = "app_states";
			elseif ( $tbl === "C" ): $tbl = "app_cities"; endif;
			@$query = "SELECT name FROM " . $tbl . " WHERE id = '" . $id . "' ";
			@$execQuery = Data_Access::execSQL( $query )['dataArray'];
			if ( @$execQuery ):
				return @Data_Access::fetchAssoc( $execQuery )['dataArray'][0]['name'];
			endif;

		}
	}

	//-------------------------------------------------
	public function formatDate( $date = "" ) {
		if ( $date != "" ) {
			$dateTime = new DateTime( $date );
		} else {
			$dateTime = new DateTime( "now" );
		}
		$date = $dateTime->format( 'd/m/Y h:i:s A' );

		return $date;

	}

}