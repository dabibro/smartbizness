<?php
/**
 * Created by PhpStorm.
 * User: Dauda Ibrahim
 * Date: 6/21/2020
 * Time: 6:48 PM
 */

class SMBAPI extends AppConfig
{
    protected $api_path = "";

    public function __construct()
    {
        $this->initials();
    }

    public function LaunchEngine()
    {
        $this->api_path = $this->srv_protocol . $this->srv . $this->webRoot . 'api/';
        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => $this->api_path,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HEADER => 0,
            CURLOPT_CUSTOMREQUEST => "POST",
            CURLOPT_POSTFIELDS => ["SMBLaunch" => 1, "SMBPrivateKey" => '',]
        ));
        $response = curl_exec($curl);
        $err = curl_error($curl);
        @$getResponse = json_decode($response, true);
        if ($err) {
            die('Internal server error contact support team: ' . $err);
        }
        if (@$getResponse['success'] !== 1) {
            die('Internal server error contact support team' . $err);
        } else {
            return base64_decode($getResponse['SMBCore']);
        }
    }
}