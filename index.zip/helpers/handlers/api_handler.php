<?php
if ((!defined('CONST_INCLUDE_KEY')) || (CONST_INCLUDE_KEY !== 'd4e2ad09-b1c3-4d70-9a9a-0e6149302486')) {
    header("Location: /404.html", TRUE, 404);
    echo file_get_contents($_SERVER['DOCUMENT_ROOT'] . '/404.html');
    die;
}

class API_Handler
{

    private $function_map;

    public function __construct()
    {
        $this->loadFunctionMap();
    }

    private function loadFunctionMap()
    {

        // load up all public facing functions
        $this->function_map = [
            'VerifyKey' => ['class' => 'API_Handler', 'function_name' => 'VerifyKey'],
        ];

    }

    //--------------------------------------------------------------------------------------------------------------------

    public function parseResponse($param)
    {
        ob_start();
        extract($param);
        include('app_response.html');
        $content = ob_get_contents();
        ob_end_clean();
        return $content;
    }

    //----------------------------------------------------------------------------------------------------------------------

    public function parseShopResponse($param)
    {
        ob_start();
        extract($param);
        include('app/index.php');
        $content = ob_get_contents();
        ob_end_clean();
        return $content;
    }

    //----------------------------------------------------------------------------------------------------------------------

    public function execCommand($varFunctionName, $varFunctionParams)
    {

        // get the actual function name (if necessary) and the class it belongs to.
        $returnArray = $this->getCommand($varFunctionName);
        // if we don't get a function back, then raise the error
        if ($returnArray['success'] == FALSE) {
            return $returnArray;
        }

        $class = $returnArray['dataArray']['class'];
        $functionName = $returnArray['dataArray']['function_name'];

        // Execute User Profile Commands
        $cObjectClass = new $class();
        $returnArray = $cObjectClass->$functionName($varFunctionParams);

        return $returnArray;


    }

    //----------------------------------------------------------------------------------------------------

    private function getCommand($varFunctionName)
    {
        // get the actual function name and the class it belongs to.
        if (isset($this->function_map[$varFunctionName])) {
            $dataArray['class'] = $this->function_map[$varFunctionName]['class'];
            $dataArray['function_name'] = $this->function_map[$varFunctionName]['function_name'];

            $returnArray = App_Response::getResponse('200');
            $returnArray['dataArray'] = $dataArray;
        } else {
            $returnArray = App_Response::getResponse('405');
        }

        return $returnArray;

    }

    //----------------------------------------------------------------------------------------------------------------------

    public function validateRequest($shopId = NULL, $secretKey = NULL)
    {
        // this function requires and API key and token parameters
        if (!$shopId || !$secretKey) {
            $returnArray = App_Response::getResponse('403');
            $returnArray['responseDescription'] .= " Missing Secret key.";
            return $returnArray;
        }

        // get the api key object
        $cApp_API_Key = new App_API_Key;
        $res = $cApp_API_Key->getRecordByAPIKey($secretKey);
        //unset($cApp_API_Key);

        // if anything looks sketchy, bail.
        if ($res['response'] !== '200') {
            return $res;
        }

        // get the client id .
        $clientId = $res['dataArray'][0]['user_id'];

        $clientVerify = $cApp_API_Key->getClientRecord($clientId);

        // if api keys don't match, kick'em out
        if ($clientVerify['response'] != "200") {
            $returnArray = App_Response::getResponse('403');
            $returnArray['responseDescription'] .= " Invalid User Account.";
            return $returnArray;
        }
        $clientId = $clientVerify['dataArray'][0]['user_id'];
        $shopVerify = $cApp_API_Key->getShopRecord($clientId, $shopId);
        if ($shopVerify['response'] !== '200') {
            $returnArray = App_Response::getResponse('403');
            $returnArray['responseDescription'] .= " Invalid Shop Selection.";
            return $returnArray;
        }
        $returnArray = App_Response::getResponse('200');
        return $returnArray;

    }

    //--------------------------------------------------------------------------------------------------------------------

    private function VerifyKey($varParams)
    {
        // api key is required
        if (!isset($varParams['secretKey']) || empty($varParams['secretKey'])) {
            $returnArray = App_Response::getResponse('400');
            return $returnArray;
        }

        $secretKey = $varParams['secretKey'];
        // get the api key object
        $cApp_API_Key = new App_API_Key;
        $res = $cApp_API_Key->getRecordByAPIKey($secretKey);

        // if anything looks sketchy, bail.
        if ($res['response'] !== '200') {
            return $res;
        }
        $clientId = $res['dataArray'][0]['user_id'];
        $shopId = $varParams['shopId'];

        $shopRecord = $cApp_API_Key->getShopRecord($clientId, $shopId);
        if ($shopRecord['response'] !== '200') {
            $returnArray = $res = App_Response::getResponse('405');
        } else {
            $returnArray = App_Response::getResponse('200');
            $returnArray['dataArray'] = array("shopRecord" => $shopRecord, "secretKey" => $secretKey);
        }
        return $returnArray;
    }

} // end of class