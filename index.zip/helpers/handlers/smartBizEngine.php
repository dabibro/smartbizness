<?php
/**
 * Created by PhpStorm.
 * User: Dauda Ibrahim
 * Date: 6/21/2020
 * Time: 9:56 PM
 */

class smartBizEngine extends AppConfig
{
    public $dropDownList;

    public function __construct()
    {
        $this->initials();
        $this->resources();
    }

    public function parseAdminTemp($filename)
    {
        ob_start();
        include($filename);
        $content = ob_get_contents();
        ob_end_clean();
        return $content;
    }

    public function fileTempParse($filename, $varParam)
    {
        ob_start();
        include($filename);
        $content = ob_get_contents();
        ob_end_clean();
        return $content;
    }

    public function LaunchCore()
    {
        $tmpFile = "../dashboard/startup.php";
        $getAdmin = $this->parseAdminTemp($tmpFile);
        $response = array("success" => 1, "smartBiz" => base64_encode($getAdmin));
        return $response;
    }
    //-------------------------------------------------
    public function escape_string($value)
    {
        $search = array("\\", "\x00", "\n", "\r", "'", '"', "\x1a");
        $replace = array("\\\\", "\\0", "\\n", "\\r", "\'", '\"', "\\Z");

        return str_replace($search, $replace, $value);
    }

    public function verify_input($data)
    {
        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data);
        $data = $this->escape_string($data);
        return $data;
    }

    public function base64_url_encryption($input, $type = NULL)
    {
        if ($type == NULL) {
            return strtr(base64_encode($input), '+/=', '._-');
        } else {
            return base64_decode(strtr($input, '._-', '+/='));
        }
    }

    public function sixRandomNumbers()
    {
        return $random_id = rand(round(ceil(rand(101, 255))), 255) . rand(round(ceil(rand(255, 999))), 500);
    }

    public function generate_random_string($strength = 6, $patter = '')
    {
        if ($patter != '') {
            $input = $patter;
        } else {
            $input = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        }
        $input_length = strlen($input);
        $random_string = '';
        for ($i = 0; $i < $strength; $i++) {
            $random_character = $input[mt_rand(0, $input_length - 1)];
            $random_string .= $random_character;
        }
        return $random_string;
    }

    public function generateAppId($prefix = '', $suffix = '', $length = '', $pattern = '')
    {
        $genId = $prefix . ($this->generate_random_string($length, $pattern)) . $suffix;

        return $genId;
    }

    public function truncateContent($text, $length)
    {
        $length = abs((int)$length);
        if (strlen($text) > $length) {
            $text = preg_replace("/^(.{1,$length})(\s.*|$)/s", '\\1...', $text);
        }
        return ($text);
    }

    //-------------------------------------------------

    public function dropDownList($itemKey = NULL, $itemLabel = NULL, $selected = NULL)
    {
        $select = "";
        if (isset($itemKey) && $itemKey != NULL) {
            if (!empty($itemLabel)):
                if (isset($selected) && $selected != ""):
                    if ($selected == $itemKey): $select = " selected";endif;
                endif;
                $this->dropDownList = "<option value='" . $itemKey . "' " . $select . ">" . $itemLabel . "</option>";
            else:
                if ($selected == $itemKey): $select = " selected";endif;
                $this->dropDownList = "<option value='" . $itemKey . "' " . $select . " >" . $itemKey . "</option>";
            endif;
            return $this->dropDownList;
        }
    }

    //-------------------------------------------------


}