<?php
/**
 * Created by PhpStorm.
 * User: Dauda Ibrahim
 * Date: 6/22/2020
 * Time: 2:19 PM
 */

class BIZConfig extends Data_Access
{
    public $currency = "";
    public $biz = "";
    protected $app_config = "app_config";
    protected $app_currency = "app_currency";

    public function __construct()
    {
        $this->initials();
        $this->dbConnect();
        $this->currency();
        $this->engine = new SMBEngine;
        $this->biz = $this->BizConfig();
        $this->gps_tracker = json_decode(htmlspecialchars_decode($this->biz['gps_tracker']), true);
    }

    public function currency()
    {
        $query = "SELECT * FROM " . $this->dbScheme . "." . $this->dbTblSuffix . $this->app_currency;
        @ $query .= " WHERE currency_code = '" . $this->currency = $this->BizConfig()['currency'] . "'";
        $getCurrency = $this->getResultSetArray($query);
        if ($getCurrency['response'] !== '200') {
            $responseArray = App_Response::getResponse('000');
        } else {
            $this->currency = $getCurrency['dataArray'][0];
        }
        return @$responseArray;
    }

    public function BizConfig()
    {
        $query = "SELECT * FROM " . $this->dbScheme . "." . $this->dbTblSuffix . $this->app_config;
        $res = $this->getResultSetArray($query);
        if ($res['response'] !== '200') {
            $responseArray = App_Response::getResponse('000');
        } else {
            $responseArray = $res['dataArray'][0];
        }
        return $responseArray;
    }

    public function AppLogging($logParam = NULL, $debug = FALSE)
    {
        $app_log_tbl = "app_log";
        $getAuth = new Auth_Access;
        $auth = $getAuth->AppAuthChecker();
        $server_exp = explode('->', $auth['logon_workstation']);
        $logParam += array(
            "user_id" => $auth['user_id'],
            "event_by" => $auth['firstname'] . ' ' . $auth['lastname'],
            "user_ip" => $server_exp[1],
            "user_host" => $server_exp[0]

        );
        $fields = "";
        $values = "";
        foreach ($logParam as $field => $val):
            if ($field != "tbl_scheme" && $field !== "pk"):
                $fields .= $field . ', ';
                $values .= "'" . $this->engine->verify_input($val) . "'" . ',';
            endif;
        endforeach;
        $fields = rtrim($fields, ', ');
        $values = rtrim($values, ', ');

        $query = "INSERT INTO " . $this->dbScheme . "." . $app_log_tbl;
        $query .= " (" . $fields . ") VALUES (" . $values . ");";
        $res = $this->insertIntoDatabase($query);
        if ($debug === TRUE) {
            if ($res['response'] !== '200') {
                $responseArray = App_Response::getResponse('000');
                $responseArray['message'] = "Could'nt process request";
            } else {
                $res['message'] = "Request processed successfully";
                $responseArray = $res;
            }
            return $responseArray;
        }
    }

    public function setval($val)
    {
        $this->gps_tracker = $val;
    }
}