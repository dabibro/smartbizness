<?php
/**
 * Created by PhpStorm.
 * User: Dauda Ibrahim
 * Date: 6/22/2020
 * Time: 11:40 AM
 */

//require SmartBizEngine::bizConfig();

class App_Users extends Data_Access
{
    protected $app_users = "app_users";

    public function __construct()
    {
        $initial = $this->initials();
        $dbConn = $this->dbConnect();
    }

    public function getUserGroup($varParam)
    {

    }

    public function getUserRecord($varParam = NULL)
    {
        if (!isset($varParam) || $varParam == NULL) {
            $responseArray = App_Response::getResponse('000');
            $responseArray['message'] = "Missing query parameters";
        } else {
            $condition = "";
            if ($varParam != NULL) {
                if (isset($varParam)) {
                    foreach ($varParam as $field => $val):
                        $condition .= '(' . $field . "= '" . $val . "')" . ' AND ';
                    endforeach;
                    $condition = rtrim($condition, "AND ");
                }
            }
            $query = "SELECT * FROM " . $this->dbScheme . "." . $this->dbTblSuffix . $this->app_users;
            $query .= " WHERE 1 AND " . $condition . ";";
            $res = $this->getResultSetArray($query);
            if ($res['response'] !== '200') {
                $responseArray = App_Response::getResponse('000');
            } else {
                $responseArray = $res;
            }
        }

        return $responseArray;
    }

    public function updateUserRecord($varParam = NULL)
    {
        $fields = "";
        $pk_fields = "";
        $passport = "";
        $user_id = "";
        if ($varParam != NULL) {
            foreach ($varParam['fields'] as $field => $val):
                if (@$field != 'passport'):
                    $fields .= $field . " = " . $val . ", ";
                endif;
                if ($field == 'passport' && $val != ""):
                    $passport = $val;
                endif;
                if ($field == 'user_id'):
                    $user_id = $val;
                endif;
            endforeach;
            $fields = rtrim($fields, ", ");
            foreach ($varParam['pk'] as $pk_field => $pk_val):
                $pk_fields .= $pk_field . " = '" . $pk_val . "' AND ";
            endforeach;
            $pk_fields = rtrim($pk_fields, " AND ");
        }
        $query = "UPDATE " . $this->dbScheme . "." . $this->app_users;
        $query .= " SET " . $fields . "  WHERE  " . $pk_fields . ";";

        $res = $this->updateDatabaseTable($query);
        if ($res['response'] !== '200') {
            $responseArray = App_Response::getResponse('000');
        } else {
            if ($passport !== ""):
                $croped_image = $passport;
                $getImageName = time();// explode('@', $_POST['email']);
                $image_name = $getImageName . '.png';
                $file_path = '../../../../contents/passports/';
                $upload = file_put_contents($file_path . $image_name, $croped_image);
                if ($upload):
                    $updatePassport = "UPDATE " . $this->dbScheme . "." . $this->app_users . " SET passport = '$image_name' WHERE user_id = '" . $user_id . "'";
                    $this->updateDatabaseTable($updatePassport);
                endif;
            endif;
            $responseArray = $res;
        }
        return $responseArray;
    }

}