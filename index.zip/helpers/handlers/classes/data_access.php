<?php

//----------------------------------------------------------------------------------------------------------------------
abstract class Data_Access extends AppConfig
{
    public function __construct()
    {
        $this->initials();
    } //--------------------------------------------------------------------------------------------------------------------

    static function execSQL($varQuery)
    {
        // attempt the query
        $rsData = $GLOBALS['dbConnection']->query($varQuery);
        if (isset($GLOBALS['dbConnection']->errno) && ($GLOBALS['dbConnection']->errno != 0)) {
            $responseArray = App_Response::getResponse('500');
            $responseArray['message'] = 'Internal server error. MySQL error: ' . $GLOBALS['dbConnection']->errno . ' ' . $GLOBALS['dbConnection']->error;
        } else {
            $responseArray = App_Response::getResponse('200');
            $responseArray['dataArray'] = $rsData;
        }
        return $responseArray;

    }

    //--------------------------------------------------------------------------------------------------------------------

    static function fetchAssoc($varQuery)
    {
        @$rowCount = $varQuery->num_rows;
        if ($rowCount != 0) {
            $results_array = array();
            $result = $varQuery;
            while ($row = $result->fetch_assoc()) {
                $results_array[] = $row;
            }
            $rsArray = $results_array;
            $responseArray = App_Response::getResponse('200');
            $responseArray['dataArray'] = $rsArray;
        } else {
            $responseArray = App_Response::getResponse('204');
            $responseArray['message'] = 'Query did not return any results.';
        }
        return $responseArray;

    }

    //--------------------------------------------------------------------------------------------------------------------

    protected function dbConnect()
    {
        if (!isset($GLOBALS['dbConnection'])) {
            $GLOBALS['dbConnection'] = new mysqli($this->dbHost, $this->dbUser, $this->dbPass, $this->dbScheme);
        }
        if ($GLOBALS['dbConnection']->connect_errno) {
            $responseArray = App_Response::getResponse('500');
            $responseArray['message'] = 'MySQL error: ' . $GLOBALS['dbConnection']->connect_errno . ' ' . $GLOBALS['dbConnection']->connect_error;
        } else {
            $responseArray = App_Response::getResponse('200');
            $responseArray['message'] = 'Database connection successful.';
        }
        return $responseArray;
    }

    //--------------------------------------------------------------------------------------------------------------------

    protected function insertIntoDatabase($varQuery)
    {
        $rsData = $GLOBALS['dbConnection']->query($varQuery);

        if (isset($GLOBALS['dbConnection']->errno) && ($GLOBALS['dbConnection']->errno != 0)) {
            // if an error occurred, raise it.
            $responseArray = App_Response::getResponse('500');
            $responseArray['message'] = 'Internal server error. MySQL error: ' . $GLOBALS['dbConnection']->errno . ' ' . $GLOBALS['dbConnection']->error;
        } else {
            // success

            $responseArray = App_Response::getResponse('200');
            $responseArray['message'] = 'Record Successfully inserted.';

        }

        return $responseArray;
    }

    //--------------------------------------------------------------------------------------------------------------------

    protected function updateDatabaseTable($varQuery)
    {
        $rsData = $GLOBALS['dbConnection']->query($varQuery);

        if (isset($GLOBALS['dbConnection']->errno) && ($GLOBALS['dbConnection']->errno != 0)) {
            // if an error occurred, raise it.
            $responseArray = App_Response::getResponse('500');
            $responseArray['message'] = 'Internal server error. MySQL error: ' . $GLOBALS['dbConnection']->errno . ' ' . $GLOBALS['dbConnection']->error;
        } else {
            // success
            $responseArray = App_Response::getResponse('200');
            $responseArray['message'] = 'Record Successfully updated.';

        }

        return $responseArray;
    }

    //--------------------------------------------------------------------------------------------------------------------

    protected function deleteTableRecord($varQuery)
    {
        $rsData = $GLOBALS['dbConnection']->query($varQuery);

        if (isset($GLOBALS['dbConnection']->errno) && ($GLOBALS['dbConnection']->errno != 0)) {
            // if an error occurred, raise it.
            $responseArray = App_Response::getResponse('500');
            $responseArray['message'] = 'Internal server error. MySQL error: ' . $GLOBALS['dbConnection']->errno . ' ' . $GLOBALS['dbConnection']->error;
        } else {
            // success
            $responseArray = App_Response::getResponse('200');
            $responseArray['message'] = 'Record Successfully updated.';

        }

        return $responseArray;
    }

    protected function getResultSetArray($varQuery)
    {

        // attempt the query
        @$rsData = $GLOBALS['dbConnection']->query($varQuery);

        if (isset($GLOBALS['dbConnection']->errno) && ($GLOBALS['dbConnection']->errno != 0)) {
            // if an error occurred, raise it.
            $responseArray = App_Response::getResponse('500');
            $responseArray['message'] = 'Internal server error. MySQL error: ' . $GLOBALS['dbConnection']->errno . ' ' . $GLOBALS['dbConnection']->error;
        } else {
            // success
            @$rowCount = $rsData->num_rows;

            if ($rowCount != 0) {
                $results_array = array();
                $result = $rsData;
                while ($row = $result->fetch_assoc()) {
                    $results_array[] = $row;
                }
                // move result set to an associative array
                $rsArray = $results_array; //$rsData->fetch_assoc();
                // add array to return
                $responseArray = App_Response::getResponse('200');
                $responseArray['dataArray'] = $rsArray;

            } else {
                // no data returned
                $responseArray = App_Response::getResponse('204');
                $responseArray['message'] = 'Query did not return any results.';
            }

        }

        return $responseArray;

    }
}