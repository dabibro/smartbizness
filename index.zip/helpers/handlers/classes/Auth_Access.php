<?php
/**
 * Created by PhpStorm.
 * User: Dauda Ibrahim
 * Date: 6/22/2020
 * Time: 9:49 AM
 */

class Auth_Access extends App_Users {
	public function AppAuth( $varParam = null ) {

		if ( ! isset( $varParam ) || $varParam === null ) {
			$responseArray = App_Response::getResponse( '403' );
		} else {
			$authId            = $varParam['AuthId'];
			$authPassword      = $varParam['AuthPassword'];
			$logon_workstation = json_encode( Detect::systemInfo() );
			if ( ! isset( $authId ) || $authId === "" ):
				$responseArray            = App_Response::getResponse( '403' );
				$responseArray['message'] = "Missing valid username/email!";
			elseif ( ! isset( $authPassword ) || $authPassword === "" ):
				$responseArray            = App_Response::getResponse( '403' );
				$responseArray['message'] = "Missing valid Password!";
			elseif ( isset( $varParam['gps_tracker'] ) && $varParam['gps_tracker'] === '1' && ! isset( $_SESSION['SMBTracker'] ) ):
				$responseArray            = App_Response::getResponse( '403' );
				$responseArray['message'] = "Enable GPS/Location to access App!";
			else:
				$getUserByUsername = array( "username" => $authId, "activation" => 1 );
				$getUserByEmail    = array( "contact_email" => $authId, "activation" => 1 );

				$userByUsername = $this->getUserRecord( $getUserByUsername );

				$userByEmail = $this->getUserRecord( $getUserByEmail );

				if ( $userByUsername['response'] !== '200' && $userByEmail['response'] !== '200' ):
					$responseArray            = App_Response::getResponse( '403' );
					$responseArray['message'] = "Invalid access credential!";
				else:
					if ( $userByUsername['response'] === '200' ):
						$userArray = array(
							"user_id"        => $userByUsername['dataArray'][0]['user_id'],
							"password"       => $userByUsername['dataArray'][0]['password'],
							"login_attempts" => $userByUsername['dataArray'][0]['login_attempts'],
							"login_status"   => $userByUsername['dataArray'][0]['login_status']
						);
					else:
						$userArray = array(
							"user_id"        => $userByEmail['dataArray'][0]['user_id'],
							"password"       => $userByEmail['dataArray'][0]['password'],
							"login_attempts" => $userByEmail['dataArray'][0]['login_attempts'],
							"login_status"   => $userByEmail['dataArray'][0]['login_status']
						);
					endif;

					if ( ! password_verify( $authPassword, trim( $userArray['password'] ) ) ):
						$updateFields = array(
							"login_attempts"    => "login_attempts + 1",
							"login_status"      => 0,
							"logon_workstation" => "'" . $logon_workstation . "'"
						);
						$updatePk     = array( "user_id" => $userArray['user_id'] );
						$updateArray  = array( "fields" => $updateFields, "pk" => $updatePk );
						$this->updateUserRecord( $updateArray );
						$responseArray              = App_Response::getResponse( '403' );
						$responseArray['message']   = "Invalid access credential!";
						$responseArray['dataArray'] = array( "login_attempts" => $userArray['login_attempts'] );
					else:
						$responseArray              = App_Response::getResponse( '200' );
						$responseArray['message']   = "Authentication OK!";
						$responseArray['dataArray'] = array(
							"login_status" => $userArray['login_status'],
							"user_id"      => $userArray['user_id']
						);
						$updateFields               = array(
							"login_attempts"    => 0,
							"login_status"      => 1,
							"last_seen"         => "CURRENT_TIMESTAMP",
							"logon_workstation" => "'" . $logon_workstation . "'",
						);
						$updatePk                   = array( "user_id" => $userArray['user_id'] );
						$updateArray                = array( "fields" => $updateFields, "pk" => $updatePk );
						$this->updateUserRecord( $updateArray );
					endif;


				endif;
			endif;

		}

		return $responseArray;

	}

	public function AuthUser( $varParam ) {
		if ( isset( $_SESSION[ $varParam ] ) && $_SESSION[ $varParam ] !== '' ):
			$engine       = new SMBEngine;
			$user_id      = $engine->base64_url_encryption( $_SESSION[ $varParam ], 'decode' );
			$getUserParam = array(
				"user_id"      => $user_id,
				"activation"   => 1,
				"login_status" => 1
			);
			$userArray    = $this->getUserRecord( $getUserParam );

			return $userArray;
		endif;
	}

	public function AppExit( $varParam = null, $userId = null ) {
		$engine = new SMBEngine;
		$biz    = new BIZConfig;
		if ( isset( $_SESSION[ $varParam ] ) && $_SESSION[ $varParam ] !== '' ):
			$signOut = $engine->base64_url_encryption( $_SESSION[ $varParam ], 'decode' );
		else:
			if ( isset( $userId ) && $userId !== "" ):
				$signOut = $engine->base64_url_encryption( $userId, 'decode' );
			endif;
		endif;
		if ( @$signOut !== "" ):
			$fieldUpdate   = array(
				"login_status" => 0,
				"last_login"   => "CURRENT_TIMESTAMP"
			);
			$updateUserPk  = array( "user_id" => @$signOut );
			$updateRequest = array(
				"fields" => $fieldUpdate,
				"pk"     => $updateUserPk
			);
			$responseArray = $this->updateUserRecord( $updateRequest );

		endif;
		$app_sessions = [
			$biz->biz['app_session'],
			"SMBTracker",
			$biz->biz['app_cart']
		];
		foreach ( $app_sessions as $session ):
			if ( isset( $_SESSION[ $session ] ) && $_SESSION[ $session ] !== '' ):
				unset( $_SESSION[ $session ] );
			endif;
		endforeach;

		return 'exitApp';
	}

	public function AppAuthChecker() {
		$engine       = new SMBEngine;
		$getBizConfig = new BIZConfig();
		$bizConfig    = $getBizConfig->BizConfig();
		$validAuth    = "";
		if ( ! isset( $_SESSION[ $bizConfig['app_session'] ] ) || $_SESSION[ $bizConfig['app_session'] ] === '' ):
			$validAuth = 0;
		else:
			$userId       = $engine->base64_url_encryption( $_SESSION[ $bizConfig['app_session'] ], 'decode' );
			$getUserParam = array(
				"user_id"      => $userId,
				"activation"   => 1,
				"login_status" => 1
			);
			$userArray    = $this->getUserRecord( $getUserParam );
			if ( $userArray['response'] !== "200" ):
				$validAuth = 0;
			endif;
		endif;
		if ( $validAuth === 0 ):
			//     echo 'exitApp';
			//echo '<script> location.replace("' . $this->webRoot . '")</script>';
		else:
			return $userArray['dataArray'][0];
		endif;
	}

	public function UpdateLastSeen( $userId ) {
		Data_Access::execSQL( "UPDATE app_users SET last_seen = CURRENT_TIMESTAMP, login_status = 0 WHERE ADDTIME(last_seen, '2:00:00') < CURRENT_TIMESTAMP " );
		Data_Access::execSQL( "UPDATE app_users SET last_seen = CURRENT_TIMESTAMP WHERE user_id = '$userId' " );

	}
}