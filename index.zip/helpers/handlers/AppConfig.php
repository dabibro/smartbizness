<?php

class AppConfig
{
    public $docRoot = "";
    public $webRoot = "";
    public $srvRoot = "";
    public $srv = "";
    public $srv_protocol = "";
    public $srv_addr = "";
    //---------------------------------------------------------------------
    public $dbHost = "";
    public $dbUser = "";
    public $dbPass = "";
    public $dbScheme = "";
    public $dbTblSuffix = "";
    //---------------------------------------------------------------------
    public $assets = "";
    public $vendors = "";
    public $plugins = "";
    public $uploads = "";
    public $inventory_images = "";
    //---------------------------------------------------------------------
    public $dashboard = "";
    public $modules = "";
    public $pos = "";
    //---------------------------------------------------------------------
    public $navbar = "";
    public $sidebar = "";
    public $asidepanel = "";
    public $footer = "";


    //---------------------------------------------------------------------
    public function __construct()
    {
        $this->initials();
        $this->resources();
        $this->layouts();
    }

    public function initials()
    {
        //---------------------------------------------------------------
        @session_start();
        date_default_timezone_set('Africa/Lagos');
        ini_set('display_errors', 'On');
        error_reporting(E_ALL);
        ini_set('max_execution_time', 1800);
        //---------------------------------------------------------------
        $getHost = explode('/', $_SERVER['SERVER_PROTOCOL']);
        $this->srv_protocol = strtolower($getHost[0]) . "://";
        $this->srv = $_SERVER['SERVER_NAME'];
        $this->srv_addr = $_SERVER['REMOTE_ADDR'];
        $thisFile = str_replace('\\', '/', __FILE__);
        $docRoot = $this->docRoot = $docRoot = $_SERVER['DOCUMENT_ROOT'];
        $this->webRoot = str_replace(array($docRoot, 'helpers/handlers/AppConfig.php'), '', $thisFile);
        $this->srvRoot = str_replace('helpers/handlers/AppConfig.php', '', $thisFile);
        //---------------------------------------------------------------
        $this->dbHost = CONST_DB_HOST;
        $this->dbUser = CONST_DB_USERNAME;
        $this->dbPass = CONST_DB_PASSWORD;
        $this->dbScheme = CONST_DB_SCHEMA;
        $this->dbTblSuffix = CONST_TBL_SUFFIX;
        //---------------------------------------------------------------

    }


    public function resources()
    {
        $this->assets = $this->webRoot . 'assets/';
        $this->vendors = $this->webRoot . 'vendors/';
        $this->plugins = $this->webRoot . 'plugins/';
        $this->modules = $this->webRoot . 'modules/';
        $this->dashboard = $this->webRoot . 'dashboard/';
        $this->uploads = $this->dashboard . 'uploads/';
        $this->inventory_images = $this->uploads . 'inventory/';
    }

    public function layouts()
    {
        //----------------------------------------------
        $this->navbar = "layouts/navbar.php";
        $this->sidebar = "layouts/sidebar.php";
        $this->footer = "layouts/footer.php";
        $this->asidepanel = "layouts/aside-panel.php";
    }

}
