<?php
if ( ( ! defined( 'APP_CONST_KEY' ) ) || ( APP_CONST_KEY === '' ) || ( ! defined( 'APP_SECRET_KEY' ) || ( APP_SECRET_KEY === '' ) ) ) {
	header( "Location: ../404.html", true, 404 );
	echo file_get_contents( '../404.html' );
	die;
}
//----------------------------------------------------------------------------------------------------------------------
$mapping = [
	'AppConfig'       => 'AppConfig.php',
	'SMBAPI'          => 'SMBAPI.php',
	'SMBEngine'       => 'SMBEngine.php',
	'Detect'          => 'Detect.php',
	'MobileDetect'    => 'MobileDetect.php',
	//--------------------------------------------
	'API_Handler'     => 'api_handler.php',
	'App_Response'    => 'app_response.php',
	//--------------------------------------------
	'Data_Access'     => 'classes/data_access.php',
	//--------------------------------------------
	'Paginator_Class' => 'classes/Paginator_Class.php',
	//--------------------------------------------
	'App_Users'       => 'classes/app_users.php',
	//--------------------------------------------
	'Auth_Access'     => 'classes/Auth_Access.php',
	'BIZConfig'       => 'classes/BIZConfig.php',
	//--------------------------------------------
	'App_Switcher'    => 'App_Switcher.php',
	//--------------------------------------------
];
//----------------------------------------------------------------------------------------------------------------------
spl_autoload_register( function ( $class ) use ( $mapping ) {
	if ( isset( $mapping[ $class ] ) ) {
		require_once $mapping[ $class ];
	}
}, true );
