<?php
/**
 * Created by PhpStorm.
 * User: Dauda Ibrahim
 * Date: 6/22/2020
 * Time: 6:56 PM
 */

class App_Switcher extends AppConfig
{
    public $AppModule = "";
    public $AppModuleRequest = "";
    public $AppModuleView = "";
    public $AppModuleTitle = "";
    public $AppModuleBreadcrumb = "";
    public $AppModuleDataTable = "";
    public $biz;
    public $AppAuth;
    public $auth;
    protected $url_constant = "/#/";

    public function __construct()
    {
        $biz = new BIZConfig;
        $this->biz = $biz->biz;
        $this->AppAuth = new Auth_Access;
        if (@$this->AppAuth->AuthUser($this->biz['app_session'])['response'] === "200"):
            $this->auth = $this->AppAuth->AppAuthChecker();
        endif;
    }

    public function moduleSwitcher($varRequest = null)
    {


        $getRequest = explode($this->url_constant, urldecode($varRequest));
        @$request = $getRequest[1];
        //-------------------------------------------------------------
        $customers = explode('customers/', $request);
        if (isset($customers[1]) && $customers[1] !== ""):
            $request = "customers/";
            $this->AppModuleView = $customers[1];
        endif;
        //-------------------------------------------------------------
        $vendors = explode('vendors/', $request);
        if (isset($vendors[1]) && $vendors[1] !== ""):
            $request = "vendors/";
            $this->AppModuleView = $vendors[1];
        endif;
        //-------------------------------------------------------------
        $inventory = explode('inventory/', $request);
        if (isset($inventory[1]) && $inventory[1] !== ""):
            $request = "inventory/";
            $this->AppModuleView = $inventory[1];
        endif;
        //-------------------------------------------------------------
        $purchase_order = explode('purchase-order/', $request);
        if (isset($purchase_order[1]) && $purchase_order[1] !== ""):
            $request = "purchase-order/";
            $this->AppModuleView = $purchase_order[1];
        endif;
        //-------------------------------------------------------------
        $pos = explode('sales-point/', $request);
        if (isset($pos[1]) && $pos[1] !== ""):
            $request = "sales-point/";
            $this->AppModuleView = $pos[1];
        endif;
        //-------------------------------------------------------------
        $messaging = explode('app-messaging/', $request);
        if (isset($messaging[1]) && $messaging[1] !== ""):
            $request = "app-messaging/";
            $this->AppModuleView = $messaging[1];
        endif;
        //-------------------------------------------------------------

        switch ($request):
            //-------------------------------------------------------------
            case "sign-out/":
                $tracking = json_decode(htmlspecialchars_decode($this->biz['gps_tracker']), true);
                if ($tracking['SMBTracker'] === 1):
                    echo '<script>console.log(exitApp()); </script>';
                else:
                    @$signOut = $this->AppAuth->AppExit($this->biz['app_session'], '');
                    echo '<script>console.log(exitApp());</script>';
                    if (@$signOut['response'] == '200'):
                    endif;
                endif;
                break;
            //-------------------------------------------------------------
            case "users-account/" :
                $this->AppModule = "../modules/manage-users/manage_users.php";
                $this->AppModuleRequest = $request;
                $this->AppModuleTitle = "Manage Users";
                $this->AppModuleBreadcrumb = array("Manage Users" => "", "Users Account" => "");
                $this->AppModuleDataTable = 1;
                break;
            //-------------------------------------------------------------
            case "users-group/" :
                $this->AppModule = "../modules/manage-users/manage_users.php";
                $this->AppModuleRequest = $request;
                $this->AppModuleTitle = "Manage Users";
                $this->AppModuleBreadcrumb = array("Manage Users" => "", "Users Group" => "");
                $this->AppModuleDataTable = 1;
                break;
            //-------------------------------------------------------------
            case "create-user/" :
                $this->AppModule = "../modules/manage-users/manage_users.php";
                $this->AppModuleRequest = $request;
                $this->AppModuleTitle = "Manage Users";
                $this->AppModuleBreadcrumb = array("Manage Users" => "", "Create User" => "");
                $this->AppModuleDataTable = 0;
                break;
            //-------------------------------------------------------------
            case "customers/" :
                $this->AppModule = "../modules/manage-customers/manage_customers.php";
                $this->AppModuleRequest = $request;
                $this->AppModuleTitle = "Manage Customers";
                $this->AppModuleBreadcrumb = array("Manage Customers" => "");
                if ($this->AppModuleView != 'record/'):
                    $this->AppModuleDataTable = 1;
                else:
                    $this->AppModuleDataTable = 0;
                endif;
                break;

            //-------------------------------------------------------------
            case "vendors/" :
                $this->AppModule = "../modules/manage-vendors/manage_vendors.php";
                $this->AppModuleRequest = $request;
                $this->AppModuleTitle = "Manage Vendors";
                $this->AppModuleBreadcrumb = array("Manage Vendors" => "", "Vendors List" => "");
                $this->AppModuleDataTable = 1;
                break;
            //-------------------------------------------------------------
            case "create-vendor/" :
                $this->AppModule = "../modules/manage-vendors/manage_vendors.php";
                $this->AppModuleRequest = $request;
                $this->AppModuleTitle = "Manage Vendors";
                $this->AppModuleBreadcrumb = array("Manage Vendors" => "", "Create/Update Vendor" => "");
                $this->AppModuleDataTable = 0;
                break;
            //-------------------------------------------------------------
            case "vendors-payment/" :
                $this->AppModule = "../modules/manage-vendors/manage_vendors.php";
                $this->AppModuleRequest = $request;
                $this->AppModuleTitle = "Manage Users";
                $this->AppModuleBreadcrumb = array("Manage Vendors" => "", "Vendors Payment" => "");
                $this->AppModuleDataTable = 1;
                break;
            //-------------------------------------------------------------
            case "stores/" :
                $this->AppModule = "../modules/manage-stores/manage_stores.php";
                $this->AppModuleRequest = $request;
                $this->AppModuleTitle = "Manage Stores";
                $this->AppModuleBreadcrumb = array("Manage Store" => "", "Stores" => "");
                $this->AppModuleDataTable = 1;
                break;
            //-------------------------------------------------------------
            case "create-store/" :
                $this->AppModule = "../modules/manage-stores/manage_stores.php";
                $this->AppModuleRequest = $request;
                $this->AppModuleTitle = "Manage Stores";
                $this->AppModuleBreadcrumb = array("Manage Store" => "", "Create/Update Store" => "");
                $this->AppModuleDataTable = 0;
                break;
            //-------------------------------------------------------------
            case "inventory/" :
                $this->AppModule = "../modules/manage-inventory/manage_inventory.php";
                $this->AppModuleRequest = $request;
                $this->AppModuleTitle = "Manage Inventory";
                if ($this->AppModuleView != 'transfer/'):
                    $this->AppModuleDataTable = 1;
                else:
                    $this->AppModuleDataTable = 0;
                endif;
                $this->AppModuleBreadcrumb = array(
                    "Manage Inventory" => "",
                    "Inventory" => "#/inventory",
                    "Category" => ""
                );
                $this->AppModuleDataTable = 1;
                break;
            //-------------------------------------------------------------
            case "purchase-order/" :
                $this->AppModule = "../modules/manage-orders/manage_orders.php";
                $this->AppModuleRequest = $request;
                $this->AppModuleTitle = "Purchase Orders";
                $this->AppModuleBreadcrumb = array("Purchase Order" => "", "Create/Update Store" => "");
                $this->AppModuleDataTable = 1;
                break;
            //-------------------------------------------------------------
            case "sales-point/" :
                $this->AppModule = "../modules/manage-sales/manage_sales.php";
                $this->AppModuleRequest = $request;
                $this->AppModuleTitle = "Manage Sales";
                $this->AppModuleBreadcrumb = array("Manage Sales" => "");
                if ($this->AppModuleView != 'pos/'):
                    $this->AppModuleDataTable = 1;
                else:
                    $this->AppModuleDataTable = 0;
                endif;
                break;
            //-------------------------------------------------------------
            case "department-unit/" :
                $this->AppModule = "../modules/manage-app/manage-app.php";
                $this->AppModuleRequest = $request;
                $this->AppModuleTitle = "Management";
                $this->AppModuleBreadcrumb = array("Management" => "", "Department/Unit" => "");
                $this->AppModuleDataTable = 1;
                break;

            case "discount-vat/" :
                $this->AppModule = "../modules/manage-app/manage-app.php";
                $this->AppModuleRequest = $request;
                $this->AppModuleTitle = "Management";
                $this->AppModuleBreadcrumb = array("Management" => "", "Discount/VAT" => "");
                $this->AppModuleDataTable = 1;
                break;

            case "measure-unit/" :
                $this->AppModule = "../modules/manage-app/manage-app.php";
                $this->AppModuleRequest = $request;
                $this->AppModuleTitle = "Management";
                $this->AppModuleBreadcrumb = array("Management" => "", "Measure Unit" => "");
                $this->AppModuleDataTable = 1;
                break;

            case "storage-location/" :
                $this->AppModule = "../modules/manage-app/manage-app.php";
                $this->AppModuleRequest = $request;
                $this->AppModuleTitle = "Management";
                $this->AppModuleBreadcrumb = array("Management" => "", "Storage/Location" => "");
                $this->AppModuleDataTable = 1;
                break;
            case "payment-settings/" :
                $this->AppModule = "../modules/manage-app/manage-app.php";
                $this->AppModuleRequest = $request;
                $this->AppModuleTitle = "Management";
                $this->AppModuleBreadcrumb = array("Management" => "", "Payment Settings" => "");
                $this->AppModuleDataTable = 1;
                break;
            case "SMBTracker/" :
                $this->AppModule = "../modules/app-tracker/manage-tracker.php";
                $this->AppModuleRequest = $request;
                $this->AppModuleTitle = "Location Tracker";
                $this->AppModuleBreadcrumb = array("Location Tracker" => "");
                $this->AppModuleDataTable = 0;
                break;
            case "app-messaging/" :
                $this->AppModule = "../modules/app-messaging/manage_messaging.php";
                $this->AppModuleRequest = $request;
                $this->AppModuleTitle = "Message Centre";
                $this->AppModuleBreadcrumb = array("Message Centre" => "");
                break;
            case "import-data/" :
                $this->AppModule = "../modules/app-controls/manage_settings.php";
                $this->AppModuleRequest = $request;
                $this->AppModuleTitle = "App Control Panel";
                $this->AppModuleBreadcrumb = array("App Control Panel" => "", "Import/Export Data (CSV)" => "");
                $this->AppModuleDataTable = 1;
                break;

            default:
                $this->AppModule = "../modules/dashboard.php";
                $this->AppModuleRequest = $request;
                $this->AppModuleTitle = "Home";
                $this->AppModuleBreadcrumb = array();
                break;
        endswitch;

        return $switchArray = array(
            "AppRequest" => 1,
            "url" => urldecode($varRequest),
            "AppModule" => @$this->AppModule,
            "AppModuleTitle" => @$this->AppModuleTitle,
            "AppModuleRequest" => @$this->AppModuleRequest,
            "AppModuleView" => @$this->AppModuleView,
            "AppModuleBreadcrumb" => @$this->AppModuleBreadcrumb,
            "AppModuleDataTable" => @$this->AppModuleDataTable,
        );
    }

    public function modulePath($varPath = null)
    {
        if (isset($varPath) && $varPath !== null) {
            $module_path = explode('/', $varPath);
            $path = $this->dashboard . $module_path[1] . "/" . $module_path[2] . '/';

            return $path;
        }
    }

}