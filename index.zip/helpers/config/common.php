<?php
/**
 * Created by DTMGS Limited.
 * User: Dauda Ibrahim
 * Date: 6/22/2020
 * Time: 4:27 PM
 * File: Common app request
 */

$switcher = $AppSwitcher->moduleSwitcher($_POST['AppRequest']);
$BizConfig = $Biz->BizConfig();
extract($BizConfig);
@$checkAuth = @$Auth->AuthUser($app_session);
if (@$checkAuth['response'] === '200'):
    @$logged = 1;
    @$AppUser = @$checkAuth['dataArray'][0];
endif;