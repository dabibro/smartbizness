<?php
/**
 * Created by DTMGS Limited.
 * User: Dauda Ibrahim
 * Date: 6/21/2020
 * Time: 10:24 PM
 * File: App Client Configuration
 */

define("APP_CONST_KEY", "1234567890");
define("APP_SECRET_KEY", "1234567890");
define("CONST_DB_HOST", "localhost");
define("CONST_DB_USERNAME", "root");
define("CONST_DB_PASSWORD", "");
define("CONST_DB_SCHEMA", "reps_manager");
define("CONST_TBL_SUFFIX", "");