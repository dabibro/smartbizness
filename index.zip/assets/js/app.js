/**
 * Created by DTMGS Limited.
 * User: Dauda Ibrahim
 * Date: 6/21/2020
 * Time: 10:24 PM
 * File: App Java Scripting
 */
//---------------------------------------------------------------------------
var modulePath = $("#ModulePath").val();
var AppPath = document.getElementById("start-page");
if (AppPath) {
    var AppRequestPath = "helpers/ajax-url-redirect.php"
} else {
    var AppRequestPath = "handlers/AppAjaxRequest.php"
    $("#app-loader").html($('#AppLoader').html());
}
//---------------------------------------------------------------------------

$(document).ready(function () {
    $(".app-menu .app-link ").on('click', function () {
        fetchURL(this.href);
    });
    fetchURL('');
    $('.num').keyup(function () {
        this.value = this.value.replace(/[^0-9\.]/g, '');
    });
});

//---------------------------------------------------------------------------

function fetchURL(requestURL) {
    "use strict";
    if (requestURL === "") {
        requestURL = window.location.href;
    }
    $("#app-loader").html($('#AppLoader').html());
    $.post(AppRequestPath,
        {
            AppRequest: encodeURIComponent(requestURL),
        }, function (response) {
            $("#app-loader").html(response);
        });
}

//---------------------------------------------------------------------------

function dropDownList(requestParam) {
    var dropDownRequest = JSON.parse(requestParam);
    $.post(modulePath + 'ajaxRequest.php', {
        dropDownRequest,
    }, function (response) {
        $("#" + dropDownRequest['target']).html(response);
    });
}

//---------------------------------------------------------------------------

function recordFormLookup(requestParam) {
    var formLookupRequest = decodeURIComponent(requestParam);
    formLookupRequest = JSON.parse(requestParam);
    if (formLookupRequest['request'] === "search") {
    }
    $.post(modulePath + 'ajaxRequest.php', {
        formLookupRequest
    }, function (response) {
        $("." + formLookupRequest['target']).html(response);
        $("." + formLookupRequest['target'] + " .search-result button:first-child").focus();
    });
}

//---------------------------------------------------------------------------

function AppModalLoader(param) {
    var modalRequest = "";
    $("#" + param.modalId).modal({backdrop: 'static'});
    $("#" + param.modalId + ' .load-content').html($("#AppLoader").html());
    $("#" + param.modalId + ' .modal-title').html(param.modalTitle);
    $("#" + param.modalId + ' #modal-close').attr('onclick', param.afterEvent);
    if (param.modalSize && param.modalSize != "") {
        $("#" + param.modalId + ' .modal-dialog').addClass(param.modalSize);
    }
    if (param.modalRequest && param.modalRequest != "") {
        var modalRequest = param.modalRequest;
    }
    var obj = {
        "required": param.required,
        "modalRequestParam": modalRequest,
        "path": modulePath,
        "afterEvent": param.afterEvent,
        "DataTable": param.DataTable,
    }
    $.post(modulePath + 'ajaxRequest.php', {
        AppModalLoader: obj,
    }, function (response) {
        //alert(response);
        $("#" + param.modalId + ' .load-content').html(response);
    });
    $("#" + param.modalId).on('hidden.bs.modal', function (e) {
        $("#" + param.modalId + ' .modal-title').html('');
        $("#" + param.modalId + ' #modal-close').removeAttr('onclick');
        $("#" + param.modalId + ' .load-content').html('');
    })
}

//---------------------------------------------------------------------------

function AppIDAutoGen(requestParam) {
    requestParam = (JSON.parse(requestParam));
    $.post(modulePath + 'ajaxRequest.php', {
        AppIDAutoGen: requestParam,
    }, function (response) {
        $("#" + requestParam['target']).val(response);
    });
}

//---------------------------------------------------------------------------


//---------------------------------------------------------------------------

function printContent(DivID, type, size) {
    var disp_setting = "toolbar=yes,location=no,";
    disp_setting += "directories=yes,menubar=yes,";
    disp_setting += "scrollbars=yes,width=650, height=600, left=100, top=25";
    var content_vlue = document.getElementById(DivID).innerHTML;
    var docprint = window.open("", "", disp_setting);
    docprint.document.open();
    docprint.document.write('<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"');
    docprint.document.write('"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">');
    docprint.document.write('<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">');
    docprint.document.write('<head><title>Printing</title>');
    if (type == 'Thermal') {
        if (size == "50mm") {
            docprint.document.write('<link rel="stylesheet" href="' + modulePath + 'pos/assets/css/receipt_50mm.css" media="print" type="text/css">');
        } else {
            docprint.document.write('<link rel="stylesheet" href="' + modulePath + 'pos/assets/css/receipt.css" media="print" type="text/css">');
        }
    }
    docprint.document.write('</head><body onLoad="self.print(); window.close();"><center>');
    docprint.document.write(content_vlue);
    docprint.document.write('</center></body></html>');
    docprint.document.close();
    docprint.focus();
}

//---------------------------------------------------------------------------
function printDiv(divName) {
    var printContents = document.getElementById(divName).innerHTML;
    var originalContents = document.body.innerHTML;
    document.body.innerHTML = printContents;
    window.print();
    document.body.innerHTML = originalContents;
    location.reload();
}

//---------------------------------------------------------------------------
function printDataTable(param) {
    var params;
    if (param['params']) {
        params = JSON.stringify(param['params']);
    }
    window.open("modules/" + param['dataTable'] + "?print-request&query=" + param['query'] + "&params=" + encodeURIComponent(params) + " ", "_blank", "toolbar=yes, location=yes, directories=no, status=no, menubar=yes, scrollbars=yes, resizable=no, copyhistory=yes, width=400, height=400",);
}

//---------------------------------------------------------------------------

function submitAppExit() {
    $.post(AppRequestPath,
        {
            AppExitRequest: 1
        }, function (response) {
            if (response === 'exitApp') {
                location.replace('../');
            }
        });
}

//---------------------------------------------------------------------------

function reloadApp() {
    location.reload();
}

//---------------------------------------------------------------------------
//setInterval(AnnouncementChecker, 2000);

function AnnouncementChecker() {
    $.post(AppRequestPath, {
        AnnouncementChecker: 1
    }, function (response) {
        if (response !== "" && response !== '0') {
            $("#announcement-flag").html('<span class="badge badge-danger navbar-badge">' + response + '</span>')
        } else {
            $("#announcement-flag").html('');
        }
    });
}