<link rel="stylesheet" href="<?php echo @$messengerPath . 'style.css'; ?>">
<div>
    <div class="messenger">
        <div class="card elevation-2 messenger-chat-box hide" id="messenger-conversations">
        </div>
        <div class="card elevation-2 messenger-content" style="display: none">
            <div class="card-header text-left px-2 pb-1 pt-2" style="overflow: auto">
                <div class="mb-0 float-left"><i class="fal fa-comments fa-lg"></i> SMBMessenger</div>
                <a class="float-right text-right text-muted closeMessenger" href="javascript:void(0)" title="Close"
                   data-toggle="tooltip"
                   data-placement="left"><i
                            class="fal fa-times-circle"></i></a>
            </div>
            <div class="card-body p-0 px-1 text-left bg-white" style="height:250px; overflow: auto;">
                <div class="form-group mb-0 mt-1">
                    <div class="input-group input-group-sm bg-light border-light">
                        <input type="text" class="form-control border-right-0 bg-transparent br-0 chat-user-lookup"
                               placeholder="Search..."
                               style="outline: 0px !important; box-shadow:none !important;">
                        <div class="input-group-append">
                    <span class="input-group-text bg-transparent border-left-0"><i
                                class="fal fa-search m-0"></i> </span>
                        </div>
                    </div>
                </div>
                <div id="online-users"></div>
            </div>
        </div>
        <div class="m-0"
             style="padding: 0.9rem; border-radius: 45px; width: 3.8rem; height: 3.8rem">
            <span style="position: absolute; top: 12px; right: 0.1rem; font-size: 12px" id="msg-flag"></span>
            <button type="button" class="text-muted border-0 bg-transparent pointer p-1 openMessenger"><i
                        class="fa fa-comments fa-2x" style="text-shadow: 2px 2px #000;"></i></button>
            <span style="position: absolute; bottom: 5px; left: 0.1rem; font-size: 0.6rem; box-shadow: 1px 1px #000"
                  class="badge badge-secondary p-1 font-weight-normal" id="online-users-count">0</span>
        </div>
    </div>
</div>

<div id="user-search" style="display: none">
    <div class="text-center mt-2 pt-5 small">
        <img src="<?php echo $messengerPath; ?>search.gif" width="32">
        <br>Please Wait. Searching...
    </div>
</div>
<div id="user-loader" style="display: none">
    <div class="text-center mt-2 pt-5 small">
        <i class="fal fa-users-class fa-2x"></i>
        <br>Please Wait. <br>
        <img src="<?php echo $messengerPath; ?>loader.gif" width="160">
        <br>Loading Online Users...
    </div>
</div>

