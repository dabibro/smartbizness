<?php
/**
 * Created by DTMGS Limited.
 * User: Dauda Ibrahim
 * Date: 6/23/2020
 * Time: 10:50 AM
 * FIle: App Ajax Request Processor
 */
if ( file_exists( "../../helpers/config/config.inc.php" ) ):
	require "../../helpers/config/config.inc.php";
endif;
require "../../helpers/handlers/app_autoloader.php";
//---------------------------------------------------------------------------
require "Plugin_Class.php";
@$app = new AppConfig;
@$plugin = new Plugin_Class;
//---------------------------------------------------------------------------
@$AppAuth = new Auth_Access();
@$AppUser = $AppAuth->AppAuthChecker();
@$userId = $AppUser['user_id'];
@$pluginPath = $app->plugins . 'messenger/';
//---------------------------------------------------------------------------
$requestMethod = $_SERVER['REQUEST_METHOD'];
if ( in_array( $requestMethod, [ "GET", "POST", "PUT", "DELETE", "OPTIONS" ] ) ):
	//---------------------------------------------------------------------------
	$requestMethodArray = array();
	$requestMethodArray = $_REQUEST;
	$AppAuth->UpdateLastSeen( $userId );
	//---------------------------------------------------------------------------
	if ( isset( $requestMethodArray['onlineUsersCount'] ) ):
		@$usersArray = $plugin->OnlineUsers();
		echo @count( @$usersArray );
	endif;
	//---------------------------------------------------------------------------
	if ( isset( $requestMethodArray['onlineUsers'] ) ):
		if ( isset( $requestMethodArray['search'] ) && $requestMethodArray['search'] != "" ):
			$condition = $requestMethodArray['search'];
			@$usersArray = $plugin->OnlineUsers( $condition );
		else:
			@$usersArray = $plugin->OnlineUsers();
		endif;
		require 'online-users.php';
	endif;
	//---------------------------------------------------------------------------
	if ( isset( $requestMethodArray['NewMessages'] ) ):
		@$msgs = @Data_Access::fetchAssoc( @Data_Access::execSQL( "SELECT m_id FROM app_messenger WHERE msg_status = 1 AND r_id = '" . @$userId . "' " )['dataArray'] )['dataArray'];
		if ( @$msgs != null ):
			echo '<i class="fal fa-envelope text-danger"></i>';
		endif;
	endif;
	//---------------------------------------------------------------------------
	if ( isset( $requestMethodArray['conversations'] ) ):
		$uId = $requestMethodArray['userId'];
		@$user = @$plugin->getRecord( [
			"tbl_scheme" => "app_users",
			"condition"  => [ "user_id" => $uId ]
		] )['dataArray'][0];
		@$chatQuery = $plugin->Conversations( [ "u1" => $uId, "u2" => $userId ] );
		@Data_Access::execSQL( "UPDATE app_messenger SET msg_status = 0 WHERE s_id = '$uId' AND r_id = '$userId' " );
		require 'conversations.php';
	endif;
	//---------------------------------------------------------------------------
	if ( isset( $requestMethodArray['submitConversation'] ) ):
		extract( @$requestMethodArray );
		@$submitChat = $plugin->createRecord( [
			"tbl_scheme" => "app_messenger",
			"s_id"       => $s_id,
			"r_id"       => $r_id,
			"message"    => $message,
		] );
		if ( @$submitChat['response'] === "200" ):
			echo '<script>openConversations(' . $r_id . ')</script>';
		endif;
	endif;
	//---------------------------------------------------------------------------
	if ( isset( $requestMethodArray['messageChecker'] ) ):
		@$sId = $requestMethodArray['userId'];
		@$sql = "SELECT * FROM app_messenger WHERE s_id = '$sId' and r_id = '$userId' AND msg_status = 1 ORDER BY entry_date ASC";
		@$query = Data_Access::execSQL( $sql );
		if ( @$query['dataArray'] !== null ):
			@$dataArray = Data_Access::fetchAssoc( $query['dataArray'] )['dataArray'];
			if ( $dataArray !== null ):
				foreach ( $dataArray as $chats ):
					if ( $chats['s_id'] == $userId ): $class = 'msg-rta';
					else: $class = 'msg'; endif;
					echo "<script>$('#msg-list').append('<li class=\" " . $class . " macro\" ><div class=\"txt text-left\"><p>" . $chats['message'] . "</p> <p class=\"small text-muted\">" . $chats['entry_date'] . "</p></div></li>');</script>";
				endforeach;
				@Data_Access::execSQL( "UPDATE app_messenger SET msg_status = 0 WHERE s_id = '$sId' AND r_id = '$userId' " );
			endif;
		endif;
	endif;
	//---------------------------------------------------------------------------
endif;
