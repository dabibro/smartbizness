<div class="card-header text-left px-2 pt-2 pb-1" style="overflow: auto">
    <div class=" mb-0 float-left"><i
                class="fal fa-user-circle fa-lg"></i> <?php echo @$user['firstname'] . ' ' . @$user['lastname']; ?>
    </div>
    <a class="float-right text-right text-muted closeMessengerConversation" href="javascript:void(0)" title="Close"
       data-toggle="tooltip"
       data-placement="left"><i
                class="fal fa-times-circle"></i></a>
</div>
<div class="card-body px-2 py-2" id="conversation-panel">
    <div style="height: 240px; overflow-y: auto; overflow-x: hidden; padding-right: 10px">
        <div id="chat-history">
			<?php if ( @$chatQuery == null ): ?>
                <div class="text-center my-5"><h3><i class="fal fa-comments-alt fa-3x m-0"></i></h3> Start
                    Conversation
                </div>
			<?php else: ?>
                <ul id="msg-list">
					<?php foreach ( @$chatQuery as $chats ):
						if ( @$chats['s_id'] == @$userId ): $class = 'msg-rta';
						else: $class = 'msg'; endif;
						$dateTime = new DateTime( $chats['entry_date'] );
						$date     = $dateTime->format( 'd/m/y h:i:s A' );
						?>
                        <li class="<?php echo @$class; ?>  macro">
                            <div class="txt text-left">
                                <p><?php echo @$chats['message']; ?></p>
                                <p class="small text-muted"><?php echo @$date; ?></p>
                            </div>
                        </li>
					<?php endforeach; ?>
                </ul>
                <div id="message-response"></div>
			<?php endif; ?>
            <input type="text" class="end bg-transparent border-0" readonly style="height: 1px">
        </div>
    </div>
    <hr class="my-2">
    <div style="position: relative; bottom: 0; width: 100%;">
        <form method="post" class="submit-messenger-conversation">
            <div class="form-group mb-0">
                <div class="input-group">
                    <input type="hidden" name="s_id" value="<?php echo $userId; ?>" id="s_id">
                    <input type="hidden" name="r_id" value="<?php echo $uId; ?>" id="r_id">
                    <input type="hidden" name="submitConversation" value="1">
                    <input type="text" autocomplete="off" name="message" id="" rows="2"
                           class="form-control br-0 messenger-chat"
                           style="font-size: 0.78rem !important; background: whitesmoke">
                    <div class="input-group-append">
                        <button class="btn btn-default chat-button" title="CRTL + &ldsh;" disabled><i
                                    class="fal fa-paper-plane m-0"></i></button>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>
<script src="<?php echo @$pluginPath . 'js.js'; ?>"></script>
<script>
    setInterval(messagesChecker, 1000);
</script>