<ul class="list-group list">
	<?php if ( @$usersArray == null ):
		?>
        <div class="text-center my-5 text-muted"><h3><i class="fal fa-comment-slash fa-2x"></i></h3>
            No user online!
        </div>
	<?php else: ?>
		<?php foreach ( @$usersArray as $online_users ):
			if ( @$online_users['user_id'] != @$userId ):

				@$msg = Data_Access::execSQL( "SELECT m_id FROM " . @$app->dbScheme . ".app_messenger WHERE msg_status = 1 AND r_id = '" . @$userId . "' AND s_id = '" . @$online_users['user_id'] . "' " )['dataArray']->num_rows;
				?>
                <button class="list-group-item py-1 px-1 border-left-0 border-right-0 border-top-0 br-0 text-left pointer"
                        style="font-size: 0.75rem"
                        onclick="openConversations('<?php echo @$online_users['user_id']; ?>');">
                    <div class="float-left">
                        <div class="text-primary"> <?php echo @$online_users['firstname'] . ' ' . @$online_users['lastname']; ?> </div>
                        <div class="text-muted small">Last Seen: <?php echo @$online_users['seen']; ?></div>
                    </div>
                    <div class="float-right">
						<?php if ( @$online_users['c_time'] < @$online_users['inactive'] ): ?>
                            <i class="fa fa-circle text-success"></i>
						<?php else: ?>
                            <i class="fa fa-circle text-muted"></i>
						<?php endif ?>
						<?php if ( @$msg !== 0 ): ?>
                            <i class="text-danger"><i class="fa fa-comment"></i></i>
						<?php endif; ?>
                    </div>
                </button>
			<?php endif;
		endforeach;
	endif; ?>
</ul>
