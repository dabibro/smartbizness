//-----------------------------------------------------------------------
$('.openMessenger').on('click', function () {
    $('.messenger-content').fadeIn();
    $('.messenger-content').removeClass('hide');
    loadOnlineUsers('loader');
});
//-----------------------------------------------------------------------
$('.closeMessenger').on('click', function () {
    $('.messenger-chat-box').fadeOut();
    $('.messenger-chat-box').addClass('hide');
    $('.messenger-content').addClass('hide');
    $('.messenger-content').fadeOut();
    $('#messenger-conversations').html('');
});
//-----------------------------------------------------------------------
$('.chat-user-lookup').on('keyup', function () {
    $('#online-users').html($("#user-search").html());
    $.post(messengerPath + 'ajaxRequest.php', {
        onlineUsers: 1,
        search: this.value
    }, function (response) {
        $('#online-users').html(response);
    });
});

//-----------------------------------------------------------------------
function loadOnlineUsers(loader) {
    "use strict";
    if (loader) {
        $('#online-users').html($("#user-loader").html());
    }
    $.post(messengerPath + 'ajaxRequest.php', {
        onlineUsers: 1
    }, function (response) {
        $('#online-users').html(response);
    });
}

//-----------------------------------------------------------------------
//setInterval(onlineUsers, 1000);

function onlineUsers() {
    "use strict";
    $.post(messengerPath + 'ajaxRequest.php', {
        onlineUsersCount: 1
    }, function (response) {
        $('#online-users-count').html(response);
    });
}

//setInterval(NewMessages, 1000);

function NewMessages() {
    "use strict";
    $.post(messengerPath + 'ajaxRequest.php', {
        NewMessages: 1
    }, function (response) {
        $('#msg-flag').html(response);
    });
}

//-----------------------------------------------------------------------
function openConversations(user_id) {
    "use strict";
    $.post(messengerPath + 'ajaxRequest.php', {
        conversations: 1,
        userId: user_id
    }, function (response) {
        $('.messenger-chat-box').fadeIn();
        $('.messenger-chat-box').removeClass('hide');
        $('#messenger-conversations').html(response);
    });
}

//-----------------------------------------------------------------------
var ConvPanel = document.getElementById("conversation-panel");
if (ConvPanel) {
    $(".end").focus();
    $(".messenger-chat").focus();

    function messagesChecker() {
        "use strict";
        var user_id = $('#r_id').val();
        $.post(messengerPath + 'ajaxRequest.php', {
            messageChecker: 1,
            userId: user_id
        }, function (response) {
            $('#message-response').html(response);
        });
    }

    $('.closeMessengerConversation').on('click', function () {
        $('.messenger-chat-box').fadeOut();
        $('.messenger-chat-box').addClass('hide');
        $('#messenger-conversations').html('');
    });


    $('.messenger-chat').on('keyup', function () {
        if (this.value != "") {
            $('.chat-button').removeAttr('disabled');
        } else {
            $('.chat-button').attr('disabled', 'disabled');
        }
    });


    $('.submit-messenger-conversation').bootstrap3Validate(function (e, data) {
        "use strict";
        e.preventDefault();
        $('.chat-button').html('<i class="fal fa-spin fa-spinner"></i>');
        $.ajax({
            url: messengerPath + "ajaxRequest.php",
            type: "POST",
            data: new FormData(this),
            contentType: false,
            cache: false,
            processData: false,
            success: function (data) {
                $('.chat-button').html('<i class="fal fa-paper-plane m-0"></i>');
                $("#chat-history").html(data);
                $(".end").focus();
            },
            error: function () {
            }
        });
    });
}