<?php
/**
 * Created by PhpStorm.
 * User: Dauda Ibrahim
 * Date: 8/21/2020
 * Time: 8:42 AM
 */
if (file_exists("../../helpers/config/config.inc.php")):
    require "../../helpers/config/config.inc.php";
endif;
require "../../helpers/handlers/app_autoloader.php";
//---------------------------------------------------------------------------
require "Plugin_Class.php";
$plugin = new Plugin_Class;
$requestMethod = $_SERVER['REQUEST_METHOD'];
if (in_array($requestMethod, ["GET", "POST", "PUT", "DELETE", "OPTIONS"])):
    $requestMethodArray = array();
    $requestMethodArray = $_REQUEST;
    if (@$requestMethodArray['track_type'] == 'All'):
        $track_conditions = [];
    else:
        @$track_conditions = [
            "track_type" => "CheckIn"
        ];
    endif;

    @$tracking = $plugin->getRecord([
        "tbl_scheme" => $plugin->tracker_scheme,
        "condition" => @$track_conditions
    ])['dataArray'];

    if (isset($requestMethodArray['params']) && $requestMethodArray['params'] != ""):
        $params = json_decode(@$requestMethodArray['params'], true);
        $track_type = "CheckIn";
        if ($params != NULL):
            extract(@$params);
        endif;
        if (@$trackerQuery == 1):
            @$conditions = [];
            if (@$country != ""):
                $conditions += array("country" => @$country);
            endif;
            if (@$state != ""):
                $conditions += array("state" => @$state);
            endif;
            if (@$store_id != ""):
                $conditions += array("app_id" => @$store_id);
            endif;
            if (@$Checkout != ""):
                $track_type = "Checkout";
            endif;
            @$stores = $plugin->getRecord([
                "tbl_scheme" => "app_stores",
                "condition" => $conditions
            ])['dataArray'];
            if (@$stores != NULL):
                @$storesArray = "";
                foreach ($stores as $list):
                    $storesArray .= "store_id='" . $list['app_id'] . "' OR ";
                endforeach;
            endif;
            @$storesArray = rtrim($storesArray, ' OR ');
            @$usersSQL = "SELECT user_id FROM " . $plugin->dbScheme . ".app_users WHERE " . $storesArray . " ";
            @$usersQuery = Data_Access::execSQL($usersSQL)['dataArray'];
            @$userArray = Data_Access::fetchAssoc($usersQuery)['dataArray'];
            if ($userArray != NULL):
                $userIds = "";
                foreach ($userArray as $users):
                    $userIds .= "track_type='" . $track_type . "' AND user_id='" . $users['user_id'] . "' OR ";
                endforeach;
                $userIds = rtrim($userIds, ' OR ');
                if (@$user_id != ""):
                    $userIds = "user_id = '" . @$user_id . "'";
                endif;
            endif;
            @$trackerSQL = "SELECT * FROM " . $plugin->dbScheme . "." . $plugin->tracker_scheme . " WHERE 1 AND " . $userIds . " ";
            @$trackerArrayQuery = Data_Access::execSQL($trackerSQL)['dataArray'];
            @$tracking = Data_Access::fetchAssoc($trackerArrayQuery)['dataArray'];
        endif;
    endif;
endif;
if (!isset($requestMethodArray['log'])):
    @$dom = new DOMDocument("1.0");
    @$node = $dom->createElement("markers");
    @$parnode = $dom->appendChild($node);
else:
    $log = $plugin->logHeader();
endif;
if (@$tracking != NULL):

    foreach ($tracking as $track):
        @$user_store = $plugin->getRecord([
            "tbl_scheme" => "app_users",
            "condition" => [
                "user_id" => $track['user_id']
            ]
        ])['dataArray'][0];
        if (@$user_store != NULL):
            @$store = $plugin->getRecord([
                "tbl_scheme" => "app_stores",
                "condition" => [
                    "app_id" => $user_store['store_id']
                ]
            ])['dataArray'][0];
            if (@$store != NULL):
                @$state = $plugin->getRecord([
                    "tbl_scheme" => "app_states",
                    "condition" => [
                        "id" => $store['state']
                    ]
                ])['dataArray'][0];
            endif;
        endif;

        if (!isset($requestMethodArray['log'])):
            @header("Content-type: text/xml");
            $node = $dom->createElement("marker");
            $newnode = $parnode->appendChild($node);
            $newnode->setAttribute("id", @$track['id']);
            $newnode->setAttribute("name", @$track['username']);
            $newnode->setAttribute("address", @$store['contact_address']);
            $newnode->setAttribute("store_name", @$store['store_name']);
            $newnode->setAttribute("phone", @$user_store['contact_phone']);
            $newnode->setAttribute("lat", @$track['position_lat']);
            $newnode->setAttribute("lng", @$track['position_lng']);
            $newnode->setAttribute("type", @$track['track_type'] . ' On:' . @$track['logging_time']);
        else:
            $sys = json_decode($track['system_info'], true);
            $system_info = "";
            foreach ($sys as $devInfo => $info):
                $system_info .= strtoupper($devInfo) . ' : ' . $info . '<br>';
            endforeach;
            $log .= $plugin->logRow([
                $track['track_type'],
                @$track['username'],
                @$track['position_lat'],
                @$track['position_lng'],
                $system_info,
                @$track['logging_time']
            ]);
        endif;
    endforeach;
endif;
if (!isset($requestMethodArray['log'])):
    echo $dom->saveXML();
else:

    $log .= $plugin->logClose();
    echo $log;

endif;

?>