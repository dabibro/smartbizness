<?php
/**
 * Created by PhpStorm.
 * User: Dauda Ibrahim
 * Date: 8/21/2020
 * Time: 1:48 AM
 */

class Plugin_Class extends Data_Access
{
    public $tracker_scheme = "app_gps_tracker";
    protected $app;
    protected $biz;
    protected $engine;
    protected $logging_time;

    public function __construct()
    {
        $this->initials();
        $this->dbConnect();
        $this->app = new AppConfig;
        $this->engine = new SMBEngine;
        $this->logging_time = new DateTime('now');
        $this->biz = new BIZConfig;

    }

    public function initialSession($varParam)
    {
        if (isset($_SESSION['SMBTracker'])):
            unset($_SESSION['SMBTracker']);
        endif;
        $_SESSION['SMBTracker'] = $varParam;
    }

    public function unsetSession()
    {
        if (isset($_SESSION['SMBTracker'])):
            unset($_SESSION['SMBTracker']);
        endif;
    }

    public function updateTracking($varParam)
    {
        @$auth = new Auth_Access;
        if ($varParam !== NULL && is_array(@$auth->AppAuthChecker())):
            @$user = $auth->AppAuthChecker();
            @extract($varParam);
            @$system_info = json_encode(Detect::systemInfo());
            @$AppSMBTracker = $this->getRecord([
                "tbl_scheme" => $this->tracker_scheme,
                "condition" => [
                    "track_type" => @$param,
                    "user_id" => @$user['user_id'],
                ]
            ]);

            if (@$user != NULL):
                if (@$AppSMBTracker['response'] === "000"):
                    $this->createRecord([
                        "tbl_scheme" => $this->tracker_scheme,
                        "track_type" => $param,
                        "user_id" => @$user['user_id'],
                        "username" => trim($user['firstname'] . ' ' . $user['lastname']),
                        "system_info" => $system_info,
                        "position_lat" => $latitude,
                        "position_lng" => $longitude,
                        "logging_time" => $this->logging_time->format('Y-m-d H:i:s')

                    ]);
                else:
                    $this->updateRecord([
                        "tbl_scheme" => $this->tracker_scheme,
                        "pkField" => 'id',
                        "pk" => $AppSMBTracker['dataArray'][0]['id'],
                        "track_type" => $param,
                        "user_id" => @$user['user_id'],
                        "username" => trim(@$user['firstname'] . ' ' . @$user['lastname']),
                        "system_info" => $system_info,
                        "position_lat" => $latitude,
                        "position_lng" => $longitude,
                        "logging_time" => $this->logging_time->format('Y-m-d H:i:s')
                    ]);
                endif;
                if (@$param === 'Checkout' && is_array($user)):
                    echo '<script>console.log(submitAppExit());</script>';
                endif;
            endif;
        endif;


    }

    public function getRecord($varParam = NULL)
    {
        $this->table_name = $varParam['tbl_scheme'];
        $condition = "";
        $orders = "";
        $limits = "";
        if (@$varParam['condition'] != NULL) {
            foreach ($varParam['condition'] as $field => $val):
                $condition .= '(' . $field . " = '" . $val . "')" . ' AND ';
            endforeach;
            $condition = " WHERE " . rtrim($condition, " AND ");
        }
        if (isset($varParam['order']) && $varParam['order'] !== "") {
            $orders = "ORDER BY " . $varParam['order'] . " ";
        }

        $query = "SELECT * FROM " . $this->app->dbScheme . " . " . $this->table_name;
        $query .= $condition . " " . $orders . ";";

        $res = $this->getResultSetArray($query);
        if ($res['response'] === '200') {
            $responseArray = $res;
        } else {
            $responseArray = App_Response::getResponse('000');
            $responseArray['message'] = "No record found for query";
        }
        return $responseArray;

    }

    public function createRecord($varParam = NULL)
    {

        $this->table_name = $varParam['tbl_scheme'];
        if (isset($varParam['pk']) && $varParam['pk'] !== "") {
            $this->pk = $varParam['pk'];
            $pkVal = $varParam[$this->pk];
            $getArray = array(
                "tbl_scheme" => $this->table_name,
                "condition" => [
                    $this->pk => $pkVal
                ]);
            $getRecord = $this->getRecord($getArray);
            if ($getRecord['response'] === "200"):
                $responseArray = App_Response::getResponse('000');
                $responseArray['message'] = "Record already exist";
                return $responseArray;
                exit;
            endif;
        }

        $fields = "";
        $values = "";
        foreach ($varParam as $field => $val):
            if ($field != "tbl_scheme" && $field !== "pk"):
                $fields .= $field . ', ';
                $values .= "'" . $this->engine->verify_input($val) . "'" . ',';
            endif;
        endforeach;
        $fields = rtrim($fields, ', ');
        $values = rtrim($values, ', ');

        $query = "INSERT INTO " . $this->dbScheme . "." . $this->table_name;
        $query .= " (" . $fields . ") VALUES (" . $values . ");";

        $res = $this->insertIntoDatabase($query);
        if ($res['response'] !== '200') {
            $responseArray = App_Response::getResponse('000');
            $responseArray['message'] = "Could'nt process request";
        } else {
            $res['message'] = "Request processed successfully";
            $responseArray = $res;
        }
        return $responseArray;
    }

    public function updateRecord($varParam = NULL)
    {
        //print_r($varParam);
        $this->table_name = $varParam['tbl_scheme'];
        $fields = "";
        $pk_field = "";
        if ($varParam != NULL) {
            foreach ($varParam as $field => $val):
                if ($field != "tbl_scheme" && $field != "pk" && $field != "pkField")
                    $fields .= $field . " = '" . $val . "'" . ', ';
            endforeach;
            $fields = rtrim($fields, ", ");
            $pk_field = $varParam['pkField'] . " = '" . $varParam['pk'] . "'";
        }
        $query = "UPDATE " . $this->app->dbScheme . " . " . $this->table_name;
        $query .= " SET " . $fields . " WHERE " . $pk_field . ";";

        $res = $this->updateDatabaseTable($query);
        if ($res['response'] !== '200') {
            $responseArray = App_Response::getResponse('000');
            $responseArray['message'] = "Couldn't update record";
        } else {
            $res['message'] = "Update request successfully";
            $responseArray = $res;
        }
        return $responseArray;
    }

    public function deleteRecord($varParam = NULL)
    {
        $this->table_name = $varParam['tbl_scheme'];
        $pk = "";
        $fk = "";
        if (isset($varParam['pk']) && $varParam['pk'] != NULL) {
            foreach ($varParam['pk'] as $pkField => $pkVal):
                $pk .= $pkField . " = '" . $pkVal . "', ";
            endforeach;
            $pk = rtrim($pk, ', ');

            if (isset($varParam['fk']) && $varParam['fk'] != NULL) {
                foreach ($varParam['pk'] as $fkField => $fkVal):
                    foreach ($varParam['fk'] as $fk2):
                        $fk .= $fk2 . " = '" . $fkVal . "', ";
                    endforeach;
                endforeach;
                $fk = trim($fk, ', ');
                $fk_query = "DELETE FROM " . $this->dbScheme . "." . $this->table_name;
                $fk_query .= " WHERE (" . $fk . ");";
                @$this->deleteTableRecord($fk_query);

            }

            $query = "DELETE FROM " . $this->dbScheme . "." . $this->table_name;
            $query .= " WHERE (" . $pk . ");";

            $res = $this->deleteTableRecord($query);
            if ($res['response'] !== '200') {
                $responseArray = App_Response::getResponse('000');
                $responseArray['message'] = "Could'nt process request";
            } else {
                $res['message'] = "Delete request completed";
                $responseArray = $res;
            }
            return $responseArray;
        }
    }

    //--------------------------------------------
    public function parseToXML($htmlStr)
    {
        $xmlStr = str_replace('<', '&lt;', $htmlStr);
        $xmlStr = str_replace('>', '&gt;', $xmlStr);
        $xmlStr = str_replace('"', '&quot;', $xmlStr);
        $xmlStr = str_replace("'", '&#39;', $xmlStr);
        $xmlStr = str_replace("&", '&amp;', $xmlStr);
        return $xmlStr;
    }

    //--------------------------------------------
    public function logHeader()
    {
        $headers = [
            "Tracking Type",
            "Tracking",
            "Latitude",
            "Longitude",
            "System Info",
            "DateTime",
        ];

        $log = "<div class='table-responsive px-4'><table class='table table-sm table-bordered table-striped data-tables '>";

        $log .= "<thead>";
        $log .= "<tr>";
        foreach ($headers as $th):
            $log .= "<th>" . $th . "</th>";
        endforeach;
        $log .= "</tr>";
        $log .= "</thead>";
        $log .= "<tbody class='card-body'>";

        return $log;
    }

    public function logRow($varParam)
    {
        $row = "<tr>";
        if ($varParam != NULL):
            foreach ($varParam as $td):
                $row .= "<td style='line-height: 1rem'>" . $td . "</td>";
            endforeach;
        endif;
        $row .= "</tr>";

        return $row;
    }

    public function logClose()
    {
        return "</tbody></table></div>";
    }
}