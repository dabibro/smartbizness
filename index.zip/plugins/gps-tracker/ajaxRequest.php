<?php
/**
 * Created by DTMGS Limited.
 * User: Dauda Ibrahim
 * Date: 6/23/2020
 * Time: 10:50 AM
 * FIle: App Ajax Request Processor
 */
if (file_exists("../../helpers/config/config.inc.php")):
    require "../../helpers/config/config.inc.php";
endif;
require "../../helpers/handlers/app_autoloader.php";
//---------------------------------------------------------------------------
require "Plugin_Class.php";
$app = new AppConfig;
$plugin = new Plugin_Class;
//---------------------------------------------------------------------------

$requestMethod = $_SERVER['REQUEST_METHOD'];
if (in_array($requestMethod, ["GET", "POST", "PUT", "DELETE", "OPTIONS"])):
    //---------------------------------------------------------------------------
    $requestMethodArray = array();
    $requestMethodArray = $_REQUEST;
    //---------------------------------------------------------------------------
    if (isset($requestMethodArray['SMBTracker'])):
        $request = $requestMethodArray['SMBTracker'];
        if (@$request !== NULL && @$request['longitude'] != "" && @$request['latitude'] != ""):
            $plugin->initialSession(json_encode($request));
        else:
            $plugin->unsetSession();
            echo 'App could not access location: ';
        endif;
    endif;
    //---------------------------------------------------------------------------
    if (isset($requestMethodArray['SMBTrackerUpdate'])):
        $request = $requestMethodArray['SMBTrackerUpdate'];
        if (@$request !== NULL && @$request['longitude'] != "" && @$request['latitude'] != ""):
            @$plugin->updateTracking($request);
        endif;
    endif;
    //---------------------------------------------------------------------------
endif;
