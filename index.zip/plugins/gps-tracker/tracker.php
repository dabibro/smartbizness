<?php
$requestMethod = $_SERVER['REQUEST_METHOD'];
if (in_array($requestMethod, ["GET", "POST", "PUT", "DELETE", "OPTIONS"])):
    $requestMethodArray = array();
    $requestMethodArray = $_REQUEST;
    //---------------------------------------------------------
    if (isset($requestMethodArray['param'])):
        $param = json_decode(urldecode($requestMethodArray['param']), true);
        extract($param);
    endif;
    if (isset($requestMethodArray['trackerQuery'])):
        $requestMethodArray['trackerQuery'] += array("trackerQuery" => 1);
        $trackQuery = json_encode($requestMethodArray['trackerQuery']);
    endif;
    //---------------------------------------------------------
    if (@$requestMethodArray['trackerQuery']['Checkout'] == 1):
        $viewing = "Checkout";
    else:
        $viewing = "CheckIn";
    endif;
endif;
?>
<link rel="stylesheet" href="<?php echo @$vendors; ?>bootstrap/css/bootstrap.min.css">
<link rel="stylesheet" href="<?php echo @$vendors; ?>fontawesome/css/all.min.css">
<link rel="stylesheet" href="<?php echo @$assets; ?>css/dashboard.css">


<style>
    body {
        background-color: transparent !important;
        position: inherit !important;
        padding-top: 35px;
    }

    #map {
        height: 100%;
        width: 100%;
        background: #f2f2f2;
        padding-top: 30px;
    }

    .response {
        padding: 0.5rem 0.78rem;
        font-size: 0.8rem;
        margin-bottom: 0.5rem;
        background: rgba(254, 254, 254, .8);
        font-family: inherit;
        overflow: auto;
        position: absolute;
        z-index: 999999999999;
        width: 100%;
        top: 0;
        left: 0;
    }
</style>
<?php ?>
<input type="hidden" id="SMBTracker" value="">
<div class="response">
    <span class="float-left">Currently viewing all <?php echo @$viewing; ?> location(s)</span>
    <span class="float-right">[ <a href="javascript:void (0);"
                                   onclick="location.replace('tracker.php?param=<?php echo urlencode(($requestMethodArray['param'])); ?>');"><i
                    class="fal fa-times"></i>  Reset Filter</a> ]</span>
    <span class="float-right">[ <a href="javascript:void (0);" onclick="printDiv('map')"><i class="fal fa-print"></i> Print</a> ]</span>
    <span class="float-right">[ <a href="javascript:void (0);"
                                   onclick="window.open('tracker.php?param=<?php echo urlencode(($requestMethodArray['param'])); ?>','_blank');"><i
                    class="fal fa-window-maximize"></i> Open in New Window</a> ]</span>
    <span class="float-right">[ <a href="javascript:void (0);"
                                   onclick="trackerLog('<?php if (@$trackQuery != ""):echo @urlencode(@$trackQuery); endif; ?>')"><i
                    class="fal fa-history"></i> Tracker Log</a> ]</span>
</div>
<div id="map"></div>
<script>
    var API_KEY = "";
</script>
<script defer
        src="https://maps.googleapis.com/maps/api/js?key="+API_KEY+"&callback=initMap">
</script>
<
script >
var gpsTrackerPath = '<?php echo @$pluginPath;?>';
var trackerQuery = '<?php if (@$trackQuery != ""):echo @urlencode(@$trackQuery); endif;?>';
</script>
<script src="<?php echo @$vendors; ?>jquery/jquery.min.js"></script>
<script src="<?php echo @$pluginPath; ?>js.js"></script>
<script src="<?php echo @$assets; ?>js/app.js"></script>
