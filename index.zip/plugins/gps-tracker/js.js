var SMBTracker = $("#SMBTracker").val();
//------------------------------------------------------------------------
if (SMBTracker === '1') {
    var geolocation = navigator.geolocation;
    if (geolocation) {
        try {
            function handleSuccess(position) {
                console.log(SMSTracker(position.coords));
            }

            geolocation.getCurrentPosition(handleSuccess, errorCallback, {
                enableHighAccuracy: true,
                maximumAge: 5000 // 5 sec.
            });
        } catch (err) {
            errorCallback(err.code);
        }
    } else {
        errorCallback(1);
    }
}

//------------------------------------------------------------------------
function SMSTracker(position) {
    $.post(gpsTrackerPath + 'ajaxRequest.php', {
        SMBTracker: {
            latitude: position.latitude,
            longitude: position.longitude
        },
    }, function (response) {
        if (response !== "") {
            alert(response);
            console.log(response);
        }
    });
}

//------------------------------------------------------------------------
var GeoErrorMsg = {
    1: {
        title: 'PERMISSION_DENIED',
        description: "The acquisition of the geolocation information failed because the page didn't have the permission to do it."
    },
    2: {
        title: 'POSITION_UNAVAILABLE',
        description: "The acquisition of the geolocation failed because at least one internal source of position returned an internal error."
    },
    3: {
        title: 'TIMEOUT',
        description: "The time allowed to acquire the geolocation, defined by PositionOptions.timeout information was reached before the information was obtained."
    }
};

function errorCallback(ErrCode) {
    $.post(gpsTrackerPath + 'ajaxRequest.php', {
        SMBTracker: {
            response: 0,
        },
    }, function (response) {
        if (ErrCode)
            alert(response + ' ' + GeoErrorMsg[ErrCode.code].title + ' ' + GeoErrorMsg[ErrCode.code].description);
    });
}


//------------------------------------------------------------------------
function SMSTrackerUpdate(param) {
    if (geolocation) {
        geolocation.getCurrentPosition(UpdateTracker, callBackResp, {
            enableHighAccuracy: true,
            maximumAge: 5000 // 5 sec.
        });

        function UpdateTracker(position) {
            $.post(gpsTrackerPath + 'ajaxRequest.php', {
                SMBTrackerUpdate: {
                    param: param,
                    latitude: position.coords.latitude,
                    longitude: position.coords.longitude
                },
            }, function (response) {
                $("#trackerResponses").html(response);
            });

        }

        function callBackResp(code) {
            if (code && param === "Checkout") {
                console.log(submitAppExit());
            }
        }
    }
}

function exitApp() {
    if (SMBTracker === '1') {
        if (geolocation) {
            SMSTrackerUpdate("Checkout");
        } else {
            console.log(submitAppExit());
        }
    } else {
        console.log(submitAppExit());
    }

}

//------------------------------------------------------------------------------
var customLabel = {
    Gombe: {
        label: 'ST4GB720M8'
    },
    Bauchi: {
        label: 'BH'
    }
};

//alert(trackerQuery);
function initMap() {
    var map = new google.maps.Map(document.getElementById('map'), {
        center: new google.maps.LatLng(9.05785, 7.49508),
        zoom: 7,
        mapTypeId: 'roadmap'

    });
    var infoWindow = new google.maps.InfoWindow;
    // Change this depending on the name of your PHP or XML file
    downloadUrl(gpsTrackerPath + 'trackerMapper.php?params=' + trackerQuery, function (data) {
        var xml = data.responseXML;
        var markers = xml.documentElement.getElementsByTagName('marker');
        Array.prototype.forEach.call(markers, function (markerElem) {
            var id = markerElem.getAttribute('id');
            var name = markerElem.getAttribute('name');
            var address = markerElem.getAttribute('address');
            var store_name = markerElem.getAttribute('store_name');
            var phone_num = markerElem.getAttribute('phone');
            var type = markerElem.getAttribute('type');
            var point = new google.maps.LatLng(
                parseFloat(markerElem.getAttribute('lat')),
                parseFloat(markerElem.getAttribute('lng')));

            var infowincontent = document.createElement('div');
            var strong = document.createElement('strong');
            strong.textContent = name + ' - ' + store_name
            infowincontent.appendChild(strong);
            infowincontent.appendChild(document.createElement('br'));

            var text = document.createElement('text');
            text.textContent = address
            infowincontent.appendChild(text);

            infowincontent.appendChild(document.createElement('br'));

            var phone = document.createElement('text');
            phone.textContent = phone_num
            infowincontent.appendChild(phone);

            infowincontent.appendChild(document.createElement('br'));

            var track_type = document.createElement('text');
            track_type.textContent = type
            infowincontent.appendChild(track_type);

            var icon = customLabel[type] || {};
            var marker = new google.maps.Marker({
                map: map,
                position: point,
                label: name
            });
            marker.addListener('click', function () {
                infoWindow.setContent(infowincontent);
                infoWindow.open(map, marker);
            });
        });
    });
}

function downloadUrl(url, callback) {
    var request = window.ActiveXObject
        ? new ActiveXObject('Microsoft.XMLHTTP')
        : new XMLHttpRequest;

    request.onreadystatechange = function () {
        if (request.readyState === 4) {
            request.onreadystatechange = doNothing;
            callback(request, request.status);
        }
    };

    request.open('GET', url, true);
    request.send(null);
}

function doNothing() {
}

function trackerLog(params) {

    $.post(gpsTrackerPath + 'trackerMapper.php', {
        log: 1,
        track_type: "All",
        params: params
    }, function (response) {
        $("#map").html(response);
    });
}
