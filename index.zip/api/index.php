<?php
/**
 * Created by DTMGS Limited.
 * User: Dauda Ibrahim
 * Date: 6/21/2020
 * Time: 10:09 PM
 * File: App Launcher
 */
//------------------------------------------------------------------------------------------
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Max-Age: 1000');
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token, Authorization');
//------------------------------------------------------------------------------------------
if (file_exists("../helpers/config/config.inc.php")):
    require "../helpers/config/config.inc.php";
endif;
require_once "../helpers/handlers/app_autoloader.php";
$SMBEngine = new SMBEngine();
//------------------------------------------------------------------------------------------
$requestMethod = $_SERVER['REQUEST_METHOD'];
//------------------------------------------------------------------------------------------
if (in_array($requestMethod, ["GET", "POST", "PUT", "DELETE", "OPTIONS"])):
    $requestMethodArray = array();
    $requestMethodArray = $_REQUEST;
    if (isset($requestMethodArray['SMBLaunch'])):
        $SMBLaunch = $SMBEngine->LaunchCore();
        if ($SMBLaunch['success'] == 1):
            echo json_encode($SMBLaunch);
        endif;
    endif;
endif;
//------------------------------------------------------------------------------------------

