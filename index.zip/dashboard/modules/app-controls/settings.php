<div class="card card-primary card-outline card-outline-tabs">
    <div class="card-header p-0 border-bottom-0">
        <ul class="nav nav-tabs" id="manage-settings-tabs" role="tablist">
            <li class="nav-item">
                <a class="nav-link active" id="tabs-configuration-tabs" data-toggle="pill" href="#configuration-tab"
                   role="tab" aria-controls="configuration-tab" aria-selected="true">Configuration</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" id="tabs-uom-tabs" data-toggle="pill" href="#uom-tab" role="tab"
                   aria-controls="uom-tab" aria-selected="false">Units of Measurement</a>
            </li>

            <li class="nav-item">
                <a class="nav-link" id="tabs-items-location-tabs" data-toggle="pill" href="#items-location-tab"
                   role="tab" aria-controls="items-location-tab" aria-selected="false">Items Location</a>
            </li>

            <li class="nav-item">
                <a class="nav-link" id="tabs-discounts-tabs" data-toggle="pill" href="#discounts-tab" role="tab"
                   aria-controls="discounts-tab" aria-selected="false">Discounts</a>
            </li>

            <li class="nav-item">
                <a class="nav-link" id="tabs-payment-option-tabs" data-toggle="pill" href="#payment-option-tab"
                   role="tab" aria-controls="payment-option-tab" aria-selected="false">Payment Option</a>
            </li>

        </ul>
    </div>
    <div class="card-body">
        <div class="tab-content" id="manage-settings-tabContent">
            <div class="tab-pane fade active show" id="configuration-tab" role="tabpanel"
                 aria-labelledby="tabs-configuration-tabs">
                <?php require_once "inc/configuration.php"; ?>

            </div>
            <div class="tab-pane fade " id="uom-tab" role="tabpanel" aria-labelledby="tabs-uom-tab">

                <?php require_once "inc/uom.php"; ?>
            </div>

            <div class="tab-pane fade " id="items-location-tab" role="tabpanel"
                 aria-labelledby="tabs-items-location-tab">
                <?php require_once "inc/items-location.php"; ?>
            </div>

            <div class="tab-pane fade a" id="discounts-tab" role="tabpanel" aria-labelledby="tabs-discounts-tab">
                <?php require_once "inc/discount.php"; ?>
            </div>

            <div class="tab-pane fade " id="payment-option-tab" role="tabpanel"
                 aria-labelledby="tabs-payment-option-tab">
                <?php require_once "inc/payment-option.php"; ?>
            </div>


        </div>
    </div>
    <!-- /.card -->
</div>
