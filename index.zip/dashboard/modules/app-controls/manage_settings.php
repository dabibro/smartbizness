<?php
require "Module_Class.php";
$module = new Module_Class;
$modulePath = @$appSwitcher->modulePath($AppModule);
$req = $AppModuleRequest;
//phpinfo();
?>
<script src="<?php echo $modulePath ?>js.js"></script>
<input type="hidden" value="<?php echo $modulePath; ?>" id="ModulePath" readonly>
<div class="card card-primary card-outline card-outline-tabs h-100">
    <div class="card-body">
        <label class="text-muted"><i class="fal fa-bars mr-2"></i> App Control Menu</label>
        <div class="row">
            <div class="col-3 col-sm-2">
                <div class="nav flex-column nav-tabs h-100" id="vert-tabs-tab" role="tablist"
                     aria-orientation="vertical">
                    <a class="nav-link active" id="vert-tabs-home-tab" data-toggle="pill" href="#vert-tabs-home"
                       role="tab" aria-controls="vert-tabs-home" aria-selected="true"><i
                                class="fal fa-sliders-v-square"></i> Configurations
                        <hr class="my-2">
                        <small class="text-muted"> Database Config | Printer Option | Misc etc.</small>
                    </a>
                    <a class="nav-link" id="vert-tabs-profile-tab" data-toggle="pill" href="#vert-tabs-profile"
                       role="tab" aria-controls="vert-tabs-profile" aria-selected="false"><i class="fal fa-archive"></i>
                        App Backup/Restore
                        <hr class="my-2">
                        <small class="text-muted">Backup/Restore application data</small>
                    </a>
                    <a class="nav-link" id="vert-tabs-import-export-tab" data-toggle="pill"
                       href="#vert-tabs-import-export"
                       role="tab" aria-controls="vert-tabs-import-export" aria-selected="false"><i
                                class="fal fa-file-csv"></i> Import/Export Data (CSV)
                        <hr class="my-2">
                        <small class="text-muted">Import/Export records (csv file)</small>
                    </a>
                    <a class="nav-link" id="vert-tabs-settings-tab" data-toggle="pill" href="#vert-tabs-settings"
                       role="tab" aria-controls="vert-tabs-settings" aria-selected="false"><i class="fal fa-cloud"></i>
                        Cloud Synchronization
                        <hr class="my-2">
                        <small class="text-muted">Sync with Cloud Database</small>
                    </a>
                    <a class="nav-link" id="vert-tabs-settings-tab" data-toggle="pill" href="#vert-tabs-settings"
                       role="tab" aria-controls="vert-tabs-settings" aria-selected="false"><i
                                class="fal fa-shield-check"></i> License
                        <hr class="my-2">
                        <small class="text-muted">License Agreement/Activation</small>
                    </a>
                    <a class="nav-link" id="vert-tabs-settings-tab" data-toggle="pill" href="#vert-tabs-settings"
                       role="tab" aria-controls="vert-tabs-settings" aria-selected="false"><i class="fal fa-books"></i>
                        Documentation
                        <hr class="my-2">
                        <small class="text-muted">Application Documentation</small>
                    </a>
                    <a class="nav-link" id="vert-tabs-settings-tab" data-toggle="pill" href="#vert-tabs-settings"
                       role="tab" aria-controls="vert-tabs-settings" aria-selected="false"><i
                                class="fal fa-life-ring"></i> Support/Feedback
                        <hr class="my-2">
                        <small class="text-muted">Report a Bugs for Fix</small>
                    </a>
                </div>
            </div>
            <div class="col-9 col-sm-10">
                <div class="tab-content" id="vert-tabs-tabContent">
                    <div class="tab-pane text-left fade " id="vert-tabs-home" role="tabpanel"
                         aria-labelledby="vert-tabs-home-tab">
                        Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin malesuada lacus ullamcorper dui
                        molestie, sit amet congue quam finibus. Etiam ultricies nunc non magna feugiat commodo. Etiam
                        odio magna, mollis auctor felis vitae, ullamcorper ornare ligula. Proin pellentesque tincidunt
                        nisi, vitae ullamcorper felis aliquam id. Pellentesque habitant morbi tristique senectus et
                        netus et malesuada fames ac turpis egestas. Proin id orci eu lectus blandit suscipit. Phasellus
                        porta, ante et varius ornare, sem enim sollicitudin eros, at commodo leo est vitae lacus. Etiam
                        ut porta sem. Proin porttitor porta nisl, id tempor risus rhoncus quis. In in quam a nibh cursus
                        pulvinar non consequat neque. Mauris lacus elit, condimentum ac condimentum at, semper vitae
                        lectus. Cras lacinia erat eget sapien porta consectetur.
                    </div>
                    <div class="tab-pane fade" id="vert-tabs-profile" role="tabpanel"
                         aria-labelledby="vert-tabs-profile-tab">
                        Mauris tincidunt mi at erat gravida, eget tristique urna bibendum. Mauris pharetra purus ut
                        ligula tempor, et vulputate metus facilisis. Lorem ipsum dolor sit amet, consectetur adipiscing
                        elit. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae;
                        Maecenas sollicitudin, nisi a luctus interdum, nisl ligula placerat mi, quis posuere purus
                        ligula eu lectus. Donec nunc tellus, elementum sit amet ultricies at, posuere nec nunc. Nunc
                        euismod pellentesque diam.
                    </div>
                    <div class="tab-pane fade show active" id="vert-tabs-import-export" role="tabpanel"
                         aria-labelledby="vert-tabs-import-export-tab">

                        <h4 class="text-muted">Import/Export Data(CSV)</h4>
                        <hr>
                        <blockquote class="border-light elevation-1 small mx-0"><i class="fal fa-info-circle"></i>
                            Import and Export feature is very useful for the data management section. The Import
                            functionality allows the user to upload and insert multiple data in the database. Using the
                            Import feature, the bulk data can be inserted in the database on a single click. The export
                            functionality allows the user to download the table data list and save in a file for offline
                            use. Using the Export feature, multiple records can be downloaded in a file format.
                        </blockquote>
                        <ul class="nav nav-pills ml-auto mb-3 p-2 modules-menu">
                            <li class="nav-item"><a class="nav-link" href="#tab_1" data-toggle="tab"><i
                                            class="fal fa-upload"></i> Import
                                    Data</a></li>
                            <li class="nav-item"><a class="nav-link" href="#tab_2" data-toggle="tab"><i
                                            class="fal fa-download"></i> Export Data</a>
                            </li>
                            <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle" data-toggle="dropdown" href="#">
                                    <i class="fal fa-cogs"></i> Options <span class="caret"></span>
                                </a>
                                <div class="dropdown-menu">
                                    <a class="dropdown-item" tabindex="-1" href="#">Action</a>
                                    <a class="dropdown-item" tabindex="-1" href="#">Another action</a>
                                    <a class="dropdown-item" tabindex="-1" href="#">Something else here</a>
                                    <div class="dropdown-divider"></div>
                                    <a class="dropdown-item" tabindex="-1" href="#">Separated link</a>
                                </div>
                            </li>

                        </ul>

                        <div class="position-relative">
                            <form class="import-data-from" id="app-data-import-form" enctype="multipart/form-data">
                                <div id="data-import-response"></div>
                                <div class="row">
                                    <div class="col-5 col-sm-4">
                                        <div class="card card-light">
                                            <div class="card-header p-2">
                                                <label for="" class="mb-0">Import CSV file</label>
                                            </div>
                                            <div class="card-body py-2 px-3 pb-3">
                                                <div class="row">
                                                    <div class="col-12">
                                                        <label for="">
                                                            <span class="required">*</span> Table
                                                        </label>
                                                    </div>
                                                    <div class="col-12">
                                                        <div class="form-group">
                                                            <select name="tbl_scheme" id="" required
                                                                    class="form-control form-control-sm select2">
                                                                <option value="">-- Select Table --</option>
                                                                <option value="app_products" selected>Inventory</option>
                                                            </select>
                                                            <div class="invalid-feedback">* Select table scheme</div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-12">
                                                        <label for="">
                                                            <span class="required">*</span> Store
                                                        </label>
                                                    </div>
                                                    <div class="col-12">
                                                        <div class="form-group">
                                                            <select name="store_id"
                                                                    class="form-control form-control-sm select2"
                                                                    id="store" required>
                                                                <option value="">-- Select Store --</option>
                                                                <?php
                                                                $storeParam = array("tbl_scheme" => 'app_stores', "condition" => ["active_status" => 1]);
                                                                $listArray = $module->getRecord($storeParam);
                                                                $dropDownArray = array();
                                                                foreach ($listArray['dataArray'] as $store):
                                                                    echo $app->dropDownList($store['store_id'], $store['store_name'], 1);
                                                                endforeach; ?>
                                                            </select>
                                                            <div class="invalid-feedback">* Select store</div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-12">
                                                        <label for="">
                                                            <span class="required">*</span> Data File
                                                        </label>
                                                    </div>
                                                    <div class="col-12">
                                                        <div class="form-group" id="import-data-file">
                                                            <div class="custom-file">
                                                                <input type="file" name="import-data-file"
                                                                       class="custom-file-input item-image pointer form-control"
                                                                       id="dataFile" form="app-data-import-form">
                                                                <label class="custom-file-label" for="dataFile">Select
                                                                    csv file</label>
                                                            </div>
                                                            <div class="small required"></div>
                                                            <small class="text-muted">Only supports csv formats</small>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-12">
                                                        <label for="" class="small text-muted">Import Options</label>
                                                        <div class="form-group mr-2">
                                                            <div class="custom-control custom-switch">
                                                                <input type="checkbox"
                                                                       class="custom-control-input propToggle"
                                                                       id="update">
                                                                <label class="custom-control-label small"
                                                                       for="update">
                                                                    Update Records</label>
                                                                <input type="hidden" readonly value="0"
                                                                       name="update-request" class="update"></div>
                                                        </div>
                                                        <div class="form-group">
                                                            <label for=""><span class="required">*</span> Select Primary
                                                                Key</label>
                                                            <select name="primary-key"
                                                                    class="form-control form-control-sm select2">
                                                                <option value="">-- Select --</option>
                                                                <?php
                                                                $sql = "SELECT * FROM  app_products";
                                                                $query = $bizD = Data_Access::execSQL($sql);
                                                                $fieldinfo = mysqli_fetch_fields($query);
                                                                foreach ($fieldinfo as $val): ?>
                                                                    <option value="<?php echo($val->name); ?>"> <?php echo($val->name); ?></option>
                                                                <?php endforeach;
                                                                ?>
                                                            </select>
                                                        </div>
                                                        <div class="form-group mr-2">
                                                            <div class="custom-control custom-switch">
                                                                <input type="checkbox"
                                                                       class="custom-control-input propToggle"
                                                                       id="column-name">
                                                                <label class="custom-control-label small"
                                                                       for="column-name">
                                                                    Columns names in the first row</label>
                                                                <input type="hidden" readonly value="0"
                                                                       name="remove-col-name" class="column-name"></div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <hr class="my-3">
                                                <button class="btn btn-default btn-sm"><i
                                                            class="fal fa-check-circle"></i>
                                                    Import
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-7 col-sm-8">
                                        <label for="" class="text-muted mb-0"><i class="fal fa-history"></i>
                                            Import History </label>
                                        <hr>
                                        <label for="" class="small text-muted w-100">Table Column Mapping <span
                                                    id="import-response" class="float-right required"></span></label>
                                        <div class="row">
                                            <div class="col-3">
                                                <label for="" class="w-100 small"><span class="required">*</span> Table
                                                    field <a
                                                            href="javascript:void(0);" class="float-right"><i
                                                                class="fal fa-question-circle"></i></a></label>
                                                <select name="" id="import-scheme-field"
                                                        class="h-100 form-control form-control-sm text-uppercase"
                                                        multiple
                                                        style="min-height:260px; font-size: 0.68rem !important;">
                                                    <?php
                                                    $sql = "SELECT app_products.sku_barcode,
                                            app_products.name,
                                            app_products.description,
                                            app_products.price,
                                            app_products.sale_price,
                                            app_products.wholesale_price, 
                                            app_products.category_id, 
                                            app_products.subcategory,                                              
                                            app_inventory.store_id, 
                                            app_inventory.storage_id,
                                            app_inventory.stock_qty, 
                                            app_inventory.packaging, 
                                            app_inventory.warning_level, 
                                            app_inventory.expiry_date, 
                                            app_inventory.measure_unit, 
                                            app_inventory.vendor_id,
                                            app_inventory.shipping,
                                            app_inventory.back_order,                                                                                        
                                            app_inventory.active_status                                                                                        
                                            FROM  app_products, app_inventory";
                                                    $query = $bizD = Data_Access::execSQL($sql);
                                                    $fieldinfo = mysqli_fetch_fields($query);
                                                    foreach ($fieldinfo as $val): ?>
                                                        <option id="<?php echo($val->name); ?>"
                                                                value="<?php echo($val->name); ?>"> <?php echo($val->name); ?></option>
                                                    <?php endforeach;
                                                    ?>
                                                </select>
                                            </div>
                                            <div class="col-2">
                                                <label for="" class="small"><span class="required">*</span>
                                                    Column</label>
                                                <select name="" id="import-data-file-column"
                                                        class="h-100 form-control form-control-sm" multiple role="menu"
                                                        style="font-size: 0.68rem !important;">
                                                    <?php
                                                    $strings = str_split("ABCDEFGHIJKLMNOPQRSTUVWXYZ");
                                                    foreach ($strings as $str):
                                                        echo '<option id="' . $str . '" value="' . $str . '">' . $str . '</option>';
                                                    endforeach;
                                                    ?>
                                                </select>
                                            </div>
                                            <div class="col-1 pt-5">
                                                <button class="btn btn-default btn-sm pr-2 mb-3 mt-5"
                                                        app-import-button="select">
                                                    <i
                                                            class="fal fa-arrow-alt-from-left m-0"></i></button>
                                                <button class="btn btn-default btn-sm pr-2"
                                                        app-import-button="deselect"><i
                                                            class="fal fa-arrow-alt-from-right m-0"></i></button>
                                            </div>
                                            <div class="col-6">
                                                <div class="form-group h-100">
                                                    <input type="text" id="import-object" name="data-import-mapping"
                                                           readonly>
                                                    <label for="" class="w-100 small"><span class="required">*</span>
                                                        Field
                                                        Mapping <a
                                                                href="javascript:void(0);" class="float-right"><i
                                                                    class="fal fa-question-circle"></i></a></label>
                                                    <select name="import-mapping" id="import-field-mapping" required
                                                            class="h-100 form-control form-control-sm" multiple
                                                            form="app-data-import-form"
                                                            style="font-size: 0.68rem !important; text-transform: uppercase">
                                                        <option value="" selected>--- Selected Import Mapping ---
                                                        </option>
                                                    </select>
                                                    <div class="invalid-feedback">* Select table scheme</div>
                                                </div>

                                            </div>
                                        </div>

                                        <div class="hide">

                                            <table class="table data-tables datatables-search table-sm">
                                                <thead>
                                                <tr>
                                                    <th>Date</th>
                                                    <th>Table Name</th>
                                                    <th>Import By</th>
                                                    <th></th>
                                                </tr>
                                                </thead>
                                                <tbody>
                                                <tr>
                                                    <td></td>
                                                    <td></td>
                                                    <td></td>
                                                    <td></td>
                                                </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                                <input type="hidden" name="created_by"
                                       value="<?php echo trim(@$auth['firstname'] . ' ' . @$auth['lastname']); ?>"
                                       readonly>
                                <input type="text" name="AppDataImport">
                            </form>
                        </div>

                    </div>
                    <div class="tab-pane fade" id="vert-tabs-settings" role="tabpanel"
                         aria-labelledby="vert-tabs-settings-tab">
                        Pellentesque vestibulum commodo nibh nec blandit. Maecenas neque magna, iaculis tempus turpis
                        ac, ornare sodales tellus. Mauris eget blandit dolor. Quisque tincidunt venenatis vulputate.
                        Morbi euismod molestie tristique. Vestibulum consectetur dolor a vestibulum pharetra. Donec
                        interdum placerat urna nec pharetra. Etiam eget dapibus orci, eget aliquet urna. Nunc at
                        consequat diam. Nunc et felis ut nisl commodo dignissim. In hac habitasse platea dictumst.
                        Praesent imperdiet accumsan ex sit amet facilisis.
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- /.card -->
</div>
<script>
    var modulePath = $("#ModulePath").val();
    $(document).on('click', '[app-import-button]', function (event) {
        event.preventDefault();
        var objSelected = $("#import-object").val();
        var scheme_column = $('#import-scheme-field');
        var csv_column = $('#import-data-file-column');
        var mapping = $('#import-field-mapping');
        var importEvent = $(this).attr('app-import-button')
        var importObject = $("#import-object");
        if (csv_column.val() == "" && importEvent == 'select' || scheme_column.val() == "" && importEvent == 'select') {
            $("#import-response").html("* Missing field/column selection");
        } else {
            $("#import-response").html("");
            if (importEvent == 'select') {
                //----------------------------------------------------------------------------------------------
                objSelected += '"' + scheme_column.val() + '":"' + csv_column.val() + '",';

                var mappingParentObj = document.getElementById(mapping.attr('id'));
                var mappingObj = document.createElement('OPTION');
                mappingObj.setAttribute('id', csv_column.val() + '=>' + scheme_column.val());
                mappingObj.setAttribute('value', csv_column.val() + '=>' + scheme_column.val());
                mappingObj.setAttribute('selected', 'selected');
                var label = document.createTextNode(csv_column.val() + ' => ' + scheme_column.val());
                mappingObj.appendChild(label);
                mappingParentObj.appendChild(mappingObj);
                //----------------------------------------------------------------------------------------------
                var schemeParentObj = document.getElementById(scheme_column.attr('id'));
                var schemeChildObj = document.getElementById(scheme_column.val());
                //----------------------------------------------------------------------------------------------
                var columnParentObj = document.getElementById(csv_column.attr('id'));
                var columnChildObj = document.getElementById(csv_column.val());
                //----------------------------------------------------------------------------------------------
                schemeParentObj.removeChild(schemeChildObj);
                columnParentObj.removeChild(columnChildObj);
                //----------------------------------------------------------------------------------------------
                importObject.val(objSelected);
                //----------------------------------------------------------------------------------------------
            } else {
                var mappingParentObj = document.getElementById(mapping.attr('id'));
                var mappingChildObj = document.getElementById(mapping.val());
                var mappedValue = mappingParentObj.value;
                var splitMapped = mappedValue.split('=>');
                var field = splitMapped[1];
                var column = splitMapped[0];
                var objSelected = '"' + field + '":"' + column + '"';
                var importObjValue = importObject.val()
                var replaceObj = importObjValue.replace(objSelected, '');
                replaceObj = replaceObj.replace(',,', ',')
                importObject.val(replaceObj);
                //alert(objSelected);
                mappingParentObj.removeChild(mappingChildObj);
                //--------------------------------------------------------------------------
                var schemeParentObj = document.getElementById(scheme_column.attr('id'));
                var schemeOption = document.createElement('OPTION');
                schemeOption.setAttribute('id', field);
                schemeOption.setAttribute('value', field);
                var schemeLabel = document.createTextNode(field);
                schemeOption.appendChild(schemeLabel);
                schemeParentObj.appendChild(schemeOption);
                //--------------------------------------------------------------------------
                var columnParentObj = document.getElementById(csv_column.attr('id'));
                var columnOption = document.createElement('OPTION');
                columnOption.setAttribute('id', column);
                columnOption.setAttribute('value', column);
                var columnLabel = document.createTextNode(column);
                columnOption.appendChild(columnLabel);
                columnParentObj.appendChild(columnOption);
                //alert(objSelected);
                //alert(replaceObj);
            }
        }
    });

    $(".import-data-from").bootstrap3Validate(function (e, data) {
        e.preventDefault();
        $.ajax({
            url: modulePath + "ajaxRequest.php",
            type: "POST",
            data: new FormData(this),
            contentType: false,
            cache: false,
            processData: false,
            success: function (data) {
                //alert(data);
                $("#data-import-response").html(data);
                var response = JSON.parse(data);
                $("#data-import-response").html(response['message']);
                if (response['success'] === 1) {
                    attribList();
                    $("#attributes-form")[0].reset();
                }
                if ($("#attrib_function").val() == 'updateRecord') {
                    $("#attribPK").val('');
                    $("#attribPKField").val('');
                    $("#attribPK").attr('disabled', 'disabled');
                    $("#attribPKField").attr('disabled', 'disabled');
                    $("#attrib_function").val("createRecord");
                }
                $(".attribActionButton").html('<i class="fal fa-save"></i> Save');
            },
            error: function () {
            }
        });

    })
</script>