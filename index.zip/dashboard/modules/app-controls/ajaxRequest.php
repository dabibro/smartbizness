<?php
/**
 * Created by DTMGS Limited.
 * User: Dauda Ibrahim
 * Date: 6/23/2020
 * Time: 9:40 PM
 * File: Module Classes
 */
if (file_exists("../../../helpers/config/config.inc.php")):
    require "../../../helpers/config/config.inc.php";
endif;
require "../../../helpers/handlers/app_autoloader.php";
require "Module_Class.php";
$engine = new SMBEngine;
$AppResponse = new App_Response;
$biz = new BIZConfig();
$appAuth = new Auth_Access;
$auth = $appAuth->AppAuthChecker();
$requestMethod = $_SERVER['REQUEST_METHOD'];
if (in_array($requestMethod, ["GET", "POST", "PUT", "DELETE", "OPTIONS"])):
    $requestMethodArray = array();
    $requestMethodArray = $_REQUEST;
    //print_r($requestMethodArray);
    if (isset($requestMethodArray['notification']) && !isset($requestMethodArray['confirmed'])):
        $tmpl = "../../tmpl/notification.html";
        echo $engine->fileTempParse($tmpl, $requestMethodArray);
        exit;
    endif;
    // print_r($requestMethodArray);
    //--------------------------------------------------------------------------
    if (isset($requestMethodArray['className']) && isset($requestMethodArray['functionName'])):
        $getCommandArray = array(
            "class" => $requestMethodArray['className'],
            "function_name" => $requestMethodArray['functionName']);
        $functionArray = [];
        foreach ($requestMethodArray as $key => $val):
            if ($key !== "className" && $key !== "functionName" && $key !== "callback")
                $functionArray += array($key => $val);
        endforeach;
        $module = new $requestMethodArray['className'];

        $execution = $module->execCommand($getCommandArray, $functionArray);

        if ($execution['response'] === "200"):
            $responseMessage = App_Response::alertResponse(@$execution['message'], 'success');
            if (@$requestMethodArray['callback']['type'] == 'actionEvent'):
                $requestMethodArray['callback'] += array("event" => '<script>' . $requestMethodArray['callback']['redirect'] . '</script>');
            endif;
            $responseArray = array("success" => 1, "message" => (@$responseMessage), "dataArray" => @$execution['dataArray'], "callback" => @$requestMethodArray['callback']);
        else:
            $responseMessage = App_Response::alertResponse(@$execution['message'], 'danger');
            $responseArray = array("success" => 0, "message" => (@$responseMessage), "callback" => @$requestMethodArray['callback']);
        endif;
        echo @json_encode($responseArray);
    endif;
    //---------------------------------------------------------------------------
    if (isset($requestMethodArray['dropDownRequest'])):
        $module = new Module_Class;
        $tbl_scheme = $requestMethodArray['dropDownRequest']['target_scheme'];
        $pkField = $requestMethodArray['dropDownRequest']['pkField'];
        $pk = $requestMethodArray['dropDownRequest']['pk'];
        $key = $requestMethodArray['dropDownRequest']['key'];
        $label = $requestMethodArray['dropDownRequest']['label'];

        $listParam = array(
            "tbl_scheme" => $tbl_scheme,
            "condition" => [$pkField => $pk]);
        $listArray = $module->getRecord($listParam);
        echo '<option value="">-- Select --</option>';
        foreach ($listArray['dataArray'] as $list):
            if (isset($key) && $key != ""):
                echo $engine->dropDownList($list[$key], $list[$label]);
            else:
                echo $engine->dropDownList($list[$label]);
            endif;
        endforeach;
    endif;
    //---------------------------------------------------------------------------
    if (isset($requestMethodArray['formLookupRequest']) && $requestMethodArray['formLookupRequest']['term'] != ""):
        $module = new Module_Class;
        $request = $requestMethodArray['formLookupRequest']['request'];
        $tbl_scheme = $requestMethodArray['formLookupRequest']['target_scheme'];
        $field = $requestMethodArray['formLookupRequest']['fields'];
        $term = $requestMethodArray['formLookupRequest']['term'];
        $key = $requestMethodArray['formLookupRequest']['key'];
        $label = $requestMethodArray['formLookupRequest']['labels'];
        $condition = $requestMethodArray['formLookupRequest']['condition'];
        $order = $requestMethodArray['formLookupRequest']['order'];
        $limit = $requestMethodArray['formLookupRequest']['limit'];
        $lookupDestination = $requestMethodArray['formLookupRequest']['destination'];
        $target = $requestMethodArray['formLookupRequest']['target'];
        $actionButton = $requestMethodArray['formLookupRequest']['action_button'];

        if ($request == "search"):
            $searchParam = [
                "tbl_scheme" => $tbl_scheme,
                "fields" => $field,
                "term" => $term,
                "condition" => $condition,
                "order" => $order,
                "limit" => $limit,
            ];
            $query = $module->searchRecord($searchParam);
            if ($query['response'] == "200"):
                $dataArray = $query['dataArray'];
                if (count($dataArray) === 0):

                else:
                    echo '<div class="search-result position-relative">';
                    echo '<a class="small text-right result-close text-muted" href="javasctipy:void(0)" onclick=\'$("."+"' . $target . '").html("");\'>[ x close ]</a>';
                    $index = 0;
                    foreach ($dataArray as $results): $index++;
                        $labels = "";
                        foreach ($label as $lbl):
                            $labels .= $results[$lbl] . ' ';
                        endforeach;
                        echo '<button tabindex = "' . $index . '"  type="button" class="list-group-item" onclick=\'javascript:$("#"+"' . $lookupDestination . '").val(this.innerHTML); $("."+"' . $target . '").html(""); $("#"+"' . $actionButton . '").click()\'>[' . $results[$key] . '] ' . $labels . '</a>';
                    endforeach;
                    echo '</div>';
                endif;
            else:
                echo '<li class="list-group-item">No result(s) found lookup</li>';
            endif;

        else:

        endif;
    endif;
    //---------------------------------------------------------------------------
    if (isset($requestMethodArray['AppModalLoader'])):
        $required = $requestMethodArray['AppModalLoader'];
        $modulePath = str_ireplace($engine->dashboard, '', $required['path']);
        $modalRequest = 1;
        $module = new Module_Class;
        require $required['required'] . '.php';
    endif;
    //---------------------------------------------------------------------------
    if (isset($requestMethodArray['AppIDAutoGen'])):
        if ($requestMethodArray['AppIDAutoGen'] != NULL):
            extract($requestMethodArray['AppIDAutoGen']);
            echo $appIdGen = $engine->generateAppId($prefix, $suffix, $strlen, $pattern);
        endif;
    endif;
    //---------------------------------------------------------------------------
    if (isset($requestMethodArray['AttribListView'])):
        $app_id = $requestMethodArray['app_id'];
        $module = new Module_Class;
        require "inc/attributes_list.php";
    endif;
    //---------------------------------------------------------------------------
    if (isset($requestMethodArray['ImageUpload'])):
        $module = new Module_Class;
        $app_id = $requestMethodArray['app_id'];
        $description = $requestMethodArray['image_description'];
        $imageFile = $requestMethodArray['image_file'];
        list($type, $imageFile) = explode(';', $imageFile);
        list(, $imageFile) = explode(',', $imageFile);
        $imageFile = base64_decode($imageFile);
        $image_name = $app_id . '_' . time() . '.png';
        $upload = file_put_contents('../../uploads/inventory/' . $image_name, $imageFile);
        if ($upload):
            $imageParam = [
                "tbl_scheme" => 'app_products_images',
                "app_id" => $app_id,
                "image_file" => $image_name,
                "description" => $description,
            ];
            $insertImage = $module->createRecord($imageParam);
            if ($insertImage['response'] === '200'):
                $insertImage['message'] = "Image successfully uploaded!";
                $responseMessage = App_Response::alertResponse(@$insertImage['message'], 'success');
                $responseArray = array("success" => 1, "message" => (@$responseMessage));
            else:
                $insertImage['message'] = "Couldn't upload image!";
                $responseMessage = App_Response::alertResponse(@$insertImage['message'], 'danger');
                $responseArray = array("success" => 0, "message" => (@$responseMessage));
            endif;
            echo @json_encode($responseArray);
        endif;
    endif;
    //---------------------------------------------------------------------------
    if (isset($requestMethodArray['ImageListView'])):
        $app_id = $requestMethodArray['app_id'];
        $app = $engine;
        $module = new Module_Class;
        require "inc/images_list.php";
    endif;
    //---------------------------------------------------------------------------
    if (isset($requestMethodArray['deleteImage'])):
        @$img_id = @$requestMethodArray['img_id'];
        @$module = new Module_Class;
        @$getImage = @$module->getRecord([
            "tbl_scheme" => 'app_products_images',
            "condition" => ['id' => @$img_id]
        ]);
        if (@$getImage['response'] === '200'):
            @$img_file = $getImage['dataArray'][0]['image_file'];
            @$deleteImage = $module->deleteRecord([
                "tbl_scheme" => 'app_products_images',
                "pk" => ['id' => @$img_id]
            ]);
            if (@$deleteImage['response'] === '200'):
                $unlink = @unlink('../../uploads/inventory/' . $img_file);
                if (@$unlink):
                    if (@$requestMethodArray['callback']['type'] == 'actionEvent'):
                        $requestMethodArray['callback'] += array("event" => '<script>' . $requestMethodArray['callback']['redirect'] . '</script>');
                    endif;
                    $deleteImage['message'] = "Image successfully deleted!";
                    $responseMessage = App_Response::alertResponse(@$deleteImage['message'], 'success');
                    $responseArray = array("success" => 1, "message" => (@$responseMessage), "callback" => @$requestMethodArray['callback']);
                endif;
            else:
                $deleteImage['message'] = "Couldn't delete image!";
                $responseMessage = App_Response::alertResponse(@$deleteImage['message'], 'danger');
                $responseArray = array("success" => 0, "message" => (@$responseMessage));
            endif;
        endif;
        echo @json_encode($responseArray);
    endif;
    //---------------------------------------------------------------------------
    if (isset($requestMethodArray['AppDataImport'])):
        $tbl_scheme = $requestMethodArray['tbl_scheme'];
        $store_id = $requestMethodArray['store_id'];
        $data_file = $_FILES['import-data-file'];
        $update = $requestMethodArray['update-request'];
        $primary_key = $requestMethodArray['primary-key'];
        @$remove_col_name = $requestMethodArray['remove-col-name'];
        $mapping = $requestMethodArray['data-import-mapping'];
        $exec_by = $requestMethodArray['created_by'];
        $csvMimes = array(
            'text/x-comma-separated-values',
            'text/comma-separated-values',
            'application/octet-stream',
            'application/vnd.ms-excel',
            'application/x-csv',
            'text/x-csv',
            'text/csv',
            'application/csv',
            'application/excel',
            'application/vnd.msexcel',
            'text/plain'
        );

        if (in_array($data_file['type'], $csvMimes)):

            if (($data_file["size"] > 2000000)):
                $responseArray['message'] = App_Response::alertResponse('CSV File size is too large.', 'danger');
            else:

                if ($update == 1 && $primary_key == ""):

                    $responseArray['message'] = App_Response::alertResponse("Update missing primary column selection key", 'danger');

                else:

                    if (@$mapping == "" || @$mapping == ","):
                        $responseArray['message'] = App_Response::alertResponse("Import missing table column mapping", 'danger');
                    else:

                        $arrEncode = (rtrim("{" . $mapping, ',')) . '}';
                        $mapArray = json_decode($arrEncode);
                        //$mapArray += array("store_id" => $store_id);
                        $strings = str_split("ABCDEFGHIJKLMNOPQRSTUVWXYZ");
                        $newMapArray = array();
                        foreach ($mapArray as $field => $col):
                            if ($col !== "" && $field !== ""):
                                $newMapArray += array($field => array_search($col, $strings));
                            endif;
                        endforeach;

                        $csvFile = fopen($data_file['tmp_name'], 'r');

                        if (@$remove_col_name == 1):
                            fgetcsv($csvFile);
                        endif;

                        $con = 0;
                        $app_inventory[] = ["store_id" => $store_id];
                        //print_r($newMapArray);
                        $app_products = [];
                        $app_products += array("tbl_scheme" => 'app_products');
                        $ln1 = "";
                        $val1 = "";
                        while (($line = fgetcsv($csvFile)) !== FALSE) {
                            foreach ($newMapArray as $field_col => $map_col):
                                if ($field_col === 'name' || $field_col == 'sku_barcode' || $field_col == 'category_id'):
                                    $ln1 .= $field_col . ', ';
                                    $val1 .= "'" . $line[$map_col] . "'" . ',';
                                    if ($update !== 1):
                                        echo $sql = "INSERT INTO app_products (" . rtrim($ln1, ', ') . ") VALUES (" . $val1 . ") ";
                                        // $exeSQL = Data_Access::execSQL($sql);
                                    endif;
                                    $app_products += array($field_col => $line[$map_col]);
                                //@$fn . '=' . $ln . '<br>';
                                else:
                                    $app_inventory[] = array($field_col => $line[$map_col]);
                                endif;
                            endforeach;


                        }
                        echo $ln1;
                        echo $val1;
                        //insert
                        $param = [
                            "app_products" => $app_products,
                            "app_inventory" => $app_inventory,
                        ];
                        //$module->createInventoryItem($param);
                        //echo json_encode($app_products, JSON_PRETTY_PRINT);
                        //print_r($app_inventory);
                    endif;
                endif;
            endif;
        else:
            $responseArray['message'] = App_Response::alertResponse('Please upload a valid CSV file.', 'danger');
        endif;


        //echo "We here";
        //$app_id = $requestMethodArray['app_id'];
        //$app = $engine;
        // $module = new Module_Class;
        //   require "inc/images_list.php";

        echo @$responseArray['message'];
    endif;
endif;