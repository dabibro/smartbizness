<?php
$record = dbQuery("SELECT * FROM app_cabinets ORDER BY cabinet ASC");

if (isset($_GET['edit-cabinet']) && $_GET['edit-cabinet'] != "") {
    $edit = dbFetchAssoc(dbQuery("SELECT * FROM app_cabinets WHERE id = '" . $_GET['edit-cabinet'] . "' "));
}
?>
<div id="responses"></div>
<div class="row">
    <div class="col-md-5 col-lg-4 ">
        <div class="x_panel card shadow-sm">
            <div class="x_title">
                <span class="title"> <i class="fal fa-edit"></i> Locations Record </span>
            </div>
            <div class="x_content">
                <div id="result"></div>
                <form method="post" class="submit-settings" novalidate>
                    <div class="form-group">
                        <label>Location Name/Code</label>
                        <input name="cabinet" type="text" required class="form-control" id="cabinet"
                               placeholder="Location Name/Code" autocomplete="off"
                               value="<?php echo @$edit['cabinet']; ?>">
                        <div class="invalid-feedback">Enter Location Name/Code</div>
                    </div>
                    <div class="form-group">
                        <label>Description</label>
                        <textarea name="description" rows="3" class="form-control" id="description"
                                  placeholder="Location Description"><?php echo @$edit['description']; ?></textarea>
                    </div>
                    <hr>
                    <button class="btn btn-primary save-btn" type="submit"><i class="fal fa-check-circle"></i> Submit
                    </button>
                    <?php if (!isset($edit)) { ?>
                        <input type="hidden" value="1" name="submit-cabinet"/>
                    <?php } else { ?>
                        <a class="btn btn-danger" href="?p=app-mgmt"><i class="fal fa-times"></i> Cancel </a>
                        <input type="hidden" value="2" name="submit-cabinet"/>
                        <input type="hidden" name="id" value="<?php echo @$edit['id'] ?>" id="id"/>
                    <?php } ?>
                </form>
            </div>
        </div>
    </div>
    <div class="col-lg-8 col-md-7">
        <div class="x_panel card shadow-sm">
            <div class="x_title">
                <span class="title"> <i class=" fa fa-columns"></i> Location Measurements</span>
            </div>
            <div class="x_content">
                <table class="table table-striped dataTable no-footer">
                    <thead>
                    <tr>
                        <th width="10">#</th>
                        <th>Location/Code</th>
                        <th>Description</th>
                        <th width="20"></th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php
                    $index = 0;
                    while ($dn = dbFetchAssoc($record)): $index++; ?>
                        <tr class="data-btn">
                            <td>
                                <?php echo $index; ?>
                            </td>
                            <td>
                                <?php echo $dn['cabinet']; ?>
                            </td>
                            <td>
                                <?php echo $dn['description']; ?>
                            </td>
                            <td width="10%" nowrap="nowrap">
                                <div class="btn-group">
                                    <a class="btn btn-sm btn-primary"
                                       href="?p=app-mgmt&&edit-cabinet=<?php echo $dn['id'] ?>" title=" Edit Record"
                                       data-toggle="tooltip"><i class="fal fa-edit"></i></a>

                                    <a class="btn btn-sm btn-primary" href="#" title=" Delete Record"
                                       data-toggle="tooltip"
                                       onclick="javascript:confirmRequest('<?php echo $dn['id'] . 'user'; ?>', <?php echo $dn['id']; ?>, 'Are you sure you want to delete this record', 'delete-cabinet');"><span
                                                class="fal fa-trash"></span></a>
                                </div>

                            </td>
                        </tr>
                    <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
