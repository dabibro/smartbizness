<?php

$record = dbQuery("SELECT * FROM app_discounts ORDER BY title ASC");

if (isset($_GET['edit-discount']) && $_GET['edit-discount'] != "") {
    $edit = dbFetchAssoc(dbQuery("SELECT * FROM app_discounts WHERE id = '" . $_GET['edit-discount'] . "' "));
}
?>
<div id="responses"></div>

<div class="row">
    <div class="col-md-5 col-lg-4">
        <div class="x_panel card shadow-sm">
            <div class="x_title">
                <span class="title"> <i class="fal fa-edit"></i> Discount Record </span>
            </div>
            <div class="x_content">
                <div id="result"></div>
                <form method="post" class="submit-settings" novalidate>

                    <div class="form-group">
                        <label>Discount Description</label>
                        <input name="title" type="text" required class="form-control br-0" id="title"
                               placeholder="Discount Description" autocomplete="off"
                               value="<?php echo @$edit['title']; ?>">
                        <div class="invalid-feedback">Enter discount description</div>
                    </div>
                    <div class="form-group">
                        <label>Discount Value</label>
                        <div class="input-group">
                            <input name="discount" type="text" required class="form-control num br-0" id="discount"
                                   placeholder="Discount Value" autocomplete="off"
                                   value="<?php echo @$edit['discount']; ?>">
                            <span class="input-group-prepend">
                            <span class="input-group-text">
                                <i class="fal fa-percent"></i>
                            </span>
                        </span>
                            <div class="invalid-feedback">Enter discount value</div>
                        </div>

                    </div>
                    <hr>
                    <button class="btn btn-primary save-btn pl-3 pr-3" type="submit"><i class="fal fa-check-circle"></i>
                        Submit
                    </button>
                    <?php if (!isset($edit)) { ?>
                        <input type="hidden" value="1" name="submit-discount"/>
                    <?php } else { ?>
                        <a class="btn btn-danger" href="?p=app-mgmt&&discounts"><i class="fal fa-times"></i> Cancel </a>
                        <input type="hidden" value="2" name="submit-discount"/>
                        <input type="hidden" name="id" value="<?php echo @$edit['id'] ?>" id="id"/>
                    <?php } ?>
                </form>
            </div>
        </div>
    </div>
    <div class="col-lg-8 col-md-7">
        <div class="x_panel card shadow-sm">
            <div class="x_title">
                <span class="title"> <i class=" fa fa-percent"></i> Discounts</span>
            </div>
            <div class="x_content">
                <table class="table table-striped dataTable no-footer">
                    <thead>
                    <tr>
                        <th width="10">#</th>
                        <th>Description</th>
                        <th>Discount Value</th>
                        <th width="20">&nbsp;</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $index = 0;
                    if (dbNumRows($record) == 0) { ?>
                        <tr>
                            <td colspan="4" class="text-center">No data available in table</td>
                        </tr>
                    <?php } else { ?>
                        <?php while ($dn = dbFetchAssoc($record)): $index++; ?>
                            <tr class="data-btn">
                                <td>
                                    <?php echo $index; ?>
                                </td>
                                <td>
                                    <?php echo $dn['title']; ?>
                                </td>
                                <td>
                                    <?php echo $dn['discount']; ?>%
                                </td>
                                <td width="10%" nowrap="nowrap">
                                    <div class="btn-group">
                                        <a class="btn btn-sm btn-primary"
                                           href="?p=app-mgmt&&discounts&&edit-discount=<?php echo $dn['id'] ?>"
                                           title=" Edit Record" data-toggle="tooltip"><i class="fal fa-edit"></i></a>
                                        <a class="btn btn-sm btn-primary" href="#" title=" Delete Record"
                                           data-toggle="tooltip"
                                           onclick="javascript:confirmRequest('<?php echo $dn['id'] . 'user'; ?>', <?php echo $dn['id']; ?>, 'Are you sure you want to delete this record?', 'delete-discount');"><span
                                                    class="fal fa-trash"></span></a>
                                    </div>

                                </td>
                            </tr>
                        <?php endwhile;

                    } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
