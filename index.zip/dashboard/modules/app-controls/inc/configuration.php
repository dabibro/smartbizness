<style>
    label.cabinet {
        display: block;
        cursor: pointer;
    }

    label.cabinet input.file {
        position: relative;
        height: 100%;
        width: auto;
        opacity: 0;
        -moz-opacity: 0;
        filter: progid:DXImageTransform.Microsoft.Alpha(opacity=0);
        margin-top: -30px;
    }

    #upload-demo {
        width: 250px;
        height: 250px;
        padding-bottom: 25px;
    }

    figure figcaption {
        position: absolute;
        bottom: 0;
        color: #fff;
        width: 100%;
        padding-left: 9px;
        padding-bottom: 5px;
        text-shadow: 0 0 10px #000;
    }
</style>
<h4 class="title mb-4"><i class="fal fa-wrench"></i> System Configurations</h4>
<hr>

<!--<?php //require 'plugins/img-cropper/cropper.php'; ?>

<ul class="nav nav-tabs" id="myTab" role="tablist">
    <li class="nav-item">
        <a class="nav-link active" id="home-tab" data-toggle="tab" href="#home" role="tab" aria-controls="home"
           aria-selected="true"> <i class="fal fa-cogs"></i> Configurations</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" id="profile-tab" data-toggle="tab" href="#profile" role="tab" aria-controls="profile"
           aria-selected="false"><i class="fal fa-user-shield"></i> Software Licence</a>
    </li>
</ul>
<div class="tab-content pt-3 x_content" id="myTabContent">
    <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
        <div id="responses"></div>
        <form method="post" class="submit-settings" enctype="multipart/form-data" novalidate>
            <div class="alert alert-danger hide"></div>
            <h5><i class="fal fa-store"></i> Business Information</h5>
            <div class="row mt-3">
                <div class="col-12 col-lg-3">
                    <div class="card pt-3 border-0 bg-transparent" style="width: 300px;">
                        <div class="p-images m-auto"
                             style="width:230px; height:230px; cursor:pointer">
                            <?php if (!file_exists('files/shop-logo.png')) { ?>
                                <img id="shop_logo" style="width: auto; max-width:100%; height: auto; max-height:100%;"
                                     src="<?php echo WEB_ROOT . 'files/app-logo.png'; ?>"
                                     onClick="$('.item-img').click();"
                                     class="card-img-top rounded-circle shadow p-2"/>
                            <?php } else { ?>
                                <img id="shop_logo" style="width: auto; max-width:100%; height: auto; max-height:100%;"
                                     src="<?php echo WEB_ROOT . 'files/shop-logo.png'; ?>"
                                     onClick="$('.item-img').click();"
                                     class="card-img-top rounded-circle shadow p-2"/>
                            <?php } ?>
                        </div>
                        <div class="card-body text-center">
                            <input type="file" class="item-img file center-block hide" name="file_photo"/>
                            <a href="#" class="btn btn-primary"
                               onClick="$('.item-img').click();"> <i
                                        class="fal fa-file-upload"></i> Choose Logo</a>
                            <?php if (@$appinfo['app_logo'] != 's') { ?>
                                <a href="#" onClick="removeLogo()" class="btn btn-danger"><i class="fal fa-sync"></i>
                                    Default</a>
                            <?php } ?>
                            <input name="Shop_logo" type="file" class="form-control hide" id="ShopLogo"
                                   onchange="readURL(this);"/>

                        </div>
                    </div>
                </div>
                <div class="col-12 col-lg-9">
                    <div class="row">
                        <div class="col-6">
                            <h5><i class="fal fa-info-circle"></i> Basic Information</h5>
                            <hr>
                            <div class="form-group">
                                <label for="app_currency">Business Name</label>
                                <input name="app_shop" type="text" class="form-control " id="app_shop"
                                       value="<?php echo $appinfo['app_shop'] ?>" required
                                       placeholder="Shop Name">
                            </div>
                            <div class="form-group">
                                <label for="">Business Description</label>
                                <textarea class="form-control" rows="6" placeholder="Businesss Description"
                                          name="shop_description"><?php echo $appinfo['shop_description'] ?></textarea>
                            </div>
                        </div>
                        <div class="col-6">
                            <h5><i class="fal fa-map-marker-alt"></i> Contact Information</h5>
                            <hr>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="app_currency">Contact Phone #</label>
                                        <input name="shop_mobile" type="text" required class="form-control "
                                               id="shop_mobile" placeholder="Shop Phone #"
                                               value="<?php echo $appinfo['shop_mobile'] ?>">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="">Contact Email</label>
                                        <input name="shop_email" type="text" class="form-control " id="shop_email"
                                               placeholder="Shop Email Address"
                                               value="<?php echo $appinfo['shop_email'] ?>">
                                    </div>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="shop_address">Business Address</label>
                                <textarea name="shop_address" rows="2" required class="form-control "
                                          id="shop_address"
                                          placeholder="Shop Address"><?php echo $appinfo['shop_address'] ?></textarea>
                            </div>
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="app_currency">Web Address</label>
                                        <input name="shop_website" type="text" class="form-control "
                                               id="shop_website" placeholder="Shop Web Address"
                                               value="<?php echo $appinfo['shop_website'] ?>">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
            <div class="row">
                <div class="col-6">
                    <h5><i class="fal fa-sliders-h"></i> Product Options</h5>
                    <hr>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="app_currency">Currency</label>
                                <input name="app_currency" type="text" required class="form-control "
                                       id="app_currency" placeholder="Currency"
                                       value="<?php echo $appinfo['app_currency'] ?>">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for=""><a href="#" class=""><i
                                                class="fal fa-question-circle"></i></a> Markup Percentage % </label>
                                <input name="markup" type="text" required class="form-control " id="markup"
                                       placeholder="Item Markup %" value="<?php echo $appinfo['markup'] ?>">
                            </div>
                        </div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-6">
                            <div style="font-size: 14px;">
                                <p>
                                <span class="float-left p-1">
                                    <a href="#"><i class="fal fa-question-circle"></i></a> Allow sales below stock level
                                </span>
                                    <?php if ($appinfo['pos_sale_out_of_stock'] == 0) { ?>
                                        <a href="#" class="float-right" title="On" data-toggle="tooltip"
                                           onclick="toggleTblValue('app_config', 'pos_sale_out_of_stock', '1', '', '');"><i
                                                    class="fal fa-toggle-off fa-2x"></i></a>
                                    <?php } else { ?>
                                        <a href="#" class="float-right" title="Off" data-toggle="tooltip"
                                           onclick="toggleTblValue('app_config', 'pos_sale_out_of_stock', '0', '', '');"><i
                                                    class="fal fa-toggle-on fa-2x"></i></a>
                                    <?php } ?>
                                </p>
                            </div>
                        </div>
                    </div>
                    <h5><i class="fal fa-lock"></i> Login Options</h5>
                    <hr>
                    <div class="row">

                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="">Login Trails</label>
                                <input name="login_trail" type="text" required class="form-control "
                                       id="login_trail" placeholder="Login Trails"
                                       value="<?php echo $appinfo['login_trail'] ?>">
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="form-group" style="font-size: 14px;">
                                <label for="">&nbsp;</label>
                                <p>
                                    <span class="float-left p-1"> <a href="#"><i class="fal fa-question-circle"></i></a> Allow multiple login</span>
                                    <?php if ($appinfo['multiple_login'] == 0) { ?>
                                        <a href="#" class="float-right" title="On" data-toggle="tooltip"
                                           onclick="toggleTblValue('app_config', 'multiple_login', '1', '', '');"><i
                                                    class="fal fa-toggle-off fa-2x"></i></a>
                                    <?php } else { ?>
                                        <a href="#" class="float-right" title="Off" data-toggle="tooltip"
                                           onclick="toggleTblValue('app_config', 'multiple_login', '0', '', '');"><i
                                                    class="fal fa-toggle-on fa-2x"></i></a>
                                    <?php } ?>
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-6">
                    <h5><i class="fal fa-print"></i> Printer Options</h5>
                    <hr>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label><a href="#" class=""><i
                                                class="fal fa-question-circle"></i></a> Receipt Template </label>
                                <select class="form-control select2" name="receipt_temp" id="receipt_temp"
                                        required>
                                    <option value="">-- Select Template --</option>
                                    <?php
$typeArray = array("Type 1");
$arrlength = count($typeArray);
$x = 0;
while ($x < $arrlength) {
    ?>
                                        <option value="<?php echo $typeArray[$x]; ?>" <?php if ($appinfo['receipt_temp'] == @ $typeArray[$x]) {
        echo 'selected';
    } ?>>
                                            <?php echo $typeArray[$x]; ?>
                                        </option>
                                        <?php $x++;
} ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Receipt Printer Size</label>
                                <select class="form-control select2" name="printer_size" id="printer_size"
                                        required>
                                    <option value="">-- Select Printer Size--</option>
                                    <?php
$typeArray = array("80mm");
$arrlength = count($typeArray);
$x = 0;
while ($x < $arrlength) {
    ?>
                                        <option value="<?php echo $typeArray[$x]; ?>" <?php if ($appinfo['printer_size'] == @ $typeArray[$x]) {
        echo 'selected';
    } ?>>
                                            <?php echo $typeArray[$x]; ?>
                                        </option>
                                        <?php $x++;
} ?>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="form-group mt-3">
                        <label for="">Receipt Footer</label>
                        <?php include('plugins/basic-editor-toolbar.php') ?>
                        <div id="editor-one" class="editor-wrapper note p-2"
                             style="min-height: 90px !important; max-height: 60px !important;  border-radius: 0; overflow-x:hidden; ">
                            <?php echo htmlspecialchars_decode(@$appinfo['app_receipt_footer']); ?>
                        </div>
                        <textarea class="form-control hide" name="receipt_footer" id="note_editor"
                                  rows="5"><?php echo @$appinfo['app_receipt_footer']; ?></textarea>


                    </div>
                </div>
            </div>
            <input type="hidden" name="AppData" value="1">
            <hr>
            <div class="btn-group">
                <button class="btn btn-primary save-btn pl-3 pr-3" type="submit"><i class="fal fa-save"></i> Save Changes
                </button>
            </div>

        </form>
    </div>
    <div class="tab-pane fade show " id="profile" role="tabpanel" aria-labelledby="profile-tab">

        <div class="row">
            <div class="col-7 m-auto">
                <div class="card shadow-sm border-0">
                    <div class="card-body">
                        <h6 class="mt-0"><i class="fal fa-info-circle"></i> Activation Info</h6>
                        <hr>
                        <div class="alert alert-success p-2"><span class="badge badge-success p-1"><i
                                        class="fal fa-trophy"></i>
                            Registered: </span> This copied of application is currently licensed to:
                        </div>
                        <div class="row">
                            <div class="col-md-8">
                                <div class="form-group">
                                    <div class="input-group">
                                        <div class="input-group-append">
                                            <span class="input-group-text">Client Name:</span>
                                        </div>
                                        <input type="text" class="form-control" readonly
                                               value="<?php echo $appinfo['app_shop']; ?>">
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <div class="input-group">
                                        <div class="input-group-append">
                                            <span class="input-group-text">License Expiry:</span>
                                        </div>
                                        <input type="text" class="form-control" readonly
                                               value="<?php echo $license['expiry_date']; ?>">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-4 m-auto text-center">
                                <div class="card border-0">
                                    <div class="card-body">
                                        <h4 class="text-muted">DAY(S) LEFT</h4>
                                        <h2 class="text-success"><?php echo str_ireplace('+', '', dateDiffDays($license['expiry_date'], $license['current_date'])); ?></h2>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-6">
                                <div class="form-group">
                                    <div class="input-group">
                                        <div class="input-group-append">
                                            <span class="input-group-text">Email Address:</span>
                                        </div>
                                        <input type="text" class="form-control" readonly
                                               value="<?php echo $appinfo['shop_email']; ?>">
                                    </div>
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="form-group">
                                    <div class="input-group">
                                        <div class="input-group-append">
                                            <span class="input-group-text">Activation Code:</span>
                                        </div>
                                        <input type="text" class="form-control" readonly
                                               value="<?php echo $license['activation_code']; ?>">
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>

</div>
</div>

<!-- cropper loader  -->
<div class="modal fade" id="cropper-loader" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog" role="document" style="max-width: 350px !important; margin: 3rem auto;">
        <div class="modal-content x_panel bg-light">
            <div class="modal-body card-body text-center  p-3" id="cropper-loader-contents">
                <div id="upload-demo" class="center-block"></div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fal fa-times-circle"></i>
                    Close
                </button>
                <button type="button" id="cropImageBtn" class="btn btn-primary"><i class="fal fa-save"></i> Crop & Save
                </button>
            </div>
        </div>
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->
