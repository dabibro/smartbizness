<?php
/**
 * Created by PhpStorm.
 * User: Dauda Ibrahim
 * Date: 8/21/2020
 * Time: 7:15 AM
 */
$modulePath = @$appSwitcher->modulePath($AppModule);
$file = '../plugins/gps-tracker/tracker.php';
if (file_exists("../" . $file)):
    require '../../plugins/gps-tracker/Plugin_Class.php';
    $plugin = new Plugin_Class;
endif;
$pluginPath = $app->webRoot . "plugins/gps-tracker/";
$param = [
    "pluginPath" => $pluginPath,
    "webRoot" => $app->webRoot,
    "vendors" => $app->vendors,
    "assets" => $app->assets
];

?>
<script src="<?php echo $modulePath ?>js.js"></script>
<input type="hidden" value="<?php echo $modulePath; ?>" id="ModulePath" readonly>
<div class="row" id="manage-tracker">
    <div class="col-3">
        <div class="card card-light elevation-2">
            <div class="card-header h6 p-2"><i class="fal fa-map"></i> Tracker</div>
            <div class="card-body">
                <form action="<?php echo $file . '?param=' . urlencode(json_encode($param)); ?>" method="post"
                      target="MapFrame" id="filterForm">
                    <label class="text-muted w-100">Tracker Query <span class="float-right"><label><input
                                        type="checkbox" name="trackerQuery[Checkout]" value="1"> CheckOut</label></span></label>
                    <div class="form-group">
                        <label for="">Country</label>
                        <select name="trackerQuery[country]" class="form-control form-control-sm select2"
                                id="country"
                                onchange='dropDownList("{\"request\":\"dropDownList\",\"pkField\":\"country_id\",\"pk\":"+ this.value +",\"target_scheme\":\"app_states\",\"key\":\"id\",\"label\":\"name\",\"target\":\"states\"}")'>
                            <option value="">-- Country --</option>
                            <?php
                            $countryParam = array("tbl_scheme" => 'app_countries', "condition" => '');
                            $listArray = $plugin->getRecord($countryParam);
                            $dropDownArray = array();
                            foreach ($listArray['dataArray'] as $countries):
                                echo $app->dropDownList($countries['id'], $countries['name'], @$country);
                            endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="">State/Province</label>
                        <select name="trackerQuery[state]" class="form-control form-control-sm select2"
                                id="states"
                                onchange='dropDownList("{\"request\":\"dropDownList\",\"pkField\":\"state\",\"pk\":"+ this.value +",\"target_scheme\":\"app_stores\",\"key\":\"app_id\",\"label\":\"store_name\",\"target\":\"store\"}")'>
                            <option value="">-- State/Provience --</option>
                            <?php if (@$getUpdate['response'] === "200"):
                                $listArray = $plugin->getRecord(["tbl_scheme" => 'app_states', "condition" => ["country_id" => $country]]);
                                foreach ($listArray['dataArray'] as $states):
                                    echo $app->dropDownList($states['id'], $states['name'], $state);
                                endforeach; endif; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="">Store/Location</label>
                        <select name="trackerQuery[store_id]"
                                class="form-control form-control-sm select2"
                                id="store"
                                onchange='dropDownList("{\"request\":\"dropDownList\",\"pkField\":\"store_id\",\"pk\":\""+ this.value +"\",\"target_scheme\":\"app_users\",\"key\":\"user_id\",\"label\":\"username\",\"target\":\"user_list\"}")'>
                            <option value="">-- Store/Location --</option>
                            <?php
                            $storeParam = array("tbl_scheme" => 'app_stores', "condition" => ["active_status" => 1]);
                            $listArray = $plugin->getRecord($storeParam);
                            $dropDownArray = array();
                            foreach ($listArray['dataArray'] as $store):
                                echo $app->dropDownList($store['app_id'], $store['store_name'], '');
                            endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="">Track User</label>
                        <select name="trackerQuery[user_id]"
                                class="form-control form-control-sm select2"
                                id="user_list">
                            <option value="">-- Track User --</option>
                            <?php
                            $storeParam = array("tbl_scheme" => 'app_users', "condition" => ["activation" => 1, "delete_status" => 0]);
                            $listArray = $plugin->getRecord($storeParam);
                            $dropDownArray = array();
                            foreach ($listArray['dataArray'] as $store):
                                echo $app->dropDownList($store['user_id'], $store['username'], '');
                            endforeach; ?>
                        </select>
                    </div>
                    <hr>
                    <button class="btn btn-sm btn-default"><i class="fal fa-map-marker-question"></i> Submit Query
                    </button>
                    <span class="float-right">[ <a href="javascript:void(0)"
                                                   onclick="fetchURL('')">Reset Filter</a> ]</span>
                </form>
            </div>
        </div>
    </div>
    <div class="col-9">
        <iframe class="elevation-1 vh-100" src="<?php echo $file . '?param=' . urlencode(json_encode($param)); ?>"
                name="MapFrame" id="MapFrame"
                style="width: 100%; height: 500px; border: 0"></iframe>
    </div>
</div>
 