/**
 * Created by DTMGS Limited.
 * User: Dauda Ibrahim
 * Date: 6/21/2020
 * Time: 10:24 PM
 * File: Manage Vendors Module js
 */
//------------------------------------------------------------------------
var modulePath = $("#ModulePath").val();
//------------------------------------------------------------------------
var AppDashboard = document.getElementById("dashboard-page");
//------------------------------------------------------------------------
$('.AppForm').bootstrap3Validate(function (e, data) {
    "use strict";
    e.preventDefault();
    var actionButton = $("#" + this.id + ' .actionButton').html();
    var formId = this.id;
    $("#" + this.id + ' .actionButton').html('<i class="fal fa-spin fa-spinner"></i> Processing...');
    $.ajax({
        url: modulePath + "ajaxRequest.php",
        type: "POST",
        data: new FormData(this),
        contentType: false,
        cache: false,
        processData: false,
        success: function (data) {
            //alert(data);
            // return false;
            var response;
            response = JSON.parse(data);
            var success = response['success'];
            var message = response['message'];
            if (success && success == 1) {
                $("#" + formId + " #ModuleResponse").html(message);
                $("#" + formId + ' .actionButton').html(actionButton);
                if (response['callback']['type'] === 'self') {
                    fetchURL("");
                } else if (response['callback']['type'] === 'modal') {
                    $("#modal-response").html(message);
                    $("#" + formId + ' .actionButton').html(actionButton);
                } else if (response['callback']['type'] === 'actionEvent') {
                    var actionEvent = response['callback']['event'];
                    $("#actionEvents").html(actionEvent);
                    $("#" + formId + ' .actionButton').html(actionButton);
                }
                // $("#" + formId)[0].reset();
            } else {
                if (response['callback']['type'] === 'self') {
                    // alert(formId);
                    $("#" + formId + " #ModuleResponse").html(message);
                }
                else {
                    $("#modal-response").html(message);
                }
                $("#" + formId + ' .actionButton').html(actionButton);
            }
        },
        error: function () {
        }
    });

});

//------------------------------------------------------------------------
function moduleRequest(param) {
    var moduleRequest = ('{' + decodeURIComponent(param) + '}');
    // alert(moduleRequest);
    var objJSON = JSON.parse(moduleRequest);
    if (objJSON['notification']['message'] !== "" && objJSON['confirmed'] == 1) {
        var confirmation = 1;
    }
    if (objJSON['callback']['type'] === "modal" && objJSON['modalParam'] != '') {
        //alert(objJSON['modalParam']['required']);
        var moduleLauncher = ({
            modalId: objJSON['modalParam']['modalId'],
            modalTitle: objJSON['modalParam']['modalTitle'],
            required: objJSON['modalParam']['required'],
            modalSize: objJSON['modalParam']['modalSize'],
            DataTable: objJSON['modalParam']['DataTable'],
        });
    }
    $.post(modulePath + 'ajaxRequest.php',
        objJSON
        , function (response) {

            if (confirmation != 1) {
                $("#ModuleResponse").html(response);
            } else {
                //alert(response);
                response = JSON.parse(response);
                var success = response['success'];
                var message = response['message'];

                if (success && success == 1) {
                    if (response['callback']['type'] === 'self') {
                        $("#ModuleResponse").html(message);
                        fetchURL("");
                    } else if (response['callback']['type'] === 'modal') {
                        $("#modal-response").html(message);
                        AppModalLoader(moduleLauncher);
                    } else if (response['callback']['type'] === 'actionEvent') {
                        var actionEvent = response['callback']['event'];
                        $("#actionEvents").html(actionEvent);
                        $(".actionEventResponse").html(message);
                    } else if (response['callback']['type'] === 'url') {
                        location.replace(response['callback']['redirect']);
                        fetchURL("");
                    }
                } else {
                    if (response['callback']['type'] === 'self') {
                        $("#ModuleResponse").html(message);
                    }
                    else {
                        $("#modal-response").html(message);
                    }
                }
            }
        });
}

//------------------------------------------------------------------------
function moduleEditRequest(param) {
    var moduleRequest = ('{' + decodeURIComponent(param) + '}');
    var objJSON = JSON.parse(moduleRequest);
    if (objJSON['target'] && objJSON['modalParam'] != '') {
        //alert(objJSON['request']);
        AppModalLoader({
            modalId: objJSON['modalParam']['modalId'],
            modalTitle: objJSON['modalParam']['modalTitle'],
            required: objJSON['modalParam']['required'],
            modalRequest: {
                "request": objJSON['request'],
                "pkField": objJSON['pkField'],
                "pk": objJSON['pk'],
            },
            modalSize: objJSON['modalParam']['modalSize'],
            DataTable: objJSON['modalParam']['DataTable'],

        });
        return false;
    }
    //alert(objJSON['view']);
    var AppRequestPath;
    //var AppPath = document.getElementById("start-page");
    AppRequestPath = "handlers/AppAjaxRequest.php"
    $("#app-loader").html($('#AppLoader').html());
    //return false;
    $.post(AppRequestPath,
        {
            request: objJSON['request'],
            pkField: objJSON['pkField'],
            pk: objJSON['pk'],
            params: objJSON,
            AppRequest: encodeURIComponent(objJSON['view']),
        }, function (response) {

            $("#app-loader").html(response);

        });
}

//------------------------------------------------------------------------
$(".appAutoIDGen").on('click', function () {
    var elem = $("#" + this.id);
    var requestParam = elem.attr("AppId-AutoGen");
    AppIDAutoGen(requestParam);
});
//------------------------------------------------------------------------
$(".propToggle").on('click', function () {
    if (this.checked) {
        $("." + this.id).val(1);
    } else {
        $("." + this.id).val(0);
    }
});
//------------------------------------------------------------------------

$(".PHPPagination li .page-link ").on('click', function () {
    fetchURL(this.href);
});
//------------------------------------------------------------------------
var ManageSales = document.getElementById("manage-tracker");
if (ManageSales) {
    var sidebar = $("#dashboard-page").hasClass('sidebar-collapse');
    if (sidebar == false) {
        $('.sidebar-collapse-btn').click();
    }

}
//------------------------------------------------------------------------
$('#product_search').on('keyup', function () {
    $(".product_search").autocomplete({
        source: modulePath + 'pos/ajaxInventoryLookup.php'
    });
});

//----------------------------

$("#appFilterBtn").click(function (e) {
    e.preventDefault();
    var filterRequest = ($("#" + this.form.id).serializeArray());
    var obj = [];
    $.each(filterRequest, function (i, field) {
        obj.push('"' + field.name + '"' + ":" + '"' + field.value + '"' + "");
    });
    var moduleRequest = ('{' + decodeURIComponent(obj) + '}');
    var objJSON = JSON.parse(moduleRequest);
    AppRequestPath = "handlers/AppAjaxRequest.php"
    $.post(AppRequestPath, {
            filterRequest: objJSON,
            AppRequest: encodeURIComponent(objJSON['view'])
        },
        function (response) {
            $("#app-loader").html(response);
            // response = JSON.parse(response);
            // var success = response['success'];
            // var message = response['message'];
            //if (success && success == 1) {
            //   $("#ModuleResponse").html(message);
            //   if (response['callback'] === 'self') {
            //       fetchURL("");
            //   }
            // }
        });
});
