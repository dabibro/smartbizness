<?php
require "Module_Class.php";
$module = new Module_Class;
$modulePath = @$appSwitcher->modulePath($AppModule);
$req = $AppModuleRequest;
$view = $AppModuleView;
//----------------------------------------------------------------------------------
@$getAppId = explode('items/', $view);
if (isset($getAppId[1]) && $getAppId[1] != "") {
    @$view = 'items/';
    @$subView = trim($getAppId[1], '/');
}
//----------------------------------------------------------------------------------
@$getViewAppId = explode('view/', $view);
if (isset($getViewAppId[1]) && $getViewAppId[1] != "") {
    @$view = 'view/';
    @$AppId = trim($getViewAppId[1], '/');
}
//----------------------------------------------------------------------------------
@$getPOSView = explode('pos/', $view);
if (isset($getPOSView[1]) && $getPOSView[1] != "") {
    @$view = 'pos/';
    @$viewRequest = $getPOSView[1];
}
//----------------------------------------------------------------------------------
@$getSalesTransactsView = explode('sales-transacts/', $view);
if (isset($getSalesTransactsView[1]) && $getSalesTransactsView[1] != "") {
    @$view = 'sales-transacts/';
    @$viewRequest = $getSalesTransactsView[1];
}
//----------------------------------------------------------------------------------
@$getQuotationsView = explode('quotations/', $view);
if (isset($getQuotationsView[1]) && $getQuotationsView[1] != "") {
    @$view = 'quotations/';
    @$viewRequest = $getQuotationsView[1];
}
?>
<script src="<?php echo $modulePath ?>js.js"></script>
<input type="hidden" value="<?php echo $modulePath; ?>" id="ModulePath" readonly>
<div class="card card-primary card-outline card-outline-tabs" id="manage-sales">
    <div class="card-header p-0 border-bottom-0">
        <ul class="nav nav-tabs app-menu" id="manage-users-tabs" role="tablist">
            <li class="nav-item">
                <a class="nav-link <?php if ($view == 'items/'): echo 'active'; endif; ?>"
                   href="#/sales-point/items/" onclick="fetchURL(this.href)"><i class="fal fa-table"></i> Products
                    Record</a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php if ($view == 'pos/'): echo 'active'; endif; ?>"
                   href="#/sales-point/pos/" onclick="fetchURL(this.href)"><i class="fal fa-shopping-cart"></i> Sales
                    Point</a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php if ($view == 'sales-transacts/'): echo 'active'; endif; ?>"
                   href="#/sales-point/sales-transacts/" onclick="fetchURL(this.href)"><i class="fal fa-chart-line"></i>
                    Sales Transactions</a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php if ($view == 'quotations/'): echo 'active'; endif; ?>"
                   href="#/sales-point/quotations/" onclick="fetchURL(this.href)"><i class="fal fa-file-invoice"></i>
                    Manage
                    Quotations</a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php if ($req == 'create-store/'): echo 'active'; endif; ?>"
                   href="#/sales-point/options/" onclick="fetchURL(this.href)"><i class="fal fa-cog"></i> Sales Point
                    Options</a>
            </li>
        </ul>
    </div>
    <div class="card-body">
        <div class="tab-content" id="manage-users-tabContent">
            <div class="tab-pane fade <?php if ($view == 'items/'): echo 'active show'; endif; ?>"
                 id="users-tab" role="tabpanel" aria-labelledby="tabs-users-tabs">
                <?php if ($view == 'items/'): require "inc/products.php";endif; ?>
            </div>
            <div class="tab-pane fade <?php if ($view == 'pos/'): echo 'active show'; endif; ?>"
                 id="create-new-tab" role="tabpanel" aria-labelledby="tabs-create-new-tab">
                <?php if ($view == 'pos/'): require "pos/pos.php"; endif; ?>
            </div>
            <div class="tab-pane fade <?php if ($view == 'sales-transacts/'): echo 'active show'; endif; ?>"
                 id="users-tab" role="tabpanel" aria-labelledby="tabs-users-tabs">
                <?php if ($view == 'sales-transacts/'): require "inc/sales_transacts.php";endif; ?>
            </div>
            <div class="tab-pane fade <?php if ($view == 'quotations/'): echo 'active show'; endif; ?>"
                 id="users-tab" role="tabpanel" aria-labelledby="tabs-users-tabs">
                <?php if ($view == 'quotations/'): require "inc/quotations.php";endif; ?>
            </div>
        </div>
    </div>
    <!-- /.card -->
</div>

          