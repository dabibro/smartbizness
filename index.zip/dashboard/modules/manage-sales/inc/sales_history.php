<?php
//--------------------------------------------------------------------------------------------------
$store = "";
if (isset($auth['store_id']) && $auth['store_id'] != ""):
    $store = "AND store_id = '" . $auth['store_id'] . "' ";
endif;
//--------------------------------------------------------------------------------------------------
$condition = "";
//--------------------------------------------------------------------------------------------------
if (isset($_POST['filterRequest']) && $_POST['filterRequest'] !== NULL):
    $filterParam = $_POST['filterRequest'];
    if ($filterParam['search'] != ""):
        $search_query = trim($filterParam['search']);
        $condition = "AND transact_id LIKE '%" . $search_query . "%'";
        $condition .= "OR transact_type LIKE '%" . $search_query . "%' ";
        $condition .= "OR customer_type LIKE '%" . $search_query . "%' ";
        $condition .= "OR customer_id LIKE '%" . $search_query . "%' ";
        $condition .= "OR customer_name LIKE '%" . $search_query . "%' ";
        $condition .= "OR transact_by LIKE '%" . $search_query . "%' ";
        $condition .= "OR transact_date LIKE '%" . $search_query . "%'";
    else:
        $transact_type = @$filterParam['transact_type'];
        $customer_type = @$filterParam['customer_type'];
        $customer_id = @$filterParam['customer_id'];
        $cashier = @$filterParam['cashier_name'];
        $checkout_status = @$filterParam['checkout_status'];
        $start_date = @$filterParam['start_date'];
        $end_date = @$filterParam['end_date'];

        if ($transact_type != ""):
            $condition .= " AND transact_type = '$transact_type'";
        endif;
        if ($customer_type != ""):
            $condition .= " AND customer_type = '$customer_type'";
        endif;
        if ($customer_id != ""):
            $condition .= " AND customer_id = '$customer_id'";
        endif;
        if ($checkout_status != ""):
            $condition .= " AND checkout_status = '$checkout_status'";
        endif;
        if ($cashier != ""):
            $condition .= " AND transact_by = '$cashier'";
        endif;
        if ($start_date != "" && $end_date != ""):
            $condition .= " AND transact_date BETWEEN '$start_date' AND DATE_ADD('$end_date', INTERVAL 1 DAY)";
        endif;
    endif;

endif;

if (isset($viewRequest) && $viewRequest === "reversals/"):
    $condition = "AND transact_type = 'Return' ";
endif;

$paginate_exp = explode('?page=', $url);
if (isset($paginate_exp[1]) && $paginate_exp[1] != ""):
    $ipp_exp = explode('&ipp=', $paginate_exp[1]);
    if (isset($ipp_exp[0]) && $ipp_exp[0] != ""):
        define('page', $ipp_exp[0]);
    else:
    endif;
    if (isset($ipp_exp[1]) && $ipp_exp[1] != ""):
        define('ipp', $ipp_exp[1]);
    else:
    endif;
else:
    define('page', '');
    define('ipp', '');
endif;
define('self', '#/sales-point/sales-transacts/');
$pages = new Paginator_Class;
if (ipp != ""):
    $pages->default_ipp = ipp;
else:
    $pages->default_ipp = 50;
endif;
$sql_forms = Data_Access::execSQL("SELECT * FROM " . $app->dbScheme . ".app_transactions WHERE checkout_status = 1 " . $store . $condition . " ");
@$pages->items_total = $sql_forms['dataArray']->num_rows;
$pages->mid_range = 4;
$pages->paginate();

$sql = "SELECT * FROM " . $app->dbScheme . ".app_transactions WHERE checkout_status = 1  " . $store . $condition . " ORDER BY transact_date DESC " . $pages->limit . " ";
if (!($result = Data_Access::execSQL($sql))) {
    die(mysqli_error());
} else {
    @$recordsArray = Data_Access::fetchAssoc($result['dataArray'])['dataArray'];
}
?>
<div id="ModuleResponse"></div>
<div class="row marginTop mx-0">
    <div class="col-12 pl-0 paddingLeft pagerfwt">
        <?php if ($pages->items_total > 0) { ?>
            <?php echo $pages->display_pages(); ?>
            <?php echo $pages->display_items_per_page(); ?>
            <?php echo $pages->display_jump_menu(); ?>
        <?php } ?>
    </div>
    <div class="clearfix"></div>
    <hr>
</div>
<div class="table-responsive">
    <table class="table data-tables table-sm elevation-1">
        <?php if (@$filterParam != NULL): ?>
            <caption>Currently viewing filter record(s) [ <a href="javascript:void(0);" onclick="fetchURL('');"
                                                             class="small">Reset Filter</a> ]
            </caption>
        <?php else: ?>
            <caption>Viewing current month record(s)</caption>
        <?php endif; ?>
        <thead>
        <tr>
            <th>Reference #</th>
            <th>Transact Type</th>
            <th>Customer Name</th>
            <th>Product #</th>
            <th>Cost Amount <?php echo $biz->currency['currency']; ?></th>
            <th>Sale Amount <?php echo $biz->currency['currency']; ?></th>
            <th>Profit <?php echo $biz->currency['currency']; ?></th>
            <th>Transact By</th>
            <th></th>
            <th><i class="fal fa-cogs"></i></th>
        </tr>
        </thead>
        <tbody class="card-body">
        <?php
        if (isset($recordsArray) && $recordsArray != NULL):
            $cost_total = 0;
            $grand_total = 0;
            $profit_total = 0;
            foreach (@$recordsArray as $transactions): extract($transactions);
                @$product = $module->getRecord([
                    "tbl_scheme" => 'app_sales_products',
                    "condition" => [
                        "transact_id" => $transact_id,
                    ]
                ])['dataArray'];
                $transact_cost = 0;
                if ($product != NULL):
                    foreach ($product as $item):
                        @$cost = $module->getRecord([
                            "tbl_scheme" => "app_products",
                            "condition" => [
                                "app_id" => $item['product_id']
                            ]
                        ])['dataArray'][0]['price'];
                        @$transact_cost = $transact_cost + ($cost * $item['product_qty']);
                    endforeach;
                endif;
                @$profit = @$total_due - @$transact_cost;
                @$cost_total = @$cost_total + @$transact_cost;
                @$grand_total = @$grand_total + @$total_due;
                @$profit_total = @$profit_total + @$profit;
                ?>
                <tr>
                    <td><?php echo @$transact_id; ?></td>
                    <td><?php echo @trim(@$transact_type . ' Transact'); ?></td>
                    <td><?php if (@$customer_id != ""): echo @$customer_name; else: if (@$customer_name != ""): echo @$customer_name; else: echo "Walk In Customer"; endif; endif; ?></td>
                    <td><?php echo @count($product); ?></td>
                    <td><?php echo $app->valueSign(@number_format(@$transact_cost, 2)); ?></td>
                    <td><?php echo $app->valueSign(@number_format(@$total_due, 2)); ?></td>
                    <td><?php echo $app->valueSign(@number_format(@$profit, 2)); ?></td>
                    <td style="line-height: 15px;"><?php echo @$transact_by; ?></td>
                    <td class="text-muted"><?php echo @$transact_date; ?></td>
                    <td style="width:5%;" class="py-1" nowrap="nowrap">
                        <div class="btn-group-justify btn-group-sm float-right">
                            <?php if (@$total_due > 0): ?>
                                <button type="button" class="btn btn-default" title="Return"
                                        onclick='javascript: var obj = "<?php echo urlencode('"pk":"' . $transact_id . '","view":"/#/sales-point/pos/","request":"update","return":"1"'); ?>"; moduleEditRequest(obj)'>
                                    <i class="fal fa-box-up"></i></button>
                            <?php endif; ?>
                            <button type="button" class="btn btn-default" title="View Receipt"
                                    onClick="javascript:location.replace('#/sales-point/pos/print/<?php echo $transact_id; ?>/'); fetchURL('');">
                                <i class="fal fa-receipt"></i></button>
                            <button type="button" class="btn btn-default"
                                    onclick='javascript: var obj = "<?php echo urlencode('"className":"Module_Class","functionName":"deleteInventoryItem","tbl_scheme":"","pk":{"app_id":"' . @$transact_id . '"},"callback":{"type":"self","redirect":""},"notification":{"message":"Are you sure to delete this inventory record?","title":"Delete Warning"}'); ?>";  moduleRequest(obj);'
                                    title=" Edit Record"><i
                                        class="fal fa-trash-alt"></i>
                            </button>
                    </td>
                </tr>
            <?php endforeach; else: ?>
            <tr>
                <td colspan="9" align="center">No data available</td>
            </tr>
        <?php endif; ?>
        </tbody>
        <tfoot>
        <tr>
            <td colspan="4" align="right">TOTAL SALE <?php echo @$biz->currency['currency']; ?>:</td>
            <th><?php echo $app->valueSign(number_format(@$cost_total, 2)); ?></th>
            <th><?php echo $app->valueSign(number_format(@$grand_total, 2)); ?></th>
            <th colspan="4"><?php echo $app->valueSign(number_format(@$profit_total, 2)); ?></th>
        </tr>
        </tfoot>
    </table>
</div>
<div class="row marginTop mx-0">
    <div class="col-12 pl-0 paddingLeft pagerfwt">
        <?php if ($pages->items_total > 0) { ?>
            <?php echo $pages->display_pages(); ?>
            <?php echo $pages->display_items_per_page(); ?>
            <?php echo $pages->display_jump_menu(); ?>
        <?php } ?>
    </div>
    <div class="clearfix"></div>
    <hr>
</div>
