<?php
//require
require_once('inc/queries.php');
?>
<div id="responses"></div>
<div class="card x_panel shadow-sm ">
    <div class="x_title">
        <span class="title"><i class="fal fa-cube"></i> Items Sale History</span>
    </div>
    <div class="x_content">
        <div class="row mb-3">
            <div class="col-6">
                <button type="button" class="btn btn-primary dropdown-toggle px-4" data-toggle="collapse"
                        aria-expanded="false" data-target="#filterCriteria" aria-controls="filterCriteria">
                    <i class="fal fa-filter"></i> Filter Report
                </button>
                <div class="collapse px-3 py-3 card br-0 shadow-sm" aria-labelledby="dLabel" id="filterCriteria"
                     style="z-index: 1 !important; position: absolute;">
                    <form method="post">
                        <div class="form-group">
                            <input type="text" name="item-id" class="form-control item_search" placeholder="Item Name">
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group " id="str">
                                    <div class="input-group input-group-sm">
                                        <input type="text" class="form-control datepicker border-right-0"
                                               name="start_date"
                                               id="start_date" placeholder="Start Date" style="border-radius:0;"
                                               autocomplete="off">
                                        <span class="input-group-prepend">
                                <span class="input-group-text"><i class="fal fa-calendar-minus"></i></span>
                            </span>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group" id="stp">
                                    <div class="input-group input-group-sm">
                                        <input type="text" class="form-control datepicker border-right-0"
                                               name="stop_date"
                                               id="stop_date" placeholder="Stop Date" style="border-radius:0;"
                                               autocomplete="off">
                                        <span class="input-group-prepend">
                                <span class="input-group-text"> <i class="fal fa-calendar-plus"></i></span>
                            </span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <button class="btn btn-primary btn-block" type="submit"> Apply
                            Filter <i class="fal fa-angle-double-right"></i>
                        </button>
                        <input type="hidden" name="filter-transact" value="1">
                    </form>
                </div>
            </div>
            <div class="col-auto ml-auto text-right">
                <button class="btn btn-primary px-4" type="button"
                        onClick="javascript:location.replace('?p=items-sales-history&&daily=1&&date=<?php echo date('Y-m-d', time()); ?>')">
                    <i class="fal fa-chart-line"></i> Daily Sales
                    <input type="hidden" name="filter-transact" value="1">
                </button>
                <a href="?p=sales-report-print<?php if (isset($_POST['filter-transact'])) {
                    echo '&&start_date=' . $_POST['start_date'] . '&&stop_date=' . $_POST['stop_date'];
                } else if (isset($_GET['daily']) && $_GET['date'] != "") {
                    echo '&&start_date=' . $_GET['date'] . '&&stop_date=' . $_GET['date'];
                } ?>" class="btn btn-primary px-4"><i class="fal fa-print"></i> Print Report</a>
            </div>
        </div>
        <div id="transReport" class="table-responsive datatable-buttons">
            <div id="response"></div>
            <table class="table table-hover table-striped datatable-btn" style="font-size:12px;">
                <?php if (isset($_POST['filter-transact']) && $_POST['filter-transact'] == 1 || isset($_GET['daily'])) { ?>
                    <caption>Currently viewing filtered: [ <a href="?p=items-sales-history">Reset Filter</a> ]</caption>
                <?php } else {
                    echo "<caption>Currently viewing current day transactions</caption>";
                } ?>
                <thead>
                <tr>
                    <th width="10">#</th>
                    <th>Product Name</th>
                    <th>Category</th>
                    <th>Unit N</th>
                    <th>Stocking</th>
                    <th>Qty</th>
                    <th>Amount N</th>
                    <th>Date</th>
                </tr>
                </thead>
                <tbody>
                <?php $index = 0;
                $grand_total = 0;

                while ($dn = dbFetchAssoc($transact_result)): $index++;

                    $productInfo = getItemInfo($dn['product_id']);

                    //get replenishment
                    if ($start != "" && $stop != "") {

                    } else {
                        $replenishment = dbFetchAssoc( dbQuery("SELECT SUM(add_qty) as sum_qty 
                        FROM app_item_replenish_log 
                        WHERE item_id = '" . $dn['product_id'] . "' 
                        AND MONTH(CURRENT_TIMESTAMP) = MONTH(entry_date) GROUP BY item_id"));
                    }

                    $category = getItemCategory($productInfo['item_category']);

                    if ($productInfo['item_category'] == 0) {
                        $category = $category;
                    } else {
                        $category = $category['category'];
                    }

                    $grand_total = $grand_total + $dn['total_amount'];
                    ?>
                    <tr>
                        <td>
                            <?php echo $index; ?>
                        </td>
                        <td>
                            <?php echo $productInfo['item_name']; ?>
                        </td>
                        <td>
                            <?php echo $category; ?>
                        </td>
                        <td>
                            <?php echo number_format($dn['amount'], 2); ?>
                        </td>
                        <td>
                            <?php echo (int)$replenishment['sum_qty']; ?>
                        </td>
                        <td>
                            <?php echo $dn['product_qty']; ?>
                        </td>
                        <td>
                            <?php echo number_format($dn['total_amount'], 2); ?>
                        </td>


                        <td>
                            <?php echo $dn['entry_date'] ?>
                        </td>
                    </tr>

                <?php endwhile ?>

                </tbody>
                <tfoot>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th style="text-align: right">GRAND TOTAL</th>
                <th>
                    <?php echo number_format($grand_total, 2); ?>
                </th>
                <th></th>
                <th></th>
                </tfoot>
            </table>


        </div>
    </div>
    <!--Main content-->

</div> 

