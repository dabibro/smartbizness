<?php
if (@$requestMethodArray['request'] == "update" && @$requestMethodArray['pk'] != "" && @$requestMethodArray['pkField'] != ""):
    $pk = $requestMethodArray['pk'];
    $pkField = $requestMethodArray['pkField'];
    $getUpdateArray = array(
        "tbl_scheme" => 'app_promo',
        "condition" => [$pkField => $pk],
        "limit" => 1
    );
    $getUpdate = $module->getRecord($getUpdateArray);
    extract($getUpdate['dataArray'][0]);
else:
    $promo_code = $app->generateAppId('', '', 8, '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ');
endif;
?>
<div class="row">
    <div class="col-lg-4">
        <div class="card card-light elevation-1">
            <div class="card-header py-2 px-3">
                <i class="fal fa-edit"></i> Price/Promo Record
            </div>
            <div class="card-body">
                <div id="ModuleResponse"></div>
                <form action="" class="AppForm" id="promo-form">
                    <div id="ModuleResponse"></div>
                    <div class="row">
                        <div class="col-6 ml-auto">
                            <div class="form-group">
                                <label for="">Promo Code</label>
                                <input type="text" name="promo_code" class="form-control-sm form-control" readonly
                                       value="<?php echo @$promo_code; ?>">
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="w-100"><span class="required">*</span> Select Product <span
                                    class="float-right" id="sale-price"></span></label>
                        <input type="search" class="form-control form-control-sm product_search" id="product_search"
                               name="product_name" placeholder="Product Name/ID" required
                               value="<?php echo @$product_name; ?>">
                        <div class="invalid-feedback">* Required field</div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-4">
                            <div class="form-group mb-0">
                                <label><span class="required">*</span> Quantity</label>
                                <input type="text" required class="form-control form-control-sm num"
                                       name="quantity_limit"
                                       placeholder="Quantity" value="<?php echo @$quantity_limit; ?>">
                                <div class="invalid-feedback">* Required field</div>
                            </div>
                        </div>
                        <div class="col-md-8">
                            <div class="form-group mb-0">
                                <label><span class="required">*</span> Promo
                                    Price <?php echo $biz->currency['currency'] ?>
                                </label>
                                <input type="text" class="form-control form-control-sm num" required autocomplete="off"
                                       name="promo_price" placeholder="Promo Price"
                                       value="<?php echo @$promo_price; ?>">
                                <div class="invalid-feedback">* Required field</div>
                            </div>
                        </div>
                    </div>
                    <div class="form-group mb-2">
                        <div class="custom-control custom-switch">
                            <input type="checkbox" <?php if (@$time_based == 1): echo 'checked';endif; ?>
                                   class="custom-control-input propToggle" id="time_based">
                            <label class="custom-control-label pt-1" for="time_based"> Time based
                                <small class="text-muted">Specify Start & End date</small>
                            </label>

                            <input type="hidden" readonly name="time_based"
                                   class="time_based"
                                   value="<?php if (@$time_based == 1): echo 1; else: echo 0;endif; ?>">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Start Date</label>
                                <input type="text" class="form-control form-control-sm datepicker" name="start_date"
                                       placeholder="Start Date"
                                       value="<?php if (@$start_date != "0000-00-00") echo @$start_date; ?>">
                                <div class="invalid-feedback">* Required field</div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>End Date</label>
                                <input type="text" class="form-control form-control-sm datepicker" autocomplete="off"
                                       name="end_date" placeholder="End Date"
                                       value="<?php if (@$end_date != "0000-00-00") echo @$end_date; ?>">
                                <div class="invalid-feedback">* Required field</div>
                            </div>
                        </div>
                    </div>
                    <div class="form-group mb-0">
                        <div class="custom-control custom-switch">
                            <input type="checkbox" <?php if (@$active_status == 1): echo 'checked';endif; ?>
                                   class="custom-control-input propToggle" id="active_status">
                            <label class="custom-control-label pt-1" for="active_status"> Active Status</label>
                            <input type="hidden" readonly name="active_status"
                                   class="active_status"
                                   value="<?php if (@$active_status == 1): echo 1; else: echo 0;endif; ?>">
                        </div>
                    </div>
                    <hr>
                    <input name="app_id" id="app_id" type="hidden" value="<?php echo @$app_id; ?>" readonly/>
                    <input type="hidden" name="className" value="Module_Class" readonly>
                    <?php if (@$getUpdate['response'] === "200"): ?>
                        <input type="hidden" name="functionName" value="updateRecord" readonly>
                        <input type="hidden" name="pk" value="<?php echo @$pk; ?>" readonly>
                        <input type="hidden" name="pkField" value="<?php echo @$pkField; ?>" readonly>
                    <?php else: ?>
                        <input type="hidden" name="functionName" value="createRecord" readonly>
                    <?php endif; ?>
                    <input type="hidden" name="callback[type]" value="self" readonly>
                    <input type="hidden" name="callback[redirect]" value="" readonly>
                    <input type="hidden" name="tbl_scheme" value="app_promo" readonly>
                    <input type="hidden" name="created_by"
                           value="<?php echo trim(@$auth['firstname'] . ' ' . @$auth['lastname']); ?>" readonly>
                    <input type="hidden" name="store_id" value="<?php echo trim(@$auth['store_id']); ?>" readonly>
                    <button class="btn btn-default btn-sm px-3 actionButton"><i class="fal fa-check-circle"></i> Submit
                    </button>
                </form>
            </div>
        </div>
    </div>
    <div class="col-lg-8">
        <h6 class="text-muted"><i class="fal fa-gifts"></i> Special Prices/Promo</h6>
        <hr>
        <div class="table-responsive">
            <table class="table data-tables dataTables-Sort table-sm elevation-1"
                   style="font-size: 12px;">
                <thead>
                <tr>
                    <th>Code</th>
                    <th>Product Name</th>
                    <th>Quantity</th>
                    <th>Price <?php echo $biz->currency['currency']; ?></th>
                    <th>Time Based</th>
                    <th>Status</th>
                    <th>Created By</th>
                    <th></th>
                </tr>
                </thead>
                <tbody class="card-body">

                <?php
                $promo_store = "";
                if ($auth['store_id'] != ""):
                    $promo_store = "app_promo.store_id = '" . $auth['store_id'] . "' AND ";
                endif;
                $promo_sql = "SELECT 
                              app_promo.id, app_promo.promo_code, app_promo.product_name, app_products.name, 
                              app_promo.quantity_limit, app_promo.promo_price, app_promo.time_based, 
                              DATE_FORMAT(app_promo.start_date, '%d/%m/%Y') as start_date, 
                              DATE_FORMAT(app_promo.end_date, '%d/%m/%Y') as end_date, app_promo.created_by, 
                              app_promo.created_on, app_promo.active_status
                              FROM app_products, app_promo
                              WHERE " . $promo_store . " app_promo.app_id = app_products.app_id ORDER BY app_products.name, app_promo.created_on";
                @$promo_query = Data_Access::execSQL($promo_sql)['dataArray'];
                if ($promo_query != NULL):foreach ($promo_query as $promo): ?>
                    <tr class="data-btn">
                        <td><?php echo $promo['promo_code']; ?></td>
                        <td><?php echo $promo['product_name']; ?></td>
                        <td><?php echo number_format($promo['quantity_limit'], 2); ?></td>
                        <td><?php echo number_format($promo['promo_price'], 2); ?></td>
                        <td><?php if ($promo['time_based'] == 1): echo $promo['start_date'] . ' - ' . $promo['end_date']; else: echo 'No'; endif; ?></td>
                        <td><?php if ($promo['active_status'] == 1): echo 'Active'; else: echo 'Inactive'; endif; ?></td>
                        <td style="line-height: 16px;"><?php echo $promo['created_by']; ?>
                            <div class="small"><?php echo $promo['created_on']; ?></div>
                        </td>
                        <td align="right">
                            <div class="btn-group-justify btn-group-sm float-right">
                                <button type="button" class="btn btn-default"
                                        onclick='javascript: var obj = "<?php echo urlencode('"pkField":"id","pk":' . $promo['id'] . ',"view":"/#/sales-point/items/promo/","request":"update"'); ?>"; moduleEditRequest(obj)'
                                        title=" Edit Record"><i
                                            class="fal fa-edit"></i>
                                </button>
                                <button type="button" class="btn btn-default"
                                        onclick='javascript: var obj = "<?php echo urlencode('"className":"Module_Class","functionName":"deleteRecord","tbl_scheme":"app_promo","pk":{"id":' . $promo['id'] . '},"callback":{"type":"self","redirect":""},"notification":{"message":"Are you sure to delete this record?","title":"Delete Warning"}'); ?>";  moduleRequest(obj);'
                                        title=" Edit Record"><i
                                            class="fal fa-trash-alt"></i>
                                </button>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script>
    $('.product_search').focus();
    $('#product_search').on('change', function () {
        $.post(modulePath + 'ajaxRequest.php',
            {
                "promoItemVerify": this.value,
            }, function (response) {
                $("#ModuleResponse").html(response);
            });
    });
</script>