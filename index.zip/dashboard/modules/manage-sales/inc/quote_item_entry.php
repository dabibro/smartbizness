<div class="row">
    <div class="col-md-5">
        <div class="card card-light elevation-2">
            <div class="card-header px-2 py-1">
                <i class="fal fa-edit"></i> Product/Service Entry
            </div>
            <div class="card-body py-2 px-3">
                <div id="item-entry-response"></div>
                <div class="form-group">
                    <?php if (@$quote_type === 'Supply'): ?>
                        <label><span class="spin-loader"></span> Product Lookup</label>
                        <div class="input-group">
                            <input class="form-control form-control-sm inventory-lookup" type="search"
                                   name="item_description" placeholder="Name/SKU/Description"
                                   id="inventory-lookup" form="item-entry-form" required autocomplete="off"
                                   tabindex="1">
                            <div class="input-group-append">
                                <button type="button" onclick="fetchInvItem($('#inventory-lookup').val())"
                                        class="btn btn-sm btn-default pr-2"><i class="fal fa-search mr-0"></i></button>
                            </div>
                        </div>
                    <?php else: ?>
                        <label for=""><span class="required">*</span> Service Description</label>
                        <textarea name="item_description" id="service-description" class="form-control" rows="4"
                                  required form="item-entry-form" tabindex="1"
                                  placeholder="Service Description"></textarea>
                    <?php endif; ?>
                </div>

                <div id="computeArea">
                    <div class="row">
                        <div class="col-4">
                            <div class="form-group">
                                <label>Quantity</label>
                                <input class="form-control form-control-sm num" type="text" name="stock_qty"
                                       id="item-qty" tabindex="2"
                                       placeholder="Quantity" autocomplete="off"
                                       form="item-entry-form" required>
                            </div>
                        </div>
                        <div class="col-md-8">
                            <div class="form-group mb-0">
                                <label>Cost Price <?php echo $biz->currency['currency']; ?></label>
                                <input class="form-control form-control-sm num" type="text" name="stock_sale_price"
                                       id="stock_sale_price" tabindex="3"
                                       placeholder="Cost Price" autocomplete="off" form="item-entry-form"
                                       <?php if (@$quote_type === 'Supply'): ?>readonly<?php endif; ?>>
                            </div>
                        </div>
                    </div>
                </div>
                <hr>
                <input type="hidden" form="item-entry-form" name="item_appid" id="item-appid" readonly>
                <button class="btn btn-default btn-sm btn-block mb-2 itemActionButton" tabindex="5"
                        form="item-entry-form"><i
                            class="fal fa-plus-square"></i> Add Item
                </button>
            </div>
        </div>


    </div>
    <div class="col-md-7">
        <div class="table-responsive">
            <table class="table table-borderless table-sm table-striped data-tables">
                <thead>
                <tr>
                    <th width="20">#</th>
                    <th>Name/Description</th>
                    <th>Quantity</th>
                    <th>Price <?php echo $biz->currency['currency']; ?></th>
                    <th>Amount <?php echo $biz->currency['currency']; ?></th>
                    <th width="10"><i class="fal fa-trash-o fa-lg"></i></th>
                </tr>
                </thead>
                <tbody id="items-entry-table" class="card-body">
                <?php require 'quote_item_tbl_rows.php'; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
