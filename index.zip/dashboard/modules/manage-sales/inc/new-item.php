<?php
//if(@$access['new-product']!=1 || @$access['product-mgmts']!=1){
//echo "<script>location.replace('".WEB_ROOT."dashboard/')</script>";
//}
//require quries files
require_once 'inc/queries.php';
?>
<style>
    label.cabinet {
        display: block;
        cursor: pointer;
    }

    label.cabinet input.file {
        position: relative;
        height: 100%;
        width: auto;
        opacity: 0;
        -moz-opacity: 0;
        filter: progid:DXImageTransform.Microsoft.Alpha(opacity=0);
        margin-top: -30px;
    }

    #item-upload {
        width: 250px;
        height: 250px;
        padding-bottom: 25px;
    }

    figure figcaption {
        position: absolute;
        bottom: 0;
        color: #fff;
        width: 100%;
        padding-left: 9px;
        padding-bottom: 5px;
        text-shadow: 0 0 10px #000;
    }
</style>
<!-- New product panel content-->
<div class="row">
    <div class="col-md-12 col-lg-10 m-auto">
        <div class="card x_panel">
            <div class="x_title">
                <span class="title"><?php if (!$edit) {
                        echo '<i class="fal fa-cart-plus"></i>';
                    } else {
                        echo '<i class="fal fa-edit"></i>';
                    } ?> Item Record</span>
            </div>
            <div class="x_content">
                <div id="result"></div>
                <form method="post" class="submit-product" novalidate enctype="multipart/form-data">
                   
                    <div class="row">
                        <?php if (@$edit) { ?>
                            <div class="form-group col-md-4 ml-auto">
                                <label>Replenish Item <a href="#"
                                                         title="Click on the plus or minus sign in order to add or subtract the entered value"
                                                         data-toggle="tooltip"><i
                                                class="fal fa-info-circle"></i></a></label>
                                <div class="input-group">
                                    <input name="replenish" type="text" class="form-control alert-success num"
                                           id="replenish" placeholder="Enter Quantity"
                                           onkeyup="itemReplenish(), productComputation()" autocomplete="off"/>
                                    <div class="input-group-append">
                                        <button class="btn btn-primary btn-sm" title="Decrease Quantity"
                                                data-toggle="tooltip"
                                                onClick="adjItemQty(<?php echo $edit['id'] ?>, 'less')" type="button"
                                                style="border-radius:0">&nbsp; <i class="fal fa-minus m-0"></i> &nbsp;
                                        </button>
                                        <button class="btn btn-primary btn-sm" title="Increase Quantity"
                                                data-toggle="tooltip"
                                                onClick="adjItemQty(<?php echo $edit['id'] ?>, 'add')" type="button">
                                            &nbsp; <i class="fal fa-plus m-0"></i> &nbsp;
                                        </button>
                                    </div>
                                </div>
                                <div id="replenish-msg" class="small text-danger"></div>
                            </div>
                        <?php } ?>
                    </div>
                    <div class="row">
                        <div class="col-md-3 ml-auto">
                            <div class="form-group">
                                <label for="item_id"> <span class="required">*</span> Item ID/Barcode:</label>
                                <div class="input-group">
                                    <span class="input-group-append">
                                        <button class="btn-primary autogenid" type="button"
                                                title="Generate Random ID (ALT + G)"
                                                data-toggle="tooltip"><i class="fal fa-barcode"></i></button>
                                    </span>
                                    <input name="item_id" autofocus required class="form-control" id="item_id"
                                           placeholder="Item ID/Barcode" tabindex="1" autocomplete="off"
                                           value="<?php echo @$edit['item_id'] ?>">
                                </div>
                                <div class="invalid-feedback">Enter item ID/Barcode</div>
                            </div>
                        </div>
                        <div class="col-md-5">
                            <div class="form-group">
                                <label for="item_name"> <span class="required">*</span> Item Name:</label>
                                <input name="item_name" type="text" required="required" class="form-control "
                                       id="item_name" placeholder="Item Name" tabindex="2"
                                       value="<?php echo @$edit['item_name'] ?>">
                                <div class="invalid-feedback">Enter item name</div>
                            </div>


                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="item_category"> <span class="required">*</span> Item Category:</label>
                                <div class="form-group">
                                    <select name="item_category" class="form-control text-capitalize select2"
                                            id="item_category"
                                            tabindex="3" required
                                            data-title="Select item category name">
                                        <option value="">-- Select Category --</option>
                                        <?php
                                        while ($cat_sel = dbFetchAssoc($category_result)) {
                                            ?>
                                            <option value="<?php echo $cat_sel['id'] ?>" class="text-capitalize" <?php
                                            if (@$edit['item_category'] == $cat_sel['id']) {
                                                echo 'selected';
                                            }
                                            ?>>
                                                <?php echo $cat_sel['category']; ?>
                                            </option>
                                        <?php } ?>

                                    </select>
                                    <div class="invalid-feedback">Select item category name</div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="item_location"> <span class="required">*</span> Location/Cabinet</label>
                                <div class="form-group">
                                    <select name="item_location" class="form-control text-capitalize select2"
                                            id="item_location"
                                            tabindex="4" required
                                            data-title="Select item location/cabinet">
                                        <option value="">-- Select Location/Cabinet --</option>
                                        <?php
                                        while ($cat_sel = dbFetchAssoc($cabinets)) {
                                            ?>
                                            <option value="<?php echo $cat_sel['id'] ?>" class="text-capitalize" <?php
                                            if (@$edit['item_location'] == $cat_sel['id']) {
                                                echo 'selected';
                                            }
                                            ?>>
                                                <?php echo $cat_sel['cabinet']; ?>
                                            </option>
                                        <?php } ?>

                                    </select>
                                    <div class="invalid-feedback">Select item location/cabinet</div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4 ">
                            <div class="form-group">
                                <label for="">Expiry Date</label>
                                <input name="expiry_date" type="text" autocomplete="off" class="form-control datepicker"
                                       placeholder="Expiry Date" value="<?php echo @$edit['expiry_date'] ?>"
                                       tabindex="5">
                            </div>
                        </div>
                        <div class="col-md-4 ">
                            <div class="form-group">
                                <label for="">Item Manufacturer</label>
                                <input name="item_manufacturer" type="text" class="form-control"
                                       placeholder="Item Manufacturer" value="<?php echo @$edit['item_manufacturer'] ?>"
                                       tabindex="6">
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-2 ">
                            <div class="form-group">
                                <label for="item_qty"><span class="required">*</span> Quantity:</label>
                                <input name="item_qty" type="text" required autocomplete="off" class="form-control num"
                                       id="item_qty" placeholder="Quantity" tabindex="7" onkeyup="itemComputation()"
                                       value="<?php echo @$edit['item_qty'] ?>" <?php
                                if (@$edit) {
                                    echo 'readonly';
                                }
                                ?>>
                                <div class="invalid-feedback">Enter quantity</div>
                            </div>
                        </div>
                        <div class="col-md-4 ">
                            <div class="form-group">
                                <label for=""> <span class="required">*</span> Purchase Price:</label>
                                <input name="item_price" type="text" autocomplete="off" required
                                       class="form-control num" id="item_price" placeholder="Sale Price" tabindex="7"
                                       onkeyup="computeMarkup(), itemComputation()"
                                       value="<?php echo @$edit['item_price']; ?>"/>
                                <div class="invalid-feedback">Enter Purchase price</div>
                            </div>
                        </div>
                        <div class="col-md-2">
                            <div class="form-group">
                                <label>Markup Value</label>
                                <input class="form-control" readonly placeholder="MarkUp" id="markup_value">
                            </div>
                        </div>
                        <div class="col-md-4 ">
                            <div class="form-group">
                                <input type="hidden" value="<?php echo $appinfo['markup']; ?>" id="markup">
                                <label for=""> <span class="required">*</span> Sale Price:</label>
                                <input name="item_sale_price" type="text" autocomplete="off" required
                                       class="form-control num" id="item_sale_price" placeholder="Item Sale Price"
                                       tabindex="8" onkeyup="itemComputation()"
                                       value="<?php echo @$edit['item_sale_price']; ?>"/>
                                <div class="invalid-feedback">Enter Sale Price</div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-2"></div>
                        <div class="col-md-3">
                            <div class="form-group ">
                                <label for="product_amount">Total Amount:</label>
                                <input name="product_amount" type="text" class="form-control num" id="product_amount"
                                       placeholder="Product Amount"
                                       value="<?php echo @$edit['item_price'] * @$edit['item_qty']; ?>" readonly/>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="form-group">
                                <label for="product_sale_amount">Sale Amount:</label>
                                <input name="product_sale_amount" type="text" class="form-control num"
                                       id="product_sale_amount" placeholder="Sale Amount"
                                       value="<?php echo @$edit['item_sale_price'] * @$edit['item_qty']; ?>" readonly/>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="form-group">
                                <label for="product_sale_amount">Projected Profit:</label>
                                <input name="product_profit" type="text" class="form-control num" id="product_profit"
                                       placeholder="Sale Amount"
                                       value="<?php echo (@$edit['item_sale_price'] * @$edit['item_qty']) - (@$edit['item_price'] * @$edit['item_qty']); ?>"
                                       readonly/>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-2 ">
                            <div class="form-group">
                                <label><span class="required">*</span> Replenish Limit</label>
                                <input name="item_replenish" required class="form-control num" autocomplete="off"
                                       id="item_replenish" placeholder="Replinish Limit" tabindex="9"
                                       value="<?php echo @$edit['item_replenish'] ?>"/>
                                <div class="invalid-feedback">Enter replenish limit</div>
                            </div>
                        </div>
                        <div class="col-md-4 ">
                            <div class="form-group">
                                <label for="">Item Packaging</label>
                                <input name="item_packaging" type="text" class="form-control"
                                       placeholder="Item Packaging" value="<?php echo @$edit['item_packaging'] ?>"
                                       tabindex="9">
                            </div>
                        </div>
                        <div class="col-md-4 ">
                            <div class="form-group">
                                <label for="item_uom">Unit of Measurement</label>
                                <select name="item_uom" id="item_uom" class="form-control text-capitalize select2"
                                        tabindex="10">
                                    <option value="">--- Select UOM ---</option>
                                    <?php
                                    $uom = dbQuery("SELECT id, uom FROM app_uom ORDER BY uom ASC");
                                    while ($uom_list = dbFetchAssoc($uom)):
                                        ?>
                                        <option value="<?php echo $uom_list['id']; ?>" <?php
                                        if (@$edit['item_uom'] == $uom_list['id']) {
                                            echo 'selected';
                                        }
                                        ?>>
                                            <?php echo $uom_list['uom'] ?>
                                        </option>
                                    <?php endwhile ?>
                                </select>

                            </div>
                        </div>

                    </div>
                    <div class="row">
                        <div class="col-md-8">
                            <div class="form-group ">
                                <label for="item_description">Description:</label>
                                <?php include('plugins/basic-editor-toolbar.php') ?>
                                <div id="editor-one" class="editor-wrapper note"
                                     style="min-height: 168px !important; max-height: 168px !important;  border-radius: 0; overflow-x:hidden; "
                                     tabindex="11">
                                    <?php echo htmlspecialchars_decode(@$edit['item_description']); ?>
                                </div>
                                <textarea class="form-control hide" name="item_description" id="note_editor" rows="5"
                                          placeholder="Item Description"><?php echo @$edit['item_description']; ?></textarea>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="">Item Image</label><br>
                                <div class="" style="width:180px; height: 180px;">
                                    <div class="mb-1" style="position: relative !important; ">
                                        <input name="imageFile" type="file" class="form-control hide item-img"
                                               id="imagefile"/>
                                        <button class="btn px-4 btn-primary" type="button" role="button"
                                                onClick='javascript:$("#imagefile").click()'><i
                                                    class="fal fa-camera fa-lg"></i>
                                            Select Image
                                        </button>
                                    </div>
                                    <?php if (isset($edit) && $edit['item_image'] != "") {
                                        $file_src = PRODUCTS . ($edit['item_image']);
                                    } else {
                                        $file_src = WEB_ROOT . 'files/products/no image.jpg';
                                    } ?>
                                    <img src="<?php echo $file_src; ?>" id="item-image"
                                         style="width: auto; max-width:100% !important; height: auto; max-height:100% !important;"
                                         onClick='javascript:$("#imagefile").click()' class="img-thumbnail br-0"/>
                                    <input type="hidden" name="image-file" id="image-field">
                                </div>

                            </div>
                        </div>
                    </div>
                    <hr>
                    <button class="btn btn-primary px-4 save-btn" type="submit"><i class="fal fa-check-circle"></i>
                        Submit
                    </button>
                    <a href="?p=items-list" class="btn btn-danger px-4"><i class="fal fa-times-circle"></i> Close</a>
                    <?php if (@$edit) { ?>
                        <input name="submit-product" type="hidden" value="2"/>
                        <input name="id" type="hidden" value="<?php echo $edit['id'] ?>"/>

                    <?php } else { ?>
                        <input name="submit-product" type="hidden" value="1"/>
                    <?php } ?>
                </form>
            </div>
        </div>
    </div>
</div>


<!-- cropper loader  -->
<div class="modal fade" id="item-cropper-loader" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog" role="document" style="max-width: 350px !important; margin: 3rem auto;">
        <div class="modal-content x_panel bg-light">
            <div class="modal-body card-body text-center  p-3" id="cropper-loader-contents">
                <div id="item-upload" class="center-block"></div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fal fa-times"></i> Close
                </button>
                <button type="button" id="cropImageBtn" class="btn btn-primary"><i class="fal fa-check-circle"></i> Crop & Submit
                </button>
            </div>
        </div>
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->


<script>
    function readURL(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            reader.onload = function (e) {
                document.getElementById('passport').src = e.target.result;
            }
            reader.readAsDataURL(input.files[0]);
        }
    }

</script>
