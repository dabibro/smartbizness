<div id="QuotePrintArea">
    <table class="TableGrid" border="0" cellspacing="0" cellpadding="0" width="740">
        <tbody>
        <tr>
            <td></td>
            <td width="368" valign="top" style="width:276.1pt;padding:0in 5.4pt 0in 5.4pt">
                <table class="MsoTableGrid" border="0" cellspacing="0" cellpadding="0" style="border: none;">
                    <tbody>
                    <tr>
                        <td width="46" valign="top" style="width:34.25pt;padding:0in 5.4pt 0in 5.4pt">
                            <p class="MsoHeader">
                                <img width="64" height="auto"
                                     src="<?php echo $app->webRoot . $biz->biz['logo']; ?>"><!--[endif]--> </p>
                        </td>
                        <td width="288" valign="top"
                            style="width:215.85pt;padding:0in 5.4pt 0in 5.4pt;font-size:13.0pt; text-transform: uppercase">
                            <p class="MsoHeader"><b><?php echo $biz->biz['business_name']; ?></b></p>
                        </td>
                    </tr>
                    </tbody>
                </table>
            </td>
        </tr>
        <tr>
            <td width="352" valign="top" style="width:263.9pt;padding:0in 5.4pt 0in 5.4pt">
                <p class="MsoHeader font-weight-bold"><span
                            style="font-size:20.0pt;">QUOTATION</span>
                </p>
            </td>
            <td width="368" valign="top" style="width:276.1pt;padding:0in 5.4pt 0in 5.4pt">
                <table class="MsoTable15Plain3" border="0" cellspacing="0" cellpadding="0" align="right" width="336"
                       style="width: 3.5in; margin-left: -2.25pt; margin-right: -2.25pt;">
                    <tbody>
                    <tr style="mso-yfti-irow:-1;mso-yfti-firstrow:yes;mso-yfti-lastfirstrow:
    yes;height:.2in">
                        <td width="132" valign="top" style="width:99.0pt;border:none;border-bottom:
    solid #7F7F7F 1.0pt;mso-border-bottom-themecolor:text1;mso-border-bottom-themetint:
    128;mso-border-bottom-alt:solid #7F7F7F .5pt;mso-border-bottom-themecolor:
    text1;mso-border-bottom-themetint:128;padding:0in 5.4pt 0in 5.4pt;
    height:.2in">
                            <p class="MsoNormal" style="margin-bottom:0in;margin-bottom:.0001pt;
    line-height:115%;"><b><span style="font-size:9.0pt;
    mso-bidi-font-size:11.0pt;line-height:115%;text-transform:uppercase">Ref/Quote No.:</span></b></p>
                        </td>
                        <td width="204" valign="top" style="width:153.0pt;border:none;border-bottom:
    solid #7F7F7F 1.0pt;mso-border-bottom-themecolor:text1;mso-border-bottom-themetint:
    128;mso-border-bottom-alt:solid #7F7F7F .5pt;mso-border-bottom-themecolor:
    text1;mso-border-bottom-themetint:128;padding:0in 5.4pt 0in 5.4pt;
    height:.2in">
                            <p class="MsoNormal" style="margin-bottom:0in;margin-bottom:.0001pt;
    line-height:115%;mso-yfti-cnfc:1"><?php echo @$reference; ?></p>
                        </td>
                    </tr>
                    <tr style="mso-yfti-irow:0;height:.2in">
                        <td width="132" valign="top" style="width:99.0pt;border:none;border-right:solid #7F7F7F 1.0pt;
    mso-border-right-themecolor:text1;mso-border-right-themetint:128;
    mso-border-right-alt:solid #7F7F7F .5pt;mso-border-right-themecolor:text1;
    mso-border-right-themetint:128;background:#F2F2F2;mso-background-themecolor:
    background1;mso-background-themeshade:242;padding:0in 5.4pt 0in 5.4pt;
    height:.2in">
                            <p class="MsoNormal" style="margin-top:0in;margin-right:.05pt;margin-bottom:
    0in;margin-left:0in;margin-bottom:.0001pt;line-height:115%;mso-yfti-cnfc:
    68"><b><span style="font-size:9.0pt;mso-bidi-font-size:11.0pt;line-height:
    115%;text-transform:uppercase">Submission Date:</span></b>
                            </p>
                        </td>
                        <td width="204" valign="top" style="width:153.0pt;background:#F2F2F2;
    mso-background-themecolor:background1;mso-background-themeshade:242;
    padding:0in 5.4pt 0in 5.4pt;height:.2in">
                            <p class="MsoNormal" style="margin-bottom:0in;margin-bottom:.0001pt;
    line-height:115%;mso-yfti-cnfc:1"><?php echo @$submission_date; ?></p>
                        </td>
                    </tr>
                    <tr style="mso-yfti-irow:1;mso-yfti-lastrow:yes;height:.2in">
                        <td width="132" valign="top" style="width:99.0pt;border:none;border-right:solid #7F7F7F 1.0pt;
    mso-border-right-themecolor:text1;mso-border-right-themetint:128;
    mso-border-right-alt:solid #7F7F7F .5pt;mso-border-right-themecolor:text1;
    mso-border-right-themetint:128;padding:0in 5.4pt 0in 5.4pt;height:.2in">
                            <p class="MsoNormal" style="margin-top:0in;margin-right:.05pt;margin-bottom:
    0in;margin-left:0in;margin-bottom:.0001pt;line-height:115%;mso-yfti-cnfc:
    4"><b><span style="font-size:9.0pt;mso-bidi-font-size:11.0pt;line-height:
    115%;text-transform:uppercase">Request Date:</span></b></p>
                        </td>
                        <td width="204" valign="top" style="width:153.0pt;padding:0in 5.4pt 0in 5.4pt;
    height:.2in">
                            <p class="MsoNormal" style="margin-bottom:0in;margin-bottom:.0001pt;
    line-height:115%;mso-yfti-cnfc:1"><?php echo @$request_date; ?></p>
                        </td>
                    </tr>
                    <tr style="mso-yfti-irow:0;height:.2in">
                        <td width="132" valign="top" style="width:99.0pt;border:none;border-right:solid #7F7F7F 1.0pt;
    mso-border-right-themecolor:text1;mso-border-right-themetint:128;
    mso-border-right-alt:solid #7F7F7F .5pt;mso-border-right-themecolor:text1;
    mso-border-right-themetint:128;background:#F2F2F2;mso-background-themecolor:
    background1;mso-background-themeshade:242;padding:0in 5.4pt 0in 5.4pt;
    height:.2in">
                            <p class="MsoNormal" style="margin-top:0in;margin-right:.05pt;margin-bottom:
    0in;margin-left:0in;margin-bottom:.0001pt;line-height:115%;mso-yfti-cnfc:
    68"><b><span style="font-size:9.0pt;mso-bidi-font-size:11.0pt;line-height:
    115%;text-transform:uppercase">Validity Period:</span></b>
                            </p>
                        </td>
                        <td width="204" valign="top" style="width:153.0pt;background:#F2F2F2;
    mso-background-themecolor:background1;mso-background-themeshade:242;
    padding:0in 5.4pt 0in 5.4pt;height:.2in">
                            <p class="MsoNormal" style="margin-bottom:0in;margin-bottom:.0001pt;
    line-height:115%;mso-yfti-cnfc:1"><?php echo @$validity_period; ?></p>
                        </td>
                    </tr>
                    <tr style="mso-yfti-irow:1;mso-yfti-lastrow:yes;height:.2in">
                        <td width="132" valign="top" style="width:99.0pt;border:none;border-right:solid #7F7F7F 1.0pt;
    mso-border-right-themecolor:text1;mso-border-right-themetint:128;
    mso-border-right-alt:solid #7F7F7F .5pt;mso-border-right-themecolor:text1;
    mso-border-right-themetint:128;padding:0in 5.4pt 0in 5.4pt;height:.2in">
                            <p class="MsoNormal" style="margin-top:0in;margin-right:.05pt;margin-bottom:
    0in;margin-left:0in;margin-bottom:.0001pt;line-height:115%;mso-yfti-cnfc:
    4"><b><span style="font-size:9.0pt;mso-bidi-font-size:11.0pt;line-height:
    115%;text-transform:uppercase">RFQ #:</span></b></p>
                        </td>
                        <td width="204" valign="top" style="width:153.0pt;padding:0in 5.4pt 0in 5.4pt;
    height:.2in">
                            <p class="MsoNormal" style="margin-bottom:0in;margin-bottom:.0001pt;
    line-height:115%;mso-yfti-cnfc:1"><?php echo @$rfq; ?></p>
                        </td>
                    </tr>
                    </tbody>
                </table>
            </td>
        </tr>
        </tbody>
    </table>
    <table class="TableGrid" border="0" cellspacing="0" cellpadding="0" width="720">
        <tbody>
        <tr style="mso-yfti-irow:0;mso-yfti-firstrow:yes;height:75.95pt">
            <td width="372" valign="top" style="width:279.0pt;padding:0in 0in 0in 0in;
  height:75.95pt">
                <p class="MsoNormal" style="margin-bottom:0in;margin-bottom:.0001pt;line-height:
  normal">
                    <o:p>&nbsp;</o:p>
                </p>
                <table class="MsoTable15Grid4Accent5" border="1" cellspacing="0" cellpadding="0" width="351"
                       style="margin-left: 0.5pt; border: none;">
                    <tbody>
                    <tr style="mso-yfti-irow:-1;mso-yfti-firstrow:yes;mso-yfti-lastfirstrow:
    yes;mso-yfti-lastrow:yes;height:.2in">
                        <td width="351" style="width:263.55pt;border:solid #5B9BD5 1.0pt;mso-border-themecolor:
    accent5;mso-border-alt:solid #5B9BD5 .5pt;mso-border-themecolor:accent5;
    background:#5B9BD5;mso-background-themecolor:accent5;padding:0in 5.4pt 0in 5.4pt;
    height:.2in">
                            <p class="MsoNormal" style="margin-bottom:0in;margin-bottom:.0001pt;
    line-height:115%;"><b><span style="font-size:9.0pt;
    line-height:115%;color:white;mso-themecolor:background1">Customer Information</span></b></p>
                        </td>
                    </tr>
                    </tbody>
                </table>
                <table class="MsoTable15Plain4" border="0" cellspacing="0" cellpadding="0" width="351">
                    <tbody>
                    <tr style="mso-yfti-irow:-1;mso-yfti-firstrow:yes;mso-yfti-lastfirstrow: yes;height:.2in">
                        <td width="96" valign="top" style="width:1.1in;padding:0in 5.4pt 0in 5.4pt; height:.2in">
                            <p class="MsoNormal" style="margin-bottom:0in;margin-bottom:.0001pt; line-height:115%;">
                                <b><span style="font-size:9.0pt; mso-bidi-font-size:11.0pt;line-height:115%">Customer Name:</span></b>
                            </p>
                        </td>
                        <td width="255" valign="top" style="width:191.55pt;padding:0in 5.4pt 0in 5.4pt;
    height:.2in">
                            <p class="MsoNormal" style="margin-bottom:0in;margin-bottom:.0001pt;
    line-height:115%;mso-yfti-cnfc:1"><span style="font-size:9.0pt;line-height:
    115%"><?php echo @$customer['customer_name']; ?></span></p>
                        </td>
                    </tr>
                    <tr style="mso-yfti-irow:0;height:.2in">
                        <td width="96" valign="top" style="width:1.0in;background:#F2F2F2;mso-background-themecolor:
    background1;mso-background-themeshade:242;padding:0in 5.4pt 0in 5.4pt;
    height:.2in">
                            <p class="MsoNormal" style="margin-bottom:0in;margin-bottom:.0001pt;
    line-height:115%;mso-yfti-cnfc:68"><b><span style="font-size:9.0pt;
    mso-bidi-font-size:11.0pt;line-height:115%">Contact Name</span>
                                </b></p>
                        </td>
                        <td width="255" valign="top" style="width:191.55pt;background:#F2F2F2;
    mso-background-themecolor:background1;mso-background-themeshade:242;
    padding:0in 5.4pt 0in 5.4pt;height:.2in">
                            <p class="MsoNormal" style="margin-bottom:0in;margin-bottom:.0001pt;
    line-height:115%;mso-yfti-cnfc:64"><span style="font-size:9.0pt;line-height:
    115%"><?php echo @$customer['contact_name']; ?></span></p>
                        </td>
                    </tr>
                    <tr style="mso-yfti-irow:2;height:.2in">
                        <td width="96" valign="top" style="width:1.0in;background:#F2F2F2;mso-background-themecolor:
    background1;mso-background-themeshade:242;padding:0in 5.4pt 0in 5.4pt;
    height:.2in">
                            <p class="MsoNormal" style="margin-bottom:0in;margin-bottom:.0001pt;
    line-height:115%;mso-yfti-cnfc:68"><b><span style="font-size:9.0pt;
    mso-bidi-font-size:11.0pt;line-height:115%">Phone:</span></b></p>
                        </td>
                        <td width="255" valign="top" style="width:191.55pt;background:#F2F2F2;
    mso-background-themecolor:background1;mso-background-themeshade:242;
    padding:0in 5.4pt 0in 5.4pt;height:.2in">
                            <p class="MsoNormal" style="margin-bottom:0in;margin-bottom:.0001pt;
    line-height:115%;mso-yfti-cnfc:64"><span style="font-size:9.0pt;line-height:
    115%"><?php echo @$customer['contact_phone']; ?></span></p>
                        </td>
                    </tr>
                    <tr style="mso-yfti-irow:3;mso-yfti-lastrow:yes;height:.2in">
                        <td width="96" valign="top" style="width:1.0in;padding:0in 5.4pt 0in 5.4pt;
    height:.2in">
                            <p class="MsoNormal" style="margin-bottom:0in;margin-bottom:.0001pt;
    line-height:115%;mso-yfti-cnfc:4"><b><span style="font-size:9.0pt;
    mso-bidi-font-size:11.0pt;line-height:115%">Address:</span>
                                </b></p>
                        </td>
                        <td width="255" valign="top" style="width:191.55pt;padding:0in 5.4pt 0in 5.4pt;
    height:.2in">
                            <p class="MsoNormal" style="margin-bottom:0in;margin-bottom:.0001pt;
    line-height:115%;tab-stops:52.0pt"><span style="font-size:9.0pt;line-height:
    115%"><?php echo @$customer['address_1']; ?></span>
                            </p>
                        </td>
                    </tr>
                    </tbody>
                </table>
                <p class="MsoNormal" style="margin-bottom:0in;margin-bottom:.0001pt;line-height:
  115%;tab-stops:88.0pt">

                </p>
            </td>
            <td width="348" valign="top" style="width:261.0pt;padding:0in 0in 0in 0in;
  height:75.95pt">
                <p class="MsoNormal" style="margin-bottom:0in;margin-bottom:.0001pt;line-height:
  normal">
                    <o:p>&nbsp;</o:p>
                </p>
                <table class="MsoTable15Grid4Accent5" border="1" cellspacing="0" cellpadding="0" width="360"
                       style="border: none;">
                    <tbody>
                    <tr style="mso-yfti-irow:-1;mso-yfti-firstrow:yes;mso-yfti-lastfirstrow:
    yes;mso-yfti-lastrow:yes;height:.2in">
                        <td width="360" style="width:269.9pt;border:solid #5B9BD5 1.0pt;mso-border-themecolor:
    accent5;mso-border-alt:solid #5B9BD5 .5pt;mso-border-themecolor:accent5;
    background:#5B9BD5;mso-background-themecolor:accent5;padding:0in 5.4pt 0in 5.4pt;
    height:.2in">
                            <p class="MsoNormal" style="margin-bottom:0in;margin-bottom:.0001pt;
    line-height:115%;"><b><span style="font-size:9.0pt;
    line-height:115%;color:white;mso-themecolor:background1">Contact Information</span></b></p>
                        </td>
                    </tr>
                    </tbody>
                </table>
                <table class="MsoTable15Plain4" border="0" cellspacing="0" cellpadding="0" width="360">
                    <tbody>
                    <tr style="mso-yfti-irow:0;height:.2in">
                        <td width="108" valign="top" style="width:80.85pt;background:#F2F2F2;
    mso-background-themecolor:background1;mso-background-themeshade:242;
    padding:0in 5.4pt 0in 5.4pt;height:.2in">
                            <p class="MsoNormal" style="margin-bottom:0in;margin-bottom:.0001pt;
    line-height:115%;mso-yfti-cnfc:68"><b><span style="font-size:9.0pt;
    mso-bidi-font-size:11.0pt;line-height:115%">Contact Name:</span>
                                </b></p>
                        </td>
                        <td width="252" valign="top" style="width:189.05pt;background:#F2F2F2;
    mso-background-themecolor:background1;mso-background-themeshade:242;
    padding:0in 5.4pt 0in 5.4pt;height:.2in">
                            <p class="MsoNormal" style="margin-bottom:0in;margin-bottom:.0001pt;
    line-height:115%;mso-yfti-cnfc:64"><span style="font-size:9.0pt;line-height:
    115%"><?php echo $contact['firstname'] . ' ' . $contact['lastname']; ?></span></p>
                        </td>
                    </tr>
                    <tr style="mso-yfti-irow:1;height:.2in">
                        <td width="108" valign="top" style="width:80.85pt;padding:0in 5.4pt 0in 5.4pt;
    height:.2in">
                            <p class="MsoNormal" style="margin-bottom:0in;margin-bottom:.0001pt;
    line-height:115%;mso-yfti-cnfc:4"><b><span style="font-size:9.0pt;
    mso-bidi-font-size:11.0pt;line-height:115%">Phone:</span>

                                </b></p>
                        </td>
                        <td width="252" valign="top" style="width:189.05pt;padding:0in 5.4pt 0in 5.4pt;
    height:.2in">
                            <p class="MsoNormal" style="margin-bottom:0in;margin-bottom:.0001pt;
    line-height:115%"><span style="font-size:9.0pt;line-height:115%"><?php echo $contact['contact_phone']; ?></span></p>
                        </td>
                    </tr>
                    <tr style="mso-yfti-irow:2;mso-yfti-lastrow:yes;height:.2in">
                        <td width="108" valign="top" style="width:80.85pt;background:#F2F2F2;
    mso-background-themecolor:background1;mso-background-themeshade:242;
    padding:0in 5.4pt 0in 5.4pt;height:.2in">
                            <p class="MsoNormal" style="margin-bottom:0in;margin-bottom:.0001pt;
    line-height:115%;mso-yfti-cnfc:68"><b><span style="font-size:9.0pt;
    mso-bidi-font-size:11.0pt;line-height:115%">Address:</span>

                                </b></p>
                        </td>
                        <td width="252" valign="top" style="width:189.05pt;background:#F2F2F2;
    mso-background-themecolor:background1;mso-background-themeshade:242;
    padding:0in 5.4pt 0in 5.4pt;height:.2in">
                            <p class="MsoNormal" style="margin-bottom:0in;margin-bottom:.0001pt;
    line-height:115%;mso-yfti-cnfc:64"><span style="font-size:9.0pt;line-height:
    115%"><?php echo $contact['contact_address']; ?></span></p>
                        </td>
                    </tr>
                    </tbody>
                </table>
                <p class="MsoNormal" style="margin-bottom:0in;margin-bottom:.0001pt;line-height:
  115%">

                </p>
            </td>
        </tr>
        <tr style="mso-yfti-irow:1;height:75.95pt">
            <td width="720" colspan="2" valign="top" style="width:7.5in;padding:0in 0in 0in 0in;
  height:75.95pt">
                <p class="MsoNormal" style="margin-bottom:0in;margin-bottom:.0001pt;line-height:
  normal">
                    <o:p>&nbsp;</o:p>
                </p>
                <table class="MsoTable15Grid4Accent5" border="1" cellspacing="0" cellpadding="0" width="732"
                       style="border: none;">
                    <tbody>
                    <tr style="mso-yfti-irow:-1;mso-yfti-firstrow:yes;mso-yfti-lastfirstrow:
    yes;height:.2in">
                        <td width="42" style="width:31.5pt;border:solid #5B9BD5 1.0pt;mso-border-themecolor:
    accent5;border-right:none;mso-border-top-alt:solid #5B9BD5 .5pt;mso-border-top-themecolor:
    accent5;mso-border-left-alt:solid #5B9BD5 .5pt;mso-border-left-themecolor:
    accent5;mso-border-bottom-alt:solid #5B9BD5 .5pt;mso-border-bottom-themecolor:
    accent5;background:#5B9BD5;mso-background-themecolor:accent5;padding:0in 5.4pt 0in 5.4pt;
    height:.2in">
                            <p class="MsoNormal" align="center" style="margin-bottom:0in;margin-bottom:
    .0001pt;text-align:center;line-height:115%;"><b><span
                                            style="font-size:9.0pt;line-height:115%;color:white;mso-themecolor:background1">ITEM</span></b>
                            </p>
                        </td>
                        <td width="354" style="width:265.5pt;border-top:solid #5B9BD5 1.0pt;
    mso-border-top-themecolor:accent5;border-left:none;border-bottom:solid #5B9BD5 1.0pt;
    mso-border-bottom-themecolor:accent5;border-right:none;mso-border-top-alt:
    solid #5B9BD5 .5pt;mso-border-top-themecolor:accent5;mso-border-bottom-alt:
    solid #5B9BD5 .5pt;mso-border-bottom-themecolor:accent5;background:#5B9BD5;
    mso-background-themecolor:accent5;padding:0in 5.4pt 0in 5.4pt;height:.2in">
                            <p class="MsoNormal" align="center" style="margin-bottom:0in;margin-bottom:
    .0001pt;text-align:center;line-height:115%;mso-yfti-cnfc:1"><b><span
                                            style="font-size:9.0pt;line-height:115%;color:white;mso-themecolor:background1">DESCRIPTION</span></b>
                            </p>
                        </td>
                        <td width="102" style="width:76.25pt;border-top:solid #5B9BD5 1.0pt;
    mso-border-top-themecolor:accent5;border-left:none;border-bottom:solid #5B9BD5 1.0pt;
    mso-border-bottom-themecolor:accent5;border-right:none;mso-border-top-alt:
    solid #5B9BD5 .5pt;mso-border-top-themecolor:accent5;mso-border-bottom-alt:
    solid #5B9BD5 .5pt;mso-border-bottom-themecolor:accent5;background:#5B9BD5;
    mso-background-themecolor:accent5;padding:0in 5.4pt 0in 5.4pt;height:.2in">
                            <p class="MsoNormal" align="center" style="margin-bottom:0in;margin-bottom:
    .0001pt;text-align:center;line-height:115%;mso-yfti-cnfc:1"><b><span
                                            style="font-size:9.0pt;line-height:115%;color:white;mso-themecolor:background1">QUANTITY</span></b>
                            </p>
                        </td>
                        <td width="126" style="width:94.5pt;border-top:solid #5B9BD5 1.0pt;
    mso-border-top-themecolor:accent5;border-left:none;border-bottom:solid #5B9BD5 1.0pt;
    mso-border-bottom-themecolor:accent5;border-right:none;mso-border-top-alt:
    solid #5B9BD5 .5pt;mso-border-top-themecolor:accent5;mso-border-bottom-alt:
    solid #5B9BD5 .5pt;mso-border-bottom-themecolor:accent5;background:#5B9BD5;
    mso-background-themecolor:accent5;padding:0in 5.4pt 0in 5.4pt;height:.2in">
                            <p class="MsoNormal" align="center" style="margin-bottom:0in;margin-bottom:
    .0001pt;text-align:center;line-height:115%;mso-yfti-cnfc:1"><b><span
                                            style="font-size:9.0pt;line-height:115%;color:white;mso-themecolor:background1">COST
    PRICE <?php echo $biz->currency['currency']; ?></span></b></p>
                        </td>
                        <td width="108" style="width:81.25pt;border:solid #5B9BD5 1.0pt;mso-border-themecolor:
    accent5;border-left:none;mso-border-top-alt:solid #5B9BD5 .5pt;mso-border-top-themecolor:
    accent5;mso-border-bottom-alt:solid #5B9BD5 .5pt;mso-border-bottom-themecolor:
    accent5;mso-border-right-alt:solid #5B9BD5 .5pt;mso-border-right-themecolor:
    accent5;background:#5B9BD5;mso-background-themecolor:accent5;padding:0in 5.4pt 0in 5.4pt;
    height:.2in">
                            <p class="MsoNormal" align="center" style="margin-bottom:0in;margin-bottom:
    .0001pt;text-align:center;line-height:115%;mso-yfti-cnfc:1"><b><span
                                            style="font-size:9.0pt;line-height:115%;color:white;mso-themecolor:background1">AMOUNT <?php echo $biz->currency['currency']; ?></span></b>
                            </p>
                        </td>
                    </tr>
                    <?php if (@$getItems != NULL):
                        $index = 0;
                        $subtotal = 0;
                        foreach ($getItems as $list): $index++;
                            $subtotal = $subtotal + ($list['stock_sale_price'] * $list['stock_qty']);
                            ?>
                            <tr style="mso-yfti-irow:0;height:.2in">
                                <td width="42" style="width:31.5pt;border:solid #9CC2E5 1.0pt;mso-border-themecolor:
    accent5;mso-border-themetint:153;border-top:none;mso-border-top-alt:solid #9CC2E5 .5pt;
    mso-border-top-themecolor:accent5;mso-border-top-themetint:153;mso-border-alt:
    solid #9CC2E5 .5pt;mso-border-themecolor:accent5;mso-border-themetint:153;mso-background-themecolor:accent5;mso-background-themetint:
    51;padding:0in 5.4pt 0in 5.4pt;height:.2in" valign="top">
                                    <p class="MsoNormal" align="center" style="margin-bottom:0in;margin-bottom:
    .0001pt;text-align:center;line-height:115%;mso-yfti-cnfc:68"><b><span
                                                    style="font-size:9.0pt;line-height:115%;mso-themecolor:background1"><?php echo $index; ?></span></b>
                                    </p>
                                </td>
                                <td width="354" style="width:265.5pt;border-top:none;border-left:none;
    border-bottom:solid #9CC2E5 1.0pt;mso-border-bottom-themecolor:accent5;
    mso-border-bottom-themetint:153;border-right:solid #9CC2E5 1.0pt;
    mso-border-right-themecolor:accent5;mso-border-right-themetint:153;
    mso-border-top-alt:solid #9CC2E5 .5pt;mso-border-top-themecolor:accent5;
    mso-border-top-themetint:153;mso-border-left-alt:solid #9CC2E5 .5pt;
    mso-border-left-themecolor:accent5;mso-border-left-themetint:153;
    mso-border-alt:solid #9CC2E5 .5pt;mso-border-themecolor:accent5;mso-border-themetint:
    153;background:#DEEAF6;mso-background-themecolor:accent5;mso-background-themetint:
    51;padding:0in 5.4pt 0in 5.4pt;height:.2in" valign="top">
                                    <p class="MsoNormal" align="left" style="margin-bottom:0in;margin-bottom:
    .0001pt;text-align:left;line-height:115%;mso-yfti-cnfc:64"><span
                                                style="font-size:9.0pt;line-height:115%;mso-themecolor:background1"><?php echo $list['item_description']; ?></span>
                                    </p>
                                </td>
                                <td width="102" style="width:76.25pt;border-top:none;border-left:none;
    border-bottom:solid #9CC2E5 1.0pt;mso-border-bottom-themecolor:accent5;
    mso-border-bottom-themetint:153;border-right:solid #9CC2E5 1.0pt;
    mso-border-right-themecolor:accent5;mso-border-right-themetint:153;
    mso-border-top-alt:solid #9CC2E5 .5pt;mso-border-top-themecolor:accent5;
    mso-border-top-themetint:153;mso-border-left-alt:solid #9CC2E5 .5pt;
    mso-border-left-themecolor:accent5;mso-border-left-themetint:153;
    mso-border-alt:solid #9CC2E5 .5pt;mso-border-themecolor:accent5;mso-border-themetint:
    153;background:#DEEAF6;mso-background-themecolor:accent5;mso-background-themetint:
    51;padding:0in 5.4pt 0in 5.4pt;height:.2in" valign="top">
                                    <p class="MsoNormal" align="center" style="margin-bottom:0in;margin-bottom:
    .0001pt;text-align:center;line-height:115%;mso-yfti-cnfc:64"><span
                                                style="font-size:9.0pt;line-height:115%;mso-themecolor:background1"><?php echo $list['stock_qty']; ?></span>
                                    </p>
                                </td>
                                <td width="126" style="width:94.5pt;border-top:none;border-left:none;
    border-bottom:solid #9CC2E5 1.0pt;mso-border-bottom-themecolor:accent5;
    mso-border-bottom-themetint:153;border-right:solid #9CC2E5 1.0pt;
    mso-border-right-themecolor:accent5;mso-border-right-themetint:153;
    mso-border-top-alt:solid #9CC2E5 .5pt;mso-border-top-themecolor:accent5;
    mso-border-top-themetint:153;mso-border-left-alt:solid #9CC2E5 .5pt;
    mso-border-left-themecolor:accent5;mso-border-left-themetint:153;
    mso-border-alt:solid #9CC2E5 .5pt;mso-border-themecolor:accent5;mso-border-themetint:
    153;background:#DEEAF6;mso-background-themecolor:accent5;mso-background-themetint:
    51;padding:0in 5.4pt 0in 5.4pt;height:.2in" valign="top">
                                    <p class="MsoNormal" align="left" style="margin-bottom:0in;margin-bottom:
    .0001pt;text-align:left;line-height:115%;mso-yfti-cnfc:64"><span
                                                style="font-size:9.0pt;line-height:115%;mso-themecolor:background1"><?php echo number_format($list['stock_sale_price'], 2); ?></span>
                                    </p>
                                </td>
                                <td width="108" style="width:81.25pt;border-top:none;border-left:none;
    border-bottom:solid #9CC2E5 1.0pt;mso-border-bottom-themecolor:accent5;
    mso-border-bottom-themetint:153;border-right:solid #9CC2E5 1.0pt;
    mso-border-right-themecolor:accent5;mso-border-right-themetint:153;
    mso-border-top-alt:solid #9CC2E5 .5pt;mso-border-top-themecolor:accent5;
    mso-border-top-themetint:153;mso-border-left-alt:solid #9CC2E5 .5pt;
    mso-border-left-themecolor:accent5;mso-border-left-themetint:153;
    mso-border-alt:solid #9CC2E5 .5pt;mso-border-themecolor:accent5;mso-border-themetint:
    153;background:#DEEAF6;mso-background-themecolor:accent5;mso-background-themetint:
    51;padding:0in 5.4pt 0in 5.4pt;height:.2in" valign="top">
                                    <p class="MsoNormal" align="left" style="margin-bottom:0in;margin-bottom:
    .0001pt;text-align:left;line-height:115%;mso-yfti-cnfc:64"><span
                                                style="font-size:9.0pt;line-height:115%;mso-themecolor:background1"><?php echo number_format($list['stock_sale_price'] * $list['stock_qty'], 2); ?></span>
                                    </p>
                                </td>
                            </tr>
                        <?php endforeach; endif; ?>

                    <tr style="mso-yfti-irow:1;mso-yfti-lastrow:yes;height:.2in">
                        <td width="42" style="width:31.5pt;border:solid #9CC2E5 1.0pt;mso-border-themecolor:
    accent5;mso-border-themetint:153;border-top:none;mso-border-top-alt:solid #9CC2E5 .5pt;
    mso-border-top-themecolor:accent5;mso-border-top-themetint:153;mso-border-alt:
    solid #9CC2E5 .5pt;mso-border-themecolor:accent5;mso-border-themetint:153;
    padding:0in 5.4pt 0in 5.4pt;height:.2in" valign="top">
                            <p class="MsoNormal" align="center" style="margin-bottom:0in;margin-bottom:
    .0001pt;text-align:center;line-height:115%;mso-yfti-cnfc:4"><b><span
                                            style="font-size:9.0pt;line-height:115%;color:white;mso-themecolor:background1"><o:p>&nbsp;</o:p></span></b>
                            </p>
                        </td>
                        <td width="354" style="width:265.5pt;border-top:none;border-left:none;
    border-bottom:solid #9CC2E5 1.0pt;mso-border-bottom-themecolor:accent5;
    mso-border-bottom-themetint:153;border-right:solid #9CC2E5 1.0pt;
    mso-border-right-themecolor:accent5;mso-border-right-themetint:153;
    mso-border-top-alt:solid #9CC2E5 .5pt;mso-border-top-themecolor:accent5;
    mso-border-top-themetint:153;mso-border-left-alt:solid #9CC2E5 .5pt;
    mso-border-left-themecolor:accent5;mso-border-left-themetint:153;
    mso-border-alt:solid #9CC2E5 .5pt;mso-border-themecolor:accent5;mso-border-themetint:
    153;padding:0in 5.4pt 0in 5.4pt;height:.2in">
                            <p class="MsoNormal" align="center" style="margin-bottom:0in;margin-bottom:
    .0001pt;text-align:center;line-height:115%"><span style="font-size:9.0pt;
    line-height:115%;color:white;mso-themecolor:background1"><o:p>&nbsp;</o:p></span></p>
                        </td>
                        <td width="102" style="width:76.25pt;border-top:none;border-left:none;
    border-bottom:solid #9CC2E5 1.0pt;mso-border-bottom-themecolor:accent5;
    mso-border-bottom-themetint:153;border-right:solid #9CC2E5 1.0pt;
    mso-border-right-themecolor:accent5;mso-border-right-themetint:153;
    mso-border-top-alt:solid #9CC2E5 .5pt;mso-border-top-themecolor:accent5;
    mso-border-top-themetint:153;mso-border-left-alt:solid #9CC2E5 .5pt;
    mso-border-left-themecolor:accent5;mso-border-left-themetint:153;
    mso-border-alt:solid #9CC2E5 .5pt;mso-border-themecolor:accent5;mso-border-themetint:
    153;padding:0in 5.4pt 0in 5.4pt;height:.2in">
                            <p class="MsoNormal" align="center" style="margin-bottom:0in;margin-bottom:
    .0001pt;text-align:center;line-height:115%"><span style="font-size:9.0pt;
    line-height:115%;color:white;mso-themecolor:background1"><o:p>&nbsp;</o:p></span></p>
                        </td>
                        <td width="126" style="width:94.5pt;border-top:none;border-left:none;
    border-bottom:solid #9CC2E5 1.0pt;mso-border-bottom-themecolor:accent5;
    mso-border-bottom-themetint:153;border-right:solid #9CC2E5 1.0pt;
    mso-border-right-themecolor:accent5;mso-border-right-themetint:153;
    mso-border-top-alt:solid #9CC2E5 .5pt;mso-border-top-themecolor:accent5;
    mso-border-top-themetint:153;mso-border-left-alt:solid #9CC2E5 .5pt;
    mso-border-left-themecolor:accent5;mso-border-left-themetint:153;
    mso-border-alt:solid #9CC2E5 .5pt;mso-border-themecolor:accent5;mso-border-themetint:
    153;padding:0in 5.4pt 0in 5.4pt;height:.2in">
                            <p class="MsoNormal" align="center" style="margin-bottom:0in;margin-bottom:
    .0001pt;text-align:center;line-height:115%"><span style="font-size:9.0pt;
    line-height:115%;color:white;mso-themecolor:background1"><o:p>&nbsp;</o:p></span></p>
                        </td>
                        <td width="108" style="width:81.25pt;border-top:none;border-left:none;
    border-bottom:solid #9CC2E5 1.0pt;mso-border-bottom-themecolor:accent5;
    mso-border-bottom-themetint:153;border-right:solid #9CC2E5 1.0pt;
    mso-border-right-themecolor:accent5;mso-border-right-themetint:153;
    mso-border-top-alt:solid #9CC2E5 .5pt;mso-border-top-themecolor:accent5;
    mso-border-top-themetint:153;mso-border-left-alt:solid #9CC2E5 .5pt;
    mso-border-left-themecolor:accent5;mso-border-left-themetint:153;
    mso-border-alt:solid #9CC2E5 .5pt;mso-border-themecolor:accent5;mso-border-themetint:
    153;padding:0in 5.4pt 0in 5.4pt;height:.2in">
                            <p class="MsoNormal" align="center" style="margin-bottom:0in;margin-bottom:
    .0001pt;text-align:center;line-height:115%"><span style="font-size:9.0pt;
    line-height:115%;color:white;mso-themecolor:background1"><o:p>&nbsp;</o:p></span></p>
                        </td>
                    </tr>

                    </tbody>
                </table>
                <p class="MsoNormal" style="margin-bottom:0in;margin-bottom:.0001pt;line-height:
  normal">
                    <o:p>&nbsp;</o:p>
                </p>
                <table class="MsoTable15Plain4" border="0" cellspacing="0" cellpadding="0" width="732">
                    <tbody>

                    <tr style="mso-yfti-irow:-1;mso-yfti-firstrow:yes;mso-yfti-lastfirstrow:
    yes;height:.2in">
                        <td width="498" rowspan="5" valign="top" style="width:373.5pt;padding:0in 5.4pt 0in 5.4pt;
    height:.2in">
                            <p class="MsoNormal" style="margin-bottom:0in;margin-bottom:.0001pt;
    line-height:115%;"><b><span style="font-size:9.0pt;
    line-height:115%">ADDITIONAL NOTE:</span></b><span style="font-size:9.0pt;
    line-height:115%"></span></p>
                            <p class="MsoNormal" style="margin-bottom:0in;margin-bottom:.0001pt;
    line-height:115%;"><span style="font-size:9.0pt;line-height:
    115%"><?php echo @htmlspecialchars_decode(@$additional_note); ?> </span></p>
                        </td>
                        <td width="123" valign="top" style="width:92.35pt;padding:0in 5.4pt 0in 5.4pt;
    height:.2in">
                            <p class="MsoNormal" style="margin-bottom:0in;margin-bottom:.0001pt;
    line-height:115%;mso-yfti-cnfc:1"><b><span style="font-size:9.0pt;
    line-height:115%">SUBTOTAL <?php echo $biz->currency['currency']; ?></span></b></p>
                        </td>
                        <td width="111" valign="top" style="width:83.15pt;padding:0in 5.4pt 0in 5.4pt;
    height:.2in">
                            <p class="MsoNormal" style="margin-bottom:0in;margin-bottom:.0001pt;
    line-height:115%;mso-yfti-cnfc:1"><b><span style="font-size:9.0pt;
    line-height:115%"><?php echo @number_format($subtotal, 2); ?></span></b></p>
                        </td>
                    </tr>
                    <tr style="mso-yfti-irow:0;height:.2in">
                        <td width="123" valign="top" style="width:92.35pt;background:#F2F2F2;
    mso-background-themecolor:background1;mso-background-themeshade:242;
    padding:0in 5.4pt 0in 5.4pt;height:.2in">
                            <p class="MsoNormal" style="margin-bottom:0in;margin-bottom:.0001pt;
    line-height:115%;mso-yfti-cnfc:64"><b><span style="font-size:9.0pt;line-height:
    115%">DELIVERY CHARGES <?php echo $biz->currency['currency']; ?></span></b></p>
                        </td>
                        <td width="111" valign="top" style="width:83.15pt;background:#F2F2F2;
    mso-background-themecolor:background1;mso-background-themeshade:242;
    padding:0in 5.4pt 0in 5.4pt;height:.2in">
                            <p class="MsoNormal" style="margin-bottom:0in;margin-bottom:.0001pt;
    line-height:115%;mso-yfti-cnfc:64"><span style="font-size:9.0pt;line-height:
    115%"><?php echo @number_format($delivery_charges, 2); ?></span></p>
                        </td>
                    </tr>

                    <tr style="mso-yfti-irow:1;mso-yfti-lastrow:yes;height:.2in">
                        <td width="123" valign="top" style="width:92.35pt;padding:0in 5.4pt 0in 5.4pt;
    height:.2in">
                            <p class="MsoNormal" style="margin-bottom:0in;margin-bottom:.0001pt;
    line-height:115%">
                                <b><span style="font-size:9.0pt;line-height:115%">VAT <?php if (@$vat_charges > 0): echo '(' . $vat_charges . '%)'; endif; ?>
                                        <?php echo $biz->currency['currency']; ?></span></b>
                            </p>
                        </td>
                        <td width="111" valign="top" style="width:83.15pt;padding:0in 5.4pt 0in 5.4pt;
    height:.2in">
                            <p class="MsoNormal" style="margin-bottom:0in;margin-bottom:.0001pt;
    line-height:115%">
                            <span style="font-size:9.0pt;line-height:115%"><?php if (@$vat_charges > 0): @$vat_charges = (@$vat_charges / 100) * @$subtotal; endif;
                                echo @number_format($vat_charges, 2); ?></span></p>
                        </td>
                    </tr>

                    <tr style="mso-yfti-irow:0;height:.2in">
                        <td width="123" valign="top" style="width:92.35pt;background:#F2F2F2;
    mso-background-themecolor:background1;mso-background-themeshade:242;
    padding:0in 5.4pt 0in 5.4pt;height:.2in">
                            <p class="MsoNormal" style="margin-bottom:0in;margin-bottom:.0001pt;
    line-height:115%;mso-yfti-cnfc:64"><b><span style="font-size:9.0pt;line-height:
    115%">DISCOUNT <?php echo $biz->currency['currency']; ?></span></b></p>
                        </td>
                        <td width="111" valign="top" style="width:83.15pt;background:#F2F2F2;
    mso-background-themecolor:background1;mso-background-themeshade:242;
    padding:0in 5.4pt 0in 5.4pt;height:.2in">
                            <p class="MsoNormal" style="margin-bottom:0in;margin-bottom:.0001pt;
    line-height:115%;mso-yfti-cnfc:64"><span style="font-size:9.0pt;line-height:
    115%"><?php if (@$discount > 0): @$discount = (@$discount / 100) * (@$subtotal + @$delivery_charges + @$vat_charges); endif;
                                    echo @number_format($discount, 2); ?></span></p>
                        </td>
                    </tr>


                    <tr style="mso-yfti-irow:1;mso-yfti-lastrow:yes;height:.2in">

                        <td width="123" valign="top" style="width:92.35pt;padding:0in 5.4pt 0in 5.4pt;
    height:.2in">
                            <p class="MsoNormal" style="margin-bottom:0in;margin-bottom:.0001pt;
    line-height:115%">
                                <b><span style="font-size:9.0pt;line-height:115%">TOTAL <?php echo $biz->currency['currency']; ?></span></b>
                            </p>
                        </td>
                        <td width="111" valign="top" style="width:83.15pt;padding:0in 5.4pt 0in 5.4pt;
    height:.2in">
                            <p class="MsoNormal" style="margin-bottom:0in;margin-bottom:.0001pt;
    line-height:115%">
                                <b><span style="font-size:9.0pt;line-height:115%"><?php echo @number_format((@$subtotal + @$delivery_charges + @$vat_charges) - $discount, 2); ?></span></b>
                            </p>
                        </td>
                    </tr>
                    </tbody>
                </table>
                <p class="MsoNormal" style="margin-bottom:0in;margin-bottom:.0001pt;line-height:
  115%">

                </p>
            </td>
        </tr>
        <tr style="mso-yfti-irow:2;mso-yfti-lastrow:yes;height:5.4pt">
            <td width="720" colspan="2" valign="top" style="width:7.5in;padding:0in 0in 0in 0in;
  height:5.4pt">
                <p class="MsoNormal" align="center" style="margin-bottom:0in;margin-bottom:.0001pt;
  text-align:center;line-height:normal"><b><span
                                style="font-size:9.0pt">Don't hesitate to contact us for more info.</span></b>
                </p>
                <hr style="margin: 2.0pt auto">
                <p class="MsoNormal" align="center" style="margin-bottom:0in;margin-bottom:.0001pt;
  text-align:center;line-height:normal"><b><span
                                style="font-size:9.0pt"><?php echo $biz->biz['business_address']; ?></span></b></p>
                <p class="MsoNormal" align="center" style="margin-bottom:0in;margin-bottom:.0001pt;
  text-align:center;line-height:normal"><span
                            style="font-size:9.0pt;font-family:" cambria",serif"=""> </span><span
                            style="font-size:9.0pt"><?php if ($biz->biz['email_address'] != ""): echo $biz->biz['email_address'] . ' | '; endif; ?></span>
                    <span style="font-size:9.0pt"><?php echo $biz->biz['mobile_number']; ?></span></p>
            </td>
        </tr>
        </tbody>
    </table>
</div>