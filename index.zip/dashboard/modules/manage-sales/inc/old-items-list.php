<?php
//if($roles['ProdList']!=="1"){echo '<script>location.replace("default.php")</script>';}  
// require queries file
require_once 'inc/queries.php';
?>

<div id="responses"></div>
<div class="card x_panel">
    <div class="x_title">
        <span class="title"><i class="fal fa-shopping-cart"></i> Manage Items </span>
    </div>
    <div class="x_content">
        <div class="row mb-4">
            <div class="col-auto mr-auto">
                <span class="dropdown">
                    <button class="btn btn-primary px-4 dropdown-toggle" type="button" data-toggle="dropdown">
                        <i class="fal fa-tag" title="Select Category" data-toggle="tooltip" data-placement="bottom"></i><span
                                class="text"> Category</span> <i class="caret"></i></button>
                    <ul class="dropdown-menu dropdown-menu-left scroll br-0 p-0 m-0"
                        style="max-height: 300px; overflow-y: auto">
                        <?php
                        while ($dn = dbFetchAssoc($category_result)):
                            ?>
                            <a href="?p=items-list&category=<?php echo $dn['id'] ?>" class="dropdown-item br-0">
                                    <i class="fal fa-angle-double-right"></i>
                                <?php echo $dn['category']; ?></a>
                        <?php endwhile; ?>
                        <a href="?p=items-list" class="dropdown-item"><i
                                    class="fal fa-angle-double-right"></i> All Products </a>
                    </ul>
                </span>
                <span class="dropdown">
                    <button class="btn btn-primary px-4 dropdown-toggle" type="button" data-toggle="dropdown"> <i
                                class="fal fa-clock" title="Expiry" data-toggle="tooltip"
                                data-placement="bottom"></i> <span class="text">Expiry </span> </button>
                    <ul class="dropdown-menu dropdown-menu-left m-0 p-0">
                        <a href="?p=items-list&expired=90" class="dropdown-item"><i
                                    class="fal fa-angle-double-right"></i> Expired in 3 Month </a>
                        <a href="?p=items-list&expired=180" class="dropdown-item"><i
                                    class="fal fa-angle-double-right"></i> Expired in 6 Month </a>
                        <a href="?p=items-list&expired=366" class="dropdown-item"><i
                                    class="fal fa-angle-double-right"></i> Expired in 1 Yr </a>
                    </ul>
                </span>
                <button type="button" name="button" class="btn btn-primary px-4"
                        onClick="javascript:location.replace('?p=items-list&stock-level')" title="Item Stock Level"
                        data-toggle='tooltip'><i class="fal fa-exclamation-triangle"></i> <span
                            class="text">Stock Level</span></button>
            </div>
            <div class="col-auto ml-auto">
                <?php if (@$access['item_replenishment'] == 1) { ?>
                    <button type="button" name="button" class="btn btn-primary px-4"
                            onClick="javascript:$('#replenishItem').modal({backdrop: 'static'})"
                            title="Item Replenishment" data-toggle='tooltip'><i class="fal fa-cart-plus"></i> <span
                                class="text">Replenishment</span></button>
                    <button type="button" name="button" class="btn btn-primary px-4"
                            onClick="javascript:location.replace('?p=item-replenishment-history')"
                            title="Item Replenishment History" data-toggle='tooltip'><i class="fal fa-check-circle"></i>
                        <span class="text">Replenishment History</span></button>
                <?php }
                if (@$access['item_entry'] == 1) { ?>
                    <button type="button" name="button" class="btn btn-primary px-4"
                            onClick="javascript:location.replace('?p=item-entry')" title="Add New Item"
                            data-toggle='tooltip'><i class="fal fa-cart-plus"></i> <span
                                class="text">Add New Item</span></button>
                <?php }
                if (@$access['items_category'] == 1) { ?>
                    <button type="button" name="button" class="btn btn-primary px-4"
                            onClick="javascript:location.replace('?p=items-category')" title="Item Category"
                            data-toggle='tooltip'><i class="fal fa-folder-tree"></i> <span class="text">Item Category</span>
                    </button>
                <?php } ?>


            </div>
        </div>
        <div class="table-responsive datatable-buttons">
            <table class="table table-hover table-striped datatable-btn" style="font-size:12px;">
                <?php if (isset($_GET['expired']) || isset($_GET['stock-level']) || isset($_GET['category'])) { ?>
                    <caption>
                        Currently viewing filtered records [ <a href="?p=items-list">View All</a> ]
                    </caption>
                <?php } else { ?>
                    <caption>Currently viewing unfiltered records</caption>
                <?php } ?>
                <thead>
                <tr>
                    <th>Item ID</th>
                    <th>Item Name/Description</th>
                    <th>Item Category</th>
                    <th>Location/Cabinet</th>
                    <th>Quantity</th>
                    <?php if ($userinfo['user_group'] == 1) { ?>
                        <th>Unit Price (N)</th>
                        <th>Sale Price (N)</th>
                        <th>Total Amount (N)</th>
                        <th>Sale Amount (N)</th>
                    <?php } ?>
                    <th>&nbsp;</th>
                </tr>
                </thead>
                <tbody>
                <?php
                $index = 0;
                $grand_total = 0;
                $grand_sale_total = 0;
                while ($dn = dbFetchAssoc($items_result)): $index++;
                    $category = getItemCategory($dn['item_category']);
                    if ($dn['item_category'] == 0) {
                        $category = $category;
                    } else {
                        $category = $category['category'];
                    }
                    $cabinet = getCabinet($dn['item_location']);
                    $uom = getUOM($dn['item_uom']);
                    $grand_total = $grand_total + $dn['item_qty'] * $dn['item_price'];
                    $grand_sale_total = $grand_sale_total + $dn['item_qty'] * $dn['item_sale_price'];
                    ?>
                    <tr class="data-btn">
                        <td>
                            <?php echo $dn['item_id'] ?>
                        </td>
                        <td>
                            <?php echo $dn['item_name'] ?>

                        </td>
                        <td>
                            <?php echo $category; ?>
                        </td>
                        <td>
                            <?php echo $cabinet['cabinet']; ?>
                        </td>
                        <td>
                            <?php echo $dn['item_qty'] ?>
                        </td>
                        <?php if ($userinfo['user_group'] == 1) { ?>
                            <td>
                                <?php echo number_format($dn['item_price'], 2) ?>
                            </td>
                            <td>
                                <?php echo number_format($dn['item_sale_price'], 2) ?>
                            </td>
                            <td>
                                <?php echo number_format($dn['item_price'] * $dn['item_qty'], 2) ?>
                            </td>
                            <td>
                                <?php echo number_format($dn['item_sale_price'] * $dn['item_qty'], 2) ?>
                            </td>
                        <?php } ?>
                        <td align="right">
                            <div class="btn-group btn-group-sm">
                                <a class="btn btn-primary" title="View Record" data-toggle="tooltip" href="#"
                                   onclick="javascript:$('#viewRecord').modal('show'); getItemInfo('<?php echo $dn['id']; ?>');">
                                    <i class="fal fa-info-circle"></i> </a>
                                <?php if (@$access['edit_item'] == 1) { ?>
                                    <a class="btn btn-primary" title="Edit Record" data-toggle="tooltip"
                                       href="?p=item-entry&edit-item=<?php echo $dn['id'] ?>"> <i
                                                class="fal fa-edit"></i>
                                    </a>
                                <?php }
                                if (@$access['delete_item'] == 1) { ?>
                                    <a class="btn btn-primary" href="#" title="Delete Record" data-toogle="tooltip"
                                       onClick="javascript:confirmRequest('<?php echo $dn['id'] . 'item'; ?>', <?php echo $dn['id']; ?>, 'Are you sure you want to delete this item?', 'delete-item');"><i
                                                class="fal fa-trash"></i></a>
                                <?php } ?>
                            </div>

                        </td>
                    </tr>
                <?php endwhile; ?>
                </tbody>
                <tfoot>
                <tr>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <?php if ($userinfo['user_group'] == 1) { ?>
                        <td></td>
                        <th colspan="">GRAND TOTAL</th>
                        <td colspan=""><?php echo number_format($grand_total, 2) ?></td>
                        <td colspan=""><?php echo number_format($grand_sale_total, 2) ?></td>
                    <?php } ?>
                    <td></td>
                </tr>
                </tfoot>
            </table>

        </div>
    </div>

</div>

<div class="modal fade mb-5" id="viewRecord">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content card x_panel bg-light">
            <div class="modal-header x_title">
                <h6 class="modal-title title m-0 p-0"><i class="fal fa-info-circle"></i> Item Record</h6>
            </div>
            <div class="modal-body x_content" id="product-details">

            </div>
            <div class="modal-footer">
                <button class="btn px-4 btn-primary" onclick="javascript:printDiv('product-details');"><i
                            class="fal fa-print"></i> Print
                </button>
                <button type="button" class="btn btn-danger px-4" data-dismiss="modal"
                        onclick="$('#viewRecord').modal('hide');"><i class="fal fa-times-circle"></i> Close
                </button>
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->


<!-- Item replenishment modal -->

<div class="modal fade" id="replenishItem">
    <div class="modal-dialog modal-sm" role="document">
        <div class="modal-content bg-light x_panel p-2">
            <div class="modal-header x_title">
                <h6 class=" m-0 p-0 h6"><i class="fal fa-cart-plus"></i> Replenishment</h6>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body x_content p-2" id="product-details">
                <div id="result"></div>
                <form method="post" class="submit-product" novalidate>
                    <div class="alert alert-danger px-4 p-2 hide"></div>
                    <div class="form-group">
                        <label>Select Item</label>
                        <div class="input-group ">
                            <input class="form-control item_search replenish-item-stock"
                                   placeholder="Enter Item ID/Name" required data-title="Select Item">
                            <span class="input-group-btn">
                                    <button class="btn btn-primary br-0" type="button"><i
                                                class="fal fa-search m-0"></i></button>
                                </span>
                        </div>
                    </div>
                    <div id="replenish-response">
                    </div>
                    <div id="replenish-info" class="hide">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Current Qty</label>
                                    <input class="form-control" name="current_qty" id="current-qty"
                                           placeholder="Current Qty" readonly>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Add Qty</label>
                                    <input type="text" class="form-control num" min="0" required data-title="Enter Qty"
                                           onkeyup="calcRepQty();" onchange="calcRepQty();" autocomplete="off"
                                           name="add_qty" id="add-qty" placeholder="Enter Qty">
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <label>New Quantity</label>
                            <input class="form-control" name="new_qty" id="new-qty" readonly placeholder="New Qty">
                        </div>

                        <input type="hidden" name="item_id" id="item-id">
                        <input type="hidden" name="submit-item-replenish" value="1">
                        <button class="btn px-4 btn-primary save-btn"><i class="fal fa-save"></i> Save</button>
                        <button type="button" class="btn btn-danger px-4" data-dismiss="modal"
                                onclick="$('#replenishItem').modal('hide');"><i class="fal fa-times-circle"></i> Close
                        </button>
                    </div>
                </form>
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->

<script>

</script>
