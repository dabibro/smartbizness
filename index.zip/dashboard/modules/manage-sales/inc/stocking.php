<?php
/**
 * Created by PhpStorm.
 * User: Dauda Ibrahim
 * Date: 8/18/2020
 * Time: 9:43 AM
 */

?>
<script src="<?php echo $modulePath ?>js.js"></script>
<form method="post" class="AppForm" id="submit-stocking-form">
    <div id="ModuleResponse"></div>
    <div id="stocking-response"></div>
    <div class="form-group">
        <label>Product Selection</label>
        <div class="input-group input-group-sm">
            <input type="search" name="product_name" tabindex="1"
                   class="form-control product_search stock_query" autocomplete="off"
                   id="product_search" placeholder="SKU/Name/Description" required>
            <div class="btn-group">
                <button class="btn btn-sm btn-default pr-2" tabindex="2" type="button"
                        onclick="fetchProductInfo($('.stock_query').val());"><i
                            class="fal fa-check-circle m-0"></i></button>
            </div>
            <div class="invalid-feedback">* Required: No product selected</div>
        </div>
    </div>
    <div id="stocking-info" class="">
        <div class="row">
            <div class="col-md-4">
                <div class="form-group">
                    <label>In Stock</label>
                    <input class="form-control form-control-sm" name="stock_qty" id="stock_qty"
                           placeholder="Current Qty" readonly>
                </div>
            </div>
            <div class="col-md-4">
                <div class="form-group">
                    <label>Cost Price <?php echo @$biz->currency['currency']; ?></label>
                    <input type="text" class="form-control num form-control-sm" min="0" required
                           autocomplete="off" name="price" id="stock_price" readonly
                           placeholder="Cost Price">
                    <div class="invalid-feedback">* Required field</div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="form-group">
                    <label>Sale Price <?php echo @$biz->currency['currency']; ?></label>
                    <input type="text" class="form-control num form-control-sm" min="0" required
                           autocomplete="off" name="sale_price" id="stock_sale_price" readonly
                           placeholder="Sale Price">
                    <div class="invalid-feedback">* Required field</div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-4">
                <div class="form-group">
                    <label>Add Stock</label>
                    <input type="text" class="form-control num form-control-sm" min="0" required tabindex="3"
                           onkeyup="calcStockingQty();" onchange="calcStockingQty();" autocomplete="off"
                           name="add_qty" id="add-qty" placeholder="Enter Quantity">
                    <div class="invalid-feedback">* Required field</div>
                </div>
            </div>
            <div class="col-lg-4">
                <div class="form-group">
                    <label>New Stock</label>
                    <input class="form-control form-control-sm" name="new_qty" id="new-qty" readonly
                           placeholder="New Qty">
                </div>
            </div>
            <div class="col-lg-4">
                <div class="form-group pt-4">
                    <input type="hidden" name="app_id" id="item-appid">
                    <input type="hidden" name="SubmitProductStocking" value="1">

                </div>
            </div>
        </div>
        <hr class="mt-2">
        <button class="btn px-4 btn-default btn-block actionButton btn-sm"><i
                    class="fal fa-check-circle"></i> Submit Stocking
        </button>
    </div>
</form>

<div id="actionEvents"></div>
<script>
    //-------------------------------------------------------------------------------

    $('.num').keyup(function () {
        this.value = this.value.replace(/[^0-9\.-]/g, '');
    });
    $(".product_search").autocomplete({
        source: modulePath + 'pos/ajaxInventoryLookup.php'
    });

    //-------------------------------------------------------------------------------
    function fetchProductInfo(query) {
        if (query !== "") {
            var split = query.split(' -> ');
            var app_id = split[0];
            $.post(modulePath + 'ajaxRequest.php',
                {
                    fetchInvItem: 1,
                    app_id: app_id,
                },
                function (response) {
                    $('#stocking-response').html(response);
                });
        }
    }

    //-------------------------------------------------------------------------------
    function calcStockingQty() {
        var current_qty = $('#stock_qty').val();
        var add_qty = $('#add-qty').val();
        var new_qty = (current_qty - 0) + (add_qty - 0);
        if (new_qty > 0 && new_qty !== 'NaN' && add_qty !== '') {
            $("#new-qty").val(new_qty);
        } else {
            $("#new-qty").val('');
        }
    }

    //-------------------------------------------------------------------------------
    function resetStocking() {
        $("#submit-stocking-form")[0].reset();
        $('.product_search').focus();
    }
</script>