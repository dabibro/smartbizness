<?php
//--------------------------------------------------------------------------------------------------

$store = "";
if (isset($auth['store_id']) && $auth['store_id'] != ""):
    $store = "AND app_inventory.store_id = '" . $auth['store_id'] . "' ";
endif;
//--------------------------------------------------------------------------------------------------
$default = "app_inventory.app_id = app_products.app_id AND app_inventory.active_status = 1 " . $store;
$condition = $default;
//--------------------------------------------------------------------------------------------------
if (isset($_POST['filterRequest']) && $_POST['filterRequest'] !== NULL):
    $filterParam = $_POST['filterRequest'];
    if ($filterParam['search'] != ""):
        $condition = "";
        $search_query = trim($filterParam['search']);
        $condition = $default . "AND app_products.sku_barcode LIKE '%" . $search_query . "%'";
        $condition .= "OR " . $default . " AND app_products.app_id LIKE '%" . $search_query . "%' ";
        $condition .= "OR " . $default . " AND app_products.batch_sku_barcode LIKE '%" . $search_query . "%' ";
        $condition .= "OR " . $default . " AND app_products.name LIKE '%" . $search_query . "%' ";
        $condition .= "OR " . $default . " AND app_products.description LIKE '%" . $search_query . "%' ";
    else:
        @$category_id = @$filterParam['category_subcategory'];
        @$warning_level = @$filterParam['warning_level'];
        @$expiry_warning = @$filterParam['expiry_warning'];
        if ($category_id != "" || $warning_level != "" || $expiry_warning != ""):
            $condition = "";
        endif;
        if (@$category_id != ""):
            $condition .= $default . " AND app_products.category_id = '$category_id'";
        endif;
        if (@$warning_level != ""):
            $condition .= $default . " AND app_inventory.stock_qty < app_inventory.warning_level ";
        endif;
        if (@$expiry_warning != ""):
            $condition .= $default . " AND app_inventory.expiry_date != '' 
            AND app_inventory.expiry_date != '0000-00-00' 
            AND app_inventory.expiry_date <= DATE_ADD(CURRENT_DATE(), INTERVAL '$expiry_warning' DAY)";
        endif;
    endif;
endif;
$paginate_exp = explode('?page=', $url);
if (isset($paginate_exp[1]) && $paginate_exp[1] != ""):
    $ipp_exp = explode('&ipp=', $paginate_exp[1]);
    if (isset($ipp_exp[0]) && $ipp_exp[0] != ""):
        define('page', $ipp_exp[0]);
    else:
    endif;
    if (isset($ipp_exp[1]) && $ipp_exp[1] != ""):
        define('ipp', $ipp_exp[1]);
    else:
    endif;
else:
    define('page', '');
    define('ipp', '');
endif;
define('self', '#/sales-point/items/');
$pages = new Paginator_Class;
if (ipp != ""):
    $pages->default_ipp = ipp;
else:
    $pages->default_ipp = 50;
endif;

$sql_forms = Data_Access::execSQL("SELECT app_inventory.app_id FROM " . $app->dbScheme . ".app_inventory, " . $app->dbScheme . ".app_products WHERE " . $condition . "  ");
@$pages->items_total = $sql_forms['dataArray']->num_rows;
$pages->mid_range = 4;
$pages->paginate();

$sql = "SELECT app_inventory.stock_qty, app_inventory.app_id, app_products.sku_barcode, 
app_products.name, app_products.category_id, app_products.price, app_products.sale_price ";
$sql .= "FROM " . $app->dbScheme . ".app_inventory, " . $app->dbScheme . ".app_products ";
$sql .= "WHERE   " . $condition . " ORDER BY store_id ASC " . $pages->limit . " ";

if (!($result = Data_Access::execSQL($sql))):
    die(mysqli_error());
else :
    @$recordsArray = Data_Access::fetchAssoc($result['dataArray'])['dataArray'];
endif;
?>
<div id="ModuleResponse"></div>
<div class="row marginTop mx-0">
    <div class="col-12 pl-0 paddingLeft pagerfwt">
        <?php if ($pages->items_total > 0) { ?>
            <?php echo $pages->display_pages(); ?>
            <?php echo $pages->display_items_per_page(); ?>
            <?php echo $pages->display_jump_menu(); ?>
        <?php } ?>
    </div>
    <div class="clearfix"></div>
    <hr>
</div>
<div class="table-responsive">
    <table class="table data-tables table-sm elevation-1">
        <?php if (@$filterParam != NULL): ?>
            <caption>Currently viewing filter product(s) [ <a href="javascript:void(0);" onclick="fetchURL('');"
                                                              class="small">Reset Filter</a> ]
            </caption>
        <?php else: ?>
            <caption>Current viewing all product(s)</caption>
        <?php endif; ?>
        <thead>
        <tr>
            <th>SKU/Barcode</th>
            <th>Name/Description</th>
            <th>Category</th>
            <th>Stock Qty</th>
            <th>Price</th>
            <th>Sale Price</th>
            <th><i class="fal fa-cogs"></i></th>
        </tr>
        </thead>
        <tbody class="card-body">
        <?php
        if (isset($recordsArray) && $recordsArray != NULL):foreach (@$recordsArray as $products): extract($products); ?>
            <tr>
                <td><?php echo @$sku_barcode; ?></td>
                <td><?php echo @trim(@$name); ?></td>
                <td><?php echo @trim(@$module->getRecord(["tbl_scheme" => 'app_category', "condition" => ["id" => @$category_id]])['dataArray'][0]['name']); ?></td>
                <td><?php echo @$stock_qty; ?></td>
                <td><?php echo @number_format($price, 2); ?></td>
                <td><?php echo @number_format($sale_price, 2); ?></td>
                <td style="width:5%;" class="py-1" nowrap="nowrap">
                    <div class="btn-group-justify btn-group-sm float-right">
                        <button type="button" class="btn btn-default"
                                onclick="AppModalLoader({modalId:'ModuleModal', modalSize:'modal-lg', modalTitle:'Product Information', required:'../manage-inventory/inc/product_info', afterEvent: '', modalRequest:{'app_id':'<?php echo $app_id; ?>'}});"
                                title="View Record"><i
                                    class="fal fa-info-circle"></i>
                        </button>
                </td>
            </tr>
        <?php endforeach;
        else: ?>
            <tr>
                <td colspan="7" align="center">No data available</td>
            </tr>
        <?php endif; ?>
        </tbody>
    </table>
</div>
<div class="row marginTop mx-0">
    <div class="col-12 pl-0 paddingLeft pagerfwt">
        <?php if ($pages->items_total > 0) { ?>
            <?php echo $pages->display_pages(); ?>
            <?php echo $pages->display_items_per_page(); ?>
            <?php echo $pages->display_jump_menu(); ?>
        <?php } ?>
    </div>
    <div class="clearfix"></div>
    <hr>
</div>
