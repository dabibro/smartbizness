<?php
$getSubView = explode('products/', @$viewRequest);
if (isset($getSubView[1]) && @$viewRequest != ""):
    $subView = "products/";
endif;
?>
    <div class="row mb-3">
        <div class="col-12">
            <ul class="nav ml-auto modules-menu">
                <li class="nav-item"><a
                            class="nav-link <?php if (@$viewRequest == 'products/'): echo ' active'; endif; ?>"
                            href="#/sales-point/sales-transacts/products/"
                            onclick="fetchURL(this.href)"><i
                                class="fal fa-boxes"></i> Products Sales Report</a></li>
                <li class="nav-item">
                    <a class="nav-link app-link <?php if (@$viewRequest == 'reversals/'): echo ' active'; endif; ?>"
                       href="#/sales-point/sales-transacts/reversals/"
                       onclick="fetchURL(this.href)"><i class="fal fa-history"></i> Reversal
                        History</a>
                </li>
                <li class="nav-item"><a
                            class="nav-link <?php if (@$viewRequest == 'deposits/'): echo ' active'; endif; ?>"
                            href="#/sales-point/sales-transacts/deposits/"
                            onclick="fetchURL(this.href)"><i
                                class="fal fa-wallet"></i> Purchase Deposits</a></li>


                <?php if (isset($subView) && @$subView === "products/"): ?>
                    <!--- Products Sales Filter -->
                    <li class="nav-item app-collapse  ml-auto">
                        <div class="form-group mb-1">
                            <div class="input-group input-group-sm">
                                <input type="search" class="form-control form-control-sm border-right-0" name="search"
                                       placeholder="Search keyword..."
                                       style="border-radius: 0;" form="product-sales-report">
                                <div class="btn-group">
                                    <button class="btn mr-2 btn-default btn-sm pr-2" form="product-sales-report"
                                            style="height: 31px" type="button"
                                            onclick="javascript:$('#appFilterBtn').click();">
                                        <i
                                                class="fal fa-search m-0"
                                                style="font-size: 0.70rem;"></i>
                                    </button>
                                    <a class="nav-link dropdown-toggle" data-toggle="collapse"
                                       href="#collapseSalesFilter"
                                       aria-expanded="false" aria-controls="collapseSalesFilter">
                                        <i class="fal fa-filter"></i> Advance Filter<span class="caret"></span>
                                    </a>
                                </div>
                            </div>
                        </div>
                        <div class="collapse collapse-container right" id="collapseSalesFilter">
                            <div class="card-body elevation-1 bg-light left p-3">
                                <form method="post" action="#" id="product-sales-report">
                                    <div class="form-group">
                                        <label for="" class="w-100">Product Name <span class="float-right"><label
                                                        class="mb-0"><input
                                                            type="checkbox"
                                                            name="return" value="1"> Returned Products</label></span>
                                        </label>
                                        <input name="product" id="product_search"
                                               class="form-control form-control-sm product_search"
                                               placeholder="Product Name">
                                    </div>
                                    <div class="form-group">
                                        <label for="">Cashier Name</label>
                                        <select name="cashier_name"
                                                class="form-control form-control-sm select2">
                                            <option value="">-- Select --</option>
                                            <?php
                                            $cashiersArray = $module->getRecord(["tbl_scheme" => 'app_users', "condition" => ['delete_status' => 0]]);
                                            foreach ($cashiersArray['dataArray'] as $cashiers):
                                                echo $app->dropDownList($cashiers['firstname'] . ' ' . $cashiers['lastname'], '');
                                            endforeach; ?>
                                        </select>
                                    </div>
                                    <label for="" class="small text-muted">Transaction Date Range</label>
                                    <div class="row">
                                        <div class="col-6">
                                            <div class="form-group mb-0">
                                                <label for="">Start Date</label>
                                                <input type="text" name="start_date"
                                                       class="form-control form-control-sm datepicker"
                                                       placeholder="Start Date">
                                            </div>
                                        </div>
                                        <div class="col-6">
                                            <div class="form-group mb-0">
                                                <label for="">End Date</label>
                                                <input type="text" name="end_date"
                                                       class="form-control form-control-sm datepicker"
                                                       placeholder="End Date">
                                            </div>
                                        </div>
                                    </div>
                                    <input type="hidden" readonly name="delete_status" value="0">
                                    <hr class="my-3">
                                    <button class="btn btn-default btn-sm btn-block" id="appFilterBtn">
                                        <i class="fal fa-check-circle"></i>
                                        Submit
                                    </button>
                                    <input type="hidden" readonly name="view"
                                           value="/#/sales-point/<?php echo $view . @$viewRequest; ?>">
                                </form>
                            </div>
                        </div>
                    </li>
                <?php elseif (isset($viewRequest) && @$viewRequest === "deposits/"): ?>
                    <!--- Purchase Deposit Filter -->
                    <li class="nav-item app-collapse  ml-auto">
                        <div class="form-group mb-1">
                            <div class="input-group input-group-sm">
                                <input type="search" class="form-control form-control-sm border-right-0" name="search"
                                       placeholder="Search keyword..."
                                       style="border-radius: 0;" form="deposits-report">
                                <div class="btn-group">
                                    <button class="btn mr-2 btn-default btn-sm pr-2" form="deposits-report"
                                            style="height: 31px" type="button"
                                            onclick="javascript:$('#appFilterBtn').click();">
                                        <i
                                                class="fal fa-search m-0"
                                                style="font-size: 0.70rem;"></i>
                                    </button>
                                    <a class="nav-link dropdown-toggle" data-toggle="collapse"
                                       href="#collapseSalesFilter"
                                       aria-expanded="false" aria-controls="collapseSalesFilter">
                                        <i class="fal fa-filter"></i> Advance Filter<span class="caret"></span>
                                    </a>
                                </div>
                            </div>
                        </div>
                        <div class="collapse collapse-container right" id="collapseSalesFilter">
                            <div class="card-body elevation-1 bg-light left p-3">
                                <form method="post" action="#" id="deposits-report">
                                    <div class="form-group">
                                        <label for="">Cashier Name</label>
                                        <select name="cashier_name"
                                                class="form-control form-control-sm select2">
                                            <option value="">-- Select --</option>
                                            <?php
                                            $cashiersArray = $module->getRecord(["tbl_scheme" => 'app_users', "condition" => ['delete_status' => 0]]);
                                            foreach ($cashiersArray['dataArray'] as $cashiers):
                                                echo $app->dropDownList($cashiers['firstname'] . ' ' . $cashiers['lastname'], '');
                                            endforeach; ?>
                                        </select>
                                    </div>
                                    <label for="" class="small text-muted">Transaction Date Range</label>
                                    <div class="row">
                                        <div class="col-6">
                                            <div class="form-group mb-0">
                                                <label for="">Start Date</label>
                                                <input type="text" name="start_date"
                                                       class="form-control form-control-sm datepicker"
                                                       placeholder="Start Date">
                                            </div>
                                        </div>
                                        <div class="col-6">
                                            <div class="form-group mb-0">
                                                <label for="">End Date</label>
                                                <input type="text" name="end_date"
                                                       class="form-control form-control-sm datepicker"
                                                       placeholder="End Date">
                                            </div>
                                        </div>
                                    </div>
                                    <input type="hidden" readonly name="delete_status" value="0">
                                    <hr class="my-3">
                                    <button class="btn btn-default btn-sm btn-block" id="appFilterBtn">
                                        <i class="fal fa-check-circle"></i>
                                        Submit
                                    </button>
                                    <input type="hidden" readonly name="view"
                                           value="/#/sales-point/<?php echo $view . @$viewRequest; ?>">
                                </form>
                            </div>
                        </div>
                    </li>
                <?php else: ?>
                    <!--- Sales Transact Filter -->
                    <li class="nav-item app-collapse  ml-auto">
                        <div class="form-group mb-1">
                            <div class="input-group input-group-sm">
                                <input type="search" class="form-control form-control-sm border-right-0" name="search"
                                       placeholder="Search keyword..."
                                       style="border-radius: 0;" form="sales-transact-filter">
                                <div class="btn-group">
                                    <button class="btn mr-2 btn-default btn-sm pr-2" form="sales-transact-filter"
                                            style="height: 31px" type="button"
                                            onclick="javascript:$('#appFilterBtn').click();">
                                        <i
                                                class="fal fa-search m-0"
                                                style="font-size: 0.70rem;"></i>
                                    </button>
                                    <a class="nav-link dropdown-toggle" data-toggle="collapse"
                                       href="#collapseSalesFilter"
                                       aria-expanded="false" aria-controls="collapseSalesFilter">
                                        <i class="fal fa-filter"></i> Advance Filter<span class="caret"></span>
                                    </a>
                                </div>
                            </div>
                        </div>
                        <div class="collapse collapse-container right" id="collapseSalesFilter">
                            <div class="card-body elevation-1 bg-light left p-3">
                                <form method="post" action="#" id="sales-transact-filter">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label for="">Transaction Type</label>
                                                <select name="transact_type"
                                                        class="form-control form-control-sm select2">
                                                    <option value="">-- Select --</option>
                                                    <?php
                                                    $listArray = array("Sales" => 'Sales Transact', "Billing" => "Billing Transact", "Return" => "Return Transact");
                                                    foreach ($listArray as $type => $label):
                                                        echo $app->dropDownList($type, $label, '');
                                                    endforeach; ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label for="">Customer Type</label>
                                                <select name="customer_type"
                                                        class="form-control form-control-sm select2">
                                                    <option value="">-- Select --</option>
                                                    <?php
                                                    $listArray = array("Walk In Customer" => 'Walk In Customer', "On Account Customer" => "On Account Customer");
                                                    foreach ($listArray as $type => $label):
                                                        echo $app->dropDownList($type, $label, '');
                                                    endforeach; ?>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="">Customer Name</label>
                                        <select name="customer_id" class="form-control form-control-sm select2">
                                            <option value="">-- Select --</option>
                                            <?php
                                            $listArray = $module->getRecord([
                                                "tbl_scheme" => 'app_customers', "condition" => ['active_status' => 1, 'delete_status' => 0]
                                            ]);
                                            foreach ($listArray['dataArray'] as $customer_data):
                                                echo $app->dropDownList($customer_data['app_id'], $customer_data['customer_name'], '');
                                            endforeach; ?>
                                        </select>
                                    </div>
                                    <div class="row">
                                        <div class="col-7">
                                            <div class="form-group">
                                                <label for="">Cashier Name</label>
                                                <select name="cashier_name"
                                                        class="form-control form-control-sm select2">
                                                    <option value="">-- Select --</option>
                                                    <?php
                                                    $cashiersArray = $module->getRecord(["tbl_scheme" => 'app_users', "condition" => ['delete_status' => 0]]);
                                                    foreach ($cashiersArray['dataArray'] as $cashiers):
                                                        echo $app->dropDownList($cashiers['firstname'] . ' ' . $cashiers['lastname'], '');
                                                    endforeach; ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-5">
                                            <div class="form-group">
                                                <label for="">Status</label>
                                                <select name="checkout_status"
                                                        class="form-control form-control-sm select2">
                                                    <option value="">-- Status --</option>
                                                    <?php $itemArray = array("Checked Out" => 1, "Saved Order" => 0);
                                                    foreach ($itemArray as $item => $val): ?>
                                                        <option value="<?php echo $val ?>"><?php echo $item; ?></option>
                                                    <?php endforeach; ?>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <label for="" class="small text-muted">Transaction Date Range</label>
                                    <div class="row">
                                        <div class="col-6">
                                            <div class="form-group mb-0">
                                                <label for="">Start Date</label>
                                                <input type="text" name="start_date"
                                                       class="form-control form-control-sm datepicker"
                                                       placeholder="Start Date">
                                            </div>
                                        </div>
                                        <div class="col-6">
                                            <div class="form-group mb-0">
                                                <label for="">End Date</label>
                                                <input type="text" name="end_date"
                                                       class="form-control form-control-sm datepicker"
                                                       placeholder="End Date">
                                            </div>
                                        </div>
                                    </div>
                                    <input type="hidden" readonly name="delete_status" value="0">
                                    <hr class="my-3">
                                    <button class="btn btn-default btn-sm btn-block" id="appFilterBtn">
                                        <i class="fal fa-check-circle"></i>
                                        Submit
                                    </button>
                                    <input type="hidden" readonly name="view"
                                           value="/#/sales-point/<?php echo $view . @$viewRequest; ?>">
                                </form>
                            </div>
                        </div>
                    </li>
                <?php endif; ?>
            </ul>
        </div>
    </div>

<?php
if (isset($subView) && @$subView === "products/"):
    require "products_history.php";
elseif (isset($viewRequest) && @$viewRequest === "deposits/"):
    require 'deposit_history.php';
else:
    require "sales_history.php";
endif;
?>