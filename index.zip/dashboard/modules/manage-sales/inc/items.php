<div class="row mb-3">
    <div class="col-12">
        <ul class="nav ml-auto modules-menu">
            <li class="nav-item"><a class="nav-link active app-link" href="#/inventory/add-item/"
                                    onclick="fetchURL(this.href)"><i class="fal fa-exclamation-triangle"></i> Stock
                    Level</a>
            </li>

            <li class="nav-item dropdown show">
                <a class="nav-link dropdown-toggle" href="#" role="button" id="dropdownMenuLink"
                   data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <i class="fal fa-calendar-check"></i> Expiry
                </a>
                <div class="dropdown-menu m-0 py-0" aria-labelledby="dropdownMenuLink">
                    <a class="dropdown-item" href="#">Expiring in 3 Months</a>
                    <a class="dropdown-item" href="#">Expiring in 6 Months</a>
                    <a class="dropdown-item" href="#">Expiring in 1 Year</a>
                </div>
            </li>

            <li class="nav-item ml-auto"><a class="nav-link active app-link" href="#/inventory/add-item/"
                                            onclick="fetchURL(this.href)"><i class="fal fa-boxes"></i> Item Stocking</a>
            </li>
            <li class="nav-item "><a class="nav-link <?php if (@$subView == 'promo'): echo ' active'; endif; ?>"
                                     href="#/sales-point/items/promo/"
                                     onclick="fetchURL(this.href)"><i
                            class="fal fa-gifts"></i> Special Prices/Promo</a></li>
            <li class="nav-item app-collapse">
                <a class="nav-link dropdown-toggle" data-toggle="collapse"
                   href="#collapseUsersFilter"
                   aria-expanded="false" aria-controls="collapseUsersFilter">
                    <i class="fal fa-filter"></i> Advance Filter<span class="caret"></span>
                </a>
                <div class="collapse collapse-container right" id="collapseUsersFilter">
                    <div class="card-body elevation-1 bg-light left">
                        <form action="">
                            <div class="form-group">
                                <label for="">Users Group</label>
                                <select name="users_group" class="form-control form-control-sm select2">
                                    <option value="">-- Users Group --</option>
                                </select>
                            </div>
                            <div class="row">
                                <div class="col-6">
                                    <div class="form-group">
                                        <label for="">Users Store</label>
                                        <select name="users_location"
                                                class="form-control form-control-sm select2">
                                            <option value="">-- Users Store --</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-6">
                                    <div class="form-group">
                                        <label for="">Active Status</label>
                                        <select name="activation" class="form-control form-control-sm select2">
                                            <option value="">-- Active Status --</option>
                                        </select>
                                    </div>
                                </div>

                            </div>

                            <hr class="my-2">
                            <button class="btn btn-default btn-sm btn-block"><i class="fal fa-check-circle"></i>
                                Submit
                            </button>
                        </form>
                    </div>
                </div>
            </li>
        </ul>
    </div>
</div>
<?php
//echo $subView;
if ($view == "category/"):
    require "category.php";
elseif (isset($subView) && @$subView == "promo"):
    require "promo.php";
else:
    require "items_list.php";
endif;
?>