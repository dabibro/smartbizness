<?php
//--------------------------------------------------------------------------------------------------
$store = "";
if (isset($auth['store_id']) && $auth['store_id'] != ""):
    $store = "AND store_id = '" . $auth['store_id'] . "' ";
endif;
//--------------------------------------------------------------------------------------------------
$condition = "";
//--------------------------------------------------------------------------------------------------
if (isset($_POST['filterRequest']) && $_POST['filterRequest'] !== NULL):
    $filterParam = $_POST['filterRequest'];
    if ($filterParam['search'] != ""):
        $search_query = trim($filterParam['search']);
        $condition = "AND reference LIKE '%" . $search_query . "%'";
        $condition .= "OR quote_type LIKE '%" . $search_query . "%' ";
        $condition .= "OR store_id LIKE '%" . $search_query . "%' ";
        $condition .= "OR customer_id LIKE '%" . $search_query . "%' ";
        $condition .= "OR additional_note LIKE '%" . $search_query . "%' ";
        $condition .= "OR request_date LIKE '%" . $search_query . "%' ";
        $condition .= "OR created_by LIKE '%" . $search_query . "%' ";
        $condition .= "OR created_on LIKE '%" . $search_query . "%'";
    else:
        $quote_type = @$filterParam['quote_type'];
        $store_id = @$filterParam['store_id'];
        $customer_id = @$filterParam['customer_id'];
        $created_by = @$filterParam['created_by'];
        $status = @$filterParam['status'];
        $start_date = @$filterParam['start_date'];
        $end_date = @$filterParam['end_date'];

        if ($quote_type != ""):
            $condition .= " AND quote_type = '$quote_type'";
        endif;
        if ($store_id != ""):
            $condition .= " AND store_id = '$store_id'";
        endif;
        if ($customer_id != ""):
            $condition .= " AND customer_id = '$customer_id'";
        endif;
        if ($status != ""):
            $condition .= " AND status = '$status'";
        endif;
        if ($created_by != ""):
            $condition .= " AND created_by = '$created_by'";
        endif;
        if ($start_date != "" && $end_date != ""):
            $condition .= " AND created_on BETWEEN '$start_date' AND DATE_ADD('$end_date', INTERVAL 1 DAY)";
        endif;
    endif;

endif;

$paginate_exp = explode('?page=', $url);
if (isset($paginate_exp[1]) && $paginate_exp[1] != ""):
    $ipp_exp = explode('&ipp=', $paginate_exp[1]);
    if (isset($ipp_exp[0]) && $ipp_exp[0] != ""):
        define('page', $ipp_exp[0]);
    else:
    endif;
    if (isset($ipp_exp[1]) && $ipp_exp[1] != ""):
        define('ipp', $ipp_exp[1]);
    else:
    endif;
else:
    define('page', '');
    define('ipp', '');
endif;
define('self', '#/sales-point/quotations/');
$pages = new Paginator_Class;
if (ipp != ""):
    $pages->default_ipp = ipp;
else:
    $pages->default_ipp = 50;
endif;
$sql_forms = Data_Access::execSQL("SELECT * FROM " . $app->dbScheme . ".app_quotations WHERE 1 " . $store . $condition . " ");
@$pages->items_total = $sql_forms['dataArray']->num_rows;
$pages->mid_range = 4;
$pages->paginate();

$sql = "SELECT * FROM " . $app->dbScheme . ".app_quotations WHERE 1 " . $store . $condition . " ORDER BY created_on DESC " . $pages->limit . " ";
if (!($result = Data_Access::execSQL($sql))) {
    die(mysqli_error());
} else {
    @$recordsArray = Data_Access::fetchAssoc($result['dataArray'])['dataArray'];
}
?>
<div id="ModuleResponse"></div>
<div class="row marginTop mx-0">
    <div class="col-12 pl-0 paddingLeft pagerfwt">
        <?php if ($pages->items_total > 0) { ?>
            <?php echo $pages->display_pages(); ?>
            <?php echo $pages->display_items_per_page(); ?>
            <?php echo $pages->display_jump_menu(); ?>
        <?php } ?>
    </div>
    <div class="clearfix"></div>
    <hr>
</div>
<div class="table-responsive">
    <table class="table data-tables table-sm elevation-1">
        <?php if (@$filterParam != NULL): ?>
            <caption>Currently viewing filter record(s) [ <a href="javascript:void(0);" onclick="fetchURL('');"
                                                             class="small">Reset Filter</a> ]
            </caption>
        <?php else: ?>
            <caption>Viewing current month record(s)</caption>
        <?php endif; ?>
        <thead>
        <tr>
            <th>Reference #</th>
            <th>Quote Type</th>
            <th>Customer Name</th>
            <th>Item #</th>
            <th>Cost Amount <?php echo $biz->currency['currency']; ?></th>
            <th>Request Date</th>
            <th>Submission</th>
            <th>Quoted By</th>
            <th></th>
            <th><i class="fal fa-cogs"></i></th>
        </tr>
        </thead>
        <tbody class="card-body">
        <?php
        if (isset($recordsArray) && $recordsArray != NULL):
            $cost_total = 0;
            $grand_total = 0;
            $profit_total = 0;
            foreach (@$recordsArray as $quotations): extract($quotations);
                @$product = $module->getRecord(["tbl_scheme" => 'app_quotation_item', "condition" => ["reference" => $reference,]])['dataArray'];
                $customer_name = $module->getRecord(["tbl_scheme" => 'app_customers', "condition" => ["app_id" => $customer_id,]])['dataArray'][0]['customer_name'];
                $transact_cost = 0;
                if ($product != NULL):
                    foreach ($product as $item):
                        @$transact_cost = $transact_cost + ($item['stock_qty'] * $item['stock_sale_price']);
                    endforeach;
                endif;
                @$transact_cost = @$transact_cost + @$delivery_charges;
                @$vat_charges = (@$vat_charges / 100) * @$transact_cost;
                @$discount = (@$discount / 100) * @$transact_cost;
                $transact_cost = ($transact_cost + $vat_charges) - $discount;
                @$grand_total = @$grand_total + @$transact_cost;
                ?>
                <tr>
                    <td><?php echo @$reference; ?></td>
                    <td><?php echo @trim(@$quote_type); ?></td>
                    <td><?php echo @$customer_name; ?></td>
                    <td><?php echo @count($product); ?></td>
                    <td><?php echo $app->valueSign(@number_format(@$transact_cost, 2)); ?></td>
                    <td><?php $reqDate = new DateTime($request_date);
                        echo $reqDate->format('d/m/Y'); ?></td>
                    <td><?php if ($status == 1): echo 'Submitted'; else: echo 'Pending';endif; ?></td>
                    <td style="line-height: 15px;"><?php echo @$created_by; ?></td>
                    <td class="text-muted"><?php echo @$created_on; ?></td>
                    <td style="width:5%;" class="py-1" nowrap="nowrap">
                        <div class="btn-group-justify btn-group-sm float-right">
                            <?php if (@$status === '0'): ?>
                                <button type="button" class="btn btn-default"
                                        onclick='javascript: location.replace("#/sales-point/quotations/quote/<?php echo $reference; ?>/"); fetchURL("")'
                                        title=" Edit Record"><i class="fal fa-edit"></i>
                                </button>
                            <?php endif; ?>
                            <button type="button" class="btn btn-default" title="View Receipt"
                                    onClick="javascript:location.replace('#/sales-point/pos/print/<?php echo $reference; ?>/'); fetchURL('');">
                                <i class="fal fa-receipt"></i></button>
                            <button type="button" class="btn btn-default"
                                    onclick='javascript: var obj = "<?php echo urlencode('"className":"Module_Class","deleteQuotation":"1","tbl_scheme":"","pk":{"reference":"' . @$reference . '"},"callback":{"type":"self","redirect":""},"notification":{"message":"Are you sure to delete this quotation record?","title":"Delete Warning"}'); ?>";  moduleRequest(obj);'
                                    title=" Edit Record"><i
                                        class="fal fa-trash-alt"></i>
                            </button>
                    </td>
                </tr>
            <?php endforeach; else: ?>
            <tr>
                <td colspan="9" align="center">No data available</td>
            </tr>
        <?php endif; ?>
        </tbody>
        <tfoot>
        <tr>
            <td colspan="4" align="right">TOTAL <?php echo @$biz->currency['currency']; ?>:</td>
            <th colspan="6"><?php echo $app->valueSign(number_format(@$grand_total, 2)); ?></th>
        </tr>
        </tfoot>
    </table>
</div>
<div class="row marginTop mx-0">
    <div class="col-12 pl-0 paddingLeft pagerfwt">
        <?php if ($pages->items_total > 0) { ?>
            <?php echo $pages->display_pages(); ?>
            <?php echo $pages->display_items_per_page(); ?>
            <?php echo $pages->display_jump_menu(); ?>
        <?php } ?>
    </div>
    <div class="clearfix"></div>
    <hr>
</div>
