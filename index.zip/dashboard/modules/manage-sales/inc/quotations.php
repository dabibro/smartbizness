<?php
@$getAppId = explode('quote/', $viewRequest);
if (isset($getAppId[1]) && $getAppId[1] != "") {
    @$viewRequest = 'quote/';
    @$AppId = trim($getAppId[1], '/');
}
?>
    <div class="row mb-3">
        <div class="col-12">
            <ul class="nav ml-auto modules-menu">
                <li class="nav-item  mb-1"><a class="nav-link app-link" href="#/sales-point/quotations/quote/"
                                              onclick="fetchURL(this.href)"><i class="fal fa-plus-square"></i>
                        Create
                        Quotation</a>
                </li>
                <!--- Sales Transact Filter -->
                <li class="nav-item app-collapse  ml-auto">
                    <div class="form-group mb-1">
                        <div class="input-group input-group-sm">
                            <input type="search" class="form-control form-control-sm border-right-0" name="search"
                                   placeholder="Search keyword..."
                                   style="border-radius: 0;" form="sales-transact-filter">
                            <div class="btn-group">
                                <button class="btn mr-2 btn-default btn-sm pr-2" form="sales-transact-filter"
                                        style="height: 31px" type="button"
                                        onclick="javascript:$('#appFilterBtn').click();">
                                    <i
                                            class="fal fa-search m-0"
                                            style="font-size: 0.70rem;"></i>
                                </button>
                                <a class="nav-link dropdown-toggle" data-toggle="collapse"
                                   href="#collapseSalesFilter"
                                   aria-expanded="false" aria-controls="collapseSalesFilter">
                                    <i class="fal fa-filter"></i> Advance Filter<span class="caret"></span>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="collapse collapse-container right" id="collapseSalesFilter">
                        <div class="card-body elevation-1 bg-light left p-3">
                            <form method="post" action="#" id="sales-transact-filter">
                                <div class="row">
                                    <div class="<?php if ($store_id !== ""): echo 'col-md-6'; else: echo 'col-md-12'; endif; ?>">
                                        <div class="form-group">
                                            <label for="">Quotation Type</label>
                                            <select name="quote_type"
                                                    class="form-control form-control-sm select2">
                                                <option value="">-- Select --</option>
                                                <?php
                                                $listArray = array("Supply" => 'Supply Quotation', "Services" => "Services Quotation");
                                                foreach ($listArray as $type => $label):
                                                    echo $app->dropDownList($type, $label, '');
                                                endforeach; ?>
                                            </select>
                                        </div>
                                    </div>
                                    <?php if ($store_id !== ""): ?>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label for="">Store/Location</label>
                                                <select name="store_id"
                                                        class="form-control form-control-sm select2">
                                                    <option value="">-- Select --</option>
                                                    <?php
                                                    @$store = $module->getRecord(["tbl_scheme" => 'app_stores'])['dataArray'];
                                                    foreach ($store as $store_list):
                                                        echo $app->dropDownList($store_list['app_id'], $store_list['store_name'], '');
                                                    endforeach; ?>
                                                </select>
                                            </div>
                                        </div>
                                    <?php endif; ?>
                                </div>
                                <div class="form-group">
                                    <label for="">Customer Name</label>
                                    <select name="customer_id" class="form-control form-control-sm select2">
                                        <option value="">-- Select --</option>
                                        <?php
                                        $listArray = $module->getRecord([
                                            "tbl_scheme" => 'app_customers', "condition" => ['active_status' => 1, 'delete_status' => 0]
                                        ]);
                                        foreach ($listArray['dataArray'] as $customer_data):
                                            echo $app->dropDownList($customer_data['app_id'], $customer_data['customer_name'], '');
                                        endforeach; ?>
                                    </select>
                                </div>
                                <div class="row">
                                    <div class="col-7">
                                        <div class="form-group">
                                            <label for="">Quoted By</label>
                                            <select name="created_by"
                                                    class="form-control form-control-sm select2">
                                                <option value="">-- Select --</option>
                                                <?php
                                                $cashiersArray = $module->getRecord(["tbl_scheme" => 'app_users', "condition" => ['delete_status' => 0]]);
                                                foreach ($cashiersArray['dataArray'] as $cashiers):
                                                    echo $app->dropDownList($cashiers['firstname'] . ' ' . $cashiers['lastname'], '');
                                                endforeach; ?>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-5">
                                        <div class="form-group">
                                            <label for="">Submission Status</label>
                                            <select name="status"
                                                    class="form-control form-control-sm select2">
                                                <option value="">-- Status --</option>
                                                <?php $itemArray = array("Submitted" => 1, "Pending" => 0);
                                                foreach ($itemArray as $item => $val): ?>
                                                    <option value="<?php echo $val ?>"><?php echo $item; ?></option>
                                                <?php endforeach; ?>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <label for="" class="small text-muted">Transaction Date Range</label>
                                <div class="row">
                                    <div class="col-6">
                                        <div class="form-group mb-0">
                                            <label for="">Start Date</label>
                                            <input type="text" name="start_date"
                                                   class="form-control form-control-sm datepicker"
                                                   placeholder="Start Date">
                                        </div>
                                    </div>
                                    <div class="col-6">
                                        <div class="form-group mb-0">
                                            <label for="">End Date</label>
                                            <input type="text" name="end_date"
                                                   class="form-control form-control-sm datepicker"
                                                   placeholder="End Date">
                                        </div>
                                    </div>
                                </div>
                                <input type="hidden" readonly name="delete_status" value="0">
                                <hr class="my-3">
                                <button class="btn btn-default btn-sm btn-block" id="appFilterBtn">
                                    <i class="fal fa-check-circle"></i>
                                    Submit
                                </button>
                                <input type="hidden" readonly name="view"
                                       value="/#/sales-point/<?php echo $view . @$viewRequest; ?>">
                            </form>
                        </div>
                    </div>
                </li>
            </ul>
        </div>
    </div>
<?php
if ($view == "view/"):
    require "order-preview.php";
elseif (@$viewRequest == "quote/"):
    require "quote_record.php";
else:
    require "quotes_list.php";
endif;
?>