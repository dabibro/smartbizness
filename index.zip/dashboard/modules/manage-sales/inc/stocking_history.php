<?php
//--------------------------------------------------------------------------------------------------
$store = "";
if (isset($auth['store_id']) && $auth['store_id'] != ""):
    $store = "AND store_id = '" . $auth['store_id'] . "' ";
endif;
//--------------------------------------------------------------------------------------------------
$condition = "";
//--------------------------------------------------------------------------------------------------
if (isset($_POST['filterRequest']) && $_POST['filterRequest'] !== NULL):
    $filterParam = $_POST['filterRequest'];
    if ($filterParam['search'] != ""):
        $search_query = $filterParam['search'];
        $condition = "AND product_name LIKE '%" . $search_query . "%'";
        $condition .= "OR stocked_by LIKE '%" . $search_query . "%' ";
        $condition .= "OR stocking_date LIKE '%" . $search_query . "%' ";
    else:
        $product = explode('->', @$filterParam['product']);
        if (isset($product[0]) && $product[0] != ""):
            $product_id = $product[0];
        endif;
        $return = @$filterParam['return'];
        $cashier = @$filterParam['cashier_name'];
        $start_date = @$filterParam['start_date'];
        $end_date = @$filterParam['end_date'];

        if (@$product_id != ""):
            $condition .= " AND app_id = '$product_id'";
        endif;
        if (isset($return) && $return == 1):
            $condition .= " AND add_qty < 0 ";
        endif;

        if (@$cashier != ""):
            $condition .= " AND stocked_by = '$cashier'";
        endif;
        if ($start_date != "" && $end_date != ""):
            $condition .= " AND stocking_date BETWEEN '$start_date' AND DATE_ADD('$end_date', INTERVAL 1 DAY)";
        endif;
    endif;

endif;

$paginate_exp = explode('?page=', $url);
if (isset($paginate_exp[1]) && $paginate_exp[1] != ""):
    $ipp_exp = explode('&ipp=', $paginate_exp[1]);
    if (isset($ipp_exp[0]) && $ipp_exp[0] != ""):
        define('page', $ipp_exp[0]);
    else:
    endif;
    if (isset($ipp_exp[1]) && $ipp_exp[1] != ""):
        define('ipp', $ipp_exp[1]);
    else:
    endif;
else:
    define('page', '');
    define('ipp', '');
endif;
define('self', '#/sales-point/items/stocking/');
$pages = new Paginator_Class;
if (ipp != ""):
    $pages->default_ipp = ipp;
else:
    $pages->default_ipp = 50;
endif;
$sql_forms = Data_Access::execSQL("SELECT * FROM " . $app->dbScheme . ".app_products_stocking WHERE 1 " . $store . $condition . " ");
@$pages->items_total = $sql_forms['dataArray']->num_rows;
$pages->mid_range = 4;
$pages->paginate();

$sql = "SELECT * FROM " . $app->dbScheme . ".app_products_stocking ";
$sql .= "WHERE 1 " . $store . $condition . " ORDER BY stocking_date DESC " . $pages->limit . " ";
if (!($result = Data_Access::execSQL($sql))) {
    die(mysqli_error());
} else {
    @$recordsArray = Data_Access::fetchAssoc($result['dataArray'])['dataArray'];
}
?>
<style>
    .ui-autocomplete {
        z-index: 9999 !important;
    }
</style>
<div id="ModuleResponse"></div>
<div class="row marginTop mx-0">
    <div class="col-12 pl-0 paddingLeft pagerfwt">
        <?php if ($pages->items_total > 0) { ?>
            <?php echo $pages->display_pages(); ?>
            <?php echo $pages->display_items_per_page(); ?>
            <?php echo $pages->display_jump_menu(); ?>
        <?php } ?>
    </div>
    <div class="clearfix"></div>
    <hr>
</div>
<div class="table-responsive">
    <table class="table data-tables table-sm elevation-1">
        <?php if (@$filterParam != NULL): ?>
            <caption>Currently viewing filter record(s) [ <a href="javascript:void(0);" onclick="fetchURL('');"
                                                             class="small">Reset Filter</a> ]
            </caption>
        <?php else: ?>
            <caption>Viewing current month record(s)</caption>
        <?php endif; ?>
        <thead>
        <tr>
            <th>Products ID</th>
            <th>Products Name</th>
            <th>Category</th>
            <th>Quantity</th>
            <th>Cost Price <?php echo $biz->currency['currency']; ?></th>
            <th>Sale Price <?php echo $biz->currency['currency']; ?></th>
            <th>Cost Amount <?php echo $biz->currency['currency']; ?></th>
            <th>Sale Amount <?php echo $biz->currency['currency']; ?></th>
            <th>Profit <?php echo $biz->currency['currency']; ?></th>
            <th>Transact By</th>
        </tr>
        </thead>
        <tbody class="card-body">
        <?php
        if (isset($recordsArray) && $recordsArray != NULL):
            $cost_total = 0;
            $grand_total = 0;
            $profit_total = 0;
            foreach (@$recordsArray as $transactions): extract($transactions);
                @$product = $module->getRecord([
                    "tbl_scheme" => 'app_products',
                    "condition" => [
                        "app_id" => $app_id,
                    ]
                ])['dataArray'][0];
                $transact_cost = 0;
                @$cost_amount = $product['price'] * $add_qty;
                @$sale_amount = $sale_price * $add_qty;
                @$profit = $sale_amount - $cost_amount;
                @$cost_total = @$cost_total + @$cost_amount;
                @$grand_total = @$grand_total + @$sale_amount;
                @$profit_total = @$profit_total + @$profit;
                ?>
                <tr>
                    <td><?php echo @$product['sku_barcode']; ?></td>
                    <td><?php echo @$product_name; ?></td>
                    <td><?php echo @trim(@$module->getRecord(["tbl_scheme" => "app_category", "condition" => ['id' => $product['category_id']]])['dataArray'][0]['name']); ?></td>
                    <td><?php echo @$add_qty; ?></td>
                    <td><?php echo $app->valueSign(number_format(@$product['price'], 2)); ?></td>
                    <td><?php echo $app->valueSign(@number_format(@$sale_price, 2)); ?></td>
                    <td><?php echo $app->valueSign(@number_format(@$cost_amount, 2)); ?></td>
                    <td><?php echo $app->valueSign(@number_format(@$sale_amount, 2)); ?></td>
                    <td><?php echo $app->valueSign(@number_format(@$profit, 2)); ?></td>
                    <td style="line-height: 15px;"><?php echo @trim(@$stocked_by); ?>
                        <div class="small text-muted"><?php echo @trim(@$stocking_date); ?></div>
                    </td>

                </tr>
            <?php endforeach; else: ?>
            <tr>
                <td colspan="10" align="center">No data available</td>
            </tr>
        <?php endif; ?>
        </tbody>
        <tfoot>
        <tr>
            <td colspan="6" align="right">TOTAL SALE <?php echo @$biz->currency['currency']; ?>:</td>
            <th><?php echo $app->valueSign(number_format(@$cost_total, 2)); ?></th>
            <th><?php echo $app->valueSign(number_format(@$grand_total, 2)); ?></th>
            <th colspan="2"><?php echo $app->valueSign(number_format(@$profit_total, 2)); ?></th>
        </tr>
        </tfoot>
    </table>
</div>
<div class="row marginTop mx-0">
    <div class="col-12 pl-0 paddingLeft pagerfwt">
        <?php if ($pages->items_total > 0) { ?>
            <?php echo $pages->display_pages(); ?>
            <?php echo $pages->display_items_per_page(); ?>
            <?php echo $pages->display_jump_menu(); ?>
        <?php } ?>
    </div>
    <div class="clearfix"></div>
    <hr>
</div>
<script>
    $('#ModuleModal').on('hidden.bs.modal', function (e) {
        fetchURL('');
    })

    function reloadStocking() {

    }
</script>