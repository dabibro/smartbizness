<?php
if (isset($AppId) && @$AppId['pk'] != ""):
    $pk = $AppId;
    $pkField = 'reference';
    $getUpdateArray = array(
        "tbl_scheme" => 'app_quotations',
        "condition" => [$pkField => $pk],
        "limit" => 1
    );
    $getUpdate = $module->getRecord($getUpdateArray);
    if ($getUpdate['response'] != '200' || $getUpdate['dataArray'][0]['status'] === '1'):
        echo '<script>location.replace("#/sales-point/quotations/quote/"); fetchURL("");</script>';
    endif;
    @extract($getUpdate['dataArray'][0]);
    $update = 1;
    @$app_id = $reference;
else:
    $app_id = $app->generateAppId('Q', '', 7, '1234567890ABCDEFGHIJ');
endif;


?>
<div class="position-relative">
    <form method="post" class="AppForm" id="inventory-item-form">
        <div class="row">
            <div class="col-2">
                <div class="nav flex-column nav-tabs h-100" id="vert-tabs-tab" role="tablist"
                     aria-orientation="vertical">
                    <a class="nav-link active" id="basic-tabs" data-toggle="pill" href="#basic-tabs-panel" role="tab"
                       aria-controls="basic-tabs-panel" aria-selected="false"><i class="fal fa-info-circle mr-1"></i>
                        Basics Data
                        <hr class="my-1">
                        <small class="text-muted">Fill in the item basic details.
                        </small>
                    </a>
                    <a class="nav-link <?php if (@$update != 1):echo "disabled"; endif; ?>" id="advance-tabs"
                       data-toggle="pill" href="#advance-tabs-panel"
                       role="tab"
                       aria-controls="advance-tabs-panel" aria-selected="false"><i class="fal fa-file-edit mr-1"></i>
                        Products/Services Entry
                        <hr class="my-1">
                        <small class="text-muted">Advance item attributes
                        </small>
                    </a>
                    <a class="nav-link <?php if (@$update != 1):echo "disabled"; endif; ?>" id="preview-tabs"
                       data-toggle="pill" href="#preview-tabs-panel" onclick="loadOrderPreview();"
                       role="tab"
                       aria-controls="preview-tabs-panel" aria-selected="false"><i class="fal fa-file-search mr-1"></i>
                        Quotation Preview
                        <hr class="my-1">
                        <small class="text-muted">Preview template entry
                        </small>
                    </a>
                </div>
            </div>
            <div class="col-10">
                <div class="tab-content" id="add-item-tabContent">
                    <div class="row">
                        <div class="col-md-3 col-lg-2"></div>
                        <div class="col-md-9 col-lg-8">
                            <div id="ModuleResponse"></div>
                        </div>
                    </div>
                    <div class="tab-pane text-left fade active show" id="basic-tabs-panel" role="tabpanel"
                         aria-labelledby="basic-tabs">
                        <div class="row">
                            <div class="col-md-9 col-lg-10">
                                <div class="row">
                                    <div class="col-4 ml-auto">
                                        <div class="form-group">
                                            <label for=""> <span class="required">*</span> Reference/Quote No.:</label>
                                            <input type="text" name="reference" class="form-control form-control-sm"
                                                   value="<?php echo @$app_id; ?>">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-9 col-lg-10">
                                <div class="row">
                                    <div class="col-3">
                                        <div class="form-group">
                                            <label for=""><span class="required">*</span> Quotation Type</label>
                                            <select name="quote_type"
                                                    class="form-control form-control-sm select2"
                                                    id="quote_type" required>
                                                <option value="">-- Select --</option>
                                                <?php
                                                $orderTypeArray = array("Supply" => "Supply Quotation", "Services" => "Services Quotation");
                                                foreach ($orderTypeArray as $orderType => $label):
                                                    echo $app->dropDownList($orderType, $label, @$quote_type);
                                                endforeach; ?>
                                            </select>
                                            <div class="invalid-feedback">* Required field</div>
                                        </div>
                                    </div>
                                    <div class="col-4">
                                        <div class="form-group">
                                            <label for=""><span class="required">*</span> Customer Name</label>
                                            <select name="customer_id"
                                                    class="form-control form-control-sm select2" required>
                                                <option value="">-- Select --</option>
                                                <?php
                                                $listArray = $module->getRecord(["tbl_scheme" => 'app_customers', "condition" => ['active_status' => 1]]);
                                                $dropDownArray = array();
                                                foreach ($listArray['dataArray'] as $temps):
                                                    echo $app->dropDownList($temps['app_id'], $temps['customer_name'], @$customer_id);
                                                endforeach; ?>
                                            </select>
                                            <div class="invalid-feedback">* Required field</div>
                                        </div>
                                    </div>
                                    <div class="col-3">
                                        <div class="form-group">
                                            <label for="">RFQ #: </label>
                                            <input type="text" name="rfq"
                                                   class="form-control form-control-sm"
                                                   autocomplete="off"
                                                   placeholder="RFQ"
                                                   value="<?php echo @$rfq; ?>">
                                            <div class="invalid-feedback">* Required field</div>
                                        </div>
                                    </div>
                                    <div class="col-2">
                                        <div class="form-group">
                                            <label><span class="required">*</span> Request Date</label>
                                            <input type="text" name="request_date"
                                                   class="form-control form-control-sm datepicker" autocomplete="off"
                                                   placeholder="Request Date" required
                                                   value="<?php echo @$request_date; ?>">
                                            <div class="invalid-feedback">* This field is required</div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-4">
                                        <div class="form-group">
                                            <label for=""><span class="required">*</span> Contact Person</label>
                                            <select name="contact_person"
                                                    class="form-control form-control-sm select2" tabindex="8" required>
                                                <option value="">-- Select --</option>
                                                <?php
                                                $listArray = $module->getRecord(["tbl_scheme" => 'app_users', "condition" => ["delete_status" => 0]]);
                                                foreach ($listArray['dataArray'] as $contacts_person):
                                                    echo $app->dropDownList($contacts_person['user_id'], trim($contacts_person['firstname'] . ' ' . $contacts_person['lastname']), @$contact_person);
                                                endforeach; ?>
                                            </select>
                                            <div class="invalid-feedback">* This field is required</div>
                                        </div>
                                    </div>
                                    <div class="col-3">
                                        <div class="form-group">
                                            <label><span class="required">*</span> Submission Date</label>
                                            <input type="text" name="submission_date"
                                                   class="form-control form-control-sm datepicker"
                                                   autocomplete="off"
                                                   placeholder="Submission Date" required
                                                   value="<?php echo @$submission_date; ?>">
                                            <div class="invalid-feedback">* This field is required</div>
                                        </div>
                                    </div>
                                    <div class="col-4">
                                        <div class="form-group">
                                            <label>Validity Period</label>
                                            <input type="text" name="validity_period"
                                                   class="form-control form-control-sm" autocomplete="off"
                                                   placeholder="Validity Period"
                                                   value="<?php echo @$validity_period; ?>">
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-3">
                                        <div class="form-group">
                                            <label>Delivery Charges <?php echo $biz->currency['currency']; ?></label>
                                            <input type="text" name="delivery_charges"
                                                   class="form-control form-control-sm" autocomplete="off"
                                                   placeholder="Delivery Charges"
                                                   value="<?php if (@$delivery_charges > 0) echo str_replace(',', '', @number_format($delivery_charges, 2)); ?>">
                                        </div>
                                    </div>
                                    <div class="col-3">
                                        <div class="form-group">
                                            <label>VAT Charges</label>
                                            <select name="vat_charges"
                                                    class="form-control form-control-sm select2" tabindex="8">
                                                <option value="">-- Select --</option>
                                                <?php
                                                $listArray = $module->getRecord(["tbl_scheme" => 'app_discount_vat', "condition" => ["active_status" => 1, "category" => 'VAT']]);
                                                foreach ($listArray['dataArray'] as $vat_list):
                                                    echo $app->dropDownList($vat_list['percent'], trim($vat_list['name']), @$vat_charges);
                                                endforeach; ?>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-3">
                                        <div class="form-group">
                                            <label>Discount</label>
                                            <select name="discount"
                                                    class="form-control form-control-sm select2" tabindex="8">
                                                <option value="">-- Select --</option>
                                                <?php
                                                $listArray = $module->getRecord(["tbl_scheme" => 'app_discount_vat', "condition" => ["active_status" => 1, "category" => 'Discount']]);
                                                foreach ($listArray['dataArray'] as $vat_list):
                                                    echo $app->dropDownList($vat_list['percent'], trim($vat_list['percent'] . '% - ' . $vat_list['name']), @$discount);
                                                endforeach; ?>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label>Additional Note/Instruction</label>
                                    <textarea class="text-editor" name="additional_note"
                                              placeholder="Additional Description"
                                              style="width: 100%; height: 250px; font-size: 14px; line-height: 18px; border: 1px solid #dddddd; padding: 10px;"><?php echo @$additional_note; ?></textarea>
                                </div>

                            </div>
                        </div>
                        <input type="hidden" name="className" value="Module_Class" readonly>
                        <?php if (@$getUpdate['response'] === "200"): ?>
                            <input type="hidden" name="functionName" value="updateRecord" readonly>
                            <input type="hidden" name="pk" value="<?php echo @$pk; ?>" readonly>
                            <input type="hidden" name="pkField" value="<?php echo @$pkField; ?>" readonly>
                        <?php else: ?>
                            <input type="hidden" name="functionName" value="createRecord" readonly>
                            <input type="hidden" name="pk" value="reference" readonly>
                        <?php endif; ?>
                        <input type="hidden" name="callback[type]" value="actionEvent" readonly>
                        <input type="hidden" name="callback[redirect]" value="itemCallback()" readonly>
                        <input type="hidden" name="tbl_scheme" value="app_quotations" readonly>
                        <input type="hidden" name="created_by"
                               value="<?php echo trim(@$auth['firstname'] . ' ' . @$auth['lastname']); ?>" readonly>
                        <input type="hidden" name="store_id"
                               value="<?php echo trim(@$auth['store_id']); ?>" readonly>
                        <hr class="my-3">
                        <div class="row">
                            <div class="col-md-9 col-lg-10">
                                <button class="btn btn-default btn-sm actionButton"><i class="fal fa-check-circle"></i>
                                    Submit
                                </button>
                                <div class="float-right text-muted py-2"><i class="fal fa-info-circle"></i> Submit
                                    basics
                                    data to enable template entry page
                                </div>
                            </div>
                        </div>

                    </div>
                    <div class="tab-pane text-left fade" id="advance-tabs-panel" role="tabpanel"
                         aria-labelledby="advance-tabs">
                        <div class="row">
                            <div class="col-md-9 col-lg-12">
                                <?php require "quote_item_entry.php"; ?>
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane text-left fade" id="preview-tabs-panel" role="tabpanel"
                         aria-labelledby="preview-tabs">
                        <div id="preview-template"></div>
                        <hr>
                        <div class="row">
                            <div class="col-md-9 col-lg-10">
                                <?php if (@$status == 1): ?>
                                    <button class="btn btn-default btn-sm" type="button"
                                            onclick="printContent('QuotePrintArea','','')"><i
                                                class="fal fa-print"></i> Print Quotation
                                    </button>

                                <?php else: ?>
                                    <button class="btn btn-default btn-sm" type="button"
                                            onclick='javascript: var obj = "<?php echo urlencode('"className":"Module_Class","functionName":"updateRecord","tbl_scheme":"app_quotations","status":1,"pkField":"reference","pk":"' . $app_id . '","callback":{"type":"self","redirect":""},"notification":{"message":"Are you sure to submit quotation?","title":"Quotation Submission"}'); ?>";  moduleRequest(obj);'>
                                        <i class="fal fa-check-circle"></i> Submit Quotation
                                    </button>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </form>
</div>
<form id="item-entry-form" method="post">
    <input type="hidden" name="quote_type" value="<?php echo @$quote_type; ?>" readonly>
    <input type="hidden" name="reference" value="<?php echo $app_id; ?>" readonly>
    <input type="hidden" id="SubmitQuoteItem" name="SubmitQuoteItem" value="1" readonly>
</form>
<div id="actionEvents"></div>
<script>
    function itemCallback() {
        location.replace("#/sales-point/quotations/quote/<?php echo @$app_id; ?>/");
        fetchURL("");
    }

    //-------------------------------------------------
    $("#item-entry-form").on('submit', function (e) {
        e.preventDefault();
        $(".itemActionButton").html('<i class="fal fa-spin fa-spinner"></i> Processing...');
        $.ajax({
            url: modulePath + "ajaxRequest.php",
            type: "POST",
            data: new FormData(this),
            contentType: false,
            cache: false,
            processData: false,
            success: function (data) {
                $("#item-entry-response").html(data);
                $(".itemActionButton").html('<i class="fal fa-plus-square"></i> Add Item');
            },
            error: function () {
            }
        });
    });

    //--------------------------------------------------
    function loadEntryRows() {
        $.post(modulePath + "ajaxRequest.php",
            {
                fetchEntryRows: 1,
                reference: "<?php echo $app_id; ?>",
            }, function (response) {
                $("#items-entry-table").html(response);
            });
    }

    function delEntryRows(row_id) {
        $.post(modulePath + "ajaxRequest.php",
            {
                className: 'Module_Class',
                delEntryRows: row_id,
                callback: {type: "actionEvent", redirect: "loadEntryRows()"},
                notification: {message: "Are you sure to delete?", title: "Delete Warning"},
            }, function (response) {
                $("#item-entry-response").html(response);
            });
    }

    function editEntryRows(id) {
        $.post(modulePath + "ajaxRequest.php",
            {
                fetchInvItemEdit: 1,
                row_id: id,
            }, function (response) {
                $("#item-entry-response").html(response);
                $("#SubmitQuoteItem").val('2');
            });
    }

    //--------------------------------------------------
    function loadOrderPreview() {
        $.post(modulePath + "ajaxRequest.php",
            {
                orderPreview: 1,
                ref_no: "<?php echo $app_id;?>",
            }, function (response) {
                $("#preview-template").html(response);
            });
    }

    //--------------------------------------------------
    $('#inventory-lookup').on('keyup', function () {
        $(".inventory-lookup").autocomplete({
            source: 'modules/manage-inventory/src/ajaxInventoryLookup.php'
        });
    });
    //--------------------------------------------------
    $('#inventory-lookup').on('change', function () {

    });

    function fetchInvItem(query) {
        if (query !== "") {
            var split = query.split(' -> ');
            var app_id = split[0];
            $.post(modulePath + "ajaxRequest.php",
                {
                    fetchInvItem: 1,
                    app_id: app_id,
                }, function (response) {
                    $("#item-entry-response").html(response);
                });
        }
    }

    //--------------------------------------------------
    $("#computeArea input").on('keyup', function () {
        entryCalc();
    });

    function entryCalc() {
        var qty = $("#order_qty").val();
        var stock_qty = $("#stock_qty").val();
        var new_qty = $("#new_qty");
        var nQty = (qty - 0) + (stock_qty - 0);

        if (qty !== "" && nQty !== 'NaN') {
            new_qty.val(nQty);
        } else {
            new_qty.val('');
        }

        var order_price = $("#order_price").val();
        var stock_price = $("#stock_price").val();
        var new_price = $("#new_price");

        var nPrice = (order_price - 0) + (stock_price - 0);

        if (qty !== "" && order_price !== "") {
            var av1 = qty * order_price;
            var av2 = stock_qty * stock_price;
            var av3 = av1 + av2;
            var av4 = av3 / new_qty.val();
            new_price.val(av4);
        } else {
            // new_qty.val('');
        }

    }
</script>