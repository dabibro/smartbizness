<?php
/**
 * Created by DTMGS Limited.
 * User: Dauda Ibrahim
 * Date: 6/23/2020
 * Time: 9:40 PM
 * File: Module Classes
 */
if (file_exists("../../../helpers/config/config.inc.php")):
    require "../../../helpers/config/config.inc.php";
endif;
require "../../../helpers/handlers/app_autoloader.php";
require "Module_Class.php";
require "pos/classes/POS.php";
$engine = new SMBEngine;
$AppResponse = new App_Response;
$appAuth = new Auth_Access;
$auth = $appAuth->AppAuthChecker();
$store_id = $auth['store_id'];
$auth_username = trim($auth['firstname'] . ' ' . $auth['lastname']);
$requestMethod = $_SERVER['REQUEST_METHOD'];
if (in_array($requestMethod, ["GET", "POST", "PUT", "DELETE", "OPTIONS"])):
    $requestMethodArray = array();
    $requestMethodArray = $_REQUEST;
    if (isset($requestMethodArray['notification']) && !isset($requestMethodArray['confirmed'])):
        $tmpl = "../../tmpl/notification.html";
        echo $engine->fileTempParse($tmpl, $requestMethodArray);
        exit;
    endif;
    //--------------------------------------------------------------------------
    if (isset($requestMethodArray['className']) && isset($requestMethodArray['functionName'])):
        $getCommandArray = array(
            "class" => $requestMethodArray['className'],
            "function_name" => $requestMethodArray['functionName']);
        $functionArray = [];
        foreach ($requestMethodArray as $key => $val):
            if ($key !== "className" && $key !== "functionName" && $key !== "callback" && $key !== "notification" && $key !== "confirmed")
                $functionArray += array($key => $val);
        endforeach;
        $module = new $requestMethodArray['className'];
        $execution = $module->execCommand($getCommandArray, $functionArray);
        if ($execution['response'] === "200"):
            $responseMessage = App_Response::alertResponse(@$execution['message'], 'success');
            if (@$requestMethodArray['callback']['type'] == 'actionEvent'):
                $requestMethodArray['callback'] += array("event" => '<script>' . $requestMethodArray['callback']['redirect'] . '</script>');
            endif;
            $responseArray = array("success" => 1, "message" => (@$responseMessage), "dataArray" => @$execution['dataArray'], "callback" => @$requestMethodArray['callback']);
        else:
            $responseMessage = App_Response::alertResponse(@$execution['message'], 'danger');
            $responseArray = array("success" => 0, "message" => (@$responseMessage), "callback" => @$requestMethodArray['callback']);
        endif;
        echo @json_encode($responseArray);
    endif;
    //---------------------------------------------------------------------------
    if (isset($requestMethodArray['dropDownRequest'])):
        $module = new Module_Class;
        $tbl_scheme = $requestMethodArray['dropDownRequest']['target_scheme'];
        $pkField = $requestMethodArray['dropDownRequest']['pkField'];
        $pk = $requestMethodArray['dropDownRequest']['pk'];
        $key = $requestMethodArray['dropDownRequest']['key'];
        $label = $requestMethodArray['dropDownRequest']['label'];

        $listParam = array(
            "tbl_scheme" => $tbl_scheme,
            "condition" => [$pkField => $pk]);
        $listArray = $module->getRecord($listParam);
        echo '<option value="">-- Select --</option>';
        foreach ($listArray['dataArray'] as $list):
            if (isset($key) && $key != ""):
                echo $engine->dropDownList($list[$key], $list[$label]);
            else:
                echo $engine->dropDownList($list[$label]);
            endif;
        endforeach;
    endif;
    //---------------------------------------------------------------------------
    if (isset($requestMethodArray['formLookupRequest']) && $requestMethodArray['formLookupRequest']['term'] != ""):
        $module = new Module_Class;
        $request = $requestMethodArray['formLookupRequest']['request'];
        $tbl_scheme = $requestMethodArray['formLookupRequest']['target_scheme'];
        $field = $requestMethodArray['formLookupRequest']['fields'];
        $term = $requestMethodArray['formLookupRequest']['term'];
        $key = $requestMethodArray['formLookupRequest']['key'];
        $label = $requestMethodArray['formLookupRequest']['labels'];
        $condition = $requestMethodArray['formLookupRequest']['condition'];
        $order = $requestMethodArray['formLookupRequest']['order'];
        $limit = $requestMethodArray['formLookupRequest']['limit'];
        $lookupDestination = $requestMethodArray['formLookupRequest']['destination'];
        $target = $requestMethodArray['formLookupRequest']['target'];
        $actionButton = $requestMethodArray['formLookupRequest']['action_button'];

        if ($request == "search"):
            $searchParam = [
                "tbl_scheme" => $tbl_scheme,
                "fields" => $field,
                "term" => $term,
                "condition" => $condition,
                "order" => $order,
                "limit" => $limit,
            ];
            $query = $module->searchRecord($searchParam);
            if ($query['response'] == "200"):
                $dataArray = $query['dataArray'];
                if (count($dataArray) === 0):

                else:
                    echo '<div class="search-result position-relative">';
                    echo '<a class="small text-right result-close text-muted" href="javasctipy:void(0)" onclick=\'$("."+"' . $target . '").html("");\'>[ x close ]</a>';
                    $index = 0;
                    foreach ($dataArray as $results): $index++;
                        $labels = "";
                        foreach ($label as $lbl):
                            $labels .= $results[$lbl] . ' ';
                        endforeach;
                        echo '<button tabindex = "' . $index . '"  type="button" class="list-group-item" onclick=\'javascript:$("#"+"' . $lookupDestination . '").val(this.innerHTML); $("."+"' . $target . '").html(""); $("#"+"' . $actionButton . '").click()\'>[' . $results[$key] . '] ' . $labels . '</a>';
                    endforeach;
                    echo '</div>';
                endif;
            else:
                echo '<li class="list-group-item">No result(s) found lookup</li>';
            endif;

        else:

        endif;
    endif;
    //---------------------------------------------------------------------------
    if (isset($requestMethodArray['AppModalLoader'])):
        $required = $requestMethodArray['AppModalLoader'];
        if (isset($requestMethodArray['AppModalLoader']['modalRequestParam'])):
            $varParam = $requestMethodArray['AppModalLoader']['modalRequestParam'];
        endif;
        $modulePath = str_ireplace($engine->dashboard, '', $required['path']);
        $modalRequest = 1;
        $module = new Module_Class;
        $biz = new BIZConfig;
        require $required['required'] . '.php';
    endif;
    //---------------------------------------------------------------------------
    if (isset($requestMethodArray['AppIDAutoGen'])):
        if ($requestMethodArray['AppIDAutoGen'] != NULL):
            extract($requestMethodArray['AppIDAutoGen']);
            echo $appIdGen = $engine->generateAppId($prefix, $suffix, $strlen, $pattern);
        endif;
    endif;
    //---------------------------------------------------------------------------
    if (isset($requestMethodArray['promoItemVerify']) && $requestMethodArray['promoItemVerify'] != ""):
        $module = new Module_Class;
        @$query = @$requestMethodArray['promoItemVerify'];
        @$explode = explode(' -> ', $query);
        @$app_id = @$explode[0];
        $getProduct = $module->getRecord([
            "tbl_scheme" => 'app_products',
            "condition" => [
                "app_id" => $app_id,
            ]
        ]);
        if ($getProduct['response'] === '200' && $getProduct['dataArray'] != NULl):
            echo '<script>$("#app_id").val("' . $getProduct['dataArray'][0]['app_id'] . '")</script>';
            echo '<script>$("#product_search").val("' . $getProduct['dataArray'][0]['name'] . '")</script>';
            echo '<script>$("#sale-price").html("Sales Price: ' . $getProduct['dataArray'][0]['sale_price'] . '")</script>';
        else:
            echo '<script>$("#app_id").val("")</script>';
            echo '<script>$("#sale-price").html("")</script>';
            echo App_Response::alertResponse('Invalid product selection!', 'danger');
        endif;


    endif;
    //---------------------------------------------------------------------------
    if (isset($requestMethodArray['AttribListView'])):
        $app_id = $requestMethodArray['app_id'];
        $module = new Module_Class;
        require "inc/attributes_list.php";
    endif;
    //---------------------------------------------------------------------------
    if (isset($requestMethodArray['ImageUpload'])):
        $module = new Module_Class;
        $app_id = $requestMethodArray['app_id'];
        $description = $requestMethodArray['image_description'];
        $imageFile = $requestMethodArray['image_file'];
        list($type, $imageFile) = explode(';', $imageFile);
        list(, $imageFile) = explode(',', $imageFile);
        $imageFile = base64_decode($imageFile);
        $image_name = $app_id . '_' . time() . '.png';
        $upload = file_put_contents('../../uploads/inventory/' . $image_name, $imageFile);
        if ($upload):
            $imageParam = [
                "tbl_scheme" => 'app_products_images',
                "app_id" => $app_id,
                "image_file" => $image_name,
                "description" => $description,
            ];
            $insertImage = $module->createRecord($imageParam);
            if ($insertImage['response'] === '200'):
                $insertImage['message'] = "Image successfully uploaded!";
                $responseMessage = App_Response::alertResponse(@$insertImage['message'], 'success');
                $responseArray = array("success" => 1, "message" => (@$responseMessage));
            else:
                $insertImage['message'] = "Couldn't upload image!";
                $responseMessage = App_Response::alertResponse(@$insertImage['message'], 'danger');
                $responseArray = array("success" => 0, "message" => (@$responseMessage));
            endif;
            echo @json_encode($responseArray);
        endif;
    endif;
    //---------------------------------------------------------------------------
    if (isset($requestMethodArray['fetchInvItem'])):
        $module = new Module_Class;
        $app_id = $requestMethodArray['app_id'];
        @$getProduct = $module->getRecord([
            "tbl_scheme" => 'app_products',
            "condition" => ['app_id' => $app_id]
        ]);
        if ($getProduct['response'] !== '200'):
            echo App_Response::alertResponse('Invalid product selection', 'danger');
        else:

            $product = $getProduct['dataArray'][0];
            $qty = $module->getRecord([
                "tbl_scheme" => 'app_inventory',
                "condition" => ['app_id' => $app_id, "store_id" => $store_id]
            ])['dataArray'][0]['stock_qty'];

            echo '<script>$("#item-appid").val("' . $product['app_id'] . '")</script>';
            echo '<script>$("#product_search").val("' . $product['name'] . '")</script>';
            echo '<script>$("#inventory-lookup").val("' . $product['name'] . '")</script>';
            echo '<script>$("#stock_qty").val("' . $qty . '")</script>';
            echo '<script>$("#stock_price").val("' . $product['price'] . '")</script>';
            echo '<script>$("#stock_sale_price").val("' . $product['sale_price'] . '")</script>';
        endif;

    endif;
    //---------------------------------------------------------------------------
    if (isset($requestMethodArray['SubmitProductStocking'])):
        $module = new Module_Class;
        $product_id = $requestMethodArray['app_id'];
        $check = $module->getRecord([
            "tbl_scheme" => 'app_inventory',
            "condition" => ["app_id" => $product_id, "store_id" => $store_id]
        ]);
        if (@$check['response'] !== '200' && @$check['dataArray'] != NULL):
            $responseMessage = App_Response::alertResponse('Invalid products selection, verify!', 'danger');
            $responseArray = array("success" => 0, "message" => (@$responseMessage));
        else:
            $fieldsArray = ["tbl_scheme" => 'app_products_stocking', "stocked_by" => $auth_username, "store_id" => $store_id];
            foreach ($requestMethodArray as $key => $val):
                if ($key !== "SubmitProductStocking" && $key !== "editPk")
                    $fieldsArray += array($key => $val);
            endforeach;
            $stock_qty = $requestMethodArray['new_qty'];
            $updateInventory = $module->updateRecord([
                "tbl_scheme" => 'app_inventory',
                "pkField" => 'id',
                "pk" => $check['dataArray'][0]['id'],
                "stock_qty" => $stock_qty,
            ]);
            if (@$updateInventory['response'] === '200'):
                $recordSubmit = $module->createRecord($fieldsArray);
                $callback = ["type" => 'actionEvent',
                    "redirect" => 'resetStocking()'];

                if (@$callback['type'] == 'actionEvent'):
                    $callback += array("event" => '<script>' . $callback['redirect'] . '</script>');
                endif;
                $responseMessage = App_Response::alertResponse('Product stocking submitted successfully', 'success');
                $responseArray = array("success" => 1, "message" => $responseMessage, "dataArray" => '', "callback" => @$callback);
            endif;
        endif;
        echo @json_encode($responseArray);
    endif;
    //---------------------------------------------------------------------------

    //---------------------------------------------------------------------------
    if (isset($requestMethodArray['fetchEntryRows'])):
        $reference = $requestMethodArray['reference'];
        $module = new Module_Class;
        require "inc/quote_item_tbl_rows.php";
    endif;
    //---------------------------------------------------------------------------
    if (isset($requestMethodArray['SubmitQuoteItem'])):
        $module = new Module_Class;
        $request = $requestMethodArray['SubmitQuoteItem'];
        $reference = $requestMethodArray['reference'];
        $item_appid = $requestMethodArray['item_appid'];
        $quote_type = $requestMethodArray['quote_type'];

        $check = $module->getRecord([
            "tbl_scheme" => 'app_quotation_item',
            "condition" => ["reference" => $reference, "item_appid" => $item_appid]
        ]);
        if (@$check['response'] === '200' && @$check['dataArray'] != NULL && $request == 1 && $quote_type === "Supply"):
            echo App_Response::alertResponse('Item already exist, verify!', 'danger');
        else:
            $fieldsArray = ["tbl_scheme" => 'app_quotation_item'];
            foreach ($requestMethodArray as $key => $val):
                if ($key !== "SubmitQuoteItem" && $key !== "editPk")
                    $fieldsArray += array($key => $val);
            endforeach;
            if ($request == 1):
                $recordSubmit = $module->createRecord($fieldsArray);
            else:
                $pk = $requestMethodArray['editPk'];
                $fieldsArray += array("pkField" => 'id', "pk" => $pk);
                $recordSubmit = $module->updateRecord($fieldsArray);
            endif;
            if (@$recordSubmit['response'] === '200'):
                echo App_Response::alertResponse('Item entry submitted successfully', 'success');
                echo '<script>$("#item-entry-form")[0].reset();</script>';
                echo '<script>loadEntryRows();</script>';
                echo '<script>$("#inventory-lookup").focus();</script>';
                echo '<script>$("#editPk").val("");</script>';
                echo '<script>$("#SubmitQuoteItem").val(1);</script>';
            endif;
        endif;
    endif;

    //---------------------------------------------------------------------------
    if (isset($requestMethodArray['delEntryRows'])):
        $module = new Module_Class;
        $row_id = $requestMethodArray['delEntryRows'];
        $deleteRecord = $module->deleteRecord([
            "tbl_scheme" => 'app_quotation_item',
            "pk" => ['id' => $row_id]
        ]);
        if (@$deleteRecord['response'] === '200'):
            if (@$requestMethodArray['callback']['type'] == 'actionEvent'):
                $requestMethodArray['callback'] += array("event" => '<script>' . $requestMethodArray['callback']['redirect'] . '</script>');
            endif;
            $deleteImage['message'] = "Image successfully deleted!";
            $responseMessage = App_Response::alertResponse(@$deleteImage['message'], 'success');
            $responseArray = array("success" => 1, "message" => (@$responseMessage), "callback" => @$requestMethodArray['callback']);
        else:
            $deleteImage['message'] = "Couldn't delete image!";
            $responseMessage = App_Response::alertResponse(@$deleteImage['message'], 'danger');
            $responseArray = array("success" => 0, "message" => (@$responseMessage));
        endif;
        echo @json_encode($responseArray);
    endif;
    //---------------------------------------------------------------------------
    if (isset($requestMethodArray['fetchInvItemEdit'])):
        $module = new Module_Class;
        $id = $requestMethodArray['row_id'];
        @$getEntry = $module->getRecord([
            "tbl_scheme" => 'app_quotation_item',
            "condition" => ['id' => $id]
        ]);
        if ($getEntry['response'] !== '200'):
            echo App_Response::alertResponse('Invalid item selection', 'danger');
        else:
            $entry = $getEntry['dataArray'][0];
            echo '<script>$("#item-appid").val("' . $entry['item_appid'] . '")</script>';
            if ($entry['quote_type'] != "Services"):
                echo '<script>$("#inventory-lookup").val("' . $entry['item_description'] . '")</script>';
            else:
                echo '<script>$("#service-description").val("' . htmlspecialchars($entry['item_description']) . '")</script>';
            endif;
            echo '<script>$("#item-qty").val("' . $entry['stock_qty'] . '")</script>';
            echo '<script>$("#stock_sale_price").val("' . str_replace(',', '', number_format($entry['stock_sale_price'], 2)) . '")</script>';
            echo '<script> var pk = document.getElementById("editPk"); if(!pk){ $("#SubmitQuoteItem").after(\'<input type="hidden" name="editPk" value="' . $entry['id'] . '" id="editPk">\'); }else{ $("#editPk").val("' . $entry['id'] . '") }</script>';
        endif;

    endif;
    //---------------------------------------------------------------------------
    if (isset($requestMethodArray['orderPreview'])):
        $app = $engine;
        $biz = new BIZConfig;
        $module = new Module_Class;
        $ref = $requestMethodArray['ref_no'];
        @$getQuote = $module->getRecord([
            "tbl_scheme" => 'app_quotations',
            "condition" => ['reference' => $ref],
            "limit" => 1
        ]);
        @extract($getQuote['dataArray'][0]);
        $subDate = new DateTime($submission_date);
        $reqDate = new DateTime($request_date);
        $submission_date = $subDate->format('d/m/Y');
        $request_date = $reqDate->format('d/m/Y');
        //--------------------------------------------------
        $customer = $module->getRecord([
            "tbl_scheme" => "app_customers",
            "condition" => [
                "app_id" => $customer_id
            ]
        ])['dataArray'][0];
        //--------------------------------------------------
        @$contact = $module->getRecord([
            "tbl_scheme" => "app_users",
            "condition" => [
                "user_id" => $contact_person
            ]
        ])['dataArray'][0];
        //--------------------------------------------------
        @$getItems = $module->getRecord([
            "tbl_scheme" => 'app_quotation_item',
            "condition" => ['reference' => $ref]
        ])['dataArray'];
        require 'inc/quote_preview.php';
    endif;
    //---------------------------------------------------------------------------
    if (isset($requestMethodArray['deleteQuotation'])):
        $module = new Module_Class;
        $reference = $requestMethodArray['pk']['reference'];
        $deleteItemRecord = $module->deleteRecord([
            "tbl_scheme" => 'app_quotation_item',
            "pk" => ['reference' => $reference]
        ]);
        $deleteRecord = $module->deleteRecord([
            "tbl_scheme" => 'app_quotations',
            "pk" => ['reference' => $reference]
        ]);
        if (@$deleteRecord['response'] === '200'):
            if (@$requestMethodArray['callback']['type'] == 'actionEvent'):
                $requestMethodArray['callback'] += array("event" => '<script>' . $requestMethodArray['callback']['redirect'] . '</script>');
            endif;
            $deleteImage['message'] = "Record successfully deleted!";
            $responseMessage = App_Response::alertResponse(@$deleteImage['message'], 'success');
            $responseArray = array("success" => 1, "message" => (@$responseMessage), "callback" => @$requestMethodArray['callback']);
        else:
            $deleteImage['message'] = "Couldn't delete image!";
            $responseMessage = App_Response::alertResponse(@$deleteImage['message'], 'danger');
            $responseArray = array("success" => 0, "message" => (@$responseMessage));
        endif;
        echo @json_encode($responseArray);
    endif;
    //---------------------------------------------------------------------------
    if (isset($requestMethodArray['orderPosting'])):
        $module = new Module_Class;
        $reference = $requestMethodArray['pk']['reference'];
        $confirm = $module->getRecord([
            "tbl_scheme" => 'app_purchase_orders',
            "condition" => [
                "reference" => $reference,
                "status" => 1,
                "approval" => 1,
                "post_status" => 0],
        ]);
        if ($confirm['response'] !== '200'):
            $responseMessage = App_Response::alertResponse('Invalid purchase order posting, verify order and try again!!', 'danger');
            $responseArray = array("success" => 0, "message" => (@$responseMessage), "callback" => @$requestMethodArray['callback']);
        else:
            $store_id = $confirm['dataArray'][0]['store_id'];
            $checkItems = $module->getRecord([
                "tbl_scheme" => 'app_purchase_orders_item',
                "condition" => [
                    'reference' => $reference,
                    'post_status' => 0],
            ]);
            if (@$checkItems['dataArray'] == NULL):
                $responseMessage = App_Response::alertResponse('No item(s) in purchase order, verify order and try again!!', 'danger');
                $responseArray = array("success" => 0, "message" => (@$responseMessage), "callback" => @$requestMethodArray['callback']);
            else:
                foreach ($checkItems['dataArray'] as $item):
                    $getInvInfo = $module->getRecord([
                        "tbl_scheme" => 'app_inventory',
                        "condition" => [
                            "app_id" => $item['item_appid'],
                            "store_id" => $store_id],
                    ])['dataArray'][0];
                    $itemRow = $getInvInfo['id'];
                    $qty = $getInvInfo['stock_qty'];
                    $updateProduct = $module->updateRecord([
                        "tbl_scheme" => 'app_products',
                        "pkField" => 'app_id',
                        "pk" => $item['item_appid'],
                        "price" => $item['new_price'],
                        "sale_price" => $item['new_sale_price']
                    ]);
                    $updateInventory = $module->updateRecord([
                        "tbl_scheme" => 'app_inventory',
                        "pkField" => 'id',
                        "pk" => $itemRow,
                        "stock_qty" => $qty + $item['order_qty'],
                    ]);
                    if ($updateInventory['response'] === '200'):
                        $updateEntry = $module->updateRecord([
                            "tbl_scheme" => 'app_purchase_orders_item',
                            "pkField" => 'id',
                            "pk" => $item['id'],
                            "post_status" => 1
                        ]);
                    endif;
                endforeach;
                $verify = $module->getRecord([
                    "tbl_scheme" => 'app_purchase_orders_item',
                    "condition" => [
                        'reference' => $reference,
                        'post_status' => 0],
                ]);
                if ($verify['response'] !== '200'):
                    $updateOrder = $module->updateRecord([
                        "tbl_scheme" => 'app_purchase_orders',
                        "pkField" => 'reference',
                        "pk" => $reference,
                        "post_status" => 1
                    ]);
                    if ($updateOrder['response'] === '200'):
                        $responseMessage = App_Response::alertResponse('Purchase order successfully posted', 'success');
                        $responseArray = array("success" => 1, "message" => (@$responseMessage), "callback" => @$requestMethodArray['callback']);
                    endif;
                endif;
            endif;
        endif;
        echo @json_encode($responseArray);
    endif;
    //-------------------------------- POS Events ------------------------------//
    if (isset($requestMethodArray['DiscardTransact']) && $requestMethodArray['DiscardTransact'] == 1):
        $pos = new POS;
        $biz = new BIZConfig;
        $callback = ["type" => 'actionEvent',
            "redirect" => 'reloadPOS()'];
        $app_cart = $biz->biz['app_cart'];
        $discard = $pos->DiscardTransact();
        if (isset($_SESSION[$app_cart])):
            unset($_SESSION[$app_cart]);
        endif;
        if (@$callback['type'] == 'actionEvent'):
            $callback += array("event" => '<script>' . $callback['redirect'] . '</script>');
        endif;
        $responseArray = array("success" => 1, "message" => '', "dataArray" => '', "callback" => @$callback);
        echo @json_encode($responseArray);
    endif;
    //-----------------------------------------------------------------------------------
    if (isset($requestMethodArray['deleteSaveOrder']) && $requestMethodArray['deleteSaveOrder'] == 1):
        $module = new Module_Class;
        $transact_id = $requestMethodArray['pk'];
        $getOrder = $module->getRecord([
            "tbl_scheme" => 'app_transactions',
            "condition" => [
                "transact_id" => $transact_id
            ]
        ])['dataArray'][0];
        if ($getOrder != NULL):
            @$module->deleteRecord([
                "tbl_scheme" => 'app_sales_products',
                "pk" => ['transact_id' => $transact_id]
            ]);
            @$deleteTrans = $module->deleteRecord([
                "tbl_scheme" => 'app_transactions',
                "pk" => ["transact_id" => $transact_id]
            ]);
        endif;
        if ($deleteTrans['response'] === '200'):
            $responseArray = array("success" => 1, "message" => '', "callback" => @$requestMethodArray['callback']);
        endif;
        echo json_encode($responseArray);
    endif;
    //-----------------------------------------------------------------------------------
    if (isset($requestMethodArray['DiscardReturn']) && $requestMethodArray['DiscardReturn'] == 1):
        $pos = new POS;
        $biz = new BIZConfig;
        $callback = ["type" => 'actionEvent',
            "redirect" => 'reloadPOS()'];
        $app_cart = $biz->biz['app_cart'];
        $transact_id = $_SESSION[$app_cart];
        $initialize = Data_Access::execSQL("UPDATE app_sales_products SET product_qty = -product_qty WHERE transact_id = '$transact_id'");
        if ($initialize['response'] === '200'):
            if (isset($_SESSION[$app_cart])):
                unset($_SESSION[$app_cart]);
            endif;
            if (isset($_SESSION['ReturnSales'])):
                unset($_SESSION['ReturnSales']);
            endif;
        endif;
        if (@$callback['type'] == 'actionEvent'):
            $callback += array("event" => '<script>' . $callback['redirect'] . '</script>');
        endif;
        $responseArray = array("success" => 1, "message" => '', "dataArray" => '', "callback" => @$callback);
        echo @json_encode($responseArray);
    endif;
    //-----------------------------------------------------------------------------------
    if (isset($requestMethodArray['submitDeposit'])):
        $module = new Module_Class;
        $reference = $engine->generateAppId('', rand(10, 99), 8, '0123456789ABCDEFGHIJKLM');
        @$transact_reference = $requestMethodArray['transact_id'];
        @$amount_tendered = $requestMethodArray['amount_tendered'];
        @$deposit_date = $requestMethodArray['deposit_date'];
        @$additional_note = $requestMethodArray['additional_note'];
        @$received_by = $auth['firstname'] . ' ' . $auth['lastname'];
        @$store_id = $auth['store_id'];

        $callback = [
            "type" => 'actionEvent',
            "redirect" => 'loadDeposit("' . $transact_reference . '")'
        ];
        $submit = $module->createRecord([
            "tbl_scheme" => "app_sales_deposits",
            "reference" => $reference,
            "transact_reference" => $transact_reference,
            "amount_tendered" => $amount_tendered,
            "deposit_date" => $deposit_date,
            "additional_note" => $additional_note,
            "store_id" => $store_id,
            "received_by" => $received_by
        ]);
        if ($submit['response'] === '200'):
            $responseMessage = App_Response::alertResponse('Purchase order successfully posted', 'success');
            if (@$callback['type'] == 'actionEvent'):
                $callback += array("event" => '<script>' . $callback['redirect'] . '</script>');
            endif;
            $responseArray = array("success" => 1, "message" => '', "dataArray" => '', "callback" => @$callback);
        endif;
        echo @json_encode($responseArray);
    endif;
    if (isset($requestMethodArray['loadDeposit'])):
        $module = new Module_Class;
        $biz = new BIZConfig;
        $reference = $requestMethodArray['loadDeposit'];
        require 'pos/inc/deposits.php';
    endif;
endif;