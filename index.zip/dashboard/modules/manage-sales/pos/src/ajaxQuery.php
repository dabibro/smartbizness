<?php
require_once("../../../../helpers/config.php");
require_once("../../../../helpers/functions.php");

//load POS cart
if (isset($_GET['loadItemsInventory'])) {
    require_once("ModulePaginator.php");

    $condition = "AND active_status = 1 AND quantity > 0";
    if (isset($_GET['category']) && $_GET['category'] != 0) {
        $category_id = $_GET['category'];
        $condition = " AND active_status = 1 AND quantity > 0 AND category = '$category_id'";
    } else if (isset($_GET['q']) && $_GET['q'] != "") {
        $search_term = $_GET['q'];
        $condition = "AND menu_id LIKE '%" . $search_term . "%' AND active_status = 1 AND  quantity > 0 OR menu_name LIKE '%" . $search_term . "%' AND active_status = 1 AND  quantity > 0 OR additional_description LIKE '%" . $search_term . "%' AND active_status = 1 AND  quantity > 0 OR sales_price LIKE '%" . $search_term . "%' AND active_status = 1 AND  quantity > 0";
    } else if (isset($_GET['all-products'])) {
        $condition = "AND active_status = 1 AND quantity > 0";
    }

    //Main query
    @$pages = new pospagination;
    @$pages->default_ipp = 12;
    @$sql_forms = dbQuery("SELECT * FROM app_menus WHERE 1 " . $condition . "");
    @$pages->items_total = $sql_forms->num_rows;
    @$pages->mid_range = 5;
    @$pages->paginate();

    $results = dbQuery("SELECT * FROM app_menus WHERE 1 " . $condition . " ORDER BY menu_name " . $pages->limit . "");

    if (!($results)) {
        die(mysqli_error());
    }
    require_once('../inc/inventory-lists.php');
}

//pos selection
if (isset($_GET['addToCart']) || isset($_GET['selection'])) {
    if (isset($_GET['selection']) && $_GET['selection'] == 1) {
        //Trasaction details & product id extraction
        $getId = explode(' -> ', $_GET['product_id']);
        $getQty = @array_pad(explode('=', $_GET['product_id']), 2, null);
        $transact_id = $_GET['transact_id'];

        if (!@$getId[1]) {
            $get_id = getMenu($getId[0]);
            $product_id = $get_id['id'];
            $product_name = $get_id['menu_name'];
        } else {
            $get_id = getMenu($getId[0]);
            $product_id = $get_id['id'];
            $product_name = $get_id['menu_name'];
        }
        if (isset($getQty[1])) {
            $Qty = $getQty[1];
        } else {
            $Qty = 1;
        }
    } else {
        $get_id = getMenu($_GET['product_id']);
        $transact_id = $_GET['transact_id'];
        $product_id = $get_id['id'];
        $product_name = $get_id['menu_name'];
        //qty
        $Qty = 1;
    }
    // echo $Qty; exit;
    $entry_by = $user_id;
    //product details
    $product_check = dbQuery("SELECT id, sales_price FROM app_menus WHERE id  = '$product_id' AND active_status = 1");
    if (dbNumRows($product_check) == 0) {
        echo '<div class="alert alert-danger alert-dismissible p-2 pr-3 pl-3" role="alert">
        <i class="fal fa-exclamation-triangle"></i> Invalid item selection, try again</div>';
        echo "<script>$('#product_search').val('');</script>";
    } else {
        //product information
        $product = dbFetchAssoc($product_check);
        // product Price
        $price = $product['sales_price'];

        if (isset($_SESSION[$cart])) {
            $transact_id = $_SESSION[$cart];
            $check_transact = dbFetchAssoc(dbQuery("SELECT count(id) as row FROM app_menu_transacts WHERE transact_id = '$transact_id' AND item_id = '" . $product['id'] . "' LIMIT 1"));
            $check_stat = 0;
            if ($check_transact['row'] > 0) {
                $check_stat = 1;
            } else {
                $check_stat = 0;
            }
            switch ($check_stat) {
                case '1':
                    $sql = "UPDATE app_menu_transacts SET
                item_qty = item_qty + '$Qty' WHERE item_id = '" . $product['id'] . "' AND transact_id = '" . $transact_id . "'";
                    break;
                default:
                    $sql = "INSERT INTO app_menu_transacts (transact_id, item_name, item_id, item_qty, amount, entry_by)
                VALUES ('$transact_id', '$product_name', '$product_id', '$Qty', '$price', '$entry_by')";
                    break;
            }
            if (!$query1 = dbQuery($sql)) {
                die(mysqli_error());
            }
            echo '<script>loadPosCart();</script>';
        } else {
            $sql = "INSERT INTO app_menu_transacts (transact_id, item_name, item_id, item_qty, amount, entry_by)
                VALUES ('$transact_id', '$product_name', '$product_id', '$Qty', '$price', '$entry_by')";
            if (!$query = dbQuery($sql)) {
                die(mysqli_error());
            }
            if (isset($_SESSION[$cart])) {
                echo '<script>loadPosCart();</script>';
            } else {
                $_SESSION[$cart] = $transact_id;
                echo '<script>location.reload();</script>';
            }
        }

    }
}

//delete cart item
if (isset($_GET['delCartItem']) && $_GET['delCartItem'] != "") {

    if (isset($_SESSION[$cart])) {

        $id = $_GET['delCartItem'];

        $transact_id = $_SESSION[$cart];

        $sql = "SELECT id FROM app_menu_transacts WHERE id = '$id'";

        if ($query = dbQuery($sql)) {

            dbQuery("DELETE FROM app_menu_transacts WHERE id=  '$id' AND transact_id = '$transact_id'"); // or die(mysqli_error());

        }


    }


    echo '<script>loadPosCart();</script>';


}
//change transaction product variable
if (isset($_GET['productChange']) && $_GET['productChange'] != "") {
    $row_id = $_GET['productChange'];
    $field = $_GET['field'];
    $value = $_GET['value'];
    $getInfo_sql = "SELECT id FROM app_menu_transacts WHERE id = '$row_id' ";
    $getInfo_query = dbQuery($getInfo_sql);
    if ($getInfo_query) {
        $sql = "UPDATE app_menu_transacts SET " . $field . " = '$value' WHERE id = '$row_id'";
        if (!$query = dbQuery($sql)) {
            die(mysqli_error());
        } else {
            echo '<script>loadPosCart();</script>';

        }

    }
}

//load POS cart
if (isset($_GET['loadPosCart'])) {

    require_once('../inc/shopping-cart.php');

}

if (isset($_POST['submit-cart']) && $_POST['submit-cart'] != "") {

    if (isset($_SESSION[$cart])) {
        $transact_id = $_SESSION[$cart];
        @$customer_id = $_POST['customer_id'];
        @$customer_type = $_POST['customer_type'];
        @$bill_type = $_POST['bill-type'];
        @$customer_name = test_input($_POST['customer_name']);
        if ($customer_type != 'Guest') {
            $getCustomer = getCustomer($customer_id);
            @$customer_name = $getCustomer['name'];
        }
        $subtotal = $_POST['subtotal'];
        $discount = $_POST['discount'];
        $total_due = $_POST['total_due'];
        $pay_mode = $_POST['pay_mode'];
        $pay_options = $_POST['pay_options'];
        $cash_tendered = $_POST['cash_tendered'];
        $balance_due = $_POST['balance_due'];
        $entry_by = $user_id;
        $pay_status = $_POST['submit-cart'];

        $error = "";
        if ($customer_type == '') {
            echo '<div class="alert alert-danger py-1 px-2 small"><i class="fal fa-exclamation-triangle"></i> Select customer type, before order submission!</div>';
            exit;
        } else if ($customer_type == 'Guest' && $customer_id == '') {
            echo '<div class="alert alert-danger py-1 px-2 small"><i class="fal fa-exclamation-triangle"></i> Select guest room no, before order submission!</div>';
            exit;
        } else if ($customer_type == 'Customer' && $customer_id == '') {
            echo '<div class="alert alert-danger py-1 px-2 small"><i class="fal fa-exclamation-triangle"></i> Select customer name, before order submission!</div>';
            exit;
        }
        $get_transact = "SELECT id, transact_id, item_id, item_qty, amount FROM app_menu_transacts WHERE transact_id = '$transact_id' AND status != 1";

        $transact_query = dbQuery($get_transact);

        if (isset($transact_query)) {

            $getTransact = getTransaction($transact_id);

            if ($pay_status == 1) {
                //check stock level
                while ($product = dbFetchAssoc($transact_query)):

                    $productInfo = getMenu($product['item_id']);

                    if ($productInfo['quantity'] < $product['item_qty']) {
                        $error = 1;
                        echo "<div class='alert alert-danger'>Low quantity level for " . $productInfo['menu_name'] . "</div>";

                    } else if ($product['amount'] < $productInfo['sales_price'] && $appinfo['pos_sale_out_of_stock'] != 0) {
                        $error = 1;
                        echo "<div class='alert alert-danger'>You cannot sale " . $productInfo['menu_name'] . ", its below sale price</div>";
                    }
                endwhile;

            }

            if ($error != 1) {

                $check_payment = "SELECT id FROM app_menu_sales WHERE transact_id = '" . $transact_id . "'";

                $payment_query = dbQuery($check_payment);

                if (dbNumRows($payment_query) == 0) {

                    $sql = "INSERT INTO app_menu_sales (transact_id, customer_type, customer_id, customer_name, subtotal, discount, total_due, pay_mode, mix_payments, cash_tendered, balance_due, entry_by, pay_status)VALUE('$transact_id', '$customer_type', '$customer_id', '$customer_name', '$subtotal', '$discount', '$total_due', '$pay_mode', '$pay_options', '$cash_tendered', '$balance_due', '$entry_by', '$pay_status')";

                } else {

                    $sql = "UPDATE app_menu_sales SET
                customer_type = '$customer_type',
                customer_id     = '$customer_id',
                customer_name   = '$customer_name',
                subtotal        = '$subtotal',
                discount        = '$discount',
                total_due       = '$total_due',
                pay_mode        = '$pay_mode',
                mix_payments    = '$pay_options',
                cash_tendered   = '$cash_tendered',
                balance_due     = '$balance_due',
                entry_by        = '$entry_by',
                entry_date      = CURRENT_TIMESTAMP, 
                pay_status      = '$pay_status'
                WHERE transact_id = '$transact_id'";

                }

                if ($customer_type == 'Guest') {
                    $booking = getBooking($customer_id);
                    $guest_id = $booking['guest_id'];
                    $vat = 0;
                    $remark = '';
                    $entry_by = $user_name;
                    $url = '';
                    $billing = billing($customer_id, $bill_type, $customer_type, $guest_id, $customer_name, $subtotal, $discount, $vat, $total_due, $remark, $entry_by, $url);
                    if ($billing == 1) {
                        if ($cash_tendered != 0) {
                            $payment = payment($customer_id, $bill_type, $customer_type, $guest_id, $customer_name, $pay_mode, $pay_options, $cash_tendered, $remark, $entry_by, $url);
                        }
                    }
                }

                if (!$query = dbQuery($sql)) {
                    die(mysqli_error());
                } else if ($pay_status == 1) {

                    //deduct product
                    $trans_query = dbQuery($get_transact);

                    while ($product_list = dbFetchAssoc($trans_query)):

                        $productInfo = getMenu($product_list['item_id']);

                        //echo $productInfo['item_qty'].$product_list['item_id']; exit;

                        if ($productInfo['quantity'] >= $product_list['item_qty']) {

                            $deduct_sql = "UPDATE app_menus SET quantity = quantity - '" . $product_list['item_qty'] . "' WHERE id = '" . $product_list['item_id'] . "'";

                            if (!$deduct_query = dbQuery($deduct_sql)) {
                                die(mysqli_error());
                            } else {
                                dbQuery("UPDATE app_menu_transacts SET status = 1 WHERE id = '" . $product_list['id'] . "'");
                            }
                        }

                    endwhile;
                }
                //print receipt
                echo '<script>location.replace("?p=manage-restaurant&sales&receipt=' . $transact_id . '")</script>';
                unset($_SESSION[$cart]);
            }
        }

    }
}

if (isset($_GET['reversalLookup']) && $_GET['p_id'] != "") {
    $p_id = test_input($_GET['p_id']);
    // get product information
    $product = getItemInfo($p_id);
    if (!$product) {
        echo '<div class="p-2 alert-danger  mb-2"><i class="fal fa-exclamation-triangle"></i> Invalid product selection, try again!!!</div>';
    } else {
        extract($product);
        echo $item_sale_price;
    }

    //echo 'Hi';
}

//reversal submission
if (isset($_POST['submit-reversal']) && $_POST['submit-reversal'] != "") {
    //variable
    $reference = $_POST['reference'];
    $product_id = $_POST['reversing_product_id'];
    $product_qty = $_POST['reversed_qty'];
    $product_price = $_POST['reversing_product_price'];
    $cost_amount = $_POST['cost_amount'];
    $issued_amount = $_POST['issued_amount'];
    $issued_date = $_POST['issued_date'];
    $additional_note = test_input($_POST['remark']);
    $entry_by = $userinfo['id'];

    $sql = "INSERT INTO app_returns (reference, item_id, reversed_qty, product_price, cost_amount, issued_amount, issued_date, additional_note, entry_by) 
values ('$reference', '$product_id', '$product_qty', '$product_price', '$cost_amount', '$issued_amount', '$issued_date', '$additional_note', '$entry_by')";

    if (!$result = dbQuery($sql)) {
        echo mysqli_error();
    } else {
        // $new_reference = rand(000, 999) . date('ms', time());
        echo '<div class="alert alert-success alert-dismissible fade show p-2 pl-3" role="alert"> <strong><i class="fal fa-check-circle"></i></strong> Record successfully saved. <button type="button" class="close p-0 pr-2 small pt-1" data-dismiss="alert" aria-label="Close"> <span aria-hidden="true">&times;</span> </button> </div>';
        echo '<script>$(".reversalForm")[0].reset();</script>';

        echo '<script>$("#reference").val("' . $reference . '");</script>';
    }
}

//cash deposit reference lookup
if (isset($_GET['deposit-check']) && $_GET['reference'] != "") {
    $reference = test_input($_GET['reference']);
    $sql = "SELECT pay_status, balance_due FROM app_payments WHERE transact_id = '$reference'";
    if (dbNumRows(dbQuery($sql)) == 0) {
        echo '<div class="p-2 alert-danger  mb-2"><i class="fal fa-exclamation-triangle"></i> Invalid transaction reference, try again!!!</div>';
        echo "<script>$('.reversal').addClass('hide');</script>";
    } else {
        //transact info
        $transact_info = dbFetchAssoc(dbQuery($sql));
        $getStatus = getStatus($transact_info['pay_status'], 'Pending Transaction', 'Completed Transaction');
        echo "<script>$('#transact_status').html('<div class=\"alert-info p-2 mb-2\">" . $getStatus . "</div>');</script>";
        echo "<script>$('#transact_amount').val('" . number_format($transact_info['balance_due'], 2) . "');</script>";

        //deposits total
        $deposit_query = dbFetchAssoc(dbQuery("SELECT SUM(amount) as deposited FROM app_deposits WHERE transact_ref = '$reference'"));
        echo "<script>$('#deposited_amount').val('" . number_format($deposit_query['deposited'], 2) . "');</script>";

        echo "<script>$('.reversal').removeClass('hide');</script>";
        echo '<script>$("#deposit-save-btn").removeAttr("disabled"); </script>';

    }

}

//deposit submisison
if (isset($_POST['submit-deposit']) && $_POST['submit-deposit'] != "") {
    //variable
    $reference = $_POST['reference'];
    $transact_ref = $_POST['transact_ref'];
    $transact_amount = str_ireplace(',', '', $_POST['transact_amount']);
    $deposited_amount = str_ireplace(',', '', $_POST['deposited_amount']);
    $amount = str_ireplace(',', '', $_POST['amount']);
    $deposit_date = $_POST['deposit_date'];
    $additional_note = test_input($_POST['remark']);
    $entry_by = $userinfo['id'];

    $sql = "INSERT INTO app_deposits (reference, transact_ref, transact_amount, deposited_amount, amount, deposit_date, additional_note, entry_by)
values ('$reference', '$transact_ref', '$transact_amount', '$deposited_amount', '$amount', '$deposit_date', '$additional_note', '$entry_by')";

    if (!$result = dbQuery($sql)) {
        echo mysqli_error();
    } else {
        $new_reference = rand(000, 999) . date('ms', time());
        echo '<div class="alert alert-success alert-dismissible fade show p-2 pl-3" role="alert"> <strong><i class="fal fa-check-circle"></i></strong> Record successfully saved. <button type="button" class="close p-0 pr-2 small pt-1" data-dismiss="alert" aria-label="Close"> <span aria-hidden="true">&times;</span> </button> </div>';
        echo "<script>$('#transact_status').html('');</script>";
        echo '<script>$(".depositForm")[0].reset();</script>';
        echo '<script>$("#reference").val("' . $new_reference . '");</script>';
    }
}

//payment option adding
if (isset($_GET['payment-options']) && isset($_GET['array'])) {
    $array = $_GET['array'];
    if (isset($_GET['remove'])) {
        $options = trim(str_ireplace($array, '', $_GET['options']), ', ');
    } else {
        $options = $_GET['options'];
    }
    $selection = "";
    $exp_arr = explode('->', $array);
    $occur = $exp_arr[0] . '->';
    if (strstr($options, $occur, FALSE) && !isset($_GET['remove'])) {
        echo '<i class="fal fa-exclamation-triangle"></i> Payment option already selected!!';
    } else {
        if ($options != "") {
            if (isset($_GET['remove'])) {
                $selected = str_ireplace(', , ', ', ', trim($options, ', '));
            } else {
                $selected = $options . ', ' . $array;
            }
        } else {
            $selected = $array;
        }
        $exp_selection = explode(',', $selected);
        $arr_count = count($exp_selection);
        $exit = 0;
        $x = 0;
        $total_tendered = 0;
        while ($x < $arr_count) {

            if ($arr_count == 1) {
                $exit = 1;
            }
            $getOption = explode('->', $exp_selection[$x]);
            @$getPayOption = getPaymentSettings(@$getOption[0]);
            $total_tendered = $total_tendered + $getOption[1];
            $selection .= '<div class="row mx-0"><div class="col-7 pl-2 p-1">' . @$getPayOption['mode_name'] . '</div><div class="col-5  border-bottom p-1">' . number_format(@$getOption[1], 2) . '<span class="float-right"><button type="button" class="bg-transparent pointer border-0" onclick="removePayOption(' . @$getOption[0] . ', ' . @$getOption[1] . ', ' . $exit . ');" ><i class="fal fa-trash-alt"></i></button></span></div></div>';
            $x++; ///echo $x;
        }
        if ($arr_count != 0) {
            $selection .= '<div class="row mx-0"><div class="col-7 pl-2 p-1 text-right">Total Tendered ' . @$currency . ':</div><div class="col-5  border-bottom p-1">' . number_format(@$total_tendered, 2) . '</div></div>';
        }
        echo '<script>$("#selected-options").html(\'' . $selection . '\');</script>';
        echo '<script>$("#pay-options").val("' . $selected . '");</script>';
        echo '<script>$("#tendered").val("' . $total_tendered . '"); tendered();</script>';
        echo '<script>$("#cash_tendered").val("");</script>';

    }

}

?>
