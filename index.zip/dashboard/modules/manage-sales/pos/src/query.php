<?php

//require function file
require_once('../helpers/functions.php');

//check user login
checkUser();

//application data
$appinfo = getShopConfig();

//retrieve user information
$userinfo = getUserInfo();

//cart session name
$cart = cartSession();

//customers list
$customers = dbQuery("SELECT id, name FROM app_customers WHERE delete_status = 0 ORDER BY name");

//payment options
$payment_options = dbQuery("SELECT id, mode_name FROM app_payment_settings WHERE delete_status = 0");


//logout 
//logout request
if (isset($_GET['logout'])) {
    doLogout();
}


if (dbNumRows(dbQuery($orders_sql)) != 0) {
    $orders_query = dbQuery($orders_sql);
}
//reversals
$reversals_sql = "SELECT id, reference, product_id, product_price, reversed_qty, issued_amount, issued_date FROM app_returns WHERE  entry_by = '" . $userinfo['id'] . "' AND MONTH(entry_date) = MONTH(CURRENT_TIMESTAMP) GROUP BY reference ORDER BY issued_date ASC";

if (dbNumRows(dbQuery($reversals_sql)) != 0) {
    $reversals_query = dbQuery($reversals_sql);
}
//deposits
$deposits_sql = "SELECT id, reference, additional_note, transact_ref, amount, deposit_date FROM app_deposits WHERE  entry_by = '" . $userinfo['id'] . "' AND MONTH(entry_date) = MONTH(CURRENT_TIMESTAMP) GROUP BY transact_ref ORDER BY deposit_date ASC";

if (dbNumRows(dbQuery($deposits_sql)) != 0) {
    $deposits_query = dbQuery($deposits_sql);
}


//initializing wholesale
if (isset($_GET['wholesale']) && $_GET['wholesale'] != "") {

    //$getOrder_sql = "SELECT id, transact_id FROM app_payments WHERE id = '".$_GET['edit-order']."' AND pay_status = 0";
    //$getOrder_query = dbQuery($getOrder_sql);
    //if($getOrder_query){
    //$order = dbFetchAssoc($getOrder_query);

    if ($_GET['wholesale'] == 1) {
        $_SESSION['wholesale'] = 1; //$order['transact_id'];
    } else {
        $_SESSION['wholesale'] = "";
        unset($_SESSION['wholesale']);
    }
    echo '<script>location.replace("' . POS . '")</script>';
}


//updating saved order
if (isset($_SESSION[$cart])) {
    $tran_id = $_SESSION[$cart];
    //get transaction information
    $tran_sql = "SELECT * FROM app_payments WHERE transact_id = '$tran_id' ";
    if ($tran_result = dbQuery($tran_sql)) {
        $tran_info = dbFetchAssoc($tran_result);
    }
}


?>
