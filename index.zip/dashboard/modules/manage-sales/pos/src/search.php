<?php
require_once("../../../../helpers/config.php");
//get search term
$search_term = $_GET['term'];
$sql = "SELECT id, menu_name FROM app_menus WHERE menu_id LIKE '%" . $search_term . "%' AND active_status = 1 AND  quantity > 0 
        OR menu_name LIKE '%" . $search_term . "%' AND active_status = 1 AND  quantity > 0 
        OR additional_description LIKE '%" . $search_term . "%' AND active_status = 1 AND  quantity > 0 
        ORDER BY menu_name LIMIT 20";
$query = dbQuery($sql);
if (dbNumRows($query) == 0) {
    $data[] = 'No result found for search';
} else {
    while ($row = dbFetchAssoc($query)) {
        $data[] = '' . $row['id'] . ' -> ' . $row['menu_name'];
    }
}
echo json_encode($data);
?>