<?php
require 'classes/POS.php';
$pos = new POS;
//------------------------------------------------------------------------------------------------------
$cart = $biz->biz['app_cart'];
//------------------------------------------------------------------------------------------------------
@$printOutRequest = explode('print/', $viewRequest);
if (isset($printOutRequest[1]) && @$printOutRequest[1] != "") {
    @$printRequest = 1;
    @$printRef = trim(@$printOutRequest[1], '/');
}
//------------------------------------------------------------------------------------------------------
@$savedOrdersRequest = explode('saved-orders/', $viewRequest);
if (isset($savedOrdersRequest[1])) {
    @$savedOrders = 1;
    if (@$savedOrdersRequest[1] != ""):
        @$orderRef = trim(@$savedOrdersRequest[1], '/');
    endif;
}
//------------------------------------------------------------------------------------------------------
@$dailySalesRequest = explode('daily-sales/', $viewRequest);
if (isset($dailySalesRequest[1])) {
    @$dailySales = 1;
}

//------------------------------------------------------------------------------------------------------
if (isset($requestMethodArray['request']) && @$requestMethodArray['request'] == "update" && $requestMethodArray['pk'] != ""):
    $transact_id = $requestMethodArray['pk'];
    if (isset($requestMethodArray['params']['return'])):
        $check_status = $requestMethodArray['params']['return'];
        if (isset($_SESSION['ReturnSales'])):
            unset($_SESSION['ReturnSales']);
        endif;
        $initialize = Data_Access::execSQL("UPDATE app_sales_products SET product_qty = -product_qty WHERE transact_id = '$transact_id'");
        if ($initialize['response'] === '200'):
            $_SESSION['ReturnSales'] = $transact_id;
        endif;
    else:
        $check_status = 0;
    endif;
    @$getOrder = $module->getRecord([
        "tbl_scheme" => 'app_transactions',
        "condition" => [
            "transact_id" => $transact_id,
            "checkout_status" => $check_status
        ]
    ])['dataArray'][0];
    if ($getOrder != NULL):
        $_SESSION[$cart] = $getOrder['transact_id'];
        echo '<script>location.replace("#/sales-point/pos/"); location.reload();</script>';
    endif;
endif;

if (isset($_GET['daily-sales']) && $_GET['date'] != "") {
    $date = $_GET['date'];

    $payment_history = "SELECT id, transact_id, customer_id, customer_name, total_due, pay_mode,  entry_by, pay_status, entry_date FROM app_menu_sales WHERE entry_by = '" . $user_id . "' AND entry_date >= '$date' AND entry_date <= DATE_ADD('$date', INTERVAL 1 DAY) ORDER BY entry_date DESC";
    if (!($result = @dbQuery($payment_history))) {
        echo die(mysqli_error($dbConn));
    }
}
?>
<script src="<?php echo $modulePath ?>pos/js.js"></script>
<link rel="stylesheet" href="<?php echo $modulePath ?>pos/style.css">
<div id="ModuleResponse"></div>
<div class="text-right small text-uppercase mb-2">
    <?php
    if (isset($_SESSION['PriceSelector'])):
        echo '<i class="fa fa-circle text-danger"></i> Price Selector: ' . str_replace('_', " ", $_SESSION['PriceSelector']);
    endif;
    ?>
</div>
<div class="container-fluid  animated fadeIn pr-1 pl-1" id="point-of-sale">
    <?php require('layouts/bottom-menus.php'); ?>
    <hr class="my-2">
    <div class="row">
        <div class="col-sm col-lg-7 pb-3 pr-2 pl-0">
            <div id="pos-response"></div>
            <?php require 'menu-switcher.php'; ?>
        </div>

        <div class="col-sm  col-lg-5 pb-3 pl-2 pr-0  border-left">
            <?php
            if (isset($printRequest) || isset($savedOrders) || isset($dailySales)):
                require 'layouts/landing-page.php';
            else:
                require('inc/inventory.php');
            endif; ?>
        </div>
    </div>
</div>
<div id="actionEvents"></div>
<script>
    loadItemsInventory();
</script>