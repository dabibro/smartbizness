var modulePath = $("#ModulePath").val();
$(document).ready(function () {
    $('.num').keyup(function () {
        this.value = this.value.replace(/[^0-9\.]/g, '');
    });
    //----------------------------------------------------------------------------------
    $('.select2').select2();
    //----------------------------------------------------------------------------------
    $('.product_search').focus();
    //----------------------------------------------------------------------------------
    $('#product_search').on('keyup', function () {
        $(".product_search").autocomplete({
            source: modulePath + 'pos/ajaxInventoryLookup.php'
        });
    });
    //----------------------------------------------------------------------------------
    $('.submit-cart-search').bootstrap3Validate(function (e, data) {
        "use strict";
        e.preventDefault();
        var transact_id = $('#transact_id').val();
        var product_id = $('#product_search').val();
        $.post(modulePath + 'pos/ajaxRequest.php',
            {
                addToCartSearch: 1,
                transactId: transact_id,
                productId: product_id
            },
            function (response) {
                $("#pos-response").html(response).fadeIn("fast");
            });
    });
    //----------------------------------------------------------------------------------
    $('.form-control').attr('autocomplete', 'off');
    //----------------------------------------------------------------------------------
    $("#pos-customer").on('change', function () {
        if (this.value == 'Walk In Customer') {
            $('#customer_name').removeClass('customer-lookup');
            $('#customer_id').val('');
            $('#customer_name').val('');
        } else if (this.value == 'On Account Customer') {
            $('#customer_name').addClass('customer-lookup');
        } else {
            $('#customer_name').removeClass('customer-lookup');
            $('#customer_id').val('');
            $('#customer_name').val('');
        }
    });
    //----------------------------------------------------------------------------------
    $('#customer_name').on('keyup', function () {
        if ($('#pos-customer').val() !== 'On Account Customer') {
            return false;
        }
        $(".customer-lookup").autocomplete({
            source: 'modules/manage-customers/src/ajaxCustomerLookup.php'
        });
    });
    //----------------------------------------------------------------------------------
    $('.customer-modal-loader').on('click', function () {
        $('#customer-record-modal').modal({backdrop: 'static'});
    });
    //----------------------------------------------------------------------------------
    $('.submit-cart').bootstrap3Validate(function (e, data) {
        "use strict";
        e.preventDefault();
        $('.pay-order-btn').html('<i class="fal fa-spin fa-spinner"></i> Processing...');
        $.ajax({
            url: modulePath + "pos/ajaxRequest.php",
            type: "POST",
            data: new FormData(this),
            contentType: false,
            cache: false,
            processData: false,
            success: function (data) {
                $("#pos-response").html(data);
                $('.pay-order-btn').html('<i class="fal fa-check-circle"></i> Submit Order ');
            },
            error: function () {
            }
        });
    });
    //----------------------------------------------------------------------------------
    //----------------------------------------------------------------------------------
    //----------------------------------------------------------------------------------
    //----------------------------------------------------------------------------------
})

//--------------------------------------------------------------------------------------

function priceSelector(price) {
    $.post(modulePath + 'pos/ajaxRequest.php',
        {
            priceSelection: 1,
            selection: price
        }, function (response) {
            $("#pos-response").html(response).fadeIn("fast");
        });
}

//--------------------------------------------------------------------------------------
function reloadPOS() {
    location.reload();
}

//--------------------------------------------------------------------------------------

function loadItemsInventory(query) {
    "use strict";
    $("#items-list").html($('.inventory-loader-content').html());
    $.post(modulePath + 'pos/ajaxRequest.php',
        {
            loadInventory: 1,
            query: query
        },
        function (response) {
            $("#items-list").html(response).fadeIn("fast");
        });
}

//--------------------------------------------------------------------------------------
function loadCart() {
    "use strict";
    $("#shopping-cart").html($('.cart-loader-content').html());

    $.post(modulePath + 'pos/ajaxRequest.php',
        {
            loadCart: 1,
            modulePath: modulePath
        },
        function (response) {
            $("#shopping-cart").html(response).fadeIn("fast");
        });
}

//--------------------------------------------------------------------------------------
function addToCart(btnId, transact_id, product_id) {
    "use strict";
    var transact_id = $('#' + transact_id).val();
    $("#" + btnId).addClass('animated bounce');
    $.post(modulePath + 'pos/ajaxRequest.php',
        {
            addToCart: 1,
            transactId: transact_id,
            productId: product_id
        },
        function (response) {
            $("#pos-response").html(response).fadeIn("fast");
        });
}

//--------------------------------------------------------------------------------------
function deleteCartItem(id) {
    "use strict";
    $.post(modulePath + 'pos/ajaxRequest.php',
        {
            deleteCartItem: id,
        },
        function (response) {
            $("#pos-response").html(response);
        });
}

//--------------------------------------------------------------------------------------
function cartItemUpdate(product_id, field, change_value) {
    $.post(modulePath + 'pos/ajaxRequest.php',
        {
            cartItemUpdate: product_id,
            field: field,
            value: change_value
        },
        function (response) {
            $("#pos-response").html(response);
        });
}

//--------------------------------------------------------------------------------------
function giveDiscount(discount, discountType) {
    var total = $('#subTotal').val();
    if (discountType == "Percentage") {
        var discount_val = discount / 100 * total;
        var formatted_discount = CommaFormatted(discount_val.toFixed(2));
        $('#discount_input').val(formatted_discount);
        var total_amt = total - discount_val;
        var formatted_amt = CommaFormatted(total_amt.toFixed(2));
        $('#total_amount').val(formatted_amt);
        $('#Total').val(total_amt);
    } else {
        if ((discount - 0) > (total - 0)) {
            $('#discount_error').html('<i class="fal fa-exclamation-triangle"></i> Discount is greater than subtotal!!!');
        } else {
            $('#discount_error').html('');
            var discount_val = (total - 0) - (discount - 0);
        }
        var formatted_discount = CommaFormatted(discount_val.toFixed(2));
        $('#total_amount').val(formatted_discount);
        $('#Total').val(discount_val);
    }
    calculateBalance();
}

//--------------------------------------------------------------------------------------
function paymentMode(option, amount, selection, action) {
    if (action === "add" && amount === 0 || action === 'add' && amount === "") {
        $('#pay-option-response').html('<i class="fal fa-info-circle"></i> Enter amount tendered and try again!!');
    } else {
        $('#pay-option-response').html('');
        $.post(modulePath + 'pos/ajaxRequest.php', {
            PaymentOption: option,
            Amount: amount,
            Selection: selection,
            Action: action
        }, function (response) {
            $("#pay-option-response").html(response).fadeIn("fast");
        });
    }
}

function removePayOption(opt, amt, ext) {
    if (ext != 1) {
        var pay_options = $('#pay-options').val();
        var arr = opt + '->' + amt;
        $.ajax({
            url: 'modules/restaurant/pos/src/ajaxQuery.php?payment-options&&array=' + arr + '&options=' + pay_options + '&&remove',
            success: function (response) {
                $("#pay-option-response").html(response).fadeIn("fast");
            }
        });
    } else {
        $('#selected-options').html('');
        $('#pay-options').val('');
        $('#tendered').val('');
        tendered();

    }
}

//--------------------------------------------------------------------------------------
function splitCustomerInfo(elem) {
    var result = elem.value;
    var spl = result.split(' -> ');
    var id = spl[0];
    var name = spl[1];

    if (name != undefined) {
        $('#customer_id').val(id);
        $('#customer_name').val(name);
    }
}

//--------------------------------------------------------------------------------------
function tendered() {
    var bal = $('#Total').val() - $('#tendered').val();
    var format_bal = CommaFormatted(bal.toFixed(2));
    $('#balance_due').val(format_bal);
    $('#balance').val(bal);
}

//--------------------------------------------------------------------------------------
function calculateBalance() {
    var cash_tendered = $('#tendered').val();
    var total_due = $('#Total').val();
    if (cash_tendered != " " || cash_tendered != 0) {
        var balance = total_due - cash_tendered;
        var formatted = CommaFormatted(balance.toFixed(2));
    } else {
        var balance = total_due;
        var formatted = CommaFormatted(balance.toFixed(2));
    }
    $('#balance_due').val(formatted);
    $('#balance').val(balance);
}

//--------------------------------------------------------------------------------------


//--------------------------------------------------------------------------------------
//--------------------------------------------------------------------------------------
//--------------------------------------------------------------------------------------


//calculate balance


//##### Number formatting function #######//
function CommaFormatted(amount) {
    "use strict";
    var delimiter = ","; // replace comma if desired
    var a = amount.split('.', 2);
    var d = a[1];
    var i = parseInt(a[0]);
    if (isNaN(i)) {
        return '';
    }
    var minus = '';
    if (i < 0) {
        minus = '-';
    }
    i = Math.abs(i);
    var n = new String(i);
    var a = [];
    while (n.length > 3) {
        var nn = n.substr(n.length - 3);
        a.unshift(nn);
        n = n.substr(0, n.length - 3);
    }
    if (n.length > 0) {
        a.unshift(n);
    }
    n = a.join(delimiter);
    if (d.length < 1) {
        amount = n;
    } else {
        amount = n + '.' + d;
    }
    amount = minus + amount;
    return amount;
}

//delete cart item

//verifiy cart submission
$('.pay-order-btn').on('click', function () {
    // $('.submit-cart').submit();
});


//printing div content
function printDiv(divName) {
    var printContents = document.getElementById(divName).innerHTML;
    var originalContents = document.body.innerHTML;
    document.body.innerHTML = printContents;
    window.print();
    document.body.innerHTML = originalContents;
    location.reload();
}

//switch customer search
function switchCustomer(customer) {
    if (customer == 'Guest') {
        $('#customer_name').removeClass('customer-lookup');
        $('#customer_name').addClass('booking-lookup');
    } else if (customer == '') {

    } else {
        $('#customer_name').removeClass('booking-lookup');
        $('#customer_name').addClass('customer-lookup');
    }
}
