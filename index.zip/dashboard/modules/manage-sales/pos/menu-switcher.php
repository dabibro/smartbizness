<?php
if (isset($printRequest) && @$printRequest != "") {
    $transact_id = $printRef;
    $info = $biz->biz;
    $tmp = $info['receipt_temp'];
    $transact = $module->getRecord([
        "tbl_scheme" => 'app_transactions',
        "condition" => [
            "transact_id" => $transact_id
        ]
    ])['dataArray'][0];
    if ($transact == NULL):
        echo '<script>location.replace("#/"); location.reload();</script>';
    else:
        @$payment = $module->getRecord([
            "tbl_scheme" => 'app_payments',
            "condition" => [
                "payment_reference" => $transact_id
            ]
        ])['dataArray'][0];
        $tmpl_file = "tmpl/" . $tmp . ".php";
        require($tmpl_file);
    endif;
} else if (isset($savedOrders) && $savedOrders != "") {
    require_once('inc/saved-orders.php');
} else if (isset($dailySales)) {
    require_once('inc/sales-receipts.php');
} else if (isset($_GET['reversals'])) {
    require_once('inc/reversals.php');
} else if (isset($_GET['deposits'])) {
    require_once('inc/deposits.php');
} else {
    require_once('inc/shopping-cart.php');
}

?>