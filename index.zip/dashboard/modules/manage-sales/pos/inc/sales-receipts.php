<div class="card card-light">
    <div class="card-header p-2">
        <span class="mb-0"><i class="fal fa-chart-pie"></i> Daily Sales History</span>
    </div>
    <div class="card-body p-2">
        <div id="ModuleResponse"></div>
        <div id="transReport" class="table-responsive">
            <table class="table table-striped table-sm dataTables data-tables">
                <thead>
                <tr>
                    <th>Reference #</th>
                    <th>Customer</th>
                    <th>Amount <?php echo $biz->currency['currency']; ?></th>
                    <th>Transact By</th>
                    <th></th>
                </tr>
                </thead>
                <tbody class="card-body">
                <?php $index = 0;
                $grand_total = 0;
                $store = "";
                if (isset($auth['store_id']) && $auth['store_id'] != ""):
                    $store = "store_id = '" . $auth['store_id'] . "' AND ";
                endif;
                @$dailySalesSQL = "SELECT transact_id, customer_type, total_due, transact_by, transact_date  
                                  FROM app_transactions 
                                  WHERE " . $store . " checkout_status = 1 AND DATE(transact_date) = CURRENT_DATE ORDER BY transact_date DESC";
                @$dailySalesQuery = Data_Access::execSQL($dailySalesSQL);
                @$dailySales = Data_Access::fetchAssoc($dailySalesQuery['dataArray'])['dataArray'];
                if (@$dailySales != NULL):
                    foreach ($dailySales as $sales): $index++;
                        $grand_total = $grand_total + $sales['total_due']; ?>
                        <tr>
                            <td><?php echo $sales['transact_id'] ?></td>
                            <td><?php echo $sales['customer_type'] ?></td>
                            <td><?php echo number_format($sales['total_due'], 2); ?></td>
                            <td><?php echo $sales['transact_by']; ?></td>
                            <td>
                                <div class="btn-group-justify btn-group-sm float-right">
                                    <?php if ($sales['total_due'] > 0): ?>
                                        <button type="button" class="btn btn-default" title="Return Invoice"
                                                onclick='javascript: var obj = "<?php echo urlencode('"pk":"' . $sales['transact_id'] . '","view":"/#/sales-point/pos/","request":"update","return":"1"'); ?>"; moduleEditRequest(obj)'>
                                            <i class="fal fa-box-up"></i></button>
                                    <?php endif; ?>
                                    <button type="button" class="btn btn-default" title="View Receipt"
                                            onClick="javascript:location.replace('#/sales-point/pos/print/<?php echo $sales['transact_id']; ?>/'); fetchURL('');">
                                        <i class="fal fa-receipt"></i></button>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; endif; ?>
                </tbody>
                <tfoot>
                <th colspan="2" style="text-align: right">TOTAL SALES <?php echo $biz->currency['currency']; ?></th>
                <th colspan="3">
                    <?php echo number_format($grand_total, 2); ?>
                </th>
                </tfoot>
            </table>
        </div>
    </div>
</div>