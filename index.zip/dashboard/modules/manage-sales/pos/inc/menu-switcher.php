<?php
/**
 * Created by PhpStorm.
 * User: DBlasterMaster
 * Date: 9/19/2019
 * Time: 8:55 PM
 */

//receipt printing information
if (isset($_GET['receipt']) && $_GET['receipt'] != "") {

    ####get transaction information
    $transact_id = $_GET['receipt'];
    $dn = getSales($transact_id);
    $clerk = getUser($dn['entry_by']);
    $customer = getCustomer($dn['customer_id']);
    $get_date = dbFetchAssoc(dbQuery("SELECT DATE(entry_date) as entry_date FROM app_menu_sales WHERE id = '" . $dn['id'] . "' "));
}
if (isset($_GET['receipt'])) {
    $temp = getReceiptTemp($appinfo['receipt_temp']) . '.php';
    require_once($temp);
} else if (isset($_GET['pending-orders'])) {
    require_once('pending-orders.php');
} else if (isset($_GET['daily-sales'])) {
    require_once('sales-receipts.php');
} else if (isset($_GET['reversals'])) {
    require_once('inc/reversals.php');
} else if (isset($_GET['deposits'])) {
    require_once('inc/deposits.php');
} else {
    require_once('shopping-cart.php');
}

?>