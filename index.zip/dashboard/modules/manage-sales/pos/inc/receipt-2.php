<style>
    #rcp_head th {
        vertical-align: middle !important;
    }
</style>
<div class="row mt-3">
    <div class="col-lg-12 text-right">
        <div class="btn-group btn-group-sm receipt-bottons">
            <button onClick="printDiv('receiptPrint');"
                    class="btn btn-success btn-sm br-0 pl-3 pr-3" id="printReceipt"
                    title="Print Receipt" data-toggle="tooltip" data-placement="top"><i class="fal fa-print"></i> Print
            </button>
            <?php if (!isset($_GET['id'])) { ?>
                <a class="btn btn-primary btn-sm br-0 pl-3 pr-3" href="<?php echo POS_DIR; ?>" title="New Sales"
                   data-toggle="tooltip" data-placement="top"><i class="fal fa-plus"></i> New Sales</a>
            <?php } else { ?>
                <a class="btn btn-primary br-0 pl-3 pr-3" href="#" onclick="history.back(-1);" title="Back"
                   data-toggle="tooltip" data-placement="top"><i class="fal fa-arrow-left"></i> Back</a>
            <?php } ?>
        </div>
    </div>
</div>

<div class="panel panel-primary border scroll shadow-sm"
     <?php if (!isset($_GET['id'])) { ?>style="max-height:565px; overflow:auto"
    <?php } ?>>
    <div class="panel-body" style="background:#fff; padding:30px">
        <div id="receiptPrint" class="sales-receipt">
            <div class="row">
                <div class="col p-0" style="max-width: 25%">
                    <div class="header-logo text-center" style="min-height:96px; min-width: 96px">
                        <!--  <div class="logo_bg" style="background: url('<?php echo WEB_ROOT . $appinfo['app_logo'] ?>'); background-repeat: no-repeat; background-position: center; background-size: 100%; min-height: 68px"></div> -->
                        <?php if (@$appinfo['app_logo'] == '' || !file_exists(WEB_ROOT . $appinfo['app_logo'])) { ?>
                            <img id="shop_logo" style="z-index: -1; width:100%"
                                 src="<?php echo WEB_ROOT . 'files/app-logo.png'; ?>"/>
                        <?php } else { ?>
                            <img src="<?php echo WEB_ROOT . $appinfo['app_logo'] ?>" alt=""
                                 style="z-index: -1; max-width: 35px">
                        <?php } ?>
                    </div>
                </div>
                <div class="col px-0">
                    <div class="text-left" style="text-transform:uppercase;">
                        <h5 style="margin:0" class="s_name">
                            <?php echo $appinfo['app_shop']; ?>
                        </h5>
                    </div>
                    <div class=" text-left"> <?php echo $appinfo['shop_description']; ?></div>
                </div>
            </div>
            <div class="p-1">
                <div class="row">
                    <div class="col-3 small">
                        <?php if ($dn['customer_id'] != 0 || $dn['customer_name']) { ?>
                            <div class="col-md-12"><strong for="">Customer</strong><br>
                                <?php echo $dn['customer_name']; ?>
                            </div>
                        <?php } ?>
                    </div>

                    <div class="col-3 p-1">
                        <h6 class="text-center border pt-1 pb-2 pl-2 pr-2" id="r_title">
                            <small>CASH/CREDIT</small>
                            INVOICE
                        </h6>
                    </div>
                    <div class="col-6 p-1">
                        <div class="row">
                            <div class="col-6">
                                <div class="text-left address small ">
                                    <strong>Address</strong><br>
                                    <?php echo $appinfo['shop_address']; ?>
                                </div>
                            </div>
                            <div class="col-6 small p-1">
                                <div><strong for="">Ref #:</strong>
                                    <?php echo $dn['transact_id']; ?>
                                </div>
                                <div>
                                    <strong>Date:</strong> <br>
                                    <?php echo $dn['entry_date']; ?>
                                </div>
                            </div>
                        </div>
                        <div class="small">
                            <strong for="">Mobile No</strong>:
                            <?php echo $appinfo['shop_mobile']; ?>
                        </div>
                    </div>

                </div>
            </div>
            <div class="row r_ref">
                <div class="col-md-12 text-left">
                </div>
            </div>
            <div class="row r_ref">
                <div class="col-md-12 text-left pull-right">
                </div>
            </div>
            <div class="row r_ref">

            </div>
            <div class="row r_ref">

            </div>
            <div class="row r_ref">

            </div>
            <table width="100%" border="0" cellpadding="0" cellspacing="0" class="table table-sm mb-0">
                <thead id="rcp_head" class="text-left">
                <tr class="row">
                    <th class="col-2"><strong>QTY-M<sup>2</sup></strong></th>
                    <th align="left" class="col-4"><strong><span class="v_hide">DESCRIPTION OF GOODS</span></strong>
                    </th>
                    <th class="col-2"><strong>QTY-CTN DELIVERED</strong></th>
                    <th class="col-2 text-left"><strong>RATE</strong></th>
                    <th class="col-2"><strong>AMOUNT</strong></th>
                </tr>
                </thead>
                <tbody>
                <?php
                $index = 0;
                $total = 0;

                $items = dbQuery("SELECT id, product_id, product_qty, amount FROM app_items_transacts WHERE transact_id = '" . $dn['transact_id'] . "'");

                while ($dn2 = dbFetchAssoc($items)): $index++;

                    $produce = getItemInfo($dn2['product_id']);
                    $total = $total + ($dn2['product_qty'] * $dn2['amount']);
                    ?>
                    <tr class="row">
                        <td class="col-2">
                            <?php echo $dn2['product_qty']; ?>
                        </td>
                        <td class="col-4">
                            <?php echo $produce['item_name']; ?>
                        </td>
                        <td class="col-2"></td>

                        <td class="col-2">
                            <?php echo $dn2['amount']; ?>
                        </td>
                        <td class="col-2">
                            <?php echo number_format($dn2['amount'] * $dn2['product_qty'], 2); ?>
                        </td>
                    </tr>
                <?php endwhile; ?>
                </tbody>
            </table>
            <hr class="row mb-2 ">
            <div class="row pt-2">
                <div class="col-6  p-0 m-0">
                    <p class="p-1 mb-0 border bg-light">Additional Note</p>
                    <p class="p-1 border" style="min-height: 70px; border-top:0;"></p>
                    <p class="">GOOD SOLD/RECEIVED IN GOOD CONDITION,<br> NO REFUND OF MONEY AFTER PAYMENT </p>
                </div>
                <div class="col-6  p-0 pl-3 m-0">
                    <?php if ($dn['discount'] == 0.00 || $dn['discount'] == "") { ?>
                        <div class="row">
                            <div class="col-7 text-right px-0 ml-auto">
                                <div class=" p-1 font-weight-bold">TOTAL N</div>
                            </div>
                            <div class="col-4 text-left pl-0 mr-0">
                                <div class="border p-1"><?php echo number_format($total, 2); ?></div>
                            </div>
                        </div>

                    <?php } else { ?>
                        <!--SUBTOTAL-->
                        <div class="row">
                            <div class="col-7 text-right px-0 ml-auto">
                                <div class=" p-1 font-weight-bold">SUBTOTAL
                                    N
                                </div>
                            </div>
                            <div class="col-4 text-left pl-0 mr-0">
                                <div class="border p-1"><?php echo number_format($total, 2); ?></div>
                            </div>
                        </div>
                        <!--- DISCOUNT -->
                        <div class="row">
                            <div class="col-7 text-right px-0 ml-auto">
                                <div class=" p-1 font-weight-bold">DISCOUNT
                                    N
                                </div>
                            </div>
                            <div class="col-4 text-left pl-0 mr-0">
                                <div class="border p-1"><?php echo number_format($dn['discount'], 2); ?></div>
                            </div>
                        </div>
                        <!-- TOTAL -->
                        <div class="row">
                            <div class="col-7 text-right px-0 ml-auto">
                                <div class=" p-1 font-weight-bold">TOTAL
                                    N
                                </div>
                            </div>
                            <div class="col-4 text-left pl-0 mr-0">
                                <div class="border p-1"><?php echo number_format($dn['total_due'], 2); ?></div>
                            </div>
                        </div>
                    <?php } ?>
                    <?php if ($dn['cash_tendered'] < $dn['total_due']) { ?>
                        <!-- Deposit -->
                        <div class="row">
                            <div class="col-7 text-right px-0 ml-auto">
                                <div class=" p-1 font-weight-bold">ADVANCE
                                    N
                                </div>
                            </div>
                            <div class="col-4 text-left pl-0 mr-0">
                                <div class="border p-1"> <?php echo number_format($dn['cash_tendered'], 2); ?></div>
                            </div>
                        </div>
                        <!-- BALANCE DUE -->
                        <div class="row">
                            <div class="col-7 text-right px-0 ml-auto">
                                <div class=" p-1 font-weight-bold">DUE
                                    N
                                </div>
                            </div>
                            <div class="col-4 text-left pl-0 mr-0">
                                <div class="border p-1"> <?php echo number_format($dn['balance_due'], 2); ?></div>
                            </div>
                        </div>
                    <?php } ?>
                    <?php ?>
                    <hr class="mb-2">
                    <?php if ($dn['mix_payments'] != "") {
                        $mix = explode(', ', $dn['mix_payments']);
                        $arr_count = count($mix);
                        $exit = 0;
                        $x = 0;
                        $total_tendered = 0;
                        while ($x < $arr_count) {

                            if ($arr_count == 1) {
                                $exit = 1;
                            }
                            $getOption = explode('->', $mix[$x]);
                            @$getPayOption = getPaymentSettings(@$getOption[0]);
                            $total_tendered = $total_tendered + $getOption[1];
                            echo '<div class="row mx-0"><div class="col-7 pl-2 p-1 ml-auto">' . @$getPayOption['mode_name'] . '</div><div class="col-4  border-bottom p-1 ">' . number_format(@$getOption[1], 2) . '</div></div>';
                            $x++; ///echo $x;
                        }
                    } else { ?>
                        <div class="">
                            <strong>Payment Options:</strong>
                            <?php
                            $paymethod = getPaymentSettings($dn['pay_mode']);
                            echo $paymethod['mode_name']
                            ?>
                        </div>
                    <?php } ?>
                    <hr class="mt-2">
                    <div class="row">
                        <div class="col-6"><strong>Status:</strong>
                            <?php echo getStatus($dn['pay_status'], 'Pending', 'Cleared'); ?></div>
                        <div class="col-6"><strong for="">Cashier:</strong>
                            <?php echo $clerk['firstname'] . ' ' . $clerk['lastname']; ?></div>
                    </div>
                </div>
            </div>
            <hr>
            <div class="row">
                <div class="col-5">
                    <div class="p-1 border pb-2 pt-3 mb-0 mr-2 ml-2">
                        <div class="text-center small pt-2">
                            <strong>Customer's Signature</strong>
                        </div>
                    </div>
                </div>
                <div class="col-2"></div>
                <div class="col-5">
                    <div class="p-1 border pb-2 pt-3 mb-0 mr-2 ml-2">
                        <div class="text-center small pt-2">
                            <strong>For:</strong> <?php echo $appinfo['app_shop']; ?>
                        </div>
                    </div>
                </div>
            </div>

            <div style="text-align: center; margin: 8px 0; border-top: 0.01em solid #000;" id="r_footer">
                <p>
                    <?php echo htmlspecialchars_decode($appinfo['app_receipt_footer']); ?>
                </p>
            </div>

        </div>
    </div>
</div>


<!--
<script>
    
    function printReceipt(id) {
        var contents = $('#' + id).html();
        alert(contents);
        $('#' + id).printThis();
    }

</script> -->
