<div class="row mt-3 mb-2">
    <div class="col-lg-12 text-right">
        <div class="btn-group-justified">
            <button onClick="printReceipt('receiptPrint');"
                    class="btn btn-dark btn-sm receipt-print-btn px-3" id="printReceipt"
                    title="Print Receipt" data-toggle="tooltip" data-placement="top"><i class="fal fa-print"></i>
                Print
            </button>
            <?php if (isset($_GET['id'])) { ?>
                <a class="btn btn-dark br-0 pl-3 pr-3" href="#" onclick="history.back(-1);" title="Back"
                   data-toggle="tooltip" data-placement="top"><i class="fal fa-arrow-left fa-lg"></i> Back</a>
            <?php } ?>
        </div>
    </div>
</div>
<div class="panel panel-primary border shadow-sm"
     <?php if (!isset($_GET['id'])) { ?>style="max-height:565px; overflow:auto"
    <?php } ?>>
    <div class="panel-body position-relative" style="background:#fff; padding:30px; font-family: receipt;">
        <div id="receiptPrint" class="sales-receipt">
            <div class="text-center" style="text-transform:uppercase;">
                <h3 style="margin:0" class="s_name">
                    <?php echo $appinfo['app_shop']; ?>
                </h3>
            </div>
            <div class="text-center address">
                <?php echo $appinfo['shop_address']; ?><br>
                <label for="">CALL US:</label>
                <?php echo $appinfo['shop_mobile']; ?>
            </div>
            <h4 class="text-center" id="r_title">SALES INVOICE</h4>
            <div class="row r_ref">
                <div class="col-md-12 text-left">
                    <div><label for="">Invoice #:</label>
                        <?php echo $dn['transact_id']; ?>
                    </div>
                </div>
            </div>
            <div class="row r_ref">
                <div class="col-md-12 text-left pull-right">
                    <div><label for="">Cashier:</label>
                        <?php echo $clerk['firstname'] . ' ' . $clerk['lastname']; ?>
                    </div>
                </div>
            </div>
            <?php if ($dn['cash_tendered'] > $dn['total_due']) { ?>
                <div class="row r_ref">
                    <div class="col-md-12  <?php if ($dn['customer_name'] == "") { ?> ml-auto <?php } ?>">
                        <label>Paid:</label>
                        <?php
                        $paymethod = getPaymentSettings($dn['pay_mode']);
                        echo $paymethod['mode_name']
                        ?>
                    </div>
                </div>
            <?php } ?>
            <div class="row r_ref">
                <?php if ($dn['customer_name'] != "") { ?>
                    <div class="col-md-12"><label for="">Customer:</label>
                        <?php echo $dn['customer_name'] ?>
                    </div>
                <?php } ?>
            </div>

            <div class="row  align-content-center hide">
                <div class="col-6 m-auto position-absolute" style="max-height: 100%; left: 35%;"
                     id="watermark-container">
                    <div class="watermark text-uppercase text-muted">
                        <span><?php
                            if ($dn['cash_tendered'] == 0) {
                                echo 'UNPAID';
                            } else {
                                echo strip_tags(getStatus($dn['pay_status'], 'Unpaid', 'Paid'));
                            } ?></span>
                        <div class="small"><?php echo $get_date['entry_date']; ?></div>

                    </div>
                </div>
            </div>

            <table width="100%" border="0" cellpadding="0" cellspacing="0" class="table">
                <thead id="rcp_head">
                <td>#</td>
                <td align="left">Description</td>
                <td>Qty</td>
                <td nowrap>Amount <?php echo $currency; ?></td>
                </thead>
                <tbody>
                <?php
                $index = 0;
                $total = 0;
                $items = dbQuery("SELECT id, item_id, item_name, item_qty, amount FROM app_menu_transacts WHERE transact_id = '" . $dn['transact_id'] . "'");
                while ($dn2 = dbFetchAssoc($items)): $index++;
                    $total = $total + ($dn2['item_qty'] * $dn2['amount']);
                    ?>
                    <tr>
                        <td>
                            <?php echo $index; ?>
                        </td>
                        <td>
                            <?php echo $dn2['item_name']; ?>
                        </td>
                        <td>
                            <?php echo number_format($dn2['item_qty']); ?>
                        </td>
                        <td>
                            <?php echo number_format($dn2['amount'] * $dn2['item_qty']); ?>
                        </td>
                    </tr>
                <?php endwhile; ?>

                <?php if ($dn['discount'] == 0.00 || $dn['discount'] == "") { ?>
                    <tr class="t_row">
                        <th colspan="3" style="padding-right: 1px" class=" text-right">TOTAL
                            <?php echo $currency; ?>
                        </th>
                        <td align="left" class="">
                            <?php echo number_format($total); ?>
                        </td>
                    </tr>
                <?php } else { ?>
                    <tr class="t_row">
                        <th colspan="3" style="padding-right: 1px" class=" text-right">SUBTOTAL
                            <?php echo $currency; ?>
                        </th>
                        <td align="left" class="">
                            <?php echo number_format($total); ?>
                        </td>
                    </tr>
                    <tr>
                        <th colspan="3" style="padding-right: 1px" class=" text-right">DISCOUNT
                            <?php echo $currency; ?>
                        </th>
                        <td align="left" class="">
                            <?php echo number_format($dn['discount']); ?>
                        </td>
                    </tr>
                    <tr>
                        <th colspan="3" style="padding-right: 1px" class=" text-right">TOTAL
                            <?php echo $currency; ?>
                        </th>
                        <td align="left" class="">
                            <?php echo number_format($dn['total_due']); ?>
                        </td>
                    </tr>
                <?php } ?>
                <?php if ($dn['customer_id'] != 0 && $dn['cash_tendered'] != 0) { ?>
                    <tr>
                        <th colspan="3" style="padding-right: 1px" class=" text-right">DEPOSIT
                            <?php echo $currency; ?>
                        </th>
                        <td align="left" class="">
                            <?php echo number_format($dn['cash_tendered']); ?>
                        </td>
                    </tr>
                    <tr>
                        <th colspan="3" style="padding-right: 1px" class=" text-right">BALANCE
                            <?php echo $currency; ?>
                        </th>
                        <td align="left" class="">
                            <?php echo number_format($dn['balance_due']); ?>
                        </td>
                    </tr>

                <?php } ?>
                <?php ?>
                </tbody>
            </table>

            <div style="text-align: center; margin: 5px 0; border-top: 0.01em solid #000;" id="r_footer">
                <p>
                    <?php echo htmlspecialchars_decode($appinfo['app_receipt_footer']); ?>
                </p>
            </div>

        </div>
    </div>
</div>


<!--
<script>
    
    function printReceipt(id) {
        var contents = $('#' + id).html();
        alert(contents);
        $('#' + id).printThis();
    }

</script> -->
