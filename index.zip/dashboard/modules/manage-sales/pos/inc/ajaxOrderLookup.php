<?php

//--------------------------------------------------------------------
if (file_exists("../../../../../helpers/config/config.inc.php")):
    require "../../../../../helpers/config/config.inc.php";
endif;
require "../../../../../helpers/handlers/app_autoloader.php";
require "../../Module_Class.php";
$module = new Module_Class;
//--------------------------------------------------------------------
$appAuth = new Auth_Access;
$auth = $appAuth->AppAuthChecker();
//--------------------------------------------------------------------
if (isset($auth['store_id']) && $auth['store_id'] != ""):
    $store = "store_id = '" . trim($auth['store_id']) . "' AND ";
endif;
//--------------------------------------------------------------------
$search_term = $_GET['term'];
$sql = "SELECT app_transactions.transact_id, app_transactions.customer_type, app_transactions.customer_name ";
$sql .= "FROM " . $module->dbScheme . ".app_transactions ";
$sql .= "WHERE " . $store . " app_transactions.transact_id LIKE '%" . $search_term . "%' ";
$sql .= "OR " . $store . " app_transactions.customer_name LIKE '%" . $search_term . "%' ";
$sql .= "OR " . $store . " app_transactions.customer_id LIKE '%" . $search_term . "%' ";
$sql .= "OR " . $store . " app_transactions.transact_by LIKE '%" . $search_term . "%' ";
$sql .= "ORDER BY app_transactions.transact_date, app_transactions.customer_name DESC LIMIT 10";
$query = Data_Access::execSQL($sql);
if ($query['dataArray']->num_rows === 0):
    $data[] = 'No record found';
else:
    foreach ($query['dataArray'] as $field):
        if ($field['customer_name'] != ""):
            $customer_name = ' -> ' . $field['customer_name'];
        else:
            $customer_name = ' -> ' . $field['customer_type'];
        endif;
        $data[] = '' . $field['transact_id'] . $customer_name;
    endforeach;
endif;
echo json_encode($data);
