<div class="inventory-header mb-2">
    <div class="row">
        <div class="col-8">
            <div class="form-group pb-0 mb-0 search-bar">
                <div class="input-group input-group-sm">
                    <input type="search" name="q" class="form-control border-0" autocomplete="off"
                           onkeyup="loadItemsInventory('&q='+this.value);"
                           placeholder="Product Search Keyword">
                    <div class="input-group-append">
                        <span class="btn btn-default"><i class="fal fa-search"></i></span>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-4 pr-0">
            <div class="text-right pr-1">
                <div class="dropdown">
                    <button type="button" class="btn btn-default btn-sm dropdown-toggle" data-toggle="dropdown"
                            aria-haspopup="true" aria-expanded="false">
                        <i class="fal fa-tag"></i> <span class="d-none d-lg-inline"> By Category</span>
                    </button>

                    <div class="dropdown-menu scroll dropdown-menu-right py-0"
                         style="border-radius:0; max-height: 250px; overflow-y: auto;">
                        <?php
                        $categoryArray = $module->getRecord([
                            "tbl_scheme" => 'app_category',
                            "condition" => ['delete_status' => 0],
                            "order" => 'name ASC'
                        ])['dataArray'];
                        if ($categoryArray != NULL):
                            foreach ($categoryArray as $categories):
                                ?>
                                <a class="dropdown-item small" href="javascript:void (0)"
                                   onclick="loadItemsInventory('&category=<?php echo @$categories['id']; ?>')"><i
                                            class="fal fa-angle-double-right"></i>
                                    <?php echo @$categories['name']; ?></a>
                            <?php endforeach; endif; ?>
                        <a class="dropdown-item small" href="javascript:void(0)"
                           onclick="loadItemsInventory()"><i
                                    class="fal fa-angle-double-right"></i> View all products</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="br-0 mb-5 mb-lg-2">
    <div class="pl-0 pr-0 pr-1" id="items-list">
    </div>
</div>

<div class="hide inventory-loader-content">
    <div class="cart-loader text-center mt-5 pt-5">
        <h4 class="text-muted"><i class="fal fa-boxes-alt fa-3x"></i></h4>
        <img src="<?php echo $app->assets; ?>img/h_loader.gif" class="mt-2">
        <div>Please Wait, Loading Inventory...</div>
    </div>
</div>