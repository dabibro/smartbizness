<div class="card card-light">
    <div class="card-header p-2">
        <span class="mb-0"><i class="fal fa-layer-group"></i> Saved Orders History</span>
    </div>
    <div class="card-body p-2">
        <div id="ModuleResponse"></div>
        <div class="table-responsive">
            <table class="table table-striped dataTables nowrap table-sm data-tables">
                <thead>
                <tr>
                    <th>#</th>
                    <th>Reference #</th>
                    <th>Customer Name</th>
                    <th>Amount <?php echo $biz->currency['currency']; ?></th>
                    <th>Transact By</th>
                    <th><i class="fal fa-cog"></i></th>
                </tr>
                </thead>
                <tbody class="card-body">
                <?php
                $index = 0;
                if (isset($auth['store_id']) && $auth['store_id'] != ""):
                    @$order_list = $module->getRecord(["tbl_scheme" => 'app_transactions', "condition" => ["store_id" => $auth['store_id'], "checkout_status" => 0], "order" => 'transact_date DESC'])['dataArray'];
                else:
                    @$order_list = $module->getRecord(["tbl_scheme" => 'app_transactions', "condition" => ["checkout_status" => 0], "order" => 'transact_date DESC'])['dataArray'];
                endif;
                if ($order_list != NULL):
                    $total = 0;
                    foreach ($order_list as $orders): $index++;
                        $total = $total + $orders['total_due']; ?>
                        <tr>
                            <td><?php echo $index; ?></td>
                            <td><?php echo $orders['transact_id']; ?></td>
                            <td><?php echo $orders['customer_type']; ?></td>
                            <td><?php echo number_format($orders['total_due'], 2); ?></td>
                            <td style="line-height: 16px !important;"><?php echo $orders['transact_by']; ?>
                                <div class="small text-muted"><?php echo $orders['transact_date']; ?></div>
                            </td>
                            <td>
                                <div class="btn-group-justify btn-group-sm float-right">
                                    <button type="button" class="btn btn-default" title="View Invoice"
                                            onClick="javascript:location.replace('#/sales-point/pos/print/<?php echo $orders['transact_id']; ?>/'); fetchURL('');">
                                        <i class="fal fa-receipt"></i></button>
                                    <button type="button" class="btn btn-default" title="Checkout Order"
                                            onclick='javascript: var obj = "<?php echo urlencode('"pk":"' . $orders['transact_id'] . '","view":"/#/sales-point/pos/","request":"update"'); ?>"; moduleEditRequest(obj)'>
                                        <i class="fal fa-coins"></i></button>
                                    <button type="button" class="btn btn-default"
                                            onclick='javascript: var obj = "<?php echo urlencode('"className":"Module_Class","deleteSaveOrder":"1","tbl_scheme":"app_customers","delete_status":1,"pkField":"app_id","pk":"' . $orders['transact_id'] . '","callback":{"type":"self","redirect":""},"notification":{"message":"Are you sure to discard this saved record?","title":"Delete Warning"}'); ?>";  moduleRequest(obj);'
                                            title=" Edit Record"><i
                                                class="fal fa-trash-alt"></i>
                                    </button>
                                </div>
                            </td>

                        </tr>
                    <?php endforeach; endif; ?>
                </tbody>
                <tfoot>
                <tr>
                    <td colspan="3" align="right">TOTAL <?php echo $biz->currency['currency']; ?></td>
                    <th colspan="3"><?php echo number_format(@$total, 2); ?></th>
                </tr>
                </tfoot>
            </table>
        </div>
    </div>
</div>
