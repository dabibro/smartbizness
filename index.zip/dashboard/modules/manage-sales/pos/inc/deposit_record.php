<?php
/**
 * Created by PhpStorm.
 * User: Dauda Ibrahim
 * Date: 8/10/2020
 * Time: 8:52 PM
 */
//if()

$reference = $engine->generateAppId('', '', 6, '012345678ABCDEFGHIJKLMNOPQRSTUVWXYZ')
?>

<style>
    .ui-autocomplete {
        z-index: 9999 !important;
    }

    .alert-danger {
        font-size: 0.75rem;
    }
</style>
<script src="<?php echo $modulePath ?>js.js"></script>
<div class="bg-info p-2 small mb-3">
    <i class="fal fa-info-circle"></i> Purchase Deposit helps you to keep track of instalment payments, for
    a saved order to checkout after complete payment.
</div>
<div class="row">
    <div class="col-md-4">
        <form method="post" class="AppForm" id="deposit-form">
            <div id="ModuleResponse"></div>
            <div id="deposit-response"></div>
            <div class="form-group">
                <div class="input-group input-group-sm">
                    <input name="product_name" type="search" id="order_lookup" class="form-control order_lookup"
                           autocomplete="off" placeholder="Lookup Keyword..." form="unknown">
                    <div class="input-group-append">
                        <button class="btn btn-default pl-2" type="button"
                                onclick="javascript:fetchOrderInfo($('#order_lookup').val());"><i
                                    class="fal fa-check-circle"></i></button>
                    </div>
                </div>
                <small class="text-muted"><i class="fal fa-info-circle"></i> Lookup: Reference/Customer Name</small>
            </div>
            <div class="small mb-2" id="order-info" style="display: none">
                <div class="row">
                    <div class="col-4">
                        <label class="mb-0">Reference:</label>
                        <div id="transact-id"></div>
                    </div>
                    <div class="col-4">
                        <label class="mb-0"> Total Due <?php echo $biz->currency['currency']; ?>:</label>
                        <div id="total-due"></div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-auto">
                        <label class="mb-0">Cashier :</label>
                        <div id="cashier-name"></div>
                    </div>
                    <div class="col-auto ml-auto">
                        <label class="mb-0">Transact Date:</label>
                        <div id="transact-date"></div>
                    </div>
                </div>
            </div>
            <div id="deposit-input" style="display: none">
                <div class="row">
                    <div class="col-6">
                        <div class="form-group">
                            <label class="mb-0"><span class="required">*</span>
                                Amount <?php echo $biz->currency['currency']; ?></label>
                            <input name="amount_tendered" type="text" required="required"
                                   class="form-control  form-control-sm  num" autocomplete="off"
                                   id="issuedAmount"
                                   placeholder="Amount">
                            <div class="invalid-feedback">* Required field</div>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="form-group">
                            <label class="mb-0"><span class="required">*</span> Date</label>
                            <input name="deposit_date" type="text" required="required"
                                   class="form-control  form-control-sm  datepicker"
                                   id="issued_date" autocomplete="off"
                                   placeholder="Date">
                            <div class="invalid-feedback">* Required field</div>
                        </div>
                    </div>
                </div>
                <div class="form-group">
                    <label class="mb-0">Additional Note</label>
                    <textarea name="additional_note" class="form-control" rows="2"
                              placeholder="Additional Note"></textarea>
                </div>
                <input type="hidden" name="transact_id" id="transactId" readonly>
                <input name="submitDeposit" type="hidden" value="1">
                <hr>
                <button class="btn btn-default btn-sm px-3" id="reversal-save-btn"><i
                            class="fal fa-save"></i>
                    Save
                </button>
                <button type="button" class="btn btn-danger btn-sm px-3" data-dismiss="modal" aria-label="Close"><i
                            class="fal fa-times"></i> Close
                </button>
            </div>

        </form>
    </div>
    <div class="col-md-8 border-left">
        <div id="deposit-history">

        </div>

    </div>
</div>
<div class="hide" id="defC">
    <div class="mt-5 pt-4 text-center" style="min-height: 300px">
        <h3 class="text-muted"><i class="fal fa-search fa-2x"></i></h3>
        <label class="text-muted">Lookup transaction to display deposit history.</label>
    </div>
</div>
<script>
    $("#deposit-history").html($("#defC").html());
    $('.num').keyup(function () {
        this.value = this.value.replace(/[^0-9\.]/g, '');
    });
    var date_input = $('.datepicker'); //our date input has the name "date"
    var container = $('.bootstrap-iso form').length > 0 ? $('.bootstrap-iso form').parent() : "body";
    date_input.datepicker({format: 'yyyy-mm-dd', container: container, todayHighlight: true, autoclose: true,});
    var modulePath = $("#ModulePath").val();

    $('#order_lookup').on('keyup', function () {
        $(".order_lookup").autocomplete({
            source: modulePath + 'pos/inc/ajaxOrderLookup.php'
        });
    });

    function fetchOrderInfo(query) {
        if (query !== "") {
            $.post(modulePath + 'pos/ajaxRequest.php',
                {
                    orderInfoRequest: 1,
                    query: query
                },
                function (response) {
                    $('#deposit-response').html(response);
                });
        }
    }

    function loadDeposit(ref) {
        $("#deposit-form")[0].reset();
        $.post(modulePath + 'ajaxRequest.php', {
            loadDeposit: ref
        }, function (response) {
            $("#deposit-history").html(response);
        });
    }
</script>