<style>
    .dataTables_paginate {
        width: 100% !important;
    }
</style>
<div class="inventory-navigation dataTables_paginate border-top pt-2">
    <?php if ($pages->items_total > 0) { ?>
        <?php echo $pages->display_pages(); ?>
        <?php //echo $pages->display_items_per_page(); ?>
        <?php echo $pages->display_jump_menu(); ?>
    <?php } ?>
</div>
<div class="vh-100">
    <div class="row">
        <?php if ($recordsArray != NULL): ?>
            <?php foreach ($recordsArray as $info):
                @$product = $module->getRecord([
                    "tbl_scheme" => 'app_products',
                    "condition" => ['app_id' => $info['app_id']]
                ])['dataArray'][0];
                extract($product);
                @$product_image = $module->getRecord([
                    "tbl_scheme" => 'app_products_images',
                    "condition" => ['app_id' => $info['app_id']],
                    "limit" => 1,
                ])['dataArray'][0];
                ?>
                <div class="col-4 col-md-3 col-lg-3  pb-0 mb-2 pr-0" disabled
                     id="<?php echo $info['app_id']; ?>" title="<?php echo htmlspecialchars_decode(@$name) ?>"
                     style="cursor: pointer;" <?php if (isset($_GET['receipt']) || isset($_GET['pending-orders'])) {
                } else { ?> onClick="addToCart(this.id, 'transact_id', '<?php echo @$info['app_id'] ?>')"<?php } ?>>
                    <div class=" elevation-1 p-1 border">
                        <div class="image-holder" style="width: 100%; height: 68px;">
                            <img src="<?php if (file_exists('../../../uploads/inventory/' . @$product_image['image_file']) && @$product_image['image_file'] != "") {
                                echo $engine->uploads . 'inventory/' . @$product_image['image_file'];
                            } else {
                                echo $engine->uploads . 'no-image.jpg';
                            } ?>" alt="Product Image" style="width: 100%; height: auto; max-height: 100%;"
                                 class="img- br-0">
                        </div>
                        <div class="text-dark p-1" style="background: rgba(0, 0, 0, .1) !important;">
                            <div class="text-center" style="font-size:0.75rem">
                                <?php echo $engine->truncateContent(@$name, 15) ?>
                            </div>
                            <div class="border-top" style="overflow: auto;font-size: 11px; ">
                                <div class="float-left"><i
                                            class="fal fa-directions"></i> <?php echo (int)@$info['stock_qty'] ?>
                                </div>
                                <div class="float-right"><?php echo @$biz->currency['currency'] . ' ' . number_format(@$sale_price, 2); ?></div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <div class="col-md-8 m-auto p-5 text-center text-muted ">
                <h2><i class="fal fa-info-circle fa-2x"></i></h2>
                <h6>Oops! No record found for your search! try something else.</h6>
            </div>
        <?php endif; ?>
    </div>
</div>