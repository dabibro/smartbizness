<div id="ModuleResponse"></div>
<div class="table-responsive" style="max-height: 400px; overflow: auto">
    <table class="table table-striped dataTables nowrap table-sm data-tables">
        <thead>
        <tr>
            <th>#</th>
            <th>Reference #</th>
            <th>Amount <?php echo $biz->currency['currency']; ?></th>
            <th>Received By</th>
            <th><i class="fal fa-cog"></i></th>
        </tr>
        </thead>
        <tbody class="card-body">
        <?php
        $index = 0;
        $total_deposit = 0;
        @$order_list = $module->getRecord([
            "tbl_scheme" => 'app_sales_deposits',
            "condition" => [
                "transact_reference" => $reference
            ],
            "order" => 'received_date DESC'
        ])['dataArray'];
        if ($order_list != NULL):
            foreach ($order_list as $deposits): $index++;
                $total_deposit = $total_deposit + $deposits['amount_tendered'];
                ?>
                <tr>
                    <td><?php echo $index; ?></td>
                    <td><?php echo $deposits['reference']; ?></td>
                    <td><?php echo number_format($deposits['amount_tendered'], 2); ?></td>
                    <td style="line-height: 16px !important;"><?php echo $deposits['received_by']; ?>
                        <div class="small text-muted"><?php echo $deposits['received_date']; ?></div>
                    </td>
                    <td>
                        <div class="btn-group-justify btn-group-sm float-right">
                            <button type="button" class="btn btn-default" title="Print"
                                    onclick="preparePrint('<?php echo $deposits['reference']; ?>');">
                                <i class="fal fa-print"></i>
                            </button>
                            <button type="button" class="btn btn-default"
                                    onclick='javascript: var obj = "<?php echo urlencode('"className":"Module_Class","functionName":"deleteRecord","tbl_scheme":"app_sales_deposits","pk":{"id":"' . $deposits['id'] . '"},"callback":{"type":"actionEvent","redirect":"loadDeposit(\'' . $deposits['transact_reference'] . '\')"},"notification":{"message":"Are you sure to delete this deposit record?","title":"Delete Warning"}'); ?>";  moduleRequest(obj);'
                                    title=" Delete Record"><i class="fal fa-trash-alt"></i>
                            </button>
                        </div>
                    </td>

                </tr>
            <?php endforeach; else: ?>
            <tr>
                <td colspan="5" align="center">No data available</td>
            </tr>
        <?php endif;
        if ($order_list != NULL): ?>
        </tbody>
        <tfoot>
        <tr>
            <td colspan="2" align="right">TOTAL DEPOSITS <?php echo $biz->currency['currency']; ?></td>
            <th colspan="3"><?php echo number_format($total_deposit, 2); ?></th>
        </tr>
        </tfoot>
        <?php endif; ?>
    </table>
</div>
<div id="deposit-print-out" class="hide"></div>
<script>
    function preparePrint(ref) {
        $.post(modulePath + 'pos/ajaxRequest.php', {
            loadDepositPrint: ref
        }, function (response) {
            $("#deposit-print-out").html(response);
            printContent('DepositPrint', 'Thermal', '80mm');
        });
    }
</script>