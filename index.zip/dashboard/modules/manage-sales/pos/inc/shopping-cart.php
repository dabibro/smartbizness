<?php
//-----------------------------------------------------------------------------------------------------
if (!isset($_SESSION[@$cart])):
    $transactId = $app->generateAppId('', rand(10, 75), 8, '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ' . time());
else:
    $transactId = @$_SESSION[@$cart];
endif;

@$transQuery = $module->getRecord([
    "tbl_scheme" => 'app_transactions',
    "condition" => [
        "transact_id" => $transactId
    ]
])['dataArray'][0];
if (isset($transQuery) && @$transQuery != NULL):
    @$transInfo = $transQuery;
    @$payment = $module->getRecord([
        "tbl_scheme" => 'app_payments',
        "condition" => [
            "payment_reference" => $transactId
        ]
    ])['dataArray'][0];
endif;
?>
    <style>
        .cart-table .form-control {
            font-size: 0.75rem !important;
            height: 28px !important;
            padding: 3px 5px;
            margin-top: 3px;
            margin-bottom: 3px;
        }
    </style>

    <div id="shopping-cart">
        <form method="GET" class="submit-cart-search" novalidate>
            <div class="alert alert-danger small py-1 px-2 hide" id="cart-alert"></div>
            <div class="row">
                <div class="col-lg-8">
                    <div class="form-group mb-0">
                        <div class="input-group input-group-sm">
                            <div class="input-group-prepend">
                            <span class="btn btn-default">
                                <i class="fal fa-search m-0"></i>
                            </span>
                            </div>
                            <input type="search" class="form-control product_search" name="product"
                                   required autocomplete="off"
                                   data-title="Enter search keyword/barcode/product ID" id="product_search"
                                   placeholder="Search keyword/Barcode/Product ID">
                            <div class="input-group-append">
                                <button class="btn btn-default"><i
                                            class="fal fa-arrow-alt-from-left m-0"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="form-group">
                        <div class="input-group input-group-sm">
                            <div class="input-group-prepend">
                                <div class="btn btn-default">Invoice #:</div>
                            </div>
                            <input name="transact_id" type="" class="form-control input-sm" id="transact_id"
                                   value="<?php echo @$transactId; ?>" size="10" readonly/>
                        </div>
                    </div>
                </div>
            </div>
            <input type="hidden" name="selection" value="1"/>
        </form>
        <div class="row mt-1">
            <div class="col-12 col-md-6 col-lg-5">
                <div class="form-group mb-0">
                    <select name="customer_type" id="pos-customer" required class="form-control select2 form-control-sm"
                            form="submit-cart"
                            style="width:100%" <?php if (!isset($_SESSION[@$cart])): echo 'disabled'; endif; ?>>
                        <option value="">-- Select Customer Type --</option>
                        <?php
                        $custType = array("Walk In Customer", "On Account Customer");
                        foreach ($custType as $cust): ?>
                            <option value="<?php echo $cust ?>" <?php if (@$transInfo['customer_type'] == $cust): echo 'selected'; endif; ?> ><?php echo $cust ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>
            <div class=" col-12 col-md-6 col-lg-7">
                <div class="form-group mb-0 submit-cart-search">
                    <div class="input-group input-group-sm">
                        <div class="input-group-prepend">
                            <span class="btn btn-default"><i class="fal fa-user-circle m-0"></i></span>
                        </div>
                        <input type="search" name="customer_name" id="customer_name" form="submit-cart"
                               class="form-control" autocomplete="off"
                               placeholder="Customer Name" <?php if (!isset($_SESSION[@$cart])): echo 'disabled'; endif; ?>
                               onchange="splitCustomerInfo(this);"
                               value="<?php if (isset($_SESSION[@$cart])): echo @$transInfo['customer_name']; endif; ?>">
                        <?php if (@$access['customer_record'] == 1): ?>
                            <div class="input-group-append">
                                <button type="button" class="btn btn-dark customer-modal-loader" title="Add Customer"
                                ><i class="fal fa-plus"></i></button>
                            </div>
                        <?php endif; ?>
                    </div>
                    <div id="cust_error"></div>
                </div>
                <input type="hidden" name="customer_id" id="customer_id" form="submit-cart"
                       value="<?php if (isset($_SESSION[@$cart])): echo @$transInfo['customer_id']; endif; ?>">
                <input type="hidden" name="transact_type" value="Sales" form="submit-cart">
            </div>
        </div>
        <hr class="my-2">
        <div class="progress hide" style=" height: 8px !important;">
            <div class="progress-bar cart-progress-bar progress-bar-striped progress-bar-animated hide"
                 role="progressbar"
                 aria-valuenow="100"
                 aria-valuemin="0" aria-valuemax="100" style="width: 100%;"></div>
        </div>
        <div id="pos-response"></div>
        <div id="responses" class="ml-auto"></div>
        <div style="min-height:470px; max-height:470px; overflow:auto;">
            <table class="cart-table table data-tables table-sm table-striped table-borderless" id="pos-cart">
                <thead>
                <th width="5%">#</th>
                <th width="35%">Description</th>
                <th width="12%">Qty</th>
                <th width="20%">Price <?php echo @$biz->currency['currency']; ?></th>
                <th width="20%">Amount <?php echo @$biz->currency['currency']; ?></th>
                <th width="5%" class="text-center"><i class="fal fa-trash-alt fa-lg"></i>
                </th>
                </thead>
                <tbody>
                <?php
                if (isset($_SESSION[@$cart])):
                    @$cart_products = $module->getRecord([
                        "tbl_scheme" => 'app_sales_products',
                        "condition" => [
                            "transact_id" => $transactId,
                        ]
                    ])['dataArray'];
                endif;
                if (@$cart_products !== NULL):
                    $index = 0;
                    @$cart_total = 0;
                    foreach ($cart_products as $cart_list): $index++;
                        if (isset($_SESSION['ReturnSales'])):
                            //$cart_list['product_qty'] = -$cart_list['product_qty'];
                        endif;
                        $cart_total = $cart_total + $cart_list['product_price'] * $cart_list['product_qty'];

                        ?>
                        <tr class="data-btn">
                            <td><?php echo $index; ?></td>
                            <td><?php echo htmlspecialchars_decode($cart_list['product_name']); ?></td>
                            <td class="input-group-sm">
                                <input name="product_qty" class="form-control form-control-sm  col-auto"
                                       type="text"
                                       id="product_qty<?php echo $cart_list['id'] ?>"
                                       autocomplete="off" <?php if (isset($_SESSION['ReturnSales'])): echo 'readonly'; endif; ?>
                                       onChange="cartItemUpdate(<?php echo $cart_list['id'] ?>, 'product_qty', this.value)"
                                       value="<?php echo number_format($cart_list['product_qty']); ?>">
                            </td>
                            <td class="input-group-sm">
                                <input name="product_price" type="text"
                                       class="form-control form-control-sm num col-auto"
                                       id="product_price<?php echo $cart_list['id'] ?>"
                                       autocomplete="off" <?php if (isset($_SESSION['ReturnSales'])): echo 'readonly'; endif; ?>
                                       onChange="cartItemUpdate(<?php echo $cart_list['id'] ?>, 'product_price', this.value)"
                                       value="<?php echo number_format($cart_list['product_price'], 2); ?>">
                            </td>
                            <td class="input-group-sm">
                                <input class="form-control bg-light"
                                       value="<?php echo number_format(($cart_list['product_price'] * $cart_list['product_qty']), 2); ?>"
                                       readonly>
                            </td>
                            <td class="text-center">
                                <button type="button" onClick="deleteCartItem(<?php echo $cart_list['id'] ?>)"
                                        title="Remove" data-placement="bottom"
                                        class="px-1 pointer border-0 bg-transparent"><span
                                            class="fal fa-trash-alt fa-lg"></span></button>
                            </td>
                        </tr>
                    <?php endforeach; ?>

                <?php else: ?>
                    <tr class="bg-transparent">
                        <td colspan="6">
                            <div class="mt-5" align="center">
                                <img src="<?php echo $app->assets ?>img/startup-logo.png" class="mt-5" width="180"><br>
                                <hr class="mb-1" style="width: 30%">
                                <h6>Empty Cart!! </h6>
                            </div>
                        </td>
                    </tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
        <?php if (isset($_SESSION[@$cart]) && isset($cart_total)) { ?>
            <hr class="my-2">
            <div class="btn-group btn-group-sm p-0 m-0 hide">
                <button type="button" class="btn text-primary p-0 m-0" style="background-color:transparent"><i
                            class="fal fa-shopping-cart fa-2x"></i></button>
                <span class="btn  p-2"><span class="badge badge-secondary p-2" id="active-cart-count">
                    <?php echo @count($cart_products); ?></span>
            </span>
            </div>
            <form method="post" class="submit-cart" id="submit-cart">
                <input type="hidden" name="submitCartTransact" id="cart-value" value="1">
            </form>
            <p class=" text-info p-1 pl-0 mb-0 position-relative">
              <span class="d-block">  <i class="fal fa-info-circle"></i> Enter the information
                below on checkout</span>
                <?php if (isset($_SESSION[@$cart])): ?>
                    <button type="button" class="cart-count">
                        <i class="fal fa-shopping-cart"></i>
                        <span id="bottom-cart-count"><?php echo @count($cart_products); ?></span>
                    </button>
                <?php endif; ?>
            </p>
            <button class="btn bg-transparent pointer px-0" type="button" data-toggle="collapse"
                    data-target="#AdditionalNote"
                    aria-expanded="false" aria-controls="AdditionalNote">
                <i class="fal fa-sticky-note"></i> Additional Note <i class="fal fa-caret-down"></i>
            </button>
            <div class="collapse position-absolute" id="AdditionalNote" style="z-index: 3; min-width: 400px">
                <div class="card card-body p-2">
                    <div class="form-group">
                        <label for="" class="w-100 text-right small">[ <a href="javascript:void(0);"
                                                                          data-toggle="collapse"
                                                                          data-target="#AdditionalNote"
                                                                          aria-expanded="false"
                                                                          aria-controls="AdditionalNote">&times;
                                Close</a> ]</label>
                        <textarea name="additional_note" rows="5" form="submit-cart" placeholder="Additional Note"
                                  class="form-control form-control-sm mb-0"></textarea>
                    </div>
                </div>
            </div>
            <div class="row shopping-info">
                <div class="col-md-7 col-lg-6 mb-3">
                    <div class="form-group">
                        <label for="">Discount <?php echo $biz->currency['currency']; ?></label>
                        <div class="input-group input-group-sm">
                            <input type="text" class="form-control num border-0" autocomplete="off" name="discount"
                                   form="submit-cart" id="discount_input" placeholder="Discount Amount"
                                   onkeyup="giveDiscount(this.value, 'byVal');"
                                   value="<?php if (@$transInfo['discount'] != 0):echo @$transInfo['discount'];endif; ?>">
                            <div class="input-group-append btn-group">
                                <div class="input-group-btn">
                                    <button class="btn btn-default btn-sm px-2" data-toggle="dropdown"
                                            aria-haspopup="true" aria-expanded="false">
                                        Percentage <span class="float-right ml-2"> <i
                                                    class="fal fa-caret-down"></i></span>
                                    </button>
                                    <div class="dropdown-menu dropdown-menu-right py-0" style="min-width:200px">
                                        <?php
                                        $discount_sql = "SELECT id, title, discount FROM  app_sales_discounts ORDER BY title";
                                        $discount_query = $module->getRecord([
                                            "tbl_scheme" => 'app_discount_vat',
                                            "condition" => [
                                                "category" => 'Discount',
                                                "active_status" => 1
                                            ]
                                        ])['dataArray'];
                                        if ($discount_query != NULL):
                                            foreach ($discount_query as $discount):
                                                ?>
                                                <button type="button" class="dropdown-item small" href="#"
                                                        onClick="giveDiscount('<?php echo $discount['percent']; ?>', 'Percentage')">
                                                    <i class="fal fa-angle-double-right"></i> <?php echo $discount['name']; ?>
                                                    <span class="float-right"><?php echo '(' . $discount['percent'] . '%)'; ?></span>
                                                </button>
                                            <?php endforeach; endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="text-danger mt-2" id="discount_error"></div>
                    </div>
                    <div class="form-group mb-0">
                        Payment Options:
                        <div class="input-group input-group-sm">
                            <select name="pay_mode" id="pay-option" form="submit-cart"
                                    class="form-control form-control-sm select2">
                                <?php
                                $payment_options = $module->getRecord([
                                    "tbl_scheme" => 'app_payment_options',
                                    "condition" => [
                                        "active_status" => 1
                                    ]
                                ])['dataArray'];
                                if ($payment_options != NULL):
                                    foreach ($payment_options as $pay_option):
                                        ?>
                                        <option value="<?php echo $pay_option['name']; ?>">
                                            <?php echo $pay_option['name']; ?>
                                        </option>
                                    <?php endforeach; endif; ?>
                            </select>
                            <input type="text" class="form-control num border-0" autocomplete="off" id="cash_tendered"
                                   form="submit-cart" placeholder="Amount Tendered">

                            <div class="input-group-append">
                                <button class="btn btn-default btn-sm px-3" type="button"
                                        onclick="paymentMode($('#pay-option').val(), $('#cash_tendered').val(), $('#pay-options').val(), 'add');">
                                    <i
                                            class="fal fa-check-circle m-0"></i> Add
                                </button>
                            </div>
                        </div>
                        <div id="pay-option-response" class="text-danger mt-1 text-right small"></div>
                    </div>
                    <div class="form-group mt-1" id="selected-options">
                        <?php if (@$payment['mix_payments'] != ""):
                            $mixpay = json_decode(@htmlspecialchars_decode($payment['mix_payments']), true);
                            if ($mixpay != NULL):
                                $total_tendered = 0;
                                $select_view = "";
                                foreach ($mixpay as $sel => $val): $total_tendered = $total_tendered + $val;
                                    $select_view .= "<div class=\"row mx-0\">";
                                    $select_view .= "<div class=\"col-6 pl-2 p-1\">" . $sel . "</div>";
                                    $select_view .= "<div class=\"col-6  border-bottom p-1\">" . number_format($val, 2);
                                    $select_view .= "<span class=\"float-right\"><a href=\"javascript:void(0)\" onclick=\"paymentMode(\'" . trim($sel) . "\', \'\', $(\'#pay-options\').val(), \'remove\');\" ><i class=\"fal fa-trash-alt\"></i></a></span></div>";
                                    $select_view .= "</div>";
                                endforeach;
                                $select_view .= '<div class="row mx-0"><div class="col-6 pl-2 p-1 text-right">Amount ' . $biz->currency['currency'] . ' :</div><div class="col-6  border-bottom p-1">' . number_format(@$total_tendered, 2) . '</div></div>';
                                echo $select_view;
                            endif;

                        endif; ?>

                    </div>
                    <div class="form-group mb-0">
                        <input type="hidden" name="mix_payments" id="pay-options" form="submit-cart"
                               value="<?php if (@$payment['mix_payments'] != ""):echo @$payment['mix_payments'];endif; ?>">
                        <input type="hidden" id="tendered" name="amount_tendered" form="submit-cart"
                               value="<?php if (@$payment['amount_tendered'] != 0):echo @$payment['amount_tendered'];endif; ?>">
                    </div>
                </div>
                <div class="col-md-6 pt-3">
                    <div class="form-group mb-1">
                        <div class="input-group input-group-sm ">
                            <div class="input-group-append pr-1">
                                <div class="input-group-text bg-transparent border-0 font-weight-bold"
                                     style="width:95px;">
                                    SUBTOTAL <?php echo $biz->currency['currency']; ?>:
                                </div>
                            </div>
                            <input type="text" class="form-control border-0 bg-light" readonly
                                   value="<?php echo number_format($cart_total, 2); ?>"
                                   style="border-bottom:1px solid #003c6e !important; border-left:1px solid #003c6e !important; background: #F2F2F2 !important;">
                            <input type="hidden" id="subTotal" name="subtotal" form="submit-cart"
                                   value="<?php echo @$cart_total; ?>">
                        </div>
                    </div>
                    <div class="form-group mb-1">
                        <div class="input-group  input-group-sm">
                        <span class="input-group-append pr-1">
                            <span class="input-group-text bg-transparent border-0 font-weight-bold" style="width:95px;">TOTAL <?php echo $biz->currency['currency']; ?>
                                :</span>
                        </span>
                            <input type="text" class="form-control border-0" id="total_amount" readonly value="<?php
                            if (@$transInfo['total_due'] > 0 && ($cart_total - @$transInfo['discount']) == @$transInfo['total_due']):echo number_format(@$transInfo['total_due'], 2);
                            else:echo number_format($cart_total - @$transInfo['discount'], 2);endif; ?>"
                                   style="border-bottom:1px solid #003c6e !important; border-left:1px solid #003c6e !important; background: #F2F2F2 !important;">
                            <input type="hidden" id="Total" name="total_due" form="submit-cart"
                                   value="<?php
                                   if (@$transInfo['total_due'] > 0 && ($cart_total - @$transInfo['discount']) == @$transInfo['total_due']):echo @$transInfo['total_due'];
                                   else:echo $cart_total - @$transInfo['discount'];endif; ?>" readonly>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="input-group  input-group-sm">
                        <span class="input-group-append pr-1">
                            <span class="input-group-text bg-transparent border-0 font-weight-bold" style="width:95px;">DUE <?php echo $biz->currency['currency']; ?>
                                :</span>
                        </span>
                            <input type="text" class="form-control border-0" id="balance_due" readonly
                                   value="<?php if (@$transInfo['total_due'] > 0 && ($cart_total - @$transInfo['discount']) == @$transInfo['total_due']):echo number_format(@$transInfo['total_due'] - @$total_tendered, 2); else:echo number_format(($cart_total - @$transInfo['discount']) - @$total_tendered, 2);endif; ?>"
                                   style="border-bottom:1px solid #003c6e !important; border-left:1px solid #003c6e !important; background: #F2F2F2 !important;">
                            <input type="hidden" id="balance" name="balance_due" form="submit-cart"
                                   value="<?php if (@$transInfo['total_due'] > 0 && ($cart_total - @$transInfo['discount']) == @$transInfo['total_due']):echo @$transInfo['total_due'] - @$total_tendered; else:echo ($cart_total - @$transInfo['discount']) - @$total_tendered;endif; ?>"
                                   readonly>
                        </div>
                    </div>
                </div>
            </div>
        <?php } ?>
    </div>

    <div class="hide cart-loader-content ">
        <div class="cart-loader text-center my-5 py-5">
            <img src="<?php echo $app->assets ?>img/startup-logo.png" class="mt-5" width="160"><br>
            <img src="<?php echo $app->assets ?>img/h_loader.gif" class="mt-1">
            <h6>Please Wait, Loading Cart...</h6>
        </div>
    </div>


<?php if (isset($loadCart)): ?>
    <script src="<?php echo $modulePath ?>pos/js.js"></script>
<?php endif; ?>