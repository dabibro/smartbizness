<?php $datatable = 1; ?>
<div class="card  mt-2">
    <div class="card-header bg-light">
        <span class="card-title mb-0"><i class="fal fa-save"></i> Saved Order History</span>
    </div>
    <div class="card-body">
        <table class="table table-striped dataTables nowrap table-sm ">
            <thead>
            <tr>
                <th>#</th>
                <th>Reference #</th>
                <th>Customer Name</th>
                <th>Due Amount N</th>
                <th><i class="fal fa-cog"></i></th>
            </tr>
            </thead>
            <tbody>
            <?php
            $index = 0;
            $order_list = dbQuery($orders_sql);
            while ($orders = @dbFetchAssoc(@$order_list)): $index++;
                if ($orders['customer_id'] != 0) {
                    $customer = $orders['customer_name'];
                } else {
                    $customer = "Cash Customer";
                }
                ?>
                <tr>
                    <td><?php echo $index; ?></td>
                    <td><?php echo $orders['transact_id']; ?>
                        <div class="small text-muted"><?php echo $orders['entry_date']; ?></div>
                    </td>
                    <td><?php echo $customer; ?></td>
                    <td><?php echo number_format($orders['total_due'], 2); ?></td>
                    <td>
                        <button type="button" class="px-1 bg-transparent pointer border-0" title="View Invoice"
                                data-toggle="tooltip"
                                onClick="javascript:location.replace('?p=manage-restaurant&sales&receipt=<?php echo $orders['transact_id']; ?>');">
                            <i
                                    class="fal fa-receipt fa-lg"></i></button>
                        <button type="button" class="px-1 bg-transparent pointer border-0" title="Pay Order"
                                data-toggle="tooltip"
                                onClick="javascript:location.replace('?p=manage-restaurant&sales&edit-order=<?php echo $orders['id']; ?>');">
                            <i
                                    class="fal fa-arrow-alt-circle-right fa-lg"></i></button>
                    </td>

                </tr>
            <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</div>
