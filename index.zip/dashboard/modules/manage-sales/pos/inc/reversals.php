<div class="x_panel border  mt-2">
    <div class="x_title">
        <span class="title"><i class="fal fa-chart-line"></i> Reversals History</span>
    </div>
    <div class="x_content">
        <?php if (isset($_GET['view-reversal']) && $_GET['view-reversal'] != "") {

        } else { ?>
            <table class="table table-striped dataTable nowrap table-responsive-sm">
                <thead>
                <tr>
                    <th>#</th>
                    <th>Reference #:</th>
                    <th># Items Returned</th>
                    <!--<th>Qty</th>-->
                    <th>Issued Amount N</th>
                    <th>Date</th>
                    <!--  <th><i class="fal fa-gears"></i></th>-->
                </tr>
                </thead>
                <tbody>
                <?php
                $index = 0;
                while ($reversals = @dbFetchAssoc(@$reversals_query)): $index++;
                    extract($reversals);
                    //get total return for reference
                    $getTotalCount = dbFetchAssoc(dbQuery("SELECT COUNT(id) as rows, SUM(issued_amount) as total FROM app_returns WHERE reference = '$reference'"));
                    extract($getTotalCount);
                    $item_info = getItemInfo($product_id);
                    ?>
                    <tr>
                        <td><?php echo $index; ?></td>
                        <td><?php echo $reference; ?>
                        </td>
                        <td><?php echo $rows; //echo $item_info['item_name']; ?></td>
                        <!-- <td><?php echo $reversed_qty; ?></td> -->
                        <td><?php echo number_format($total, 2); ?></td>
                        <td><?php echo $issued_date; ?></td>
                        <!-- <td>
                        <a href="#" class="btn btn-sm p-1" title="View" data-toggle="tooltip" onClick="javascript:location.replace('?reversals&view-reversal=<?php echo $id; ?>');"><i class="fal fa-receipt fa-lg"></i></a>
               <td>-->
                    </tr>
                <?php endwhile; ?>
                </tbody>
            </table>
        <?php } ?>
    </div>
</div>
