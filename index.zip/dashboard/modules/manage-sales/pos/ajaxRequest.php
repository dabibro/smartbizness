<?php
/**
 * Created by DTMGS Limited.
 * User: Dauda Ibrahim
 * Date: 6/23/2020
 * Time: 9:40 PM
 * File: Module Classes
 */
if (file_exists("../../../../helpers/config/config.inc.php")):
    require "../../../../helpers/config/config.inc.php";
endif;
require "../../../../helpers/handlers/app_autoloader.php";
require "../Module_Class.php";
require "classes/POS.php";
$engine = new SMBEngine;
$AppResponse = new App_Response;
$appAuth = new Auth_Access;
$biz = new BIZConfig;
$auth = $appAuth->AppAuthChecker();
$pos = new POS;
$requestMethod = $_SERVER['REQUEST_METHOD'];
if (in_array($requestMethod, ["GET", "POST", "PUT", "DELETE", "OPTIONS"])):
    $requestMethodArray = array();
    $requestMethodArray = $_REQUEST;
    if (isset($requestMethodArray['notification']) && !isset($requestMethodArray['confirmed'])):
        $tmpl = "../../tmpl/notification.html";
        echo $engine->fileTempParse($tmpl, $requestMethodArray);
        exit;
    endif;
    //---------------------------------------------------------------------------
    if (isset($requestMethodArray['className']) && isset($requestMethodArray['functionName'])):
        $getCommandArray = array(
            "class" => $requestMethodArray['className'],
            "function_name" => $requestMethodArray['functionName']);
        $functionArray = [];
        foreach ($requestMethodArray as $key => $val):
            if ($key !== "className" && $key !== "functionName" && $key !== "callback" && $key !== "notification" && $key !== "confirmed")
                $functionArray += array($key => $val);
        endforeach;
        $module = new $requestMethodArray['className'];
        $execution = $module->execCommand($getCommandArray, $functionArray);
        if ($execution['response'] === "200"):
            $responseMessage = App_Response::alertResponse(@$execution['message'], 'success');
            if (@$requestMethodArray['callback']['type'] == 'actionEvent'):
                $requestMethodArray['callback'] += array("event" => '<script>' . $requestMethodArray['callback']['redirect'] . '</script>');
            endif;
            $responseArray = array("success" => 1, "message" => (@$responseMessage), "dataArray" => @$execution['dataArray'], "callback" => @$requestMethodArray['callback']);
        else:
            $responseMessage = App_Response::alertResponse(@$execution['message'], 'danger');
            $responseArray = array("success" => 0, "message" => (@$responseMessage), "callback" => @$requestMethodArray['callback']);
        endif;
        echo @json_encode($responseArray);
    endif;
    //---------------------------------------------------------------------------
    if (isset($requestMethodArray['priceSelection']) && isset($requestMethodArray['selection'])):
        $selection = $requestMethodArray['selection'];
        if ($selection === ""):
            if (isset($_SESSION['PriceSelector'])):
                unset($_SESSION['PriceSelector']);
            endif;
        else:
            if (isset($_SESSION['PriceSelector'])):
                unset($_SESSION['PriceSelector']);
                $_SESSION['PriceSelector'] = $selection;
            else:
                $_SESSION['PriceSelector'] = $selection;
            endif;
        endif;
        echo '<script>location.reload();</script>';
    endif;
    //---------------------------------------------------------------------------
    if (isset($requestMethodArray['loadInventory']) && $requestMethodArray['loadInventory'] === '1'):
        require 'classes/POSPagination.php';
        $module = new Module_Class;
        $store = "";
        if (isset($auth['store_id']) && $auth['store_id'] != ""):
            $store = "app_inventory.store_id = '" . $auth['store_id'] . "' AND ";
        endif;
        //---------------------------------------------------------------
        $condition = $store . "app_inventory.app_id = app_products.app_id 
                      AND app_inventory.active_status = 1 
                      AND app_inventory.sales_point = 1";
        $default = ltrim($condition, 'AND ');
        //---------------------------------------------------------------
        if (isset($requestMethodArray['query'])):
            $paginate_exp = explode('?page=', @$requestMethodArray['query']);
            if (isset($paginate_exp[1]) && $paginate_exp[1] != ""):
                $ipp_exp = explode('&ipp=', $paginate_exp[1]);
                if (isset($ipp_exp[0]) && $ipp_exp[0] != ""):
                    define('page', $ipp_exp[0]);
                else:
                endif;
                if (isset($ipp_exp[1]) && $ipp_exp[1] != ""):
                    define('ipp', $ipp_exp[1]);
                else:
                endif;
            else:

            endif;
            //------------------------------------------------------------------------
            $search = explode('&q=', $requestMethodArray['query']);
            if (isset($search[1])):
                $q = $search[1];
                define('page', '');
                define('ipp', '');
            endif;
            //------------------------------------------------------------------------
            $category = explode('&category=', $requestMethodArray['query']);
            if (isset($category[1])):
                $category_id = $category[1];
                define('page', '');
                define('ipp', '');
            endif;
        else:
            define('page', '');
            define('ipp', '');
        endif;
        //---------------------------------------------------------------
        if (isset($category_id) && $category_id != 0):
            $condition = $default . " AND app_products.category_id = '$category_id'";
        elseif (isset($q) && $q != ""):
            $search_term = $q;
            $condition = $default . " AND app_inventory.app_id LIKE '%" . $search_term . "%'
            OR " . $default . " AND app_products.sku_barcode LIKE '%" . $search_term . "%'
            OR " . $default . " AND app_products.batch_sku_barcode LIKE '%" . $search_term . "%'
            OR " . $default . " AND app_products.name LIKE '%" . $search_term . "%'
            OR " . $default . " AND app_products.description LIKE '%" . $search_term . "%'
            OR " . $default . " AND app_products.sale_price LIKE '%" . $search_term . "%'";
        endif;
        //---------------------------------------------------------------
        @$pages = new posPagination;
        @$pages->default_ipp = 20;
        $sql_forms = "SELECT app_inventory.app_id FROM app_inventory, app_products WHERE " . $condition . " ";
        @$sql_forms_query = Data_Access::execSQL($sql_forms);
        @$pages->items_total = $sql_forms_query['dataArray']->num_rows;
        @$pages->mid_range = 5;
        @$pages->paginate();
        $sql = "SELECT app_products.name, app_inventory.app_id, app_inventory.stock_qty 
                FROM app_inventory, app_products 
                WHERE " . $condition . " ORDER BY app_products.name ASC " . $pages->limit . " ";
        //---------------------------------------------------------------
        if (!($results = Data_Access::execSQL($sql))):
            die(mysqli_error());
        else:
            $results_array = array();
            while ($row = $results['dataArray']->fetch_assoc()):
                $results_array[] = $row;
            endwhile;
            $recordsArray = $results_array;
        endif;
        require_once('inc/inventory-lists.php');
    endif;
    //---------------------------------------------------------------------------
    if (isset($requestMethodArray['loadCart'])):
        $loadCart = 1;
        $cart = $biz->biz['app_cart'];
        $app = $engine;
        $module = new Module_Class;
        $modulePath = $requestMethodArray['modulePath'];
        require 'inc/shopping-cart.php';
    endif;
    //---------------------------------------------------------------------------
    if (isset($requestMethodArray['addToCart']) || isset($requestMethodArray['addToCartSearch'])):
        $module = new Module_Class;
        $config = $biz->biz;
        $cart = $config['app_cart'];
        $store_id = trim($auth['store_id']);
        $sales_reps = trim($auth['firstname'] . ' ' . $auth['lastname']);
        if (isset($requestMethodArray['addToCartSearch']) && $requestMethodArray['addToCartSearch'] != ""):
            $searchParam = $requestMethodArray['productId'];
            //----------------------------------------------------------------------------------------------------------
            $getProductId = explode(' -> ', $searchParam);
            if (!@$getProductId[1]):
                $productId = $module->getRecord([
                    "tbl_scheme" => 'app_products',
                    "condition" => ['app_id'],
                    "limit" => 1
                ]);
                if (@$productId['response'] === '200' && @$productId['dataArray']['dataArray'][0]['app_id'] != ""):
                    $product_id = $productId['dataArray'][0]['app_id'];
                else:
                    $batchSQL = "SELECT app_id, batch_sku_barcode FROM app_products WHERE batch_sku_barcode LIKE '%" . $getProductId[0] . "%' ";
                    $batchQuery = Data_Access::execSQL($batchSQL)['dataArray'];
                    $batchArray = array();
                    while ($batch = $batchQuery->fetch_assoc()):
                        $batchArray[] = $batch;
                    endwhile;
                    foreach (explode(',', @$batchArray[0]['batch_sku_barcode']) as $batch_id):
                        if (strtolower($getProductId[0]) == trim(strtolower($batch_id))):
                            $product_id = $batchArray[0]['app_id'];
                        endif;
                    endforeach;
                endif;
            else:
                $product_id = $getProductId[0];
            endif;
            //----------------------------------------------------------------------------------------------------------
            $getQty = @array_pad(explode('=', $searchParam), 2, null);
            if (isset($getQty[1])):
                $product_qty = $getQty[1];
            else:
                $product_qty = 1;
            endif;
            //----------------------------------------------------------------------------------------------------------
            $transactId = $requestMethodArray['transactId'];
        else:
            $transactId = $requestMethodArray['transactId'];
            $product_id = $requestMethodArray['productId'];
            $product_qty = 1;
        endif;

        $verify = $module->getRecord([
            "tbl_scheme" => 'app_inventory',
            "condition" => ['app_id' => @$product_id]
        ]);
        if ($verify['response'] !== '200'):
            echo "<script>$('#product_search').val(''); $('#product_search').focus();</script>";
            echo App_Response::alertResponse('Invalid product selection!!', 'danger');
        else:

            $product_query = $module->getRecord([
                "tbl_scheme" => 'app_products',
                "condition" => ['app_id' => $product_id],
                "limit" => 1
            ])['dataArray'][0];

            if (isset($_SESSION['PriceSelector'])):
                $price_select = $_SESSION['PriceSelector'];
                $price = $product_query[$price_select];
            else:
                $price_select = 'sale_price';
                $price = $pos->PromoPriceCheck([
                    "app_id" => $product_id,
                    "quantity" => $product_qty,
                    "price" => $product_query[$price_select]
                ]);
            endif;

            if (isset($_SESSION[$cart])):
                @$cart_products = $module->getRecord([
                    "tbl_scheme" => 'app_sales_products',
                    "condition" => [
                        "transact_id" => $transactId,
                        "product_id" => $product_id,
                        "checkout_status" => 0
                    ]
                ])['dataArray'];

                if (@count($cart_products) > 0):
                    $price = $pos->PromoPriceCheck([
                        "app_id" => $product_id,
                        "quantity" => $product_qty + $cart_products[0]['product_qty'],
                        "price" => $product_query[$price_select]
                    ]);
                    $submit = $module->updateRecord([
                        "tbl_scheme" => 'app_sales_products',
                        "pkField" => 'id',
                        "pk" => $cart_products[0]['id'],
                        "product_price" => $price,
                        "product_qty" => $product_qty + $cart_products[0]['product_qty']
                    ]);
                else:
                    $submit = $module->createRecord([
                        "tbl_scheme" => 'app_sales_products',
                        "transact_id" => $transactId,
                        "product_id" => $product_id,
                        "product_name" => htmlspecialchars_decode($product_query['name']),
                        "product_qty" => $product_qty,
                        "product_price" => $price,
                        "store_id" => $store_id,
                        "created_by" => $sales_reps
                    ]);
                endif;
                if ($submit['response'] === "200"):
                    echo '<script>loadCart();</script>';
                endif;
            else:
                $create = $module->createRecord([
                    "tbl_scheme" => 'app_sales_products',
                    "transact_id" => $transactId,
                    "product_id" => $product_id,
                    "product_name" => htmlspecialchars_decode($product_query['name']),
                    "product_qty" => $product_qty,
                    "product_price" => $price,
                    "store_id" => $store_id,
                    "created_by" => $sales_reps
                ]);
                if ($create['response'] === "200"):
                    if (isset($_SESSION[$cart])):
                        echo '<script>loadCart();</script>';
                    else:
                        $_SESSION[$cart] = $transactId;
                        echo '<script>location.reload();</script>';
                    endif;
                endif;
            endif;
        endif;
    endif;
    //---------------------------------------------------------------------------
    if (isset($requestMethodArray['cartItemUpdate'])):
        $module = new Module_Class;
        $id = $requestMethodArray['cartItemUpdate'];
        $field = $requestMethodArray['field'];
        $value = $requestMethodArray['value'];
        if ($field === 'product_qty'):
            @$cart_products = $module->getRecord([
                "tbl_scheme" => 'app_sales_products',
                "condition" => [
                    "id" => $id,
                ]
            ])['dataArray'];
            $product_query = $module->getRecord([
                "tbl_scheme" => 'app_products',
                "condition" => ['app_id' => $cart_products[0]['product_id']],
                "limit" => 1
            ])['dataArray'][0];

            if (isset($_SESSION['PriceSelector'])):
                $price_select = $_SESSION['PriceSelector'];
                $price = $product_query[$price_select];
            else:
                $price_select = 'sale_price';
                $price = $pos->PromoPriceCheck([
                    "app_id" => $product_query['app_id'],
                    "quantity" => $value,
                    "price" => $product_query[$price_select]
                ]);
            endif;
            $updateCartItem = $module->updateRecord([
                "tbl_scheme" => 'app_sales_products',
                "pkField" => 'id',
                "pk" => $id,
                "product_qty" => $value,
                "product_price" => $price
            ]);
        else:
            $updateCartItem = $module->updateRecord([
                "tbl_scheme" => 'app_sales_products',
                "pkField" => 'id',
                "pk" => $id,
                $field => $value
            ]);
        endif;

        if ($updateCartItem['response'] === '200'):
            echo '<script>loadCart();</script>';
        endif;
    endif;
    //---------------------------------------------------------------------------
    if (isset($requestMethodArray['deleteCartItem'])):
        $module = new Module_Class;
        $id = $requestMethodArray['deleteCartItem'];
        $deleteRecord = $module->deleteRecord([
            "tbl_scheme" => 'app_sales_products',
            "pk" => ['id' => $id]
        ]);
        if ($deleteRecord['response'] === '200'):
            echo '<script>loadCart();</script>';
        endif;
    endif;
    //---------------------------------------------------------------------------
    if (isset($requestMethodArray['PaymentOption'])):
        $option = $requestMethodArray['PaymentOption'];
        $amount = $requestMethodArray['Amount'];
        $selection = $requestMethodArray['Selection'];
        $action = $requestMethodArray['Action'];
        if ($selection === ""):
            $selected = array();
        else:
            $selected = json_decode($selection, true);
        endif;
        $select_view = "";
        if ($action === 'add'):
            $selected += array($option => $amount);
        else:
            $new_selected = array();
            foreach ($selected as $sel => $val):
                if ($sel != $option) $new_selected += array($sel => $val);
            endforeach;
            $selected = ($new_selected);
        endif;
        $total = 0;
        foreach ($selected as $sel => $val): $total = $total + $val;
            $select_view .= "<div class=\"row mx-0\">";
            $select_view .= "<div class=\"col-6 pl-2 p-1\">" . $sel . "</div>";
            $select_view .= "<div class=\"col-6  border-bottom p-1\">" . number_format($val, 2);
            $select_view .= "<span class=\"float-right\"><a href=\"javascript:void(0)\" onclick=\"paymentMode(\'" . trim($sel) . "\', \'\', $(\'#pay-options\').val(), \'remove\');\" ><i class=\"fal fa-trash-alt\"></i></a></span></div>";
            $select_view .= "</div>";
        endforeach;
        if ($selected != NULL):
            $selected_options = json_encode($selected);
            $select_view .= '<div class="row mx-0"><div class="col-6 pl-2 p-1 text-right">Amount ' . $biz->currency['currency'] . ' :</div><div class="col-6  border-bottom p-1">' . number_format(@$total, 2) . '</div></div>';
        else:
            $selected_options = "";
        endif;
        echo "<script>$('#selected-options').html('" . $select_view . "');</script>";
        echo '<script>$("#pay-options").val(\'' . $selected_options . '\');</script>';
        echo '<script>$("#tendered").val("' . $total . '"); tendered();</script>';
        echo '<script>$("#cash_tendered").val("");</script>';

    endif;
    //---------------------------------------------------------------------------
    if (isset($requestMethodArray['submitCartTransact'])):
        $module = new Module_Class;
        @$transactId = $_SESSION[$biz->biz['app_cart']];
        $cart_error = 0;
        $cart_items = 0;
        $updateTransact = 0;
        if (isset($transactId) && $transactId != ""):
            $requestMethodArray += array("transact_by" => trim($auth['firstname'] . ' ' . $auth['lastname']));
            $requestMethodArray += array("store_id" => trim($auth['store_id']));
            extract($requestMethodArray);
            if ($submitCartTransact === '2'):
                $transact_type = 'Return';
                $submitCartTransact = '1';
            endif;
            if (isset($_SESSION['ReturnSales']) && $_SESSION['ReturnSales'] != ""):
                $cart_items = 1;
            endif;
            @$cartItems = $module->getRecord([
                "tbl_scheme" => 'app_sales_products',
                "condition" => [
                    'transact_id' => $transactId,
                    'checkout_status' => $cart_items
                ]
            ])['dataArray'];

            if (@$cartItems == NULL):
                echo App_Response::alertResponse('You have no products added to the cart!', 'danger');
                exit;
            elseif ($customer_type === ""):
                echo App_Response::alertResponse('Select customer type, and try again!', 'danger');
                exit;
            elseif ($customer_type !== "Walk In Customer" && $customer_name === ""):
                echo App_Response::alertResponse('Invalid on account customer selection!', 'danger');
                exit;
            elseif ($customer_type !== "Walk In Customer" && @$module->getRecord(['tbl_scheme' => 'app_customers', "condition" => ['app_id' => $customer_id], 'active_status' => 1, 'delete_status' => 0])['dataArray'][0] == NULL):
                echo App_Response::alertResponse('Invalid on account customer selection!', 'danger');
            else:
                if ($submitCartTransact === '1'):
                    foreach ($cartItems as $cart_product):
                        @$check = $module->getRecord([
                            "tbl_scheme" => 'app_inventory',
                            "condition" => [
                                "app_id" => $cart_product['product_id'],
                                "store_id" => $auth['store_id']
                            ]
                        ])['dataArray'][0];
                        @$check_product = $module->getRecord([
                            "tbl_scheme" => 'app_products',
                            "condition" => [
                                "app_id" => $cart_product['product_id']
                            ]
                        ])['dataArray'][0];
                        if ($check != NULL):
                            if ($check['stock_qty'] < $cart_product['product_qty'] && $check['back_order'] == 0):
                                echo App_Response::alertResponse("Low quantity stock level for " . $cart_product['product_name'], 'danger');
                                $cart_error = 1;
                            elseif (!isset($_SESSION['PriceSelector']) && $check_product['sale_price'] > $cart_product['product_price']):
                                echo App_Response::alertResponse("Selling " . $cart_product['product_name'] . ", below price", 'danger');
                                $cart_error = 1;
                            endif;
                        endif;
                    endforeach;
                endif;
                if ($cart_error == 0):
                    $tran_status = 0;
                    if (isset($_SESSION['ReturnSales']) && $_SESSION['ReturnSales'] != ""):
                        $tran_status = 1;
                    endif;
                    @$getTransact = $module->getRecord([
                        "tbl_scheme" => 'app_transactions',
                        "condition" => [
                            "transact_id" => $transactId,
                            "checkout_status" => $tran_status
                        ]
                    ])['dataArray'][0];
                    if ($getTransact == NULL):
                        $submit = $module->createRecord([
                            "tbl_scheme" => 'app_transactions',
                            "transact_id" => $transactId,
                            "transact_type" => $transact_type,
                            "customer_type" => $customer_type,
                            "customer_id" => $customer_id,
                            "customer_name" => $engine->verify_input($customer_name),
                            "subtotal" => $subtotal,
                            "discount" => $discount,
                            "total_due" => $total_due,
                            "additional_note" => $engine->verify_input($additional_note),
                            "checkout_status" => $submitCartTransact,
                            "store_id" => $store_id,
                            "transact_by" => $transact_by
                        ]);
                    else:
                        $submit = $module->updateRecord([
                            "tbl_scheme" => 'app_transactions',
                            "pkField" => 'id',
                            "pk" => $getTransact['id'],
                            "transact_id" => $transactId,
                            "transact_type" => $transact_type,
                            "customer_type" => $customer_type,
                            "customer_id" => $customer_id,
                            "customer_name" => $engine->verify_input($customer_name),
                            "subtotal" => $subtotal,
                            "discount" => $discount,
                            "total_due" => $total_due,
                            "additional_note" => $engine->verify_input($additional_note),
                            "checkout_status" => $submitCartTransact,
                            "transact_by" => $transact_by
                        ]);
                    endif;
                    if ($submit['response'] === '200'):
                        if ($amount_tendered == 0 && $customer_id == ""):
                            $amount_tendered = $subtotal;
                        endif;
                        @$payment = $module->getRecord([
                            "tbl_scheme" => 'app_payments',
                            "condition" => [
                                "payment_reference" => $transactId
                            ]
                        ]);
                        if ($payment['response'] != '200'):
                            if ($amount_tendered != 0):
                                $submit_payment = $module->createRecord([
                                    "tbl_scheme" => 'app_payments',
                                    "transact_id" => $engine->generateAppId('', '', 8, 'ABCDEFGHIJKL0123456789MNOPQRTSUV'),
                                    "payment_reference" => $transactId,
                                    "payment_type" => $transact_type,
                                    "customer_type" => $customer_type,
                                    "customer_id" => $customer_id,
                                    "customer_name" => $customer_name,
                                    "payment_option" => $pay_mode,
                                    "mix_payments" => $mix_payments,
                                    "amount_tendered" => $amount_tendered,
                                    "store_id" => $store_id,
                                    "received_by" => $transact_by
                                ]);
                            endif;
                            if ($submitCartTransact === '1'):
                                $updateTransact = 1;
                            endif;
                        else:
                            $submit_payment = $module->updateRecord([
                                "tbl_scheme" => 'app_payments',
                                "pkField" => 'id',
                                "pk" => $payment['dataArray'][0]['id'],
                                "transact_id" => $payment['dataArray'][0]['transact_id'],
                                "payment_reference" => $transactId,
                                "payment_type" => $transact_type,
                                "customer_type" => $customer_type,
                                "customer_id" => $customer_id,
                                "customer_name" => $customer_name,
                                "payment_option" => $pay_mode,
                                "mix_payments" => $mix_payments,
                                "amount_tendered" => $amount_tendered,
                                "received_by" => $transact_by
                            ]);
                            if ($submitCartTransact === '1'):
                                $updateTransact = 1;
                            endif;
                        endif;
                        if ($updateTransact == 1):
                            $cleared = 0;
                            foreach ($cartItems as $product): $cleared++;
                                $updateInventory = "UPDATE " . $engine->dbScheme . ".app_inventory ";
                                $updateInventory .= "SET stock_qty = stock_qty - '" . $product['product_qty'] . "' 
                                WHERE store_id = '" . $store_id . "' AND app_id = '" . $product['product_id'] . "' ";
                                $exec = Data_Access::execSQL($updateInventory);
                                if ($exec['response'] === '200'):
                                    $module->updateRecord([
                                        "tbl_scheme" => 'app_sales_products',
                                        "pkField" => 'id',
                                        "pk" => $product['id'],
                                        "checkout_status" => 1
                                    ]);
                                endif;
                            endforeach;
                            if ($cleared > 0 && $amount_tendered >= $subtotal):
                                $module->updateRecord([
                                    "tbl_scheme" => 'app_transactions',
                                    "pkField" => 'transact_id',
                                    "pk" => $transactId,
                                    "payment_status" => 1
                                ]);
                            endif;
                        endif;
                        $print_out = 1;
                    endif;
                endif;

                if (@$print_out == 1) {
                    echo '<script>location.replace("#/sales-point/pos/print/' . $transactId . '/"); location.reload();</script>';
                    unset($_SESSION[$biz->biz['app_cart']]);
                    if (isset($_SESSION['ReturnSales'])):
                        unset($_SESSION['ReturnSales']);
                    endif;
                }
            endif;
        endif;
    endif;
    //---------------------------------------------------------------------------
    if (isset($requestMethodArray['orderInfoRequest'])):
        $module = new Module_Class;
        $query = explode('->', $requestMethodArray['query']);
        $transactId = @$query[0];
        @$getTransaction = $module->getRecord([
            "tbl_scheme" => 'app_transactions',
            "condition" => ['transact_id' => $transactId, "checkout_status" => 0]
        ]);
        if ($getTransaction['response'] !== '200'):
            echo App_Response::alertResponse('Invalid transactions selection', 'danger');
            echo '<script>$("#deposit-input").hide();</script>';
            echo '<script>$("#order-info").hide();</script>';
            echo '<script>$("#deposit-form")[0].reset();</script>';
            echo '<script>$("#transactId").val("")</script>';
            echo '<script>$("#deposit-history").html($("#defC").html());</script>';
        else:
            echo '<script>$("#order_lookup").val("");</script>';
            echo '<script>$("#order-info").show();</script>';
            echo '<script>$("#deposit-input").show();</script>';
            @$transaction = $getTransaction['dataArray'][0];
            //@$deposit_query = Data_Access::execSQL("SELECT * FROM app_sales_deposits ");
            @$deposits = $module->getRecord([
                "tbl_scheme" => 'app_inventory',
                "condition" => ['app_id' => $app_id]
            ])['dataArray'][0]['stock_qty'];
            echo '<script>$("#transact-id").html("' . $transaction['transact_id'] . '")</script>';
            echo '<script>$("#transactId").val("' . $transaction['transact_id'] . '")</script>';
            echo '<script>$("#total-due").html("' . number_format($transaction['total_due'], 2) . '")</script>';
            //echo '<script>$("#stock_qty").val("' . @$qty . '")</script>';
            echo '<script>$("#cashier-name").html("' . $transaction['transact_by'] . '")</script>';
            echo '<script>$("#transact-date").html("' . $transaction['transact_date'] . '")</script>';
            echo '<script>loadDeposit("' . $transaction['transact_id'] . '")</script>';
        endif;

    endif;
    //---------------------------------------------------------------------------
    if (isset($requestMethodArray['loadDepositPrint'])):
        $module = new Module_Class;
        $biz = new BIZConfig;
        $reference = $requestMethodArray['loadDepositPrint'];
        require 'tmpl/deposit.php';
    endif;
    //---------------------------------------------------------------------------

    //---------------------------------------------------------------------------
    if (isset($requestMethodArray['SubmitOrderItem'])):
        $module = new Module_Class;
        $request = $requestMethodArray['SubmitOrderItem'];
        $reference = $requestMethodArray['reference'];
        $item_appid = $requestMethodArray['item_appid'];
        $check = $module->getRecord([
            "tbl_scheme" => 'app_purchase_orders_item',
            "condition" => ["reference" => $reference, "item_appid" => $item_appid]
        ]);
        if (@$check['response'] === '200' && @$check['dataArray'] != NULL && $request == 1):
            echo App_Response::alertResponse('Item already exist, verify!', 'danger');
        else:
            $fieldsArray = ["tbl_scheme" => 'app_purchase_orders_item'];
            foreach ($requestMethodArray as $key => $val):
                if ($key !== "SubmitOrderItem" && $key !== "editPk")
                    $fieldsArray += array($key => $val);
            endforeach;
            if ($request == 1):
                $recordSubmit = $module->createRecord($fieldsArray);
            else:
                $pk = $requestMethodArray['editPk'];
                $fieldsArray += array("pkField" => 'id', "pk" => $pk);
                $recordSubmit = $module->updateRecord($fieldsArray);
            endif;
            if (@$recordSubmit['response'] === '200'):
                echo App_Response::alertResponse('Item entry submitted successfully', 'success');
                echo '<script>$("#item-entry-form")[0].reset();</script>';
                echo '<script>loadEntryRows();</script>';
                echo '<script>$("#inventory-lookup").focus();</script>';
            endif;
        endif;
    endif;
    //---------------------------------------------------------------------------
    if (isset($requestMethodArray['fetchEntryRows'])):
        $reference = $requestMethodArray['reference'];
        $module = new Module_Class;
        require "inc/order_item_tbl_rows.php";
    endif;
    //---------------------------------------------------------------------------
    if (isset($requestMethodArray['delEntryRows'])):
        $module = new Module_Class;
        $row_id = $requestMethodArray['delEntryRows'];
        $deleteRecord = $module->deleteRecord([
            "tbl_scheme" => 'app_purchase_orders_item',
            "pk" => ['id' => $row_id]
        ]);
        if (@$deleteRecord['response'] === '200'):
            if (@$requestMethodArray['callback']['type'] == 'actionEvent'):
                $requestMethodArray['callback'] += array("event" => '<script>' . $requestMethodArray['callback']['redirect'] . '</script>');
            endif;
            $deleteImage['message'] = "Image successfully deleted!";
            $responseMessage = App_Response::alertResponse(@$deleteImage['message'], 'success');
            $responseArray = array("success" => 1, "message" => (@$responseMessage), "callback" => @$requestMethodArray['callback']);
        else:
            $deleteImage['message'] = "Couldn't delete image!";
            $responseMessage = App_Response::alertResponse(@$deleteImage['message'], 'danger');
            $responseArray = array("success" => 0, "message" => (@$responseMessage));
        endif;
        echo @json_encode($responseArray);
    endif;
    //---------------------------------------------------------------------------
    if (isset($requestMethodArray['fetchInvItemEdit'])):
        $module = new Module_Class;
        $id = $requestMethodArray['row_id'];
        @$getEntry = $module->getRecord([
            "tbl_scheme" => 'app_purchase_orders_item',
            "condition" => ['id' => $id]
        ]);
        if ($getEntry['response'] !== '200'):
            echo App_Response::alertResponse('Invalid item selection', 'danger');
        else:
            $entry = $getEntry['dataArray'][0];
            echo '<script>$("#item-appid").val("' . $entry['item_appid'] . '")</script>';
            echo '<script>$("#inventory-lookup").val("' . $entry['item_description'] . '")</script>';
            echo '<script>$("#order_qty").val("' . $entry['order_qty'] . '")</script>';
            echo '<script>$("#stock_qty").val("' . $entry['stock_qty'] . '")</script>';
            echo '<script>$("#new_qty").val("' . $entry['new_qty'] . '")</script>';
            echo '<script>$("#order_price").val("' . $entry['order_price'] . '")</script>';
            echo '<script>$("#stock_price").val("' . $entry['stock_price'] . '")</script>';
            echo '<script>$("#new_price").val("' . $entry['new_price'] . '")</script>';
            echo '<script>$("#stock_sale_price").val("' . $entry['stock_sale_price'] . '")</script>';
            if ($entry['new_sale_price'] > 0):
                echo '<script>$("#new_sale_price").val("' . $entry['new_sale_price'] . '")</script>';
            endif;
            echo '<script> var pk = document.getElementById("editPk"); if(!pk){ $("#SubmitOrderItem").after(\'<input type="hidden" name="editPk" value="' . $entry['id'] . '" id="editPk">\'); }else{ $("#editPk").val("' . $entry['id'] . '") }</script>';
        endif;

    endif;
    //---------------------------------------------------------------------------
    if (isset($requestMethodArray['orderPreview'])):
        $app = $engine;
        $module = new Module_Class;
        $ref = $requestMethodArray['ref_no'];
        $getOrder = $module->getRecord([
            "tbl_scheme" => 'app_purchase_orders',
            "condition" => ['reference' => $ref],
            "limit" => 1
        ]);
        @extract($getUpdate['dataArray'][0]);
        //--------------------------------------------------
        $getItems = $module->getRecord([
            "tbl_scheme" => 'app_purchase_orders_item',
            "condition" => ['reference' => $ref]
        ]);
        //--------------------------------------------------
        //$getTempFieldParam = array(
        //    "tbl_scheme" => 'app_templates',
        //    "condition" => ['temp_id' => $temp],
        //    "limit" => 1
        //);
        //--------------------------------------------------
        //$getTemp = $module->getRecord($getTempFieldParam);
        //@extract($getTemp['dataArray'][0]);
        //$temps_path = '../../tmpl/';
        //$temp_file = $temps_path . $temp_id . '.html';
        //$tempFieldsArray = json_decode(htmlspecialchars_decode($temp_fields));
        //echo $app->fileTempParse($temp_file, @$fieldArray);
        require 'inc/order-preview.php';
    endif;
    //---------------------------------------------------------------------------
    if (isset($requestMethodArray['deleteOrderRecord'])):
        $module = new Module_Class;
        $reference = $requestMethodArray['pk']['reference'];
        $deleteItemRecord = $module->deleteRecord([
            "tbl_scheme" => 'app_purchase_orders_item',
            "pk" => ['reference' => $reference]
        ]);
        $deleteRecord = $module->deleteRecord([
            "tbl_scheme" => 'app_purchase_orders',
            "pk" => ['reference' => $reference]
        ]);
        if (@$deleteRecord['response'] === '200'):
            if (@$requestMethodArray['callback']['type'] == 'actionEvent'):
                $requestMethodArray['callback'] += array("event" => '<script>' . $requestMethodArray['callback']['redirect'] . '</script>');
            endif;
            $deleteImage['message'] = "Record successfully deleted!";
            $responseMessage = App_Response::alertResponse(@$deleteImage['message'], 'success');
            $responseArray = array("success" => 1, "message" => (@$responseMessage), "callback" => @$requestMethodArray['callback']);
        else:
            $deleteImage['message'] = "Couldn't delete image!";
            $responseMessage = App_Response::alertResponse(@$deleteImage['message'], 'danger');
            $responseArray = array("success" => 0, "message" => (@$responseMessage));
        endif;
        echo @json_encode($responseArray);
    endif;
    //---------------------------------------------------------------------------
    if (isset($requestMethodArray['orderPosting'])):
        $module = new Module_Class;
        $reference = $requestMethodArray['pk']['reference'];
        $confirm = $module->getRecord([
            "tbl_scheme" => 'app_purchase_orders',
            "condition" => [
                "reference" => $reference,
                "status" => 1,
                "approval" => 1,
                "post_status" => 0],
        ]);
        if ($confirm['response'] !== '200'):
            $responseMessage = App_Response::alertResponse('Invalid purchase order posting, verify order and try again!!', 'danger');
            $responseArray = array("success" => 0, "message" => (@$responseMessage), "callback" => @$requestMethodArray['callback']);
        else:
            $store_id = $confirm['dataArray'][0]['store_id'];
            $checkItems = $module->getRecord([
                "tbl_scheme" => 'app_purchase_orders_item',
                "condition" => [
                    'reference' => $reference,
                    'post_status' => 0],
            ]);
            if (@$checkItems['dataArray'] == NULL):
                $responseMessage = App_Response::alertResponse('No item(s) in purchase order, verify order and try again!!', 'danger');
                $responseArray = array("success" => 0, "message" => (@$responseMessage), "callback" => @$requestMethodArray['callback']);
            else:
                foreach ($checkItems['dataArray'] as $item):
                    $getInvInfo = $module->getRecord([
                        "tbl_scheme" => 'app_inventory',
                        "condition" => [
                            "app_id" => $item['item_appid'],
                            "store_id" => $store_id],
                    ])['dataArray'][0];
                    $itemRow = $getInvInfo['id'];
                    $qty = $getInvInfo['stock_qty'];
                    $updateProduct = $module->updateRecord([
                        "tbl_scheme" => 'app_products',
                        "pkField" => 'app_id',
                        "pk" => $item['item_appid'],
                        "price" => $item['new_price'],
                        "sale_price" => $item['new_sale_price']
                    ]);
                    $updateInventory = $module->updateRecord([
                        "tbl_scheme" => 'app_inventory',
                        "pkField" => 'id',
                        "pk" => $itemRow,
                        "stock_qty" => $qty + $item['order_qty'],
                    ]);
                    if ($updateInventory['response'] === '200'):
                        $updateEntry = $module->updateRecord([
                            "tbl_scheme" => 'app_purchase_orders_item',
                            "pkField" => 'id',
                            "pk" => $item['id'],
                            "post_status" => 1
                        ]);
                    endif;
                endforeach;
                $verify = $module->getRecord([
                    "tbl_scheme" => 'app_purchase_orders_item',
                    "condition" => [
                        'reference' => $reference,
                        'post_status' => 0],
                ]);
                if ($verify['response'] !== '200'):
                    $updateOrder = $module->updateRecord([
                        "tbl_scheme" => 'app_purchase_orders',
                        "pkField" => 'reference',
                        "pk" => $reference,
                        "post_status" => 1
                    ]);
                    if ($updateOrder['response'] === '200'):
                        $responseMessage = App_Response::alertResponse('Purchase order successfully posted', 'success');
                        $responseArray = array("success" => 1, "message" => (@$responseMessage), "callback" => @$requestMethodArray['callback']);
                    endif;
                endif;
            endif;
        endif;
        echo @json_encode($responseArray);
    endif;
endif;