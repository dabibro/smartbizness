<header class="mb-2 mb-sm-0 mb-md-0">
    <nav class="navbar navbar-expand-md navbar-dark  top-menu p-0 m-0 pr-2">
        <a class="navbar-brand m-0 p-1 pl-2 col-3" href="<?php echo WEB_ROOT; ?>">
            <img src="<?php echo WEB_ROOT; ?>assets/img/app-logo.png" width="96" alt="" class="m-1">
        </a>
        <button class="navbar-toggler d-lg-none collapsed ml-auto border-light br-0" type="button"
                data-toggle="collapse"
                data-target="#navbarsExampleDefault" aria-controls="navbarsExampleDefault" aria-expanded="false"
                aria-label="Toggle navigation">
            <span class="fal fa-bars"></span>
        </button>
        <div class="navbar-collapse collapse" id="navbarsExampleDefault" style="">

            <ul class="navbar-nav ml-auto shortcuts pt-1">
                <li class="nav-item">
                    <a href="<?php echo POS_DIR; ?>" data-toggle="tooltip" data-placement="left"
                       title="Make Sales" class="nav-link"><i class="fal fa-shopping-cart"></i> Sale Now</a>
                </li>

                <li class="nav-item">
                    <a class="nav-link border-0" href="?pending-orders" data-toggle="tooltip" data-placement="left"
                       title="Pending Orders"><i class="fal fa-bell fa-lg"></i> Saved Order&nbsp;<span
                                class="float-right badge-danger badge small"
                                style="position: relative; top: 3px"><?php //echo dbNumRows(dbQuery($orders_sql)); ?></span></a>
                </li>
                <!-- Daily transactions -->
                <li class="nav-item">

                </li>
                <!-- Calculator plugin -->
                <li class="nav-item dropdown" id="calculator">
                    <a class="nav-link dropdown-toggle border-0" href="#" id="navbarDropdownMenuLink"
                       data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <i class="fal fa-calculator fa-lg"></i> Calculator
                    </a>
                    <div class="dropdown-menu dropdown-menu-right  py-0" id="calculator"
                         aria-labelledby="navbarDropdownMenuLink" style="min-width: 250px;">
                        <div class="dropdown-item mt-2">
                            <?php //require_once '../plugins/calculator.php'; ?>
                        </div>
                    </div>
                </li>
                <!--App Refresh Menu-->
                <li class="nav-item">
                    <a class="nav-link" href="#" title="Refresh" data-toggle="tooltip" data-placement="right"
                       onClick="javascript:location.reload()"><i class="fal fa-sync fa-lg"></i> Sync</a>
                </li>

            </ul>
        </div>
    </nav>
</header>