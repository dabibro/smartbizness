<div class="row align-items-center my-5 py-5 mx-0">
    <div class="col m-auto text-center pt-3 px-5">
        <img src="<?php echo $app->assets . 'img/app-logo.png' ?>" alt="App Logo" class="mb-3"
             width="180"/>
        <hr class="my-3">
        <div class="row">
            <div class="col-auto pr-3">
                <img src="<?php echo $app->assets . 'icons/activation-badge.png'; ?>" width="46"/>
            </div>
            <div class="col text-left">
                <div class="h6 text-muted">Software Licenced to:</div>
                <hr class="mb-1 mt-1">
                <small class="text-muted text-uppercase"><?php echo $biz->biz['business_name']; ?></small>
            </div>
        </div>
    </div>
</div>
