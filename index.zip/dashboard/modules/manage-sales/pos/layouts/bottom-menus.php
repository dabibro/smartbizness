<nav class="mb-0 bottom-menus">
    <div class="row">
        <div class="col-7 action-btn text-center text-lg-left mb-lg-0 mb-2 pl-0">
            <div class="btn-group-justified">
                <!--New sales -->
                <?php if (isset($printRequest) || isset($savedOrders) || isset($dailySales) || isset($_GET['daily-sales'])) { ?>
                    <button class="btn btn-dark btn-sm"
                            onclick="javascript:location.replace('#/sales-point/pos/'); fetchURL('');">
                        <i class="fal fa-shopping-cart"></i> Sale Now
                    </button>
                <?php } ?>
                <?php if (!isset($_SESSION['ReturnSales'])): ?>
                    <!--Cart Order Billing-->
                    <button class="btn btn-dark btn-sm" type="submit"
                            form="submit-cart" <?php if (isset($_GET['receipt']) || isset($_GET['pending-orders']) || isset($_GET['reversals']) || isset($_GET['daily-sales']) || !isset($_SESSION[@$cart])) {
                        echo 'disabled';
                    } ?> onclick="$('#cart-value').val(1); "><i class="fal fa-check-circle"></i> Submit Order
                    </button>
                <?php endif; ?>
                <!--Submit reversal/return Order-->
                <button class="btn btn-default btn-sm" type="submit"
                        form="submit-cart" <?php if (isset($_GET['receipt']) || isset($_GET['pending-orders']) || isset($_GET['reversals']) || isset($_GET['daily-sales']) || !isset($_SESSION[@$cart])) {
                    echo 'disabled';
                } ?> onclick="$('#cart-value').val(2); "><i class="fal fa-box-up"></i> Return Order
                </button>
                <?php if (!isset($_SESSION['ReturnSales'])): ?>
                    <!--Save Cart Order-->
                    <button class="btn btn-secondary btn-sm" <?php if (isset($_GET['receipt']) || isset($_GET['pending-orders']) || isset($_GET['reversals']) || isset($_GET['daily-sales']) || !isset($_SESSION[@$cart])) {
                        echo 'disabled';
                    } ?> onClick="javascript:$('#cart-value').val(0);" form="submit-cart"><i
                                class="fal fa-save"></i> Save Order
                    </button>
                    <!--Cancel Discard Cart-->

                    <button class="btn btn-sm btn-danger float-right" <?php if (!isset($_SESSION[@$cart])):echo 'disabled';endif; ?>
                            onclick='javascript: var obj = "<?php echo urlencode('"DiscardTransact":"1","tbl_scheme":"app_users","delete_status":1,"pkField":"user_id","pk":"","callback":{"type":"self","redirect":""},"notification":{"message":"Are you sure to discard this transaction? <\/br> All selected products will be deleted!","title":"Discard Warning"}'); ?>";  moduleRequest(obj);'
                    >
                        <i class="fal fa-times-circle"></i> Discard Order
                    </button>
                <?php else: ?>
                    <button class="btn btn-sm btn-danger" <?php if (!isset($_SESSION[@$cart])):echo 'disabled';endif; ?>
                            onclick='javascript: var obj = "<?php echo urlencode('"DiscardReturn":"1","callback":{"type":"self","redirect":""},"notification":{"message":"Are you sure to cancel this return?","title":"Cancel Return"}'); ?>";  moduleRequest(obj);'
                    >
                        <i class="fal fa-times-circle"></i> Cancel Return
                    </button>
                <?php endif; ?>
            </div>
        </div>
        <div class="col-auto ml-auto action-btn text-right px-0">
            <div class="btn-group-justified">
                <button class="btn btn-default btn-sm  pr-2" type="button"
                        onclick="location.replace('#/sales-point/pos/saved-orders/'); fetchURL('');"

                        data-placement="left"
                        title="Pending Orders"><i class="fal fa-layer-group"></i> Saved Orders &nbsp;<span
                            class="float-right badge-danger badge"
                            style="position: relative; top: 3px"><?php //echo @dbNumRows(dbQuery($orders_sql)); ?></span>
                </button>
                <button class="btn btn-default btn-sm  pr-2" type="button"
                        onclick="location.replace('#/sales-point/pos/daily-sales/'); fetchURL('');"
                        data-placement="right" title="Daily Sales"><i
                            class="fal fa-chart-pie"></i> Daily Sales History
                </button>
                <span class="dropdown">
                    <button class="btn btn-default btn-sm dropdown-toggle pr-2" type="button"
                            data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                       <i class="fal fa-coins"></i> Price Selection
                    </button>
                    <div class="dropdown-menu">
                        <a class="dropdown-item" href="javascript:void (0)" onclick="priceSelector('price')"><i
                                    class="fal fa-money-bill-wave"></i> Cost Price</a>
                        <a class="dropdown-item" href="javascript:void (0)" onclick="priceSelector('')"><i
                                    class="fal fa-money-bill"></i> Sales Price</a>
                        <a class="dropdown-item" href="javascript:void (0)"
                           onclick="priceSelector('wholesale_price')"><i class="fal fa-money-check-edit"></i> Wholesale Price</a>
                    </div>
                </span>
                <span class="dropdown">
                <button class="btn btn-default btn-sm dropdown-toggle  pr-2" href="#" id="tools"
                        data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <i class="fal fa-tools"></i> <span>Tools</span>
                </button>
                <div class="dropdown-menu dropdown-menu-right py-0" aria-labelledby="tools">
                    <a class="dropdown-item" href="javascript:void(0);"
                       onclick="AppModalLoader({modalId:'ModuleModal', modalSize:'modal-lg', modalTitle:'Purchase Deposit', required:'pos/inc/deposit_record', afterEvent: 'reloadSubcategory()'});"><i
                                class="fal fa-fw fa-plus-square"></i> Purchase Deposit</a>
                    <a class="dropdown-item" href="javascript:void(0);"
                       onclick="javascript:$('#deposit-modal').modal({backdrop:'static'});"><i
                                class="fal fa-fw fa-wallet"></i> Receive Payment</a>
                </div>
                </span>

            </div>
        </div>
    </div>
</nav>