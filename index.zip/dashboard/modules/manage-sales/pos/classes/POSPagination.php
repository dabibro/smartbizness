<?php

/*

 * PHP Pagination Class

 * @author admin@catchmyfame.com - http://www.catchmyfame.com

 * @version 2.0.0

 * @date October 18, 2011

 * @copyright (c) admin@catchmyfame.com (www.catchmyfame.com)

 * @license CC Attribution-ShareAlike 3.0 Unported (CC BY-SA 3.0) - http://creativecommons.org/licenses/by-sa/3.0/

 */

class posPagination
{
    var $items_per_page;
    var $items_total;
    var $current_page;
    var $num_pages;
    var $mid_range;
    var $low;
    var $limit;
    var $return;
    var $default_ipp;
    var $querystring;
    var $ipp_array;


    public function __construct()

    {
        $this->page = page;
        $this->ipp = ipp;
        $this->current_page = 1;
        $this->mid_range = 7;
        $this->ipp_array = array(12, 25, 50, 100, 150, 200, 'All');
        $this->items_per_page = ($this->ipp === "") ? $this->ipp : $this->default_ipp;
    }


    function paginate()

    {

        if (!isset($this->default_ipp)) $this->default_ipp = 100;


        if ($this->ipp == 'All') {

            $this->num_pages = 1;

        } else {

            if (!is_numeric($this->items_per_page) OR $this->items_per_page <= 0) $this->items_per_page = $this->default_ipp;

            $this->num_pages = ceil($this->items_total / $this->items_per_page);

        }


        $this->current_page = ($this->page !== "") ? (int)$this->page : 1; // must be numeric > 0

        $prev_page = $this->current_page - 1;

        $next_page = $this->current_page + 1;

        if ($this->num_pages > 1) {

            $this->return = ($this->current_page > 1 And $this->items_total >= 10) ? "<div class='row mx-0'><div class='col-12 col-lg-6  pl-0'><ul class='pagination'><li class='page-item'><a class=\"page-link\" href=\"javascript:void(0);\" onclick=\"loadItemsInventory('?loadItemsInventory&page=$prev_page&ipp=$this->items_per_page$this->querystring');\"><i class='fal fa-angle-double-left'></i></a></li> " : "<div class='row mx-0'><div class='col-12 col-lg-6 pl-0'><ul class='pagination'><li class='page-item'><a href=\"javascript:;\" class=\"page-link disabled\" tabindex=\"-1\"><i class='fal fa-angle-double-left'></i></a></li> ";


            $this->start_range = $this->current_page - floor($this->mid_range / 2);

            $this->end_range = $this->current_page + floor($this->mid_range / 2);


            if ($this->start_range <= 0) {

                $this->end_range += abs($this->start_range) + 1;

                $this->start_range = 1;

            }


            if ($this->end_range > $this->num_pages) {

                $this->start_range -= $this->end_range - $this->num_pages;

                $this->end_range = $this->num_pages;

            }


            $this->range = range($this->start_range, $this->end_range);


            for ($i = 1; $i <= $this->num_pages; $i++) {

                //if($this->range[0] > 2 And $i == $this->range[0]) $this->return .= " ... ";

                if ($this->range[0] > 2 And $i == $this->range[0]) $this->return .= "";

                // loop through all pages. if first, last, or in range, display

                if ($i == 1 Or $i == $this->num_pages Or in_array($i, $this->range)) {

                    $this->return .= ($i == $this->current_page And ($_GET['page'] != 'All')) ? "<li class='page-item active'><a title=\"Go to page $i of $this->num_pages\" class=\"page-link\" href=\"javascript:void(0);\">$i</a></li> " : "<li class='page-item'><a class=\"page-link\" title=\"Go to page $i of $this->num_pages\" onclick=\"loadItemsInventory('?page=$i&ipp=$this->items_per_page$this->querystring');\" href=\"javascript:void(0);\">$i</a></li> ";

                }
                //if($this->range[$this->mid_range-1] < $this->num_pages-1 And $i == $this->range[$this->mid_range-1]) $this->return .= " ... ";

                if ($this->range[$this->mid_range - 1] < $this->num_pages - 1 And $i == $this->range[$this->mid_range - 1]) $this->return .= "";

            }

            $this->return .= (($this->current_page < $this->num_pages And $this->items_total >= 10) And ($_GET['page'] != 'All') And $this->current_page > 0) ? "<li class='page-item'><a class=\"page-link\"  onclick=\"loadItemsInventory('?page=$next_page&ipp=$this->items_per_page$this->querystring');
            \"  href=\"javascript:void(0);\"><i class='fal fa-angle-double-right'></i></a></li>\n" : "<li class='page-item'><a href=\"javascript:;\" class=\"page-link disabled\" href=\"javascript:;\" tabindex=\"-1\"><i class='fal fa-angle-double-right'></i></a></li>\n";

            $this->return .= ($_GET['page'] == 'All') ? "<li class='page-item active'><a class=\"page-link\" hidden href=\"javascript:;\">All</a></li> \n" : "<li class='page-item'><a class=\"page-link\" hidden onclick=\"loadItemsInventory('?page=1$i&ipp=All$this->querystring');\" href=\"javascript:void(0);\">All</a></li></ul></div> \n";

        } else {

            for ($i = 1; $i <= $this->num_pages; $i++) {

                $this->return .= ($i == $this->current_page) ? "<div class='row mx-0'><div class='col-12 col-lg-6 pl-0'><ul class='pagination'><li class='page-item active'><a class=\"page-link\" href=\"javascript:void(0);\">$i</a></li> " : "<li class='page-item'><a class=\"page-link\" href=\"javascript:void(0);\" onclick=\"loadItemsInventory('?page=$i&ipp=$this->items_per_page$this->querystring');\">$i</a></li> ";

            }

            $this->return .= "<li class='page-item'><a class=\"page-link\" href=\"javascript:void(0);\" onclick=\"loadItemsInventory('?page=1&ipp=All$this->querystring');\" >All</a></li></ul></div> \n";

        }

        $this->low = ($this->current_page <= 0) ? 0 : ($this->current_page - 1) * $this->items_per_page;

        if ($this->current_page <= 0) $this->items_per_page = 0;

        $this->limit = ($this->ipp == 'All') ? "" : " LIMIT $this->low,$this->items_per_page";

    }

    function display_items_per_page()

    {

        $items = '';

        if (($this->ipp == "")) $this->items_per_page = $this->default_ipp;

        foreach ($this->ipp_array as $ipp_opt) $items .= ($ipp_opt == $this->items_per_page) ? "<option selected value=\"$ipp_opt\">$ipp_opt</option>\n" : "<option value=\"$ipp_opt\">$ipp_opt</option> \n";

        return "<div class=' col-12 col-lg-6 pr-0'><div class='row  mx-0 text-right'> <div class='col pl-0'> <div class='input-group'> <div class='input-group-append'> <span class='input-group-text border-0'>Rows:</span> </div>  <select class='border-0 text-muted form-control' onchange=\"loadItemsInventory('?page=1&ipp='+this[this.selectedIndex].value+'$this->querystring'); return false\">$items</select>  </div> </div>\n";

    }

    function display_jump_menu()

    {

        $option = '';

        for ($i = 1; $i <= $this->num_pages; $i++) {

            $option .= ($i == $this->current_page) ? "<option value=\"$i\" selected>$i</option>\n" : "<option value=\"$i\">$i</option> \n";

        }

        return "<div class='col px-0 hide'><div class='input-group'> <div class='input-group-append'> <span class='input-group-text border-0'>Page:</span> </div> <select class='border-0 text-muted form-control' onchange=\"loadItemsInventory('?page='+this[this.selectedIndex].value+'&ipp=$this->items_per_page$this->querystring');return false\">$option</select> </div> </div><div class='col pl-0 hide'> <span class='input-group-text br-0 border-0 bg-white pt-2'> <span class='text-danger text-right'>Total: " . $this->items_total . "</span> </span> </div></div></div></div>\n";

    }

    function display_pages()

    {

        return $this->return;

    }

}

?>

