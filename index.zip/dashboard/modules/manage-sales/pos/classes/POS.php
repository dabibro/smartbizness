<?php
/**
 * Created by PhpStorm.
 * User: Dauda Ibrahim
 * Date: 8/4/2020
 * Time: 2:25 PM
 */

class POS extends BIZConfig
{
    public function PromoPriceCheck($varParam = NULL)
    {
        $module = new Module_Class;
        $AppAuth = new Auth_Access();
        $auth = $AppAuth->AppAuthChecker();
        if ($varParam != NULL) {
            $app_id = $varParam['app_id'];
            $quantity = $varParam['quantity'];
            $price = $varParam['price'];
            $promo = $module->getRecord([
                "tbl_scheme" => 'app_promo',
                "condition" => [
                    "app_id" => $app_id,
                    "store_id" => $auth['store_id'],
                    "active_status" => 1
                ]
            ]);
            if ($promo['response'] === "200" && $promo['dataArray'][0]['promo_price'] != 0):
                if ($quantity >= $promo['dataArray'][0]['quantity_limit']):
                    if ($promo['dataArray'][0]['time_based'] == 1):
                        $start_date = $promo['dataArray'][0]['start_date'];
                        $end_date = $promo['dataArray'][0]['end_date'];
                        $getCurrentDate = Data_Access::execSQL("SELECT CURRENT_DATE as currentDate FROM app_promo")['dataArray'];
                        $current_date = $getCurrentDate->fetch_assoc()['currentDate'];
                        if ($current_date >= $start_date && $current_date <= $end_date):
                            $price = $promo['dataArray'][0]['promo_price'];
                        endif;
                    else:
                        $price = $promo['dataArray'][0]['promo_price'];
                    endif;
                endif;
            endif;
        }
        return $price;
    }

    //----------------------------------------------------------------
    public function DiscardTransact()
    {
        $module = new Module_Class;
        $app_cart = $this->biz['app_cart'];
        $cart = @$_SESSION[$app_cart];
        $module->deleteRecord([
            "tbl_scheme" => 'app_sales_products',
            "pk" => ['transact_id' => $cart]
        ]);
        $module->deleteRecord([
            "tbl_scheme" => 'app_transactions',
            "pk" => ['transact_id' => $cart]
        ]);
    }

    //----------------------------------------------------------------
    public function PaymentOptions($varParam)
    {

    }

    public function tempParse($filename, $varParam)
    {
        ob_start();
        if ($varParam != NULL):
            extract($varParam);
        endif;
        include($filename);
        $content = ob_get_contents();
        ob_end_clean();
        return $content;
    }

    public function valueSign($value)
    {
        if ($value < 0) {
            return '(' . str_replace('-', '', $value) . ')';
        } else {
            return $value;
        }
    }

    //----------------------------------------------------------------
    public function MeasureUnit($varParam = NULL)
    {
        if ($varParam != NULL):
            extract($varParam);
            $response = $qty;
            $max = max(@$measures);
            if ($measures != NULL):
                $units = "";
                foreach ($measures as $unit => $val):
                    if (@$qty >= $val && $qty < $max):
                        $inUnit = intval($qty / $val);
                        $remain = ($qty - ($inUnit * $val));
                        $units = $inUnit . '.' . $remain . " " . $unit;
                    endif;
                endforeach;
                if (isset($units) && $units != "") $response = $units;
            endif;
            return $response;
        endif;

    }

}