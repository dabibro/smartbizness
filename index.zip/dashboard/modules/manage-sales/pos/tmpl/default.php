<?php
$date = new DateTime($transact['transact_date']);
$transact_date = $date->format('Y-m-d');
//-----------------------------------------------
$date->add(new DateInterval('P1D'));
$new_date_in = $date->format('Y-m-d');
//-----------------------------------------------
$current = new DateTime('now');
$current_date = $current->format('Y-m-d');

?>
<div class="row mb-2">
    <div class="col-lg-12 text-right">
        <div class="btn-group-justified">
            <button onClick="printContent('receiptPrint','Thermal','80mm');"
                    class="btn btn-dark btn-sm receipt-print-btn px-3" id="printReceipt"
                    title="Print Receipt" data-toggle="tooltip" data-placement="top"><i class="fal fa-print"></i>
                Print Thermal
            </button>
            <button onClick="printDiv('receiptPrint');"
                    class="btn btn-dark btn-sm receipt-print-btn px-3" id="printReceipt"
                    title="Print Receipt" data-toggle="tooltip" data-placement="top"><i class="fal fa-print"></i>
                Print Full
            </button>
            <?php if (isset($_GET['id'])) { ?>
                <a class="btn btn-dark br-0 pl-3 pr-3" href="#" onclick="history.back(-1);" title="Back"
                   data-toggle="tooltip" data-placement="top"><i class="fal fa-arrow-left fa-lg"></i> Back</a>
            <?php } ?>
        </div>
    </div>
</div>

<div class="panel panel-primary border shadow-sm"
     <?php if (!isset($_GET['id'])) { ?>style=" overflow:auto"
    <?php } ?>>
    <div class="panel-body position-relative" style="background:#fff; padding:30px; font-family:'Fake Receipt';">
        <div id="receiptPrint" class="sales-receipt">
            <div class="logo text-center mb-2">
                <img src="<?php echo $app->assets ?>img/app-logo.png" alt="" style="max-width: 272px; max-height: 70px">
            </div>
            <div class="text-center" style="text-transform:uppercase;">
                <h5 style="margin:0" class="s_name">
                    <?php echo $info['business_name']; ?>
                </h5>
            </div>
            <div class="text-center address">
                <?php echo $info['business_address']; ?><br>
                <label for="">CALL US:</label>
                <?php echo $info['mobile_number']; ?>
            </div>
            <h4 class="text-center" id="r_title">CASH/CREDIT RECEIPT</h4>
            <div class="row r_ref">
                <div class="col-md-12 text-left">
                    <div><label for="">Receipt #:</label>
                        <?php echo $transact['transact_id']; ?>
                    </div>
                </div>
            </div>
            <div class="row r_ref">
                <div class="col-md-12 text-left pull-right">
                    <div><label for="">Cashier:</label>
                        <?php echo $transact['transact_by']; ?>
                    </div>
                </div>
            </div>
            <?php if (@$payment['amount_tendered'] > 0) { ?>
                <div class="row r_ref">
                    <div class="col-md-12 ">
                        <label>Paid:</label>
                        <?php if (@$payment['mix_payments'] == ""):
                            echo @$payment['payment_option'];
                        else:
                            echo 'Mix Payments';
                        endif; ?>
                    </div>
                </div>
            <?php } ?>
            <div class="row r_ref">
                <?php if ($transact['customer_name'] != ""): ?>
                    <div class="col-md-12">
                        <label for="">Customer:</label>
                        <?php echo $transact['customer_name']; ?>
                    </div>
                <?php elseif ($transact['customer_id'] == "" && $transact['customer_name'] == ""): ?>
                    <div class="col-md-12">
                        <label for="">Customer:</label>
                        <?php echo $transact['customer_type']; ?>
                    </div>
                <?php endif; ?>
            </div>
            <div class="row  align-content-center ">
                <div class="col-6 m-auto position-absolute" style="max-height: 100%; left: 35%;"
                     id="watermark-container">
                    <div class="watermark text-uppercase text-muted">
                        <span><?php
                            if ($transact['transact_type'] === "Return"):
                                echo "RETURN";
                            elseif ($payment == NULL):
                                echo 'UNPAID';
                            else:
                                if ($transact['checkout_status'] == 0):
                                    echo "DRAFT";
                                else:
                                    echo "PAID";
                                endif;
                            endif; ?></span>
                        <div class="small"><?php echo $transact_date; ?></div>

                    </div>
                </div>
            </div>
            <table width="100%" border="0" cellpadding="0" cellspacing="0" class="table table-sm">
                <thead id="rcp_head">
                <td>#</td>
                <td align="left">DESCRIPTION</td>
                <td>QTY</td>
                <td>RATE <?php echo $biz->currency['currency']; ?></td>
                <td nowrap>AMOUNT <?php echo $biz->currency['currency']; ?></td>
                </thead>
                <tbody>
                <?php
                $index = 0;
                $total = 0;
                @$items = $module->getRecord([
                    "tbl_scheme" => 'app_sales_products',
                    "condition" => [
                        "transact_id" => $transact['transact_id'],
                        "checkout_status" => $transact['checkout_status']
                    ]
                ])['dataArray'];
                if ($items != NULL):
                    foreach ($items as $item): $index++;
                        $total = $total + ($item['product_qty'] * $item['product_price']);
                        @$getUnit = $module->getRecord([
                            "tbl_scheme" => "app_inventory",
                            "condition" => [
                                "app_id" => $item['product_id'],
                                "store_id" => $item['store_id'],
                            ]
                        ])['dataArray'][0]['packaging'];
                        if (@$getUnit != ""):
                            $qty = $pos->MeasureUnit([
                                "qty" => @$item['product_qty'],
                                "measures" => @json_decode(@htmlspecialchars_decode(@$getUnit), true),
                            ]);
                        else:
                            $qty = @number_format($item['product_qty'], 2);
                        endif;
                        ?>
                        <tr>
                            <td><?php echo @$index; ?></td>
                            <td><?php echo @htmlspecialchars_decode($item['product_name']); ?></td>
                            <td><?php echo $qty; ?></td>
                            <td><?php echo @number_format($item['product_price'], 2); ?></td>
                            <td>
                                <?php echo $pos->valueSign(@number_format($item['product_price'] * $item['product_qty'], 2)); ?>
                            </td>
                        </tr>
                    <?php endforeach; endif; ?>
                <?php if ($transact['discount'] <= 0): ?>
                    <tr class="t_row">
                        <th colspan="4" style="padding-right: 1px" class=" text-right">TOTAL
                            <?php echo $biz->currency['currency']; ?>
                        </th>
                        <td align="left" class="">
                            <?php echo $pos->valueSign(number_format($total, 2)); ?>
                        </td>
                    </tr>
                <?php else: ?>
                    <tr class="t_row">
                        <th colspan="4" style="padding-right: 1px" class=" text-right">SUBTOTAL
                            <?php echo $biz->currency['currency']; ?>
                        </th>
                        <td align="left" class="">
                            <?php echo $pos->valueSign(number_format($total, 2)); ?>
                        </td>
                    </tr>
                    <tr>
                        <th colspan="4" style="padding-right: 1px" class=" text-right">DISCOUNT
                            <?php echo $biz->currency['currency']; ?>
                        </th>
                        <td align="left" class="">
                            <?php echo $pos->valueSign(number_format($transact['discount'], 2)); ?>
                        </td>
                    </tr>
                    <tr>
                        <th colspan="4" style="padding-right: 1px" class=" text-right">TOTAL
                            <?php echo $biz->currency['currency']; ?>
                        </th>
                        <td align="left" class="">
                            <?php echo $pos->valueSign(number_format($transact['total_due'], 2)); ?>
                        </td>
                    </tr>
                <?php endif; ?>
                <?php if ($transact['customer_id'] != ""): ?>
                    <tr>
                        <th colspan="4" style="padding-right: 1px" class=" text-right">DEPOSIT
                            <?php echo $biz->currency['currency']; ?>
                        </th>
                        <td align="left" class="">
                            <?php echo @$pos->valueSign(number_format($payment['amount_tendered'], 2)); ?>
                        </td>
                    </tr>
                    <tr>
                        <th colspan="4" style="padding-right: 1px" class=" text-right">BALANCE
                            <?php echo $biz->currency['currency']; ?>
                        </th>
                        <td align="left" class="">
                            <?php echo @$pos->valueSign(number_format(@$transact['total_due'] - @$payment['amount_tendered'], 2)); ?>
                        </td>
                    </tr>
                    <?php if ($transact['checkout_status'] == 1): ?>
                        <tr>
                            <td colspan="5">
                                <?php
                                //-----------------------------------------------------------------------------------------
                                $previous_transacts = $module->customerTransBalance([
                                    "customer_id" => $transact['customer_id'],
                                    "transact_date" => $transact['transact_date']
                                ]);
                                $previous_payments = $module->customerPayBalance([
                                    "customer_id" => $transact['customer_id'],
                                    "transact_date" => $transact['transact_date']
                                ]);
                                //-----------------------------------------------------------------------------------------
                                if ($transact_date != $current_date):
                                    $avail_transacts = $module->customerTransBalance([
                                        "customer_id" => $transact['customer_id'],
                                        "transact_date" => $date->format('Y-m-d')
                                    ]);
                                    $avail_payments = $module->customerPayBalance([
                                        "customer_id" => $transact['customer_id'],
                                        "transact_date" => $date->format('Y-m-d')
                                    ]);
                                else:
                                    $avail_transacts = $module->customerTransBalance([
                                        "customer_id" => $transact['customer_id'],
                                    ]);
                                    $avail_payments = $module->customerPayBalance([
                                        "customer_id" => $transact['customer_id'],
                                    ]);
                                endif;
                                ?>

                                Account Summary
                                <div><label>Previous Balance
                                        <?php echo $biz->currency['currency'] . ' ' . number_format((@$previous_transacts - @$previous_payments), 2); ?></label>
                                </div>
                                <div><label>Available Balance
                                        N: <?php echo number_format((@$avail_transacts - @$avail_payments), 2); ?></label>
                                </div>
                            </td>

                        </tr>
                    <?php endif; ?>

                <?php endif; ?>
                </tbody>
            </table>

            <div style="text-align: center; margin: 5px 0; border-top: 0.01em solid #000;" id="r_footer">
                <p class="my-0">
                    <?php
                    echo "<img alt='Barcode' src='" . $app->webRoot . "helpers/barcode.php?codetype=Code39&size=32&text=" . $transact_id . "&print=true' class='mt-2'/>";
                    ?>
                    <?php echo htmlspecialchars_decode($info['app_receipt_footer']); ?>
                </p>
            </div>

        </div>
    </div>
</div>