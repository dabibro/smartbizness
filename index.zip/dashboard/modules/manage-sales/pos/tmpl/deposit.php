<?php
$info = $biz->biz;
$transact = $module->getRecord([
    "tbl_scheme" => 'app_sales_deposits',
    "condition" => [
        "reference" => $reference
    ]
])['dataArray'][0];
@$getTransaction = $module->getRecord([
    "tbl_scheme" => 'app_transactions',
    "condition" => ['transact_id' => $transact['transact_reference'], "checkout_status" => 0]
])['dataArray'][0];
$date = new DateTime($transact['received_date']);
$transact_date = $date->format('Y-m-d');
//-----------------------------------------------
$date->add(new DateInterval('P1D'));
$new_date_in = $date->format('Y-m-d');
//-----------------------------------------------
$current = new DateTime('now');
$current_date = $current->format('Y-m-d');

?>
<div class="row mb-2">
    <div class="col-lg-12 text-right">
        <div class="btn-group-justified">
            <button onClick="printContent('receiptPrint','Thermal','80mm');"
                    class="btn btn-dark btn-sm receipt-print-btn px-3" id="printReceipt"
                    title="Print Receipt" data-toggle="tooltip" data-placement="top"><i class="fal fa-print"></i>
                Print Thermal
            </button>
        </div>
    </div>
</div>

<div class="panel panel-primary border shadow-sm">
    <div class="panel-body position-relative" style="background:#fff; padding:30px; font-family:'Fake Receipt';">
        <div id="DepositPrint" class="sales-receipt">
            <div class="logo text-center mb-2">
                <img src="<?php echo $engine->assets ?>img/app-logo.png" alt=""
                     style="max-width: 272px; max-height: 70px">
            </div>
            <div class="text-center" style="text-transform:uppercase;">
                <h5 style="margin:0" class="s_name">
                    <?php echo $info['business_name']; ?>
                </h5>
            </div>
            <div class="text-center address">
                <?php echo $info['business_address']; ?><br>
                <label for="">CALL US:</label>
                <?php echo $info['mobile_number']; ?>
            </div>
            <h4 class="text-center" id="r_title">DEPOSIT RECEIPT</h4>
            <div class="row r_ref">
                <div class="col-md-12 text-left">
                    <div><label for="">Deposit #:</label>
                        <?php echo $transact['reference']; ?>
                    </div>
                </div>
            </div>
            <div class="row r_ref">
                <div class="col-md-12 text-left">
                    <div><label for="">Paid For:</label>
                        <?php echo $transact['transact_reference']; ?>
                    </div>
                </div>
            </div>
            <div class="row r_ref">
                <div class="col-md-12 text-left pull-right">
                    <div><label for="">Cashier:</label>
                        <?php echo $transact['received_by']; ?>
                    </div>
                </div>
            </div>
            <div class="row r_ref">
                <?php if ($getTransaction['customer_name'] != ""): ?>
                    <div class="col-md-12">
                        <label for="">Customer:</label>
                        <?php echo $getTransaction['customer_name']; ?>
                    </div>
                <?php elseif ($getTransaction['customer_id'] == "" && $getTransaction['customer_name'] == ""): ?>
                    <div class="col-md-12">
                        <label for="">Customer:</label>
                        <?php echo $getTransaction['customer_type']; ?>
                    </div>
                <?php endif; ?>
            </div>
            <div class="row  align-content-center ">
                <div class="col-6 m-auto position-absolute" style="max-height: 100%; left: 35%;"
                     id="watermark-container">
                    <div class="watermark text-uppercase text-muted">
                        <span><?php echo "DEPOSIT"; ?></span>
                        <div class="small"><?php echo $transact_date; ?></div>

                    </div>
                </div>
            </div>
            <table width="100%" border="0" cellpadding="0" cellspacing="0" class="table table-sm">
                <thead id="rcp_head">
                <td align="left">DESCRIPTION</td>
                <td nowrap>AMOUNT <?php echo $biz->currency['currency']; ?></td>
                </thead>
                <tbody>
                <tr>
                    <td>Deposit Paid for <?php echo $transact['transact_reference']; ?> <br>
                        Amount <?php echo $biz->currency['currency'] . ': ' . number_format($getTransaction['total_due'], 2); ?>
                    </td>
                    <td><?php echo @number_format($transact['amount_tendered'], 2); ?></td>
                </tr>
                <tr>
                    <td colspan="5">
                        <?php
                        //-----------------------------------------------------------------------------------------
                        @$PrevBalanceSQL = "SELECT SUM(amount_tendered) as amount 
                         FROM app_sales_deposits WHERE received_date < '" . $transact['received_date'] . "'                         
                         AND transact_reference = '" . $transact['transact_reference'] . "'  ";
                        @$tranQuery = Data_Access::execSQL($PrevBalanceSQL);
                        @$Array = Data_Access::fetchAssoc($tranQuery['dataArray']);
                        @$previous_transacts = $Array['dataArray'][0]['amount'];
                        //-----------------------------------------------------------------------------------------
                        @$NewBalanceSQL = "SELECT SUM(amount_tendered) as amount 
                         FROM app_sales_deposits WHERE received_date <= DATE_ADD('" . $transact_date . "', INTERVAL 1 DAY)                         
                         AND transact_reference = '" . $transact['transact_reference'] . "'  ";
                        @$NewtranQuery = Data_Access::execSQL($NewBalanceSQL);
                        @$NewArray = Data_Access::fetchAssoc($NewtranQuery['dataArray']);
                        @$new_transacts = $NewArray['dataArray'][0]['amount'];
                        ?>

                        Account Summary
                        <div><label>Previous Balance
                                <?php echo $biz->currency['currency'] . ' ' . number_format((@$previous_transacts), 2); ?></label>
                        </div>
                        <div><label>Available Balance
                                N: <?php echo number_format((@$new_transacts), 2); ?></label>
                        </div>
                    </td>

                </tr>
                </tbody>
            </table>

            <div style="text-align: center; margin: 5px 0; border-top: 0.01em solid #000;" id="r_footer">
                <p class="my-0">
                    <?php
                    echo "<img alt='Barcode' src='" . $engine->webRoot . "helpers/barcode.php?codetype=Code39&size=32&text=" . $transact['reference'] . "&print=true' class='mt-2'/>";
                    ?>
                    <?php echo htmlspecialchars_decode($info['app_receipt_footer']); ?>
                </p>
            </div>

        </div>
    </div>
</div>