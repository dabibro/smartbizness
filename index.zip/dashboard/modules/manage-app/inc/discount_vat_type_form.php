<?php
if (@$modalRequest == 1):
    @$requestArray = array(
        "tbl_scheme" => 'app_discount_vat_type',
        "order" => 'category, name ASC');
    @$recordRequest = $module->getRecord($requestArray);
    @$recordsArray = $recordRequest['dataArray'];

    if (@$modalRequestParam['request'] == "update" && @$modalRequestParam['pk'] != "" && @$modalRequestParam['pkField'] != ""):
        $pk = $modalRequestParam['pk'];
        $pkField = $modalRequestParam['pkField'];

        $getUpdateArray = array(
            "tbl_scheme" => 'app_discount_vat_type',
            "condition" => [$pkField => $pk],
            "limit" => 1
        );
        $getUpdate = $module->getRecord($getUpdateArray);
        extract($getUpdate['dataArray'][0]);

    endif;
endif;
?>
<div id="actionEvents"></div>

<div class="row">
    <div class="col-4">
        <form method="post" class="AppForm" id="discount-vat-type" novalidate>
            <div id="ModuleResponse"></div>
            <div class="nav flex-column nav-tabs h-100">
                <label for="">Create/Update</label>
                <div class="form-group">
                    <label><span class="required">*</span> Name/Description</label>
                    <input type="text" name="name" class="form-control form-control-sm" placeholder="Name/Description"
                           required value="<?php echo @$name; ?>" autocomplete="off">
                    <div class="invalid-feedback">* Required field</div>
                </div>
                <div class="form-group">
                    <label><span class="required">*</span> Category</label>
                    <select name="category" class="form-control form-control-sm select2  discount-type" required>
                        <option value="">-- Select --</option>
                        <?php $itemArray = array("Discount", "VAT");
                        foreach ($itemArray as $item): ?>
                            <option value="<?php echo $item ?>" <?php if (@$category == $item): echo 'selected';endif; ?>><?php echo $item; ?></option>
                        <?php endforeach; ?>
                    </select>
                    <div class="invalid-feedback">* Required field</div>
                </div>
                <hr class="my-1">
                <button class="btn btn-default actionButton btn-sm"><i class="fal fa-check-circle"></i> Submit</button>
                <input type="hidden" name="className" value="Module_Class" readonly>
                <?php if (@$getUpdate['response'] === "200"): ?>
                    <input type="hidden" name="functionName" value="updateRecord" readonly>
                    <input type="hidden" name="pk" value="<?php echo @$pk; ?>" readonly>
                    <input type="hidden" name="pkField" value="<?php echo @$pkField; ?>" readonly>
                <?php else: ?>
                    <input type="hidden" name="functionName" value="createRecord" readonly>
                <?php endif; ?>
                <input type="hidden" name="callback[type]" value="actionEvent" readonly>
                <input type="hidden" name="callback[redirect]" value=" viewCallback();" readonly>
                <input type="hidden" name="tbl_scheme" value="app_discount_vat_type" readonly>
                <input type="hidden" name="created_by"
                       value="<?php echo trim(@$auth['firstname'] . ' ' . @$auth['lastname']); ?>" readonly>
            </div>
        </form>
    </div>
    <div class="col-8">
        <div class="tab-content" id="add-item-tabContent">
            <div class="tab-pane text-left fade active show">
                <div class="table-responsive">
                    <table class="table data-tables dataTables-Sort_Modal table-sm elevation-1">
                        <thead>
                        <tr>
                            <th>Name/Description</th>
                            <th>Category</th>
                            <th><i class="fal fa-cog"></i></th>
                        </tr>
                        </thead>
                        <tbody class="card-body">
                        <?php if (isset($recordsArray)):
                            foreach (@$recordsArray as $dvt_record):
                                extract($dvt_record);
                                ?>
                                <tr>
                                    <td><?php echo @$dvt_record['name']; ?></td>
                                    <td><?php echo @$dvt_record['category']; ?></td>
                                    <td>
                                        <div class="btn-group-justify btn-group-sm float-right">
                                            <button type="button" class="btn btn-default"
                                                    onclick='var obj = "<?php echo urlencode('"pkField":"id","pk":' . $dvt_record['id'] . ',"view":"/#/discount-vat/","request":"update","target":"modal","modalParam":{"modalId":"ModuleModal","modalTitle":"Discount/VAT Type","required":"inc/discount_vat_type_form","modalSize":"modal-lg","DataTable":"1"}'); ?>"; moduleEditRequest(obj)'
                                                    title=" Edit Record" data-toggle="tooltip"><i
                                                        class="fal fa-edit"></i>
                                            </button>
                                            <button type="button" class="btn btn-default"
                                                    onclick='var obj = "<?php echo urlencode('"className":"Module_Class","functionName":"deleteRecord","tbl_scheme":"app_discount_vat_type","pk":{"id":' . $dvt_record['id'] . '},"callback":{"type":"modal","redirect":""},"modalParam":{"modalId":"ModuleModal","modalTitle":"Discount/VAT Type","required":"inc/discount_vat_type_form","modalSize":"modal-lg","DataTable":"1"},"notification":{"message":"Are you sure to delete this record?","title":"Delete Warning"}'); ?>";  moduleRequest(obj);'
                                                    title=" Edit Record" data-toggle="tooltip"><i
                                                        class="fal fa-trash-alt"></i>
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach;
                        endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <?php
    if (@$modalRequest == 1):
        $thisFile = str_ireplace('dashboard/', '', str_ireplace($engine->srvRoot, '', str_replace('\\', '/', __DIR__)));
        echo '<script src="' . str_ireplace('inc', '', $thisFile) . 'js.js"></script>';
        ?>
        <script>

            $('.select2').select2();

            function viewCallback() {
                $("ModuleModal").modal('hide');
                AppModalLoader({
                    modalId: 'ModuleModal',
                    modalTitle: 'Discount/VAT Type',
                    required: 'inc/discount_vat_type_form',
                    modalSize: 'modal-lg',
                    DataTable: 1
                });
            }
        </script>
    <?php endif; ?>
    
    
    