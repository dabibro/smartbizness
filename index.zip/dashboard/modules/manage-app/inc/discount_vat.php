<?php
/**
 * Created by DTMGS Limited.
 * User: DBlasterMaster
 * Date: 4/11/2020
 * Time: 2:54 AM
 */

@$requestArray = array(
    "tbl_scheme" => 'app_discount_vat',

    "order" => 'category, name ASC');
@$recordRequest = $module->getRecord($requestArray);
@$recordsArray = $recordRequest['dataArray'];
if (@$requestMethodArray['request'] == "update" && @$requestMethodArray['pk'] != "" && @$requestMethodArray['pkField'] != ""):
    $pk = $requestMethodArray['pk'];
    $pkField = $requestMethodArray['pkField'];
    $getUpdateArray = array(
        "tbl_scheme" => 'app_discount_vat',
        "condition" => [$pkField => $pk],
        "limit" => 1
    );
    $getUpdate = $module->getRecord($getUpdateArray);
    extract($getUpdate['dataArray'][0]);
endif;
?>

<ul class="nav ml-auto modules-menu mb-3">
    <li class="nav-item ml-auto">
        <a class="nav-link active app-link" href="javascript:void(0)"
           onclick="AppModalLoader({modalId:'ModuleModal', modalTitle:'Discount/VAT Type', required:'inc/discount_vat_type_form', modalSize: 'modal-lg', DataTable:1});"><i
                    class="fal fa-folder"></i> Discount/VAT Types</a>
    </li>
</ul>
<div class="row">
    <div class="col-lg-4">
        <fieldset class="border card-body">
            <legend class="col-auto h6">Discount/VAT Record</legend>
            <?php require 'discount_vat_form.php'; ?>
        </fieldset>
    </div>
    <div class="col-lg-8">
        <div class="table-responsive">
            <table class="table data-tables dataTables-Sort table-sm elevation-1">
                <thead>
                <tr>
                    <th>Name/Description</th>
                    <th>Category</th>
                    <th>Percent %</th>
                    <th>Status</th>
                    <th><i class="fal fa-cog"></i></th>
                </tr>
                </thead>
                <tbody class="card-body">
                <?php if (isset($recordsArray)):
                    foreach (@$recordsArray as $record):
                        extract($record);
                        ?>
                        <tr>
                            <td><?php echo @$name; ?></td>
                            <td><?php echo @$category; ?></td>
                            <td><?php echo @number_format($percent, 2); ?></td>
                            <td><?php if (@$active_status == 1):echo 'Active'; else:echo 'Inactive'; endif; ?></td>
                            <td>
                                <div class="btn-group-justify btn-group-sm float-right">
                                    <button type="button" class="btn btn-default"
                                            onclick='var obj = "<?php echo urlencode('"pkField":"id","pk":' . $id . ',"view":"/#/discount-vat/","request":"update"'); ?>"; moduleEditRequest(obj)'
                                            title=" Edit Record" data-toggle="tooltip"><i
                                                class="fal fa-edit"></i>
                                    </button>
                                    <button type="button" class="btn btn-default"
                                            onclick='var obj = "<?php echo urlencode('"className":"Module_Class","functionName":"deleteRecord","tbl_scheme":"app_discount_vat","pk":{"id":' . $id . '},"callback":{"type":"self","redirect":""},"notification":{"message":"Are you sure to delete this record?","title":"Delete Warning"}'); ?>";  moduleRequest(obj);'
                                            title=" Edit Record" data-toggle="tooltip"><i
                                                class="fal fa-trash-alt"></i>
                                    </button>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach;
                endif; ?>
                </tbody>

            </table>
        </div>
    </div>
</div>
