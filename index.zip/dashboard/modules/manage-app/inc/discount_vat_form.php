<?php
/**
 * Created by DTMGS Limited.
 * User: DBlasterMaster
 * Date: 4/11/2020
 * Time: 2:54 AM
 */
?>

<form method="post" class="AppForm" id="discount-vat-form" novalidate>
    <div id="ModuleResponse"></div>
    <div class="form-group">
        <label><span class="required">*</span> Name/Description</label>
        <input type="text" name="name" class="form-control form-control-sm" placeholder="Name/Description"
               required value="<?php echo @$name; ?>" autocomplete="off">
        <div class="invalid-feedback">* Required field</div>
    </div>
    <div class="row">
        <div class="col-lg-6">
            <div class="form-group">
                <label><span class="required">*</span> Category</label>
                <select name="category" class="form-control form-control-sm select2  discount-type" required
                    <?php if (@$modal == 1) {
                        echo 'disabled';
                    } ?>>
                    <option value="">-- Select --</option>
                    <?php $itemArray = array("Discount", "VAT");
                    foreach ($itemArray as $item): ?>
                        <option value="<?php echo $item ?>" <?php if (@$category == $item): echo 'selected';endif; ?>><?php echo $item; ?></option>
                    <?php endforeach; ?>
                </select>
                <div class="invalid-feedback">* Required field</div>
                <?php if (@$modal == 1) { ?>
                    <input type="hidden" name="discount-type" class="discount-type">
                    <input type="hidden" name="location" value="modal">
                <?php } ?>

            </div>
        </div>
        <div class="col-lg-6">
            <div class="form-group">
                <label><span class="required">*</span> Percent %</label>
                <input name="percent" required data-regex="number"
                       class="form-control form-control-sm"
                       placeholder="Percent"
                       autocomplete="off"
                       value="<?php if (isset($percent)):echo @number_format($percent, 2);endif; ?>">
                <div class="invalid-feedback">* Required integer field</div>
            </div>
        </div>
    </div>
    <div class="form-group mb-0">
        <label for="">Additional Note</label>
        <textarea name="description" rows="4" placeholder="Additional Note" autocomplete="off"
                  class="form-control form-control-sm"><?php echo @$description; ?></textarea>
    </div>
    <?php if (@$getUpdate['response'] === "200"): ?>
        <div class="form-group mt-3">
            <div class="custom-control custom-switch">
                <input type="checkbox" <?php if (@$active_status == 1): echo 'checked';endif; ?>
                       class="custom-control-input propToggle" id="active_status">
                <label class="custom-control-label" for="active_status"> Active Status</label>
                <input type="hidden" readonly name="active_status" class="active_status"
                       value="<?php if (@$active_status == 1): echo 1; else: echo 0;endif; ?>">
            </div>
        </div>
    <?php endif; ?>
    <hr class="my-3">

    <button class="btn btn-default actionButton btn-sm"><i class="fal fa-check-circle"></i> Submit</button>
    <input type="hidden" name="className" value="Module_Class" readonly>
    <?php if (@$getUpdate['response'] === "200"): ?>
        <input type="hidden" name="functionName" value="updateRecord" readonly>
        <input type="hidden" name="pk" value="<?php echo @$pk; ?>" readonly>
        <input type="hidden" name="pkField" value="<?php echo @$pkField; ?>" readonly>
    <?php else: ?>
        <input type="hidden" name="functionName" value="createRecord" readonly>
    <?php endif; ?>
    <input type="hidden" name="callback[type]" value="self" readonly>
    <input type="hidden" name="callback[redirect]" value="" readonly>
    <input type="hidden" name="tbl_scheme" value="app_discount_vat" readonly>
    <input type="hidden" name="created_by"
           value="<?php echo trim(@$auth['firstname'] . ' ' . @$auth['lastname']); ?>" readonly>
</form>
