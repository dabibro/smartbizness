<?php
/**
 * Created by DTMGS Limited.
 * User: DBlasterMaster
 * Date: 4/11/2020
 * Time: 2:54 AM
 */

@$requestArray = array(
    "tbl_scheme" => 'app_storage_location',
    "order" => 'category, name ASC');
@$recordRequest = $module->getRecord($requestArray);
@$recordsArray = $recordRequest['dataArray'];
if (@$requestMethodArray['request'] == "update" && @$requestMethodArray['pk'] != "" && @$requestMethodArray['pkField'] != ""):
    $pk = $requestMethodArray['pk'];
    $pkField = $requestMethodArray['pkField'];

    $getUpdateArray = array(
        "tbl_scheme" => 'app_storage_location',
        "condition" => [$pkField => $pk],
        "limit" => 1
    );
    $getUpdate = $module->getRecord($getUpdateArray);
    extract($getUpdate['dataArray'][0]);

endif;
?>
<div class="row">
    <div class="col-lg-4 col-12">
        <fieldset class="border card-body">
            <legend class="col-auto h6">Storage Location</legend>
            <?php require 'storage_location_form.php'; ?>
        </fieldset>
    </div>
    <div class="col-lg-8 col-12">
        <div class="table-responsive">
            <table class="table data-tables dataTables-Sort table-sm elevation-1">
                <thead>
                <tr>
                    <th>Ref</th>
                    <th>Name/Description</th>
                    <th>Category</th>
                    <th>Store Name</th>
                    <th>Status</th>
                    <th class="text-center"><i class="fal fa-cog"></i></th>
                </tr>
                </thead>
                <tbody class="card-body">
                <?php if (isset($recordsArray)):
                    foreach (@$recordsArray as $record):
                        extract($record);
                        ?>
                        <tr>
                            <td><?php echo @$reference; ?></td>
                            <td><?php echo @$name; ?></td>
                            <td><?php echo @$category; ?></td>
                            <td><?php echo @$module->getRecord(["tbl_scheme" => 'app_stores', "condition" => ["store_id" => $store_id]])['dataArray'][0]['store_name']; ?></td>
                            <td><?php if (@$active_status == 1):echo 'Active'; else:echo 'Inactive'; endif; ?></td>
                            <td>
                                <div class="btn-group-justify btn-group-sm float-right">
                                    <button type="button" class="btn btn-default"
                                            onclick='var obj = "<?php echo urlencode('"pkField":"id","pk":' . $id . ',"view":"/#/storage-location/","request":"update"'); ?>"; moduleEditRequest(obj)'
                                            title=" Edit Record"><i
                                                class="fal fa-edit"></i>
                                    </button>
                                    <button type="button" class="btn btn-default"
                                            onclick='var obj = "<?php echo urlencode('"className":"Module_Class","functionName":"deleteRecord","tbl_scheme":"app_storage_location","pk":{"id":' . $id . '},"callback":{"type":"self","redirect":"attribList()"},"notification":{"message":"Are you sure to delete this record?","title":"Delete Warning"}'); ?>";  moduleRequest(obj);'
                                            title=" Edit Record"><i
                                                class="fal fa-trash-alt"></i>
                                    </button>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach;
                endif; ?>
                </tbody>

            </table>
        </div>
    </div>
</div>
