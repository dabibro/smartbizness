<?php
/**
 * Created by DTMGS Limited.
 * User: DBlasterMaster
 * Date: 4/11/2020
 * Time: 2:54 AM
 */
?>
    <form method="post" class="AppForm" id="measure-unit-form">
        <div class="form-group">
            <label><span class="required">*</span> Measure Unit Code</label>
            <input type="text" name="name" class="form-control form-control-sm" placeholder="Measure Unit Code"
                   required value="<?php echo @$name; ?>" autocomplete="off">
            <small class="text-muted">Example: PCS, KG, DOZ</small>
            <div class="invalid-feedback">* Required field</div>
        </div>
        <div class="form-group">
            <label>Measure Description</label>
            <input type="text" name="description" class="form-control form-control-sm" placeholder="Measure Description"
                   autocomplete="off"
                   value="<?php echo @$description; ?>">
        </div>
        <?php if (@$getUpdate['response'] === "200"): ?>
            <div class="form-group mt-3">
                <div class="custom-control custom-switch">
                    <input type="checkbox" <?php if (@$active_status == 1): echo 'checked';endif; ?>
                           class="custom-control-input propToggle" id="active_status">
                    <label class="custom-control-label" for="active_status"> Active Status</label>
                    <input type="hidden" readonly name="active_status" class="active_status"
                           value="<?php if (@$active_status == 1): echo 1; else: echo 0;endif; ?>">
                </div>
            </div>
        <?php endif; ?>
        <hr class="my-3">

        <button class="btn btn-default actionButton btn-sm"><i class="fal fa-check-circle"></i> Submit</button>
        <input type="hidden" name="className" value="Module_Class" readonly>
        <?php if (@$getUpdate['response'] === "200"): ?>
            <input type="hidden" name="functionName" value="updateRecord" readonly>
            <input type="hidden" name="pk" value="<?php echo @$pk; ?>" readonly>
            <input type="hidden" name="pkField" value="<?php echo @$pkField; ?>" readonly>
        <?php else: ?>
            <input type="hidden" name="functionName" value="createRecord" readonly>
        <?php endif; ?>
        <?php if (@$modalRequest == 1): ?>
            <input type="hidden" name="callback[type]" value="modal" readonly>
            <input type="hidden" name="callback[redirect]" value="" readonly>
        <?php else: ?>
            <input type="hidden" name="callback[type]" value="self" readonly>
            <input type="hidden" name="callback[redirect]" value="" readonly>
        <?php endif; ?>
        <input type="hidden" name="tbl_scheme" value="app_measure_unit" readonly>
        <input type="hidden" name="created_by"
               value="<?php echo trim(@$auth['firstname'] . ' ' . @$auth['lastname']); ?>" readonly>
    </form>
<?php
if (@$modalRequest == 1):
    $thisFile = str_ireplace('dashboard/', '', str_ireplace($engine->srvRoot, '', str_replace('\\', '/', __DIR__)));
    echo '<script src="' . str_ireplace('inc', '', $thisFile) . 'js.js"></script>';
    ?>
<?php endif; ?>