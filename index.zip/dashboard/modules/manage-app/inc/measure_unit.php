<?php
/**
 * Created by DTMGS Limited.
 * User: DBlasterMaster
 * Date: 4/11/2020
 * Time: 2:54 AM
 */

@$requestArray = array(
    "tbl_scheme" => 'app_measure_unit',
    "order" => 'name, description ASC');
@$recordRequest = $module->getRecord($requestArray);

@$recordsArray = $recordRequest['dataArray'];
if (@$requestMethodArray['request'] == "update" && @$requestMethodArray['pk'] != "" && @$requestMethodArray['pkField'] != ""):
    $pk = $requestMethodArray['pk'];
    $pkField = $requestMethodArray['pkField'];
    $getUpdateArray = array(
        "tbl_scheme" => 'app_measure_unit',
        "condition" => [$pkField => $pk],
        "limit" => 1
    );
    $getUpdate = $module->getRecord($getUpdateArray);
    extract($getUpdate['dataArray'][0]);

endif;
?>
<div class="row">
    <div class="col-md-5 col-lg-4 col-12">
        <fieldset class="border card-body">
            <legend class="col-auto h6">Measure Unit</legend>
            <div id="ModuleResponse"></div>
            <?php require 'measure_unit_form.php'; ?>
        </fieldset>
    </div>
    <div class="col-md-7 col-lg-8 col-12">
        <div class="table-responsive">
            <table class="table data-tables dataTables-Sort table-sm elevation-1">
                <thead>
                <tr>
                    <th>Name/Description</th>
                    <th>Category</th>
                    <th>Active Status</th>
                    <th><i class="fal fa-cog"></i></th>
                </tr>
                </thead>
                <tbody class="card-body">
                <?php if (isset($recordsArray)):
                    foreach (@$recordsArray as $record):
                        extract($record);
                        ?>
                        <tr>
                            <td><?php echo @$name; ?></td>
                            <td><?php echo @$description; ?></td>
                            <td><?php if (@$active_status == 1):echo 'Active'; else:echo 'Inactive'; endif; ?></td>
                            <td>
                                <div class="btn-group-justify btn-group-sm float-right">
                                    <button type="button" class="btn btn-default"
                                            onclick='var obj = "<?php echo urlencode('"pkField":"id","pk":' . $id . ',"view":"/#/measure-unit/","request":"update"'); ?>"; moduleEditRequest(obj)'
                                            title=" Edit Record"><i
                                                class="fal fa-edit"></i>
                                    </button>
                                    <button type="button" class="btn btn-default"
                                            onclick='var obj = "<?php echo urlencode('"className":"Module_Class","functionName":"deleteRecord","tbl_scheme":"app_measure_unit","pk":{"id":' . $id . '},"callback":{"type":"self","redirect":""},"notification":{"message":"Are you sure to delete this record?","title":"Delete Warning"}'); ?>";  moduleRequest(obj);'
                                            title=" Edit Record"><i
                                                class="fal fa-trash-alt"></i>
                                    </button>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach;
                endif; ?>
                </tbody>

            </table>
        </div>
    </div>
</div>
