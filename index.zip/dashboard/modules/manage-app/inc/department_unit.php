<?php
/**
 * Created by DTMGS Limited.
 * User: Dauda Ibrahim
 * Date: 6/24/2020
 * Time: 1:45 AM
 */
@$requestArray = array(
    "tbl_scheme" => 'app_department_unit',
    "condition" => [
        "delete_status" => 0,
    ],
    "order" => 'parent_id, name ASC');
@$recordRequest = $module->getRecord($requestArray);
@$recordsArray = $recordRequest['dataArray'];
if (@$requestMethodArray['request'] == "update" && @$requestMethodArray['pk'] != "" && @$requestMethodArray['pkField'] != ""):
    $pk = $requestMethodArray['pk'];
    $pkField = $requestMethodArray['pkField'];

    $getUpdateArray = array(
        "tbl_scheme" => 'app_department_unit',
        "condition" => [$pkField => $pk],
        "limit" => 1
    );
    $getUpdate = $module->getRecord($getUpdateArray);
    extract($getUpdate['dataArray'][0]);

endif;
?>
<div class="row">
    <div class="col-lg-5 col-12 mb-lg-0 mb-3">
        <fieldset class="border card-body">
            <legend class="col-auto h6">Department/Unit Record</legend>
            <form method="post" class="AppForm" id="dept-unit-form" novalidate>
                <div id="ModuleResponse"></div>
                <div class="row">
                    <div class="col-4 ml-auto">
                        <div class="form-group mb-3">
                            <label for=""><span class="required">*</span> Reference ID</label>
                            <input type="text" class="form-control form-control-sm" name="reference"
                                   value="<?php echo @$reference; ?>"
                                   required autofocus
                                   placeholder="Reference ID" autocomplete="off">
                            <div class="invalid-feedback">* Required field</div>
                        </div>
                    </div>
                    <div class="col-8">
                        <div class="form-group">
                            <label for=""><span class="required">*</span> Name/Description</label>
                            <input type="text" class="form-control form-control-sm" name="name"
                                   value="<?php echo @$name; ?>" required
                                   placeholder="Name/Description" autocomplete="off">
                            <div class="invalid-feedback">* Required field</div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-6">
                        <div class="form-group">
                            <label for="">Parent Record</label>
                            <select name="parent_id" class="form-control form-control-sm select2">
                                <option value="">-- Select --</option>
                                <?php if (isset($recordsArray)):
                                    foreach ($recordsArray as $list):
                                        if ($list['parent_id'] == 0): ?>

                                            <option value="<?php echo $list['id']; ?>" <?php if ($list['id'] == @$parent_id):echo "selected";endif; ?>>
                                                <?php echo $list['name']; ?>
                                            </option>
                                        <?php endif;
                                    endforeach;
                                endif;
                                ?>
                            </select>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="form-group">
                            <label for=""><span class="required">*</span> Store</label>
                            <select name="store_id"
                                    class="form-control form-control-sm select2"
                                    id="store" required>
                                <option value="">-- Store --</option>
                                <?php
                                $storeParam = array("tbl_scheme" => 'app_stores', "condition" => ["active_status" => 1]);
                                $listArray = $module->getRecord($storeParam);
                                $dropDownArray = array();
                                foreach ($listArray['dataArray'] as $store):
                                    echo $app->dropDownList($store['store_id'], $store['store_name'], @$store_id);
                                endforeach; ?>
                            </select>
                            <div class="invalid-feedback">* Required field</div>
                        </div>
                    </div>
                </div>
                <div class="form-group">
                    <label for="">Additional Note</label>
                    <textarea name="description" rows="3" placeholder="Additional Note" autocomplete="off"
                              class="form-control form-control-sm"><?php echo @$description; ?></textarea>
                </div>
                <hr class="my-3">
                <input type="hidden" name="className" value="Module_Class" readonly>
                <?php if (@$getUpdate['response'] === "200"): ?>
                    <input type="hidden" name="functionName" value="updateRecord" readonly>
                    <input type="hidden" name="pk" value="<?php echo @$pk; ?>" readonly>
                    <input type="hidden" name="pkField" value="<?php echo @$pkField; ?>" readonly>

                <?php else: ?>
                    <input type="hidden" name="functionName" value="createRecord" readonly>
                    <input type="hidden" name="pk" value="reference" readonly>
                <?php endif; ?>
                <input type="hidden" name="callback[type]" value="self" readonly>
                <input type="hidden" name="callback[redirect]" value="" readonly>
                <input type="hidden" name="tbl_scheme" value="app_department_unit" readonly>
                <input type="hidden" name="created_by"
                       value="<?php echo trim(@$auth['firstname'] . ' ' . @$auth['lastname']); ?>" readonly>

                <button class="btn btn-default btn-sm actionButton"><i class="fal fa-check-circle"></i>
                    Submit
                </button>
            </form>
        </fieldset>
    </div>
    <div class="col-lg-7 col-12">
        <div class="table-responsive">
            <table class="table data-tables dataTables table-sm elevation-1">
                <thead class="p-0">
                <tr>
                    <th class="p-0 border-0">
                        <div class="mb-0" style="width:100%">
                            <div class="row mx-0 bg-transparent">
                                <div class="col-2 th">Reference ID</div>
                                <div class="col-4 th">Name/Description</div>
                                <div class="col-4 th">Store</div>
                                <div class="col-2 th text-center"><span class="pointer" title="Action"><i
                                                class="fal fa-cogs"></i></span></div>
                            </div>
                        </div>
                    </th>
                </tr>
                </thead>
                <tbody>
                <?php if (isset($recordsArray)):
                    foreach (@$recordsArray as $record): extract($record);
                        if ($parent_id == 0):
                            if ($parent_id == 0):
                                $getChildParam = array(
                                    "tbl_scheme" => 'app_department_unit',
                                    "condition" => ["parent_id" => $id, "delete_status" => 0]);
                                $getChild = $module->getRecord($getChildParam);
                            endif;
                            ?>
                            <tr>
                                <td class="p-0">
                                    <div>
                                        <div style="width: 100%" class="my-1">
                                            <div class="row mx-0">
                                                <div class="col-2"><?php echo @$reference; ?></div>
                                                <div class="col-4"><?php echo @$name; ?></div>
                                                <div class="col-4"><?php echo @$store = $module->getRecord(["tbl_scheme" => 'app_stores', "condition" => ["store_id" => @$store_id]])['dataArray'][0]['store_name']; ?></div>
                                                <div class="col-2">
                                                    <div class="btn-group-justify btn-group-sm float-right">
                                                        <button type="button" class="btn btn-default"
                                                                onclick='var obj = "<?php echo urlencode('"pkField":"id","pk":' . $id . ',"view":"/#/department-unit/","request":"update"'); ?>"; moduleEditRequest(obj)'
                                                                title=" Edit Record"><i
                                                                    class="fal fa-edit"></i>
                                                        </button>
                                                        <button type="button" class="btn btn-default"
                                                                onclick='var obj = "<?php echo urlencode('"className":"Module_Class","functionName":"deleteRecord","tbl_scheme":"app_department_unit","pk":{"id":' . $id . '},"fk":["parent_id"],"callback":{"type":"self","redirect":""},"notification":{"message":"Are you sure to delete this record? <\/br> System will also delete child records.","title":"Delete Warning"}'); ?>";  moduleRequest(obj);'
                                                                title=" Edit Record"><i
                                                                    class="fal fa-trash-alt"></i>
                                                        </button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <?php if (isset($getChild['dataArray'])): ?>
                                        <div style="width: 100%" class="my-1">
                                            <?php foreach ($getChild['dataArray'] as $child): ?>
                                                <div>
                                                    <div class="row mx-0">
                                                        <div class="col-2">
                                                            &angrt; <?php echo $child['reference']; ?></div>
                                                        <div class="col-4"><?php echo $child['name']; ?></div>
                                                        <div class="col-4"><?php echo @$store = $module->getRecord(["tbl_scheme" => 'app_stores', "condition" => ["store_id" => @$child['store_id']]])['dataArray'][0]['store_name']; ?></div>
                                                        <div class="col-2">
                                                            <div class="btn-group-justify btn-group-sm float-right">
                                                                <div class="btn-group-justify btn-group-sm float-right">
                                                                    <button type="button" class="btn btn-default"
                                                                            onclick='var obj = "<?php echo urlencode('"pkField":"id","pk":' . $child['id'] . ',"view":"/#/department-unit/","request":"update"'); ?>"; moduleEditRequest(obj)'
                                                                            title=" Edit Record">
                                                                        <i
                                                                                class="fal fa-edit"></i>
                                                                    </button>
                                                                    <button type="button" class="btn btn-default"
                                                                            onclick='var obj = "<?php echo urlencode('"className":"Module_Class","functionName":"deleteRecord","tbl_scheme":"app_department_unit","pk":{"id":' . $child['id'] . '},"callback":{"type":"self","redirect":""},"notification":{"message":"Are you sure to delete this record?","title":"Delete Warning"}'); ?>";  moduleRequest(obj);'
                                                                            title=" Edit Record">
                                                                        <i
                                                                                class="fal fa-trash-alt"></i>
                                                                    </button>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            <?php endforeach; ?>
                                        </div>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endif; endforeach; endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
