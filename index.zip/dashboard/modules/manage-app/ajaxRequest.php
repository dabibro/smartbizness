<?php
/**
 * Created by DTMGS Limited.
 * User: Dauda Ibrahim
 * Date: 6/23/2020
 * Time: 9:40 PM
 * File: Module Classes
 */
if (file_exists("../../../helpers/config/config.inc.php")):
    require "../../../helpers/config/config.inc.php";
endif;
require "../../../helpers/handlers/app_autoloader.php";
require "Module_Class.php";
$engine = new SMBEngine;
$AppResponse = new App_Response;
$appAuth = new Auth_Access;
$auth = $appAuth->AppAuthChecker();
$requestMethod = $_SERVER['REQUEST_METHOD'];
if (in_array($requestMethod, ["GET", "POST", "PUT", "DELETE", "OPTIONS"])):
    $requestMethodArray = array();
    $requestMethodArray = $_REQUEST;
    //print_r($requestMethodArray);
    if (isset($requestMethodArray['notification']) && !isset($requestMethodArray['confirmed'])):
        $tmpl = "../../tmpl/notification.html";
        echo $engine->fileTempParse($tmpl, $requestMethodArray);
        exit;
    endif;

    if (isset($requestMethodArray['className']) && isset($requestMethodArray['functionName'])):
        $getCommandArray = array(
            "class" => $requestMethodArray['className'],
            "function_name" => $requestMethodArray['functionName']);
        $functionArray = [];
        foreach ($requestMethodArray as $key => $val):
            if ($key !== "className" && $key !== "functionName" && $key !== "callback")
                $functionArray += array($key => $val);
        endforeach;
        $module = new $requestMethodArray['className'];
        $execution = $module->execCommand($getCommandArray, $functionArray);
        if ($execution['response'] === "200"):
            //print_r($execution);
            if ($requestMethodArray['callback']['type'] == 'actionEvent'):
                $requestMethodArray['callback'] += array("event" => '<script>' . $requestMethodArray['callback']['redirect'] . '</script>');
            endif;
            $responseMessage = App_Response::alertResponse($execution['message'], 'success');
            $responseArray = array("success" => 1, "message" => ($responseMessage), "callback" => $requestMethodArray['callback']);
        else:
            $responseMessage = App_Response::alertResponse($execution['message'], 'danger');
            $responseArray = array("success" => 0, "message" => ($responseMessage), "callback" => $requestMethodArray['callback']);
        endif;
        // print_r($responseArray);
        echo @json_encode($responseArray);
    endif;
endif;
//-------------------------------------------------------------------------------
if (isset($requestMethodArray['AppModalLoader'])):
    $required = $requestMethodArray['AppModalLoader'];
    $modulePath = str_ireplace($engine->dashboard, '', $required['path']);
    $modalRequest = 1;
    $modalRequestParam = "";
    if ($required['modalRequestParam'] != NULL):
        $modalRequestParam = $required['modalRequestParam'];
    endif;
    $app = $engine;
    if (@$required['DataTable'] == 1):
        require '../../includes/dataTables.php';
    endif;
    $module = new Module_Class;
    require $required['required'] . '.php';
endif;