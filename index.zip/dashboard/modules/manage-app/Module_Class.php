<?php
/**
 * Created by PhpStorm.
 * User: Dauda Ibrahim
 * Date: 6/23/2020
 * Time: 10:14 PM
 */

class Module_Class extends Data_Access
{
    private $table_name;
    private $pk;

    public function __construct()
    {
        $this->initials();
        $this->dbConnect();
	    $this->engine = new SMBEngine;
    }

    public function createRecord($varParam = NULL)
    {

        $this->table_name = $varParam['tbl_scheme'];
        if (isset($varParam['pk']) && $varParam['pk'] !== "") {
            $this->pk = $varParam['pk'];
            $pkVal = $varParam[$this->pk];
            $getArray = array(
                "tbl_scheme" => $this->table_name,
                "condition" => [
                    $this->pk => $pkVal
                ]);
            $getRecord = $this->getRecord($getArray);
            if ($getRecord['response'] === "200"):
                $responseArray = App_Response::getResponse('000');
                $responseArray['message'] = "Record already exist";
                return $responseArray;
                exit;
            endif;
        }

        $fields = "";
        $values = "";
        foreach ($varParam as $field => $val):
            if ($field != "tbl_scheme" && $field !== "pk"):
                $fields .= $field . ', ';
                $values .= "'" . $this->engine->verify_input($val) . "'" . ',';
            endif;
        endforeach;
        $fields = rtrim($fields, ', ');
        $values = rtrim($values, ', ');

        $query = "INSERT INTO " . $this->dbScheme . "." . $this->table_name;
        $query .= " (" . $fields . ") VALUES (" . $values . ");";

        $res = $this->insertIntoDatabase($query);
        if ($res['response'] !== '200') {
            $responseArray = App_Response::getResponse('000');
            $responseArray['message'] = "Could'nt process request";
        } else {
            $res['message'] = "Request processed successfully";
            $responseArray = $res;
        }
        return $responseArray;
    }

    public function getRecord($varParam = NULL)
    {
        $this->table_name = $varParam['tbl_scheme'];
        $condition = "";
        $orders = "";
        $limits = "";

        if (isset($varParam['condition']) && @$varParam['condition'] !== NULL) {
            foreach ($varParam['condition'] as $field => $val):
                $condition .= '(' . $field . "= '" . $val . "')" . ' AND ';
            endforeach;
            $condition = " WHERE " . rtrim($condition, "AND ");
        }

        if (isset($varParam['order']) && $varParam['order'] !== "") {
            $orders = "ORDER BY " . $varParam['order'] . " ";
        }

        $query = "SELECT * FROM " . $this->dbScheme . "." . $this->table_name;
        $query .= $condition . " " . $orders . " ;";

        $res = $this->getResultSetArray($query);
        if ($res['response'] === '200') {
            $responseArray = $res;
        } else {
            $responseArray = App_Response::getResponse('000');
        }
        return $responseArray;

    }

    public function updateRecord($varParam = NULL)
    {
        //print_r($varParam);
        $this->table_name = $varParam['tbl_scheme'];
        $fields = "";
        $pk_field = "";
        if ($varParam != NULL) {
            foreach ($varParam as $field => $val):
                if ($field != "tbl_scheme" && $field != "pk" && $field != "pkField")
                    $fields .= $field . " = '" . $this->engine->verify_input($val) . "'" . ', ';
            endforeach;
            $fields = rtrim($fields, ", ");
            $pk_field = $varParam['pkField'] . "='" . $varParam['pk'] . "'";
        }
        $query = "UPDATE " . $this->dbScheme . "." . $this->table_name;
        $query .= " SET " . $fields . " WHERE " . $pk_field . ";";

        $res = $this->updateDatabaseTable($query);
        if ($res['response'] !== '200') {
            $responseArray = App_Response::getResponse('000');
            $responseArray['message'] = "Couldn't update record";
        } else {
            $res['message'] = "Update request successfully";
            $responseArray = $res;
        }
        return $responseArray;
    }

    public function deleteRecord($varParam = NULL)
    {
        $this->table_name = $varParam['tbl_scheme'];
        $pk = "";
        $fk = "";
        if (isset($varParam['pk']) && $varParam['pk'] != NULL) {
            foreach ($varParam['pk'] as $pkField => $pkVal):
                $pk .= $pkField . " = '" . $pkVal . "', ";
            endforeach;
            $pk = rtrim($pk, ', ');

            if (isset($varParam['fk']) && $varParam['fk'] != NULL) {
                foreach ($varParam['pk'] as $fkField => $fkVal):
                    foreach ($varParam['fk'] as $fk2):
                        $fk .= $fk2 . " = '" . $fkVal . "', ";
                    endforeach;
                endforeach;
                $fk = trim($fk, ', ');
                $fk_query = "DELETE FROM " . $this->dbScheme . "." . $this->table_name;
                $fk_query .= " WHERE (" . $fk . ");";
                @$this->deleteTableRecord($fk_query);

            }

            $query = "DELETE FROM " . $this->dbScheme . "." . $this->table_name;
            $query .= " WHERE (" . $pk . ");";

            $res = $this->deleteTableRecord($query);
            if ($res['response'] !== '200') {
                $responseArray = App_Response::getResponse('000');
                $responseArray['message'] = "Could'nt process request";
            } else {
                $res['message'] = "Delete request completed";
                $responseArray = $res;
            }
            return $responseArray;
        }
    }

    public
    function execCommand($varFunctionName, $varFunctionParams)
    {
        $returnArray = $this->getCommand($varFunctionName);
        if ($returnArray['success'] == FALSE) {
            return $returnArray;
        }
        $class = $returnArray['dataArray']['class'];
        $functionName = $returnArray['dataArray']['function_name'];
        $cObjectClass = new $class();
        $returnArray = $cObjectClass->$functionName($varFunctionParams);
        return $returnArray;
    }

    public
    function getCommand($varFunctionName)
    {
        $this->function_map = $this->loadFunctionMap([$varFunctionName]);
        if (isset($this->function_map)) {
            $dataArray['class'] = $this->function_map[$varFunctionName['function_name']]['class'];
            $dataArray['function_name'] = $this->function_map[$varFunctionName['function_name']]['function_name'];

            $returnArray = App_Response::getResponse('200');
            $returnArray['dataArray'] = $dataArray;
        } else {
            $returnArray = App_Response::getResponse('405');
        }
        return $returnArray;

    }

    private
    function loadFunctionMap($varParam)
    {
        return $this->function_map = [
            $varParam[0]['function_name'] => ['class' => $varParam[0]['class'], 'function_name' => $varParam[0]['function_name']],
        ];
    }

}