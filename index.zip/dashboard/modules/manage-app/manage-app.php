<?php
/**
 * Created by PhpStorm.
 * User: Dauda Ibrahim
 * Date: 6/23/2020
 * Time: 8:51 PM
 * File: App Management
 */
require "Module_Class.php";
$module = new Module_Class;
$modulePath = @$appSwitcher->modulePath($AppModule);
$req = $AppModuleRequest;

?>
<script src="<?php echo $modulePath ?>js.js"></script>
<input type="hidden" value="<?php echo $modulePath; ?>" id="ModulePath" readonly>
<div class="card card-primary card-outline card-outline-tabs">
    <div class="card-header p-0 border-bottom-0">
        <ul class="nav nav-tabs" id="custom-tabs-four-tab" role="tablist">
            <li class="nav-item">
                <a class="nav-link <?php if ($req == 'department-unit/'): echo 'active'; endif; ?>"
                   href="#/department-unit/" onclick="fetchURL(this.href)"><i class="fal fa-building"></i>
                    Department/Units</a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php if ($req == 'storage-location/'): echo 'active'; endif; ?>"
                   href="#/storage-location/" onclick="fetchURL(this.href)"><i class="fal fa-dolly"></i> Storage
                    Location</a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php if ($req == 'discount-vat/'): echo 'active'; endif; ?>"
                   href="#/discount-vat/" onclick="fetchURL(this.href)"><i class="fal fa-badge-percent"></i>
                    Discount/VAT</a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php if ($req == 'measure-unit/'): echo 'active'; endif; ?>"
                   href="#/measure-unit/" onclick="fetchURL(this.href)"><i class="fal fa-balance-scale"></i> Measure
                    Units</a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php if ($req == 'delivery-option/'): echo 'active'; endif; ?>"
                   href="#/delivery-option/" onclick="fetchURL(this.href)">Delivery Options</a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php if ($req == 'payment-settings/'): echo 'active'; endif; ?>"
                   href="#/payment-settings/" onclick="fetchURL(this.href)">Payment Settings</a>
            </li>
        </ul>
    </div>
    <div class="card-body">
        <div class="tab-content" id="custom-tabs-four-tabContent">
            <div class="tab-pane fade <?php if ($req == 'department-unit/'): echo 'show active'; endif; ?>"
                 id="custom-tabs-four-home" role="tabpanel"
                 aria-labelledby="custom-tabs-four-home-tab">
                <?php if ($req == 'department-unit/'): require "inc/department_unit.php"; endif; ?>
            </div>
            <div class="tab-pane fade <?php if ($req == 'discount-vat/'): echo 'show active'; endif; ?>"
                 id="custom-tabs-four-home" role="tabpanel"
                 aria-labelledby="custom-tabs-four-home-tab">
                <?php if ($req == 'discount-vat/'): require "inc/discount_vat.php"; endif; ?>
            </div>
            <div class="tab-pane fade <?php if ($req == 'measure-unit/'): echo 'show active'; endif; ?>"
                 id="custom-tabs-four-home" role="tabpanel"
                 aria-labelledby="custom-tabs-four-home-tab">
                <?php if ($req == 'measure-unit/'): require "inc/measure_unit.php"; endif; ?>
            </div>
            <div class="tab-pane fade <?php if ($req == 'storage-location/'): echo 'show active'; endif; ?>"
                 id="custom-tabs-four-home" role="tabpanel"
                 aria-labelledby="custom-tabs-four-home-tab">
                <?php if ($req == 'storage-location/'): require "inc/storage_location.php"; endif; ?>
            </div>
            <div class="tab-pane fade <?php if ($req == 'storage-location/'): echo 'show active'; endif; ?>"
                 id="custom-tabs-four-home" role="tabpanel"
                 aria-labelledby="custom-tabs-four-home-tab">
                <?php if ($req == 'payment-settings/'): require "inc/payment_settings.php"; endif; ?>
            </div>
        </div>
    </div>
    <!-- /.card -->
</div>
