<?php

require "Module_Class.php";
$module = new Module_Class;
$modulePath = @$appSwitcher->modulePath($AppModule);
$req = $AppModuleRequest;

//$appUsers = new App_Users;
//$req = $AppModuleRequest;
//$modulePath = @$appSwitcher->modulePath($AppModule);
?>
<script src="<?php echo $modulePath ?>js.js"></script>
<input type="hidden" value="<?php echo $modulePath; ?>" id="ModulePath" readonly>
<div class="card card-primary card-outline card-outline-tabs">
    <div class="card-header p-0 border-bottom-0">
        <ul class="nav nav-tabs app-menu" id="manage-users-tabs" role="tablist">
            <li class="nav-item">
                <a class="nav-link <?php if ($req == 'users-account/'): echo 'active'; endif; ?>"
                   href="#/users-account/" onclick="fetchURL(this.href)"><i class="fal fa-user-circle"></i> Users
                    Account</a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php if ($req == 'create-user/'): echo 'active'; endif; ?>"
                   href="#/create-user/" onclick="fetchURL(this.href)"><i class="fal fa-user-edit"></i>Create/Edit User</a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php if ($req == 'users-group/'): echo 'active'; endif; ?>" href="#/users-group/"
                   onclick="fetchURL(this.href)"><i class="fal fa-users-cog"></i> Users Group</a>
            </li>

        </ul>
    </div>
    <div class="card-body">
        <div class="tab-content" id="manage-users-tabContent">
            <div class="tab-pane fade <?php if ($req == 'users-account/'): echo 'active show'; endif; ?>"
                 id="users-tab" role="tabpanel" aria-labelledby="tabs-users-tabs">
                <?php if ($req == 'users-account/'): require "inc/users_account.php";endif; ?>
            </div>
            <div class="tab-pane fade <?php if ($req == 'create-user/'): echo 'active show'; endif; ?>"
                 id="create-new-tab" role="tabpanel" aria-labelledby="tabs-create-new-tab">
                <?php if ($req == 'create-user/'): require "inc/create_user.php"; endif; ?>

            </div>
            <div class="tab-pane fade <?php if ($req == 'users-group/'): echo 'active show'; endif; ?>" id="group-tab"
                 role="tabpanel" aria-labelledby="tabs-group-tab">
                <?php if ($req == 'users-group/'): require_once "inc/users_group.php"; endif; ?>
            </div>

        </div>
    </div>
    <!-- /.card -->
</div>

          