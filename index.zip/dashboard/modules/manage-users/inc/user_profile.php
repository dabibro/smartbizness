<?php $modulePath = $app->dashboard . "modules/manage-users/"; ?>
<style>
    label.cabinet {
        display: block;
        cursor: pointer;
    }

    label.cabinet input.file {
        position: relative;
        height: 100%;
        width: auto;
        opacity: 0;
        -moz-opacity: 0;
        filter: progid:DXImageTransform.Microsoft.Alpha(opacity=0);
        margin-top: -30px;
    }

    #item-upload {
        width: 230px;
        height: 230px;
        padding-bottom: 25px;
    }

    figure figcaption {
        position: absolute;
        bottom: 0;
        color: #fff;
        width: 100%;
        padding-left: 9px;
        padding-bottom: 5px;
        text-shadow: 0 0 10px #000;
    }
</style>
<div id="ProfileResponse"></div>
<div class="row">
    <div class="col-md-3">
        <div class="card card-light card-outline">
            <div class="card-body box-profile p-2">
                <div class="text-center position-relative">
                    <img class="profile-user-img img-fluid img-circle"
                         src="<?php echo $app->uploads . 'passports/' . @$auth['passport']; ?>"
                         alt="User profile picture" onerror="passport_handler(this);" id="passport-image">
                    <script>
                        function passport_handler(elem) {
                            elem.setAttribute('src', '<?php echo $app->uploads . 'passports/avatar.jpeg'; ?>');
                        }
                    </script>
                    <input type="file" name="passport-image" class="hide passport-file item-img">
                    <button class="position-absolute bg-transparent border-0" onclick="$('.passport-file').click();"><i
                                class="fal fa-pen"></i></button>
                </div>
                <h6 class="profile-username text-center"><?php echo @trim( @$auth['firstname'] . ' ' . @$auth['lastname'] ); ?></h6>

                <p class="text-muted text-center small mb-0"><b>Registered On:</b>
                    <br><?php echo @$engine->formatDate( $auth['created_on'] ); ?></p>

            </div>
        </div>
    </div>
    <div class="col-md-9">
        <form action="" class="UpdateProfile mb-0" id="profile-form">
            <div class="row">
                <div class="col-6">
                    <div class="form-group">
                        <label for="">First Name</label>
                        <input type="text" name="firstname" class="form-control form-control-sm"
                               value="<?php echo @$auth['firstname']; ?>" required
                               placeholder="First Name" autocomplete="off">
                        <div class="invalid-feedback">* Enter your first name</div>
                    </div>
                </div>
                <div class="col-6">
                    <div class="form-group">
                        <label for="">Last Name</label>
                        <input type="text" name="lastname" class="form-control form-control-sm"
                               value="<?php echo @$auth['lastname']; ?>" required
                               placeholder="Last Name" autocomplete="off">
                        <div class="invalid-feedback">* Enter your las name</div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-6">
                    <div class="form-group">
                        <label for="">Date of Birth</label>
                        <input type="text" name="date_of_birth" class="form-control datepicker form-control-sm"
                               value="<?php if ( $auth['date_of_birth'] != '0000-00-00' ) {
							       echo @$auth['date_of_birth'];
						       } ?>" placeholder="Date of Birth"
                               autocomplete="off" required>
                        <div class="invalid-feedback">* Select your date of birth</div>
                    </div>
                </div>
                <div class="col-6">
                    <div class="form-group">
                        <label for="">Gender</label>
                        <select name="gender" class="form-control select2 form-control-sm" required>
                            <option value="">-- Select Gender --</option>
							<?php
							$genders       = array( "Male", "Female" );
							$genders_count = count( $genders );
							$x             = 0;
							while ( $x < $genders_count ):
								?>
                                <option value="<?php echo $genders[ $x ]; ?>" <?php if ( $genders[ $x ] == $auth['gender'] ):echo 'selected';endif; ?>>
									<?php echo $genders[ $x ]; ?>
                                </option>
								<?php $x ++; endwhile; ?>

                        </select>
                        <div class="invalid-feedback">* Select your gender</div>
                    </div>
                </div>
            </div>
            <label class="text-muted mt-3"><i class="fal fa-address-card"></i> Contact Information</label>
            <hr class="my-2">
            <div class="row">
                <div class="col-6">
                    <div class="form-group">
                        <label for="">Email Address</label>
                        <input type="text" name="contact_email" class="form-control form-control-sm"
                               value="<?php echo @$auth['contact_email']; ?>">
                    </div>
                </div>
                <div class="col-6">
                    <div class="form-group">
                        <label for="">Phone Number</label>
                        <input type="text" name="contact_phone" placeholder="Phone Number"
                               class="form-control form-control-sm"
                               value="<?php echo @$auth['contact_phone']; ?>"
                               required autocomplete="off">
                        <div class="invalid-feedback">* Enter your phone number</div>

                    </div>
                </div>
            </div>
            <div class="form-group">
                <label for="">Contact Address</label>
                <textarea class="form-control form-control-sm" rows="4" required placeholder="Contact Address"
                          name="contact_address"
                          autocomplete="off"><?php echo @$auth['contact_address']; ?></textarea>
                <div class="invalid-feedback">* Enter your contact address</div>

            </div>
            <hr class="my-2">
            <button class="btn btn-default btn-sm actionButton"><i class="fal fa-check-circle"></i> Update
                Profile
            </button>
            <input type="hidden" name="UpdateProfile" value="1">
        </form>
    </div>

</div>
<div class="modal fade" id="ProfilePhotoCropper" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog" role="document" style="max-width: 350px !important; margin: 3rem auto;">
        <div class="modal-content x_panel bg-light border-0 br-0">
            <div class="modal-body card-body text-center  p-3" id="cropper-loader-contents">
                <div id="item-upload" class="center-block"></div>
            </div>
            <div class="modal-footer">
                <button type="button" id="cropImageBtn" class="btn btn-default btn-sm"><i class="fal fa-save"></i>
                    Crop & Save Photo
                </button>
                <button type="button" class="btn btn-danger btn-sm closeCropper"><i
                            class="fal fa-times-circle"></i>
                    Close
                </button>

            </div>
        </div>
    </div>
</div>
<script>
    var date_input = $('.datepicker'); //our date input has the name "date"
    var container = $('.bootstrap-iso form').length > 0 ? $('.bootstrap-iso form').parent() : "body";
    date_input.datepicker({format: 'yyyy-mm-dd', container: container, todayHighlight: true, autoclose: true,});

    $('.UpdateProfile').bootstrap3Validate(function (e, data) {
        "use strict";
        e.preventDefault();
        var actionButton = $("#" + this.id + ' .actionButton').html();
        var formId = this.id;
        $("#" + this.id + ' .actionButton').html('<i class="fal fa-spin fa-spinner"></i> Processing...');
        $.ajax({
            url: "<?php echo $modulePath; ?>ajaxRequest.php",
            type: "POST",
            data: new FormData(this),
            contentType: false,
            cache: false,
            processData: false,
            success: function (data) {
                $("#ProfileResponse").html(data);
                $("#" + formId + ' .actionButton').html(actionButton);
            },
            error: function () {
            }
        });
    });

    var $uploadCrop,
        tempFilename,
        rawImg,
        imageId;

    function readFile(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            reader.onload = function (e) {
                $('.item-upload').addClass('ready');
                $('#ProfilePhotoCropper').modal('show');
                rawImg = e.target.result;
            }
            reader.readAsDataURL(input.files[0]);
        }
        else {
            swal("Sorry - you're browser doesn't support the FileReader API");
        }
    }

    $(".closeCropper").on('click', function () {
        $('#ProfilePhotoCropper').modal('hide');
        AppModalLoader({
            modalId: 'ModuleModal',
            modalSize: 'modal-lg',
            modalTitle: 'My Profile',
            required: '../manage-users/inc/user_profile',
            afterEvent: 'reloadApp()'
        })
    });

    $uploadCrop = $('#item-upload').croppie({
        viewport: {
            width: 180,
            height: 180,
        },
        enforceBoundary: false,
        enableExif: true
    });
    $('#ProfilePhotoCropper').on('shown.bs.modal', function () {
        // alert('Shown pop');
        $uploadCrop.croppie('bind', {
            url: rawImg
        }).then(function () {
            console.log('jQuery bind complete');
        });
    });

    $('.item-img').on('change', function () {
        imageId = $(this).data('id');
        tempFilename = $(this).val();
        $('#cancelCropBtn').data('id', imageId);
        readFile(this);
    });

    $('#cropImageBtn').on('click', function (ev) {
        $uploadCrop.croppie('result', {
            type: 'base64',
            format: 'png',
            size: {width: 180, height: 180}
        }).then(function (resp) {
            $('#passport-image').attr('src', resp);
            $.post("<?php echo $modulePath; ?>ajaxRequest.php", {
                ProfilePhoto: resp,
            }, function (response) {
                $("#ProfileResponse").html(response);
            });
            //$("#image-field").val(resp);
            //$('#ProfilePhotoCropper').modal('hide');

        });
    });

</script>