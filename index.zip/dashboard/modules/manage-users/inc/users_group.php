<?php

@$requestArray = array(
    "tbl_scheme" => 'app_users_group',
    "order" => 'name ASC');
@$recordRequest = $module->getRecord($requestArray);
@$recordsArray = $recordRequest['dataArray'];
if (@$requestMethodArray['request'] == "update" && @$requestMethodArray['pk'] != "" && @$requestMethodArray['pkField'] != ""):
    $pk = $requestMethodArray['pk'];
    $pkField = $requestMethodArray['pkField'];

    $getUpdateArray = array(
        "tbl_scheme" => 'app_users_group',
        "condition" => [$pkField => $pk],
        "limit" => 1
    );
    $getUpdate = $module->getRecord($getUpdateArray);
    extract($getUpdate['dataArray'][0]);

endif;
?>
<div class="row">
    <div class="col-lg-4 col-12 mb-lg-0 mb-3">
        <fieldset class="card-body border">
            <legend class="col-auto h6"><i class="fal fa-edit"></i> Group Record</legend>
            <div id="result"></div>
            <form method="post" class="AppForm" id="AppUserGroupForm" novalidate>
                <div id="ModuleResponse"></div>
                <div class="form-group">
                    <label for="">Group Name</label>
                    <input type="text" name="name" autocomplete="off" class="form-control form-control-sm" required
                           placeholder="Group Name"
                           value="<?php echo @$name; ?>">
                    <div class="invalid-feedback">* Required field</div>

                </div>
                <div class="form-group">
                    <label for="">Group Description</label>
                    <textarea class="form-control form-control-sm" name="description" rows="3"
                              placeholder="Group Description"><?php echo @$description; ?></textarea>
                </div>
                <?php if (@$getUpdate['response'] === "200"): ?>
                    <div class="form-group mt-3">
                        <div class="custom-control custom-switch">
                            <input type="checkbox" <?php if (@$active_status == 1): echo 'checked';endif; ?>
                                   class="custom-control-input propToggle" id="active_status">
                            <label class="custom-control-label" for="active_status"> Active Status</label>
                            <input type="hidden" readonly name="active_status" class="active_status"
                                   value="<?php if (@$active_status == 1): echo 1; else: echo 0;endif; ?>">
                        </div>
                    </div>
                <?php endif; ?>
                <hr class="my-3">
                <input type="hidden" name="className" value="Module_Class" readonly>
                <?php if (@$getUpdate['response'] === "200"): ?>
                    <input type="hidden" name="functionName" value="updateRecord" readonly>
                    <input type="hidden" name="pk" value="<?php echo @$pk; ?>" readonly>
                    <input type="hidden" name="pkField" value="<?php echo @$pkField; ?>" readonly>
                <?php else: ?>
                    <input type="hidden" name="functionName" value="createRecord" readonly>
                <?php endif; ?>
                <input type="hidden" name="callback[type]" value="self" readonly>
                <input type="hidden" name="callback[redirect]" value="" readonly>
                <input type="hidden" name="tbl_scheme" value="app_users_group" readonly>
                <input type="hidden" name="created_by"
                       value="<?php echo trim(@$auth['firstname'] . ' ' . @$auth['lastname']); ?>" readonly>

                <button class="btn btn-default actionButton btn-sm"><i class="fal fa-check-circle"></i> Submit</button>
            </form>
        </fieldset>
    </div>

    <div class="col-lg-8 col-12">
        <div class="table-responsive">
            <table id="example2" class="table dataTables-Sort table-sm elevation-1 data-tables">
                <thead>
                <th>Group Name</th>
                <th>Users #</th>
                <th>Active Status</th>
                <th>Created On</th>
                <th></th>
                </thead>
                <tbody class="card-body">

                <?php if (isset($recordsArray)):
                    foreach (@$recordsArray as $record):
                        extract($record);
                        ?>
                        <tr class="data-btn">
                            <td><?php echo @$name; ?></td>
                            <td><?php echo @count($module->getRecord(["tbl_scheme" => 'app_users', "condition" => ["user_group" => $group_id]])['dataArray']);//$users_count;
                                ?></td>
                            <td><?php if (@$active_status == 1):echo 'Active'; else:echo 'Inactive'; endif; ?></td>
                            <td class="small text-muted"><?php echo @$creation_date; ?></td>
                            <td align="right" class="py-1">
                                <div class="btn-group-justify btn-group-sm float-right">
                                    <button type="button" class="btn btn-default"
                                            onclick='javascript: var obj = "<?php echo urlencode('"pkField":"group_id","pk":' . $group_id . ',"view":"/#/users-group/","request":"update"'); ?>"; moduleEditRequest(obj)'
                                            title="configure group access right" data-toggle="tooltip"><i
                                                class="fal fa-user-lock"></i>
                                    </button>
                                    <button type="button" class="btn btn-default"
                                            onclick='javascript: var obj = "<?php echo urlencode('"pkField":"group_id","pk":' . $group_id . ',"view":"/#/users-group/","request":"update"'); ?>"; moduleEditRequest(obj)'
                                            title="Update user group" data-toggle="tooltip"><i
                                                class="fal fa-edit"></i>
                                    </button>
                                    <button type="button" class="btn btn-default"
                                            onclick='javascript: var obj = "<?php echo urlencode('"className":"Module_Class","functionName":"deleteRecord","tbl_scheme":"app_users_group","pk":{"group_id":' . $group_id . '},"callback":{"type":"self","redirect":""},"notification":{"message":"Are you sure to delete this record?","title":"Delete Warning"}'); ?>";  moduleRequest(obj);'
                                            title="Delete user group" data-toggle="tooltip"><i
                                                class="fal fa-trash-alt"></i>
                                    </button>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>