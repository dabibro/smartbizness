<?php
if ( @$requestMethodArray['request'] == "update" && @$requestMethodArray['pk'] != "" && @$requestMethodArray['pkField'] != "" ):
	$pk      = $requestMethodArray['pk'];
	$pkField = $requestMethodArray['pkField'];

	$getUpdateArray = array(
		"tbl_scheme" => 'app_users',
		"condition"  => [ $pkField => $pk ],
		"limit"      => 1
	);
	$getUpdate      = $module->getRecord( $getUpdateArray );
	extract( $getUpdate['dataArray'][0] );
endif;
?>

<div class="position-relative">

    <form method="post" class="AppForm" id="AppUserForm">
        <div id="ModuleResponse"></div>
        <div class="row">
            <div class="col-2">
                <div class="nav flex-column nav-tabs h-100" id="vert-tabs-tab" role="tablist"
                     aria-orientation="vertical">
                    <a class="nav-link active" id="basic-tabs" data-toggle="pill" href="#basic-tabs-panel" role="tab"
                       aria-controls="basic-tabs-panel" aria-selected="false"><i class="fal fa-info-circle"></i> User
                        Account
                        <hr class="my-1">
                        <small class="text-muted">Fill in the user personal information to create/update account.
                        </small>
                    </a>
                </div>
            </div>
            <div class="col-8">
                <label class="text-muted">Personal Information</label>
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="firstname"><span class="required">*</span> Firstname</label>
                            <input name="firstname" type="text" required class="form-control form-control-sm "
                                   placeholder="Firstname"
                                   value="<?php echo @$firstname ?>" autocomplete="off">
                            <div class="invalid-feedback">* Require field</div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label><span class="required">*</span> Surname</label>
                            <input name="lastname" type="text" required
                                   class="form-control form-control-sm" placeholder="Lastname"
                                   value="<?php echo @$lastname; ?>" autocomplete="off">
                            <div class="invalid-feedback">* Required field</div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label>Email Address</label>
                            <div class="controls">
                                <input name="contact_email" type="email" class="form-control form-control-sm"
                                       value="<?php echo @$contact_email; ?>" placeholder="Email Address"
                                       autocomplete="off">
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label><span class="required">*</span> Contact Number</label>
                            <div class="controls">
                                <input name="contact_phone" type="text" class="form-control form-control-sm" required
                                       value="<?php echo @$contact_phone ?>" placeholder="Phone No."
                                       autocomplete="off">
                                <div class="invalid-feedback">* Require field</div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="form-group">
                    <label>Contact Address</label>
                    <textarea name="contact_address" class="form-control form-control-sm" rows="4"
                              style="min-height: 4rem; max-height: 5.8rem"
                              placeholder="Contact Address"
                              autocomplete="off"><?php echo @$contact_address ?></textarea>
                </div>
                <label class="text-muted">Account Information</label>
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label>Department/Unit</label>
                            <select name="dept_id" class="form-control form-control-sm select2">
                                <option value="">-- Select --</option>
								<?php
								$deptParam     = array( "tbl_scheme" => 'app_department_unit' );
								$listArray     = $module->getRecord( $deptParam );
								$dropDownArray = array();
								foreach ( $listArray['dataArray'] as $dept_unit ):
									echo $app->dropDownList( $dept_unit['id'], $dept_unit['name'], @$dept_id );
								endforeach; ?>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label>Store</label>
                            <select name="store_id" class="form-control form-control-sm select2">
                                <option value="">-- Select --</option>
								<?php
								$storeParam    = array(
									"tbl_scheme" => 'app_stores',
									"condition"  => [ 'active_status' => 1 ]
								);
								$listArray     = $module->getRecord( $storeParam );
								$dropDownArray = array();
								foreach ( $listArray['dataArray'] as $dept_unit ):
									echo $app->dropDownList( $dept_unit['app_id'], $dept_unit['store_name'], @$store_id );
								endforeach; ?>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label><span class="required">*</span> User Group</label>
                            <select name="user_group" required class="form-control form-control-sm select2">
                                <option value="">-- Select --</option>
								<?php
								$groupParam    = array(
									"tbl_scheme" => 'app_users_group',
									"condition"  => [ 'active_status' => 1 ]
								);
								$listArray     = $module->getRecord( $groupParam );
								$dropDownArray = array();
								foreach ( $listArray['dataArray'] as $dept_unit ):
									echo $app->dropDownList( $dept_unit['group_id'], $dept_unit['name'], @$user_group );
								endforeach; ?>
                            </select>
                            <div class="invalid-feedback">* Required field</div>

                        </div>
                    </div>
                    <div class="col-6">
						<?php if ( @$getUpdate['response'] === "200" ): ?>
                            <div class="form-group text-right">
                                <label for="">&nbsp;</label>
                                <div class="form-check">
                                    <input class="form-check-input" name="change-password" id="change-password"
                                           type="checkbox" value="1">
                                    <label class="form-check-label" for="change-password">Change Password</label>
                                </div>
                            </div>
						<?php endif; ?>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group mb-0">
                            <label><span class="required">*</span> Username</label>
                            <input name="username" type="text" class="form-control form-control-sm"
                                   value="<?php echo @$username; ?>" autocomplete="off"
                                   placeholder="Username" required>
                            <div class="invalid-feedback">* Required field</div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group mb-0">
                            <label for=""><span class="required">*</span> Password</label>
                            <input name="password" type="password" class="form-control form-control-sm" required
                                   value="<?php echo @$password ?>" placeholder="Password" autocomplete="off">
                            <div class="invalid-feedback">* Required field</div>
                        </div>
                    </div>

                </div>
                <hr class="my-3">
                <div class="btn-group mb-2">
                    <button class="btn btn-default btn-sm px-4" type="submit"><i class="fal fa-check-circle"></i>
                        Submit
                    </button>
                </div>

            </div>

        </div>

        <input type="hidden" name="className" value="Module_Class" readonly>
		<?php if ( @$getUpdate['response'] === "200" ): ?>
            <input type="hidden" name="functionName" value="updateRecord" readonly>
            <input type="hidden" name="pk" value="<?php echo @$pk; ?>" readonly>
            <input type="hidden" name="pkField" value="<?php echo @$pkField; ?>" readonly>
		<?php else: ?>
            <input type="hidden" name="functionName" value="createRecord" readonly>
		<?php endif; ?>
        <input type="hidden" name="callback[type]" value="self" readonly>
        <input type="hidden" name="callback[redirect]" value="" readonly>
        <input type="hidden" name="tbl_scheme" value="app_users" readonly>
        <input type="hidden" name="created_by"
               value="<?php echo trim( @$auth['firstname'] . ' ' . @$auth['lastname'] ); ?>" readonly>
    </form>
</div>
