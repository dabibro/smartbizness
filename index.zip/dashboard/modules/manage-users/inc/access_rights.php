<?php
//-----------------------------------------------
//if (@$access['user_group_rights'] != '1' && @$access['access_right'] != '1'):echo '<script>location.replace("' . WEB_ROOT . '")</script>'; endif;

//------------------------------------------------
//$entity = $_GET['type'];
//$entity_id = $_GET['id'];
//------------------------------------------------
if ($entity === 'user'):
    $entity_tbl = 'app_user_rights';
    $pkField = 'user_id';
    $tbl_scheme = 'app_users';
    $tbl_scheme_pkField = 'user_id';
else:
    $entity_tbl = 'app_users_group';
    $pkField = 'id';
    $tbl_scheme = 'app_users_group';
    $tbl_scheme_pkField = 'id';
endif;
//------------------------------------------------
$getInfo = array(
    "tbl_scheme" => $tbl_scheme,
    "condition" => [$tbl_scheme_pkField => $entity_id]
);
$info = $module->getRecord($getInfo)['dataArray'][0];
//------------------------------------------------
$getParam = array(
    "tbl_scheme" => $entity_tbl,
    "condition" => [$pkField => $entity_id]
);
$getRecord = $module->getRecord($getParam);
if ($getRecord['response'] == '200'):
    @$getRoles = $getRecord['dataArray'][0]['access_right'];
    @$roles = json_decode($getRoles, true);
    @$count = count($roles);
endif;

?>
<style>
    #permission .card-body .fal {
        font-size: 0.9rem;
        position: relative;
        bottom: -1px;
        text-align: center;
    }

    #permission label {
        font-weight: normal;
        font-size: 0.85rem;
        cursor: pointer;
    }

    table tbody td {
        font-size: 0.85rem;
        padding-bottom: 0px !important;
    }

    input, label {
        cursor: pointer;
    }

    tbody .fal {
        margin-right: 3px;
        width: 16px;
    !important;

    }
</style>

<form method="post" class="AppForm" id="permission" novalidate>
    <div class="row">
        <div class="col-md-8">
            <div class="text-muted btn">
                <i class="fal fa-info-circle"></i>
                <?php if ($entity == 'group') { ?>
                    Group Name:
                    <?php echo @$info['group_name']; ?>
                <?php } else { ?>
                    Fullname: <?php echo @$info['firstname'] . ' ' . @$info['lastname']; ?>
                <?php } ?>
            </div>
        </div>
        <div class="col-lg-auto ml-auto text-right">
            <div class="btn-group-justified btn-group-sm mb-0">
                <button class="btn btn-default actionButton"><i
                            class="fal fa-check-circle"></i> Submit Changes
                </button>
                <?php if ($entity == 'group') { ?>
                    <button class="btn btn-default" onClick="loadAccessRight('group', '<?php echo $id; ?>')"><i
                                class="fal fa-sync"></i> Refresh
                    </button>
                <?php } else { ?>
                    <button class="btn btn-default" onClick="loadAccessRight('user', '<?php echo $id; ?>')"><i
                                class="fal fa-sync"></i> Refresh
                    </button>
                <?php } ?>
            </div>

        </div>
    </div>
    <hr class="mb-0 mt-1">
    <div class="progress loader mt-0 hide" style="height:8px;">
        <div class="progress-bar progress-bar-striped progress-bar-animated bg-info active small"
             role="progressbar" aria-valuenow="40" aria-valuemin="0" aria-valuemax="100" style="width:100%">
            Processing ...
        </div>
    </div>
    <div id="ModuleResponse"></div>
    <div class="mt-2 text-right">
        <div class="form-group">
            <div class="custom-control custom-switch">
                <input type="checkbox"
                       class="custom-control-input checkboxToggle" <?php if (@$count > 0): echo 'checked'; endif; ?>
                       id="customSwitch1">
                <label class="custom-control-label pt-1" for="customSwitch1">Check/Uncheck All</label>
            </div>
        </div>
    </div>
    <div class="row mt-3 AppAccessRight">
        <div class="col-md-6 col-lg-4 col-sm-12">
            <div class="card-body elevation-1 p-2">
                <label class="text-muted"><i class="fal fa-users"></i> Manage People</label>
                <hr class="my-1">
                <table widtd="100%" class="table  table-sm table-borderless">
                    <tdead>
                        <td colspan="2">Permissions</td>
                        <td><a href="#" title="Create/Edit" data-toggle="tooltip"><i
                                        class="fal fa-user-edit"></i></a></td>
                        <td><a href="#" title="Access Right" data-toggle="tooltip"><i
                                        class="fal fa-cogs"></i></a>
                        </td>
                        <td><a href="#" title="User Activation" data-toggle="tooltip"><i
                                        class="fal fa-lock"></i></a>
                        </td>
                        <td><a href="#" title="Delete" data-toggle="tooltip"><i class="fal fa-trash"></i></a>
                        </td>
                    </tdead>
                    <tbody class="text-left">
                    <!-- Manage Users-->
                    <tr>
                        <td><input name="role[users]" id="users" type="checkbox" value="1" <?php
                            if (@$roles['users'] == '1') {
                                echo 'checked';
                            }
                            ?>>
                        </td>
                        <td>
                            <label for="users"><i class="fal fa-user-circle"></i> Manage Users </label>
                        </td>
                        <td>
                            <input name="role[user_record]" type="checkbox" value="1" <?php
                            if (@$roles['user_record'] == '1') {
                                echo 'checked';
                            }
                            ?>>
                        </td>
                        <td>
                            <input name="role[access_right]" type="checkbox" id="access_right" value="1" <?php
                            if (@$roles['access_right'] == '1') {
                                echo 'checked';
                            }
                            ?>>
                        </td>
                        <td>
                            <input name="role[user_activation]" id="user_activation" type="checkbox" value="1" <?php
                            if (@$roles['user_activation'] == '1') {
                                echo 'checked';
                            }
                            ?>>
                        </td>
                        <td>
                            <input name="role[delete_user]" type="checkbox" value="1" <?php
                            if (@$roles['delete_user'] == '1') {
                                echo 'checked';
                            }
                            ?> >
                        </td>
                    </tr>
                    </tbody>
                </table>
            </div>
        </div>
        <div class="col-md-6 col-lg-4 col-sm-12">
            <div class="card-body elevation-1 p-2">
                <label class="text-muted"><i class="fal fa-ballot"></i> Manage Submission</label>
                <hr class="my-1">
                <table widtd="100%" class="table table-borderless table-sm">
                    <tdead>
                        <td colspan="2">Permissions</td>
                        <td><a href="#" title="Create" data-toggle="tooltip"><i class="fal fa-plus-square"></i></a>
                        </td>
                        <td><a href="#" title="Print" data-toggle="tooltip"><i class="fal fa-print"></i></a></td>
                        <td><a href="#" title="Delete" data-toggle="tooltip"><i class="fal fa-trash"></i></a>
                        </td>
                    </tdead>
                    <tbody class="text-left">
                    <tr>
                        <td><input name="role[submissions]" id="submissions" type="checkbox" value="1" <?php
                            if (@$roles['submissions'] == '1') {
                                echo 'checked';
                            }
                            ?>>
                        </td>
                        <td>
                            <label for="submissions"> <i class="fal fa-clipboard-check"></i>
                                Submission</label>
                        </td>
                        <td>
                            <input name="role[submission_record]" type="checkbox" id="submission_record"
                                   value="1" <?php
                            if (@$roles['submission_record'] == '1') {
                                echo 'checked';
                            }
                            ?>>
                        </td>
                        <td>
                            <input name="role[print_submission]" id="print_submission" type="checkbox" title="Bill Payment"
                                   data-toggle="tooltip"
                                   value="1" <?php
                            if (@$roles['print_submission'] == '1') {
                                echo 'checked';
                            }
                            ?>>
                        </td>
                        <td>
                            <input name="role[delete_submission]" id="delete_submission" type="checkbox"
                                   value="1" <?php
                            if (@$roles['delete_submission'] == '1') {
                                echo 'checked';
                            }
                            ?>>
                        </td>
                    </tr>
                    <tr>
                        <td><input name="role[category]" id="category" type="checkbox" value="1" <?php
                            if (@$roles['category'] == '1') {
                                echo 'checked';
                            }
                            ?>>
                        </td>
                        <td>
                            <label for="category"> <i class="fal fa-wallet"></i> Category</label>
                        </td>
                        <td>

                        </td>
                        <td>
                        </td>
                        <td>
                            <input name="role[delete_category]" id="delete_category" type="checkbox"
                                   value="1" <?php
                            if (@$roles['delete_category'] == '1') {
                                echo 'checked';
                            }
                            ?>>
                        </td>
                    </tr>
                    </tbody>
                </table>
            </div>
        </div>

        <div class="col-md-6 col-lg-4 col-sm-12">
            <div class="card-body elevation-1 p-2">
                <label class="text-muted"><i class="fal fa-sliders-h-square"></i> Manage Templates</label>
                <hr class="my-1">
                <table widtd="100%" class="table table-borderless table-sm">
                    <tbody class="text-left">
                    <tr>
                        <td><input name="role[manage_templates]" id="manage_templates" type="checkbox" value="1" <?php
                            if (@$roles['manage_templates'] == '1') {
                                echo 'checked';
                            }
                            ?>>
                        </td>
                        <td>
                            <label for="manage_templates"> <i class="fal fa-table"></i>
                                Manage Template</label>
                        </td>
                    </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <input type="hidden" name="AppAccessRight" value="1" readonly>
    <input type="hidden" name="entity_id" value="<?php echo @$entity_id; ?>">
    <input type="hidden" name="entity_type" value="<?php echo @$entity; ?>">
    <input type="hidden" name="callback[type]" value="self" readonly>
</form>
<?php if (@$getUpdate['response'] === "200"): ?>
    <input type="hidden" name="functionName" value="updateRecord" readonly>
    <input type="hidden" name="pk" value="<?php echo @$pk; ?>" readonly>
    <input type="hidden" name="pkField" value="id" readonly>
<?php else: ?>
    <input type="hidden" name="functionName" value="createRecord" readonly>
    <input type="hidden" name="pk" value="group_name" readonly>
<?php endif; ?>

<input type="hidden" name="callback[type]" value="self" readonly>
<input type="hidden" name="callback[redirect]" value="" readonly>
<input type="hidden" name="tbl_scheme" value="app_users_group" readonly>