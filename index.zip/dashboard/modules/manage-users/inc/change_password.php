<?php $modulePath = $app->dashboard . "modules/manage-users/"; ?>
<form method="post" class="ChangePassword" id="change-password-form">
    <div id="PasswordResponse"></div>
    <div class="form-group">
        <label>Current Password</label>
        <input name="current_password" type="password" required="required" class="form-control form-control-sm"
               id="current_password" placeholder="Current  Password" autocomplete="off">
        <div class="invalid-feedback">* Enter current password</div>
    </div>
    <div class="form-group">
        <label>New Password</label>
        <input name="new_password" type="password" required="required" class="form-control form-control-sm"
               id="new_password" placeholder="New Password" autocomplete="off">
        <div class="invalid-feedback">* Enter new password</div>
    </div>
    <div class="form-group">
        <label>Confirm Password</label>
        <input name="password" type="password" required="required" class="form-control form-control-sm"
               id="password" placeholder="Confirm Password" autocomplete="off">
        <div class="invalid-feedback">* Enter password confirmation</div>
    </div>
    <input type="hidden" name="ChangePassword" value="1">
    <div class="py-2 px-2 alert-info small"><i class="fal fa-info-circle fa-lg"></i> Your will be logged
        out
        after you change your password. You will be required to login.
    </div>
    <hr>
    <div class=" btn-group-justified">
        <button class="btn btn-default btn-sm actionButton"><i class="fal fa-check-circle"></i> Change
        </button>
        <button type="button" class="btn btn-danger btn-sm" data-dismiss="modal"><i
                    class="fal fa-times-circle"></i>
            Close
        </button>
    </div>
</form>

<script>
    $('.ChangePassword').bootstrap3Validate(function (e, data) {
        "use strict";
        e.preventDefault();
        var actionButton = $("#" + this.id + ' .actionButton').html();
        var formId = this.id;
        $("#" + this.id + ' .actionButton').html('<i class="fal fa-spin fa-spinner"></i> Processing...');
        $.ajax({
            url: "<?php echo $modulePath; ?>ajaxRequest.php",
            type: "POST",
            data: new FormData(this),
            contentType: false,
            cache: false,
            processData: false,
            success: function (data) {
                $("#PasswordResponse").html(data);
                $("#" + formId + ' .actionButton').html(actionButton);
            },
            error: function () {
            }
        });
    });
</script>