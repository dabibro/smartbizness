<?php
/**
 * Created by DTMGS Limited.
 * User: Dauda Ibrahim
 * Date: 6/23/2020
 * Time: 9:40 PM
 * File: Module Classes
 */
if ( file_exists( "../../../helpers/config/config.inc.php" ) ):
	require "../../../helpers/config/config.inc.php";
endif;
require "../../../helpers/handlers/app_autoloader.php";
require "Module_Class.php";
$engine        = new SMBEngine;
$AppResponse   = new App_Response;
$AppAuth       = new Auth_Access;
$auth          = $AppAuth->AppAuthChecker();
$requestMethod = $_SERVER['REQUEST_METHOD'];
if ( in_array( $requestMethod, [ "GET", "POST", "PUT", "DELETE", "OPTIONS" ] ) ):
	$requestMethodArray = array();
	$requestMethodArray = $_REQUEST;
	//--------------------------------------------------------------------------------------------------
	if ( isset( $requestMethodArray['notification'] ) && ! isset( $requestMethodArray['confirmed'] ) ):
		$tmpl = "../../tmpl/notification.html";
		echo $engine->fileTempParse( $tmpl, $requestMethodArray );
		exit;
	endif;
	//--------------------------------------------------------------------------------------------------
	if ( isset( $requestMethodArray['className'] ) && isset( $requestMethodArray['functionName'] ) ):
		$getCommandArray = array(
			"class"         => $requestMethodArray['className'],
			"function_name" => $requestMethodArray['functionName']
		);
		$functionArray   = [];
		foreach ( $requestMethodArray as $key => $val ):
			if ( $key !== "className" && $key !== "functionName" && $key !== "callback" ) {
				$functionArray += array( $key => $val );
			}
		endforeach;
		$module    = new $requestMethodArray['className'];
		$execution = $module->execCommand( $getCommandArray, $functionArray );
		if ( $execution['response'] === "200" ):
			// print_r($requestMethodArray);
			$responseMessage = App_Response::alertResponse( $execution['message'], 'success' );
			if ( $requestMethodArray['callback']['type'] == "self" ):
				$responseArray = array( "success" => 1, "message" => ( $responseMessage ), "callback" => 'self' );

			endif;
		else:
			$responseMessage = App_Response::alertResponse( $execution['message'], 'danger' );
			$responseArray   = array( "success" => 0, "message" => ( $responseMessage ) );
		endif;
		echo json_encode( $responseArray );
	endif;
	//--------------------------------------------------------------------------------------------------
	if ( isset( $requestMethodArray['UpdateProfile'] ) && $requestMethodArray['UpdateProfile'] !== "" ):
		$module        = new Module_Class;
		$functionArray = [
			"tbl_scheme" => "app_users",
			"pk"         => $auth['user_id'],
			"pkField"    => 'user_id'
		];
		foreach ( $requestMethodArray as $key => $val ):
			if ( $key !== "UpdateProfile" ):
				$functionArray += array( $key => $val );
			endif;
		endforeach;
		$updateProfile = $module->updateRecord( $functionArray );
		if ( $updateProfile['response'] === "200" ):
			echo App_Response::alertResponse( "Profile successfully updated", "success" );
		endif;
	endif;
	//--------------------------------------------------------------------------------------------------
	if ( isset( $requestMethodArray['ProfilePhoto'] ) && $requestMethodArray['ProfilePhoto'] !== "" ):
		$cropped_image = @$requestMethodArray['ProfilePhoto'];
		list( $type, $cropped_image ) = explode( ';', $cropped_image );
		list( , $cropped_image ) = explode( ',', $cropped_image );
		$cropped_image = base64_decode( $cropped_image );
		$getImageName  = $auth['username'];
		$image_name    = $getImageName . '.png';
		$file_path     = '../../uploads/passports/';
		$upload        = file_put_contents( $file_path . $image_name, $cropped_image );
		if ( $upload ):
			@Data_Access::execSQL( "UPDATE " . $engine->dbScheme . ".app_users SET passport = '$image_name' WHERE user_id = '" . $auth['user_id'] . "'" );
		endif;
	endif;
	//--------------------------------------------------------------------------------------------------
	if ( isset( $requestMethodArray['ChangePassword'] ) && $requestMethodArray['ChangePassword'] == 1 ):
		$getCurrent       = Data_Access::fetchAssoc( @Data_Access::execSQL( "SELECT password FROM " . $engine->dbScheme . ".app_users WHERE user_id = '" . $auth['user_id'] . "'" )['dataArray'] )['dataArray'][0];
		$current_password = $getCurrent['password'];
		$old_password     = ( $requestMethodArray['current_password'] );
		$new_password     = ( $requestMethodArray['password'] );
		$confirm_password = ( $requestMethodArray['new_password'] );
		if ( ! password_verify( $old_password, $current_password ) ):
			echo @App_Response::alertResponse( 'Invalid current password, try again!!', 'danger' );
		elseif ( $new_password !== $confirm_password ):
			echo @App_Response::alertResponse( 'Password mismatch, try again!!', 'danger' );
		elseif ( strlen( $confirm_password ) < 6 ):
			echo @App_Response::alertResponse( 'Password must be minimum  of (6) Characters', 'danger' );
		else:
			@$update = Data_Access::execSQL( "UPDATE " . $engine->dbScheme . ".app_users SET password = '" . password_hash( $new_password, PASSWORD_DEFAULT ) . "' WHERE user_id  = '" . $auth['user_id'] . "'" );
			if ( $update ) {
				echo '<script>submitAppExit();</script>';
			}
		endif;
	endif;
	//--------------------------------------------------------------------------------------------------
	if ( isset( $requestMethodArray['AppModalLoader'] ) ):
		$required          = $requestMethodArray['AppModalLoader'];
		$modulePath        = str_ireplace( $engine->dashboard, '', $required['path'] );
		$modalRequest      = 1;
		$modalRequestParam = "";
		if ( $required['modalRequestParam'] != null ):
			$modalRequestParam = $required['modalRequestParam'];
		endif;
		$app = $engine;
		if ( @$required['DataTable'] == 1 ):
			require '../../includes/dataTables.php';
		endif;
		$module = new Module_Class;
		require $required['required'] . '.php';
	endif;

endif;