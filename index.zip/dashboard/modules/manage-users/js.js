/**
 * Created by DTMGS Limited.
 * User: Dauda Ibrahim
 * Date: 6/21/2020
 * Time: 10:24 PM
 * File: Manage User Module js
 */
var modulePath = $("#ModulePath").val();
$('.AppForm').bootstrap3Validate(function (e, data) {
    "use strict";
    e.preventDefault();
    var actionButton = $("#" + this.id + ' .actionButton').html();
    var formId = this.id;
    $("#" + this.id + ' .actionButton').html('<i class="fal fa-spin fa-spinner"></i> Processing...');
    $.ajax({
        url: modulePath + "ajaxRequest.php",
        type: "POST",
        data: new FormData(this),
        contentType: false,
        cache: false,
        processData: false,
        success: function (data) {
            //alert(data);
            //return false;
            var response;
            response = JSON.parse(data);
            var success = response['success'];
            var message = response['message'];
            if (success && success == 1) {
                $("#" + formId + " #ModuleResponse").html(message);
                $("#" + formId + ' .actionButton').html(actionButton);
                if (response['callback'] === 'self') {
                    $("#" + formId)[0].reset();
                    fetchURL("");
                }
            } else {
                $("#" + formId + " #ModuleResponse").html(message);
                $("#" + formId + ' .actionButton').html(actionButton);
            }
        },
        error: function () {
        }
    });

});

function moduleRequest(param) {
    var moduleRequest = ('{' + decodeURIComponent(param) + '}');
    //alert(moduleRequest);
    var objJSON = JSON.parse(moduleRequest);
    if (objJSON['notification']['message'] !== "" && objJSON['confirmed'] == 1) {
        var confirmation = 1;
    }
    $.post(modulePath + 'ajaxRequest.php',
        objJSON
        , function (response) {

            if (confirmation != 1) {
                $("#ModuleResponse").html(response);
            } else {
                //alert(response);
                //return false;
                response = JSON.parse(response);
                var success = response['success'];
                var message = response['message'];
                if (success && success == 1) {
                    $("#ModuleResponse").html(message);
                    //$("#" + formId + ' .actionButton').html(actionButton);
                    if (response['callback'] === 'self') {
                        //  $("#" + formId)[0].reset();
                        fetchURL("");
                    }
                } else {
                    //$("#" + formId + " #ModuleResponse").html(data);
                }
            }
        });
}

function moduleEditRequest(param) {
    var moduleRequest = ('{' + decodeURIComponent(param) + '}');
    var objJSON = JSON.parse(moduleRequest);
    //alert(objJSON['view']);
    var AppRequestPath;
    //var AppPath = document.getElementById("start-page");
    AppRequestPath = "handlers/AppAjaxRequest.php"
    $("#app-loader").html($('#AppLoader').html());

    //return false;

    $.post(AppRequestPath,
        {
            request: objJSON['request'],
            pkField: objJSON['pkField'],
            pk: objJSON['pk'],
            AppRequest: encodeURIComponent(objJSON['view']),
        }, function (response) {

            $("#app-loader").html(response);

            //return false;
        });
}

$(".propToggle").on('click', function () {
    if (this.checked) {
        $("." + this.id).val(1);
    } else {
        $("." + this.id).val(0);
    }
});

$("#appFilterBtn").click(function (e) {
    e.preventDefault();
    var filterRequest = ($("#" + this.form.id).serializeArray());
    var obj = [];
    $.each(filterRequest, function (i, field) {
        obj.push('"' + field.name + '"' + ":" + '"' + field.value + '"' + "");
    });
    var moduleRequest = ('{' + decodeURIComponent(obj) + '}');
    var objJSON = JSON.parse(moduleRequest);
    //return false;
    AppRequestPath = "handlers/AppAjaxRequest.php"
    $.post(AppRequestPath, {
            filterRequest: objJSON,
            AppRequest: encodeURIComponent(objJSON['view'])
        },
        function (response) {
            // if (confirmation != 1) {
            $("#app-loader").html(response);
            //} else {
            //alert(response);
            //return false;
            response = JSON.parse(response);
            var success = response['success'];
            var message = response['message'];
            if (success && success == 1) {
                $("#ModuleResponse").html(message);
                //$("#" + formId + ' .actionButton').html(actionButton);
                if (response['callback'] === 'self') {
                    //  $("#" + formId)[0].reset();
                    fetchURL("");
                }
            } else {
                //$("#" + formId + " #ModuleResponse").html(data);
            }
            //}
        });
});
