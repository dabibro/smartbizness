<?php
if (@$requestMethodArray['request'] == "update" && @$requestMethodArray['pk'] != "" && @$requestMethodArray['pkField'] != ""):
    $pk = $requestMethodArray['pk'];
    $pkField = $requestMethodArray['pkField'];
    $getUpdateArray = array(
        "tbl_scheme" => 'app_vendors',
        "condition" => [$pkField => $pk],
        "limit" => 1
    );
    $getUpdate = $module->getRecord($getUpdateArray);
    extract($getUpdate['dataArray'][0]);
else:
    $app_id = $app->generateAppId('V', date('md', time()), 8, '1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZ');
endif;


?>
<style>
    .select2-selection--multiple .select2-selection__rendered {
        min-height: 64px;
        max-height: 64px;
        overflow-x: hidden;
        overflow-y: auto !important;
    }
</style>
<div class="position-relative">
    <div class="row">
        <div class="col-2"></div>
        <div class="col-10">
            <div class="row">
                <div class="col-md-9 col-lg-8">
                    <div class="col-6 ml-auto">
                        <div class="form-group position-relative mb-0">
                            <div class="input-group">
                                <input type="search" class="form-control-sm form-control" id="vendor_lookup"
                                       autocomplete="off"
                                       placeholder="Vendors Lookup..."
                                       onkeyup='recordFormLookup("{\"request\":\"search\",\"target_scheme\":\"app_vendors\",\"term\":\"" + this.value + "\",\"fields\":[\"app_id\",\"vendor_id\",\"company_name\",\"contact_name\",\"contact_phone\",\"contact_email\",\"address_1\",\"address_2\",\"contact_fax\"],\"condition\":{\"active_status\":\"1\",\"delete_status\":\"0\"},\"limit\":\"10\",\"order\":{\"order_fields\":[\"company_name\",\"contact_name\"],\"sort\":\"ASC\"}, \"key\":\"app_id\",\"labels\":[\"company_name\"],\"target\":\"lookup_response\",\"destination\":\"vendor_lookup\",\"callback\":\"self\"}");'>
                                <div class="input-group-append">
                                    <button class="btn btn-default btn-sm pr-2" type="button"
                                            onclick='javascript:var obj; obj = $("#vendor_lookup").val(); obj = obj.split("]"); obj = obj[0].split("["); moduleEditRequest("\"request\":\"update\",\"pkField\":\"app_id\",\"pk\":\""+obj[1]+"\",\"view\":\"/#/create-vendor/\"")'>
                                        <i class="fal fa-search m-0"></i>
                                    </button>
                                </div>
                            </div>
                            <div class="lookup_response app-autolookup"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
    <hr class="my-2">
    <form method="post" class="AppForm" id="create-vendor-form">
        <div class="row">
            <div class="col-3 px-0 mr-3"></div>
            <div class="col-8 pl-5">
                <div id="ModuleResponse"></div>
            </div>
        </div>
        <div class="row">
            <div class="col-2">
                <div class="nav flex-column nav-tabs h-100" id="vert-tabs-tab" role="tablist"
                     aria-orientation="vertical">
                    <a class="nav-link active" id="basic-tabs" data-toggle="pill" href="#basic-tabs-panel" role="tab"
                       aria-controls="basic-tabs-panel" aria-selected="false"><i class="fal fa-info-circle"></i> Vendors
                        Data
                        <hr class="my-1">
                        <small class="text-muted">Fill in the vendors details.
                        </small>
                    </a>
                    <?php if (isset($vendor_folder)): ?>
                        <a class="nav-link" id="supplies-tabs" data-toggle="pill" href="#supplies-tabs-panel" role="tab"
                           aria-controls="supplies-tabs-panel" aria-selected="false"><i class="fal fa-boxes"></i>
                            Supplies
                            <hr class="my-1">
                            <small class="text-muted">Select supplies/inventory
                            </small>
                        </a>
                        <a class="nav-link" id="others-tabs" data-toggle="pill" href="#others-tabs-panel" role="tab"
                           aria-controls="others-tabs-panel" aria-selected="false"><i class="fal fa-money-bill"></i>
                            Payments
                            <hr class="my-1">
                            <small class="text-muted">Payments/Schedules
                            </small>
                        </a>
                    <?php endif; ?>
                </div>
            </div>
            <div class="col-10">
                <div class="tab-content" id="add-item-tabContent">
                    <ul class="nav nav-tabs mb-3" id="custom-content-below-tab" role="tablist">
                        <li class="nav-item">
                            <a class="nav-link active" id="basic-tabs" data-toggle="pill" href="#basic-tabs-panel"
                               role="tab"
                               aria-controls="basic-tabs-panel" aria-selected="false"> <i
                                        class="fal fa-file-user"></i> Vendor Basic Data</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" id="supplies-tabs" data-toggle="pill" href="#supplies-tabs-panel"
                               role="tab"
                               aria-controls="supplies-tabs-panel" aria-selected="false"> <i
                                        class="fal fa-boxes"></i> Inventory Supplies</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" id="others-tabs" data-toggle="pill" href="#others-tabs-panel"
                               role="tab" aria-controls="others-tabs-panel" aria-selected="false"><i
                                        class="fal fa-money-bill"></i> Payment Options</a>
                        </li>
                    </ul>
                    <div class="tab-pane text-left fade active show" id="basic-tabs-panel" role="tabpanel"
                         aria-labelledby="basic-tabs">
                        <div class="row">
                            <div class="col-md-9 col-lg-8">
                                <div class="row">
                                    <div class="col-4">
                                        <div class="form-group">
                                            <label class="w-100"><span class="required">*</span> Vendor Type
                                                <a title="Internal/External Vendor"
                                                   class="text-muted pointer float-right"><i
                                                            class="fal fa-question-circle"></i></a></label>
                                            <select name="vendor_type"
                                                    class="form-control form-control-sm select2" required
                                                    style="width: 100%;">
                                                <option value="">-- Select --</option>
                                                <?php $itemArray = array("Internal", "External");
                                                foreach ($itemArray as $item): ?>
                                                    <option value="<?php echo $item ?>" <?php if (@$vendor_type == $item): echo 'selected';endif; ?>><?php echo $item; ?></option>
                                                <?php endforeach; ?>
                                            </select>

                                            <div class="invalid-feedback">* Required field</div>
                                        </div>
                                    </div>
                                    <div class="col-4">
                                        <div class="form-group">
                                            <label for="" class="w-100"> <span class="required">*</span> Vendor ID <a
                                                        title="Vendor Unique Identification"
                                                        class="text-muted  pointer float-right"><i
                                                            class="fal fa-question-circle"></i></a></label>
                                            <div class="input-group input-group-sm">
                                                <input type="text" name="vendor_id" id="vendor_id"
                                                       class="form-control focus_vendor_id"
                                                       value="<?php echo @$vendor_id; ?>"
                                                       required placeholder="Vendor ID"
                                                       autocomplete="off">
                                                <div class="btn-group">
                                                    <button class="btn btn-default btn-sm appAutoIDGen pr-2"
                                                            type="button"
                                                            AppId-AutoGen='{"prefix":"V","suffix":"<?php echo date('d', time()) ?>", "strlen":"6","pattern":"0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ","target":"vendor_id"}'
                                                            id="vendorIdGen"
                                                            title="Auto Generate" data-toggle="tooltip"><i
                                                                class="fal fa-barcode m-0"></i></button>
                                                </div>
                                                <div class="invalid-feedback">* This field is required</div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-auto ml-auto">
                                        <?php if (@$getUpdate['response'] === "200"): ?>
                                            <div class="form-group">
                                                <div class="custom-control custom-switch">
                                                    <input type="checkbox" <?php if (@$active_status == 1): echo 'checked';endif; ?>
                                                           class="custom-control-input propToggle" id="active_status">
                                                    <label class="custom-control-label" for="active_status"> Active
                                                        Status</label>
                                                    <input type="hidden" readonly name="active_status"
                                                           class="active_status"
                                                           value="<?php if (@$active_status == 1): echo 1; else: echo 0;endif; ?>">
                                                </div>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-12">
                                        <div class="form-group">
                                            <label><span class="required">*</span> Vendor Name</label>
                                            <input type="text" name="company_name"
                                                   class="form-control form-control-sm"
                                                   autocomplete="off"
                                                   placeholder="Company Name" required
                                                   value="<?php echo @$company_name ?>">
                                            <div class="invalid-feedback">* This field is required</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-9 col-lg-8">
                                <div class="row">
                                    <div class="col-3">
                                        <div class="form-group">
                                            <label for="">Title</label>
                                            <select name="contact_title" class="form-control form-control-sm select2">
                                                <option value="">-- Title --</option>
                                                <?php $itemArray = array("Mr", "Mrs", "Miss");
                                                foreach ($itemArray as $item): ?>
                                                    <option value="<?php echo $item ?>" <?php if (@$contact_title == $item): echo 'selected';endif; ?>><?php echo $item; ?></option>
                                                <?php endforeach; ?>
                                            </select>
                                            <small class="text-muted">(Optional)</small>
                                        </div>

                                    </div>
                                    <div class="col-5">
                                        <div class="form-group">
                                            <label for="contact_name"> Contact Name</label>
                                            <input name="contact_name" type="text"
                                                   class="form-control form-control-sm " placeholder="Contact Name"
                                                   value="<?php echo @$contact_name; ?>" autocomplete="off">
                                            <small class="text-muted">(Optional)</small>

                                        </div>
                                    </div>
                                    <div class="col-4">
                                        <div class="form-group">
                                            <label><span class="required">*</span> Contact Phone</label>
                                            <input name="contact_phone" type="text" required
                                                   class="form-control form-control-sm" placeholder="Contact Phone"
                                                   value="<?php echo @$contact_phone; ?>" autocomplete="off">
                                            <div class="invalid-feedback">* Required field</div>

                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-4">
                                        <div class="form-group">
                                            <label>Email Address</label>
                                            <div class="controls">
                                                <input name="contact_email" type="email"
                                                       class="form-control form-control-sm"
                                                       value="<?php echo @$contact_email; ?>"
                                                       placeholder="Email Address"
                                                       autocomplete="off">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-4">
                                        <div class="form-group">
                                            <label>Fax</label>
                                            <input name="contact_fax" type="text"
                                                   class="form-control form-control-sm" placeholder="Fax"
                                                   value="<?php echo @$contact_fax; ?>" autocomplete="off">
                                        </div>
                                    </div>
                                    <div class="col-4">
                                        <div class="form-group">
                                            <label>Web URL</label>
                                            <div class="controls">
                                                <input name="website_address" type="text"
                                                       class="form-control form-control-sm"
                                                       value="<?php echo @$website_address; ?>"
                                                       placeholder="Web Address"
                                                       autocomplete="off">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label> Country</label>
                                            <select name="country" class="form-control form-control-sm select2"
                                                    id="country"
                                                    onchange='dropDownList("{\"request\":\"dropDownList\",\"pkField\":\"country_id\",\"pk\":"+ this.value +",\"target_scheme\":\"app_states\",\"key\":\"id\",\"label\":\"name\",\"target\":\"states\"}")'>
                                                <option>-- Country --</option>
                                                <?php
                                                $countryParam = array("tbl_scheme" => 'app_countries');
                                                $listArray = $module->getRecord($countryParam);
                                                $dropDownArray = array();
                                                foreach ($listArray['dataArray'] as $countries):
                                                    echo $app->dropDownList($countries['id'], $countries['name'], @$country);
                                                endforeach; ?>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label>State</label>
                                            <select name="state" class="form-control form-control-sm select2"
                                                    id="states"
                                                    onchange='dropDownList("{\"request\":\"dropDownList\",\"pkField\":\"state_id\",\"pk\":"+ this.value +",\"target_scheme\":\"app_cities\",\"key\":\"id\",\"label\":\"name\",\"target\":\"cities\"}")'>
                                                <option>-- State --</option>
                                                <?php if (@$getUpdate['response'] === "200"):
                                                    $listArray = $module->getRecord(["tbl_scheme" => 'app_states', "condition" => ["country_id" => $country]]);
                                                    foreach ($listArray['dataArray'] as $states):
                                                        echo $app->dropDownList($states['id'], $states['name'], $state);
                                                    endforeach; endif; ?>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label>City</label>
                                            <select name="city" class="form-control form-control-sm select2"
                                                    id="cities">
                                                <option>-- City --</option>
                                                <<?php if (@$getUpdate['response'] === "200"):
                                                    $listArray = $module->getRecord(["tbl_scheme" => 'app_cities', "condition" => ["state_id" => $state]]);
                                                    foreach ($listArray['dataArray'] as $cities):
                                                        echo $app->dropDownList($cities['id'], $cities['name'], $city);
                                                    endforeach; endif; ?>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-6">
                                        <div class="form-group">
                                            <label><span class="required">*</span> Address 1</label>
                                            <textarea name="address_1" required class="form-control form-control-sm"
                                                      rows="2"
                                                      placeholder="Address 1"
                                                      autocomplete="off"><?php echo @$address_1; ?></textarea>
                                            <div class="invalid-feedback">* Required field</div>

                                        </div>
                                    </div>
                                    <div class="col-6">
                                        <div class="form-group">
                                            <label>Address 2</label>
                                            <textarea name="address_2" class="form-control form-control-sm" rows="2"
                                                      placeholder="Address 2"
                                                      autocomplete="off"><?php echo @$address_2; ?></textarea>
                                            <small class="text-muted">(Optional)</small>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-4">
                                        <div class="form-group">
                                            <label>Postal Code</label>
                                            <div class="controls">
                                                <input name="postal_code" type="text"
                                                       class="form-control form-control-sm"
                                                       value="<?php echo @$postal_code; ?>"
                                                       placeholder="Postal Code"
                                                       autocomplete="off">
                                                <small class="text-muted">(Optional)</small>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane text-left fade" id="supplies-tabs-panel" role="tabpanel"
                         aria-labelledby="supplies-tabs">
                        <div class="row">
                            <div class="col-md-9 col-lg-8">
                                <div class="row">
                                    <div class="col-6">
                                        <div class="">
                                            <div class="form-group">
                                                <label class="w-100"><span class="required">*</span> Category
                                                    <a href="javascript:void (0)" title="Create new category"
                                                       onclick="AppModalLoader({modalId:'ModuleModal', modalTitle:'Category/Subcategory', required:'../manage-inventory/inc/category_form', afterEvent:'reloadCategory()'});"
                                                       class="pointer  bg-transparent border-0 float-right"> [
                                                        <i
                                                                class="fal fa-plus m-0"></i> ]
                                                    </a>
                                                </label>
                                                <select name="category_id"
                                                        class="form-control form-control-sm select2"
                                                        id="category_id" required style="width: 100%;"
                                                        onchange='dropDownList("{\"request\":\"dropDownList\",\"pkField\":\"parent_id\",\"pk\":"+ this.value +",\"target_scheme\":\"app_category\",\"key\":\"id\",\"label\":\"name\",\"target\":\"subcategory\"}")'
                                                >
                                                    <option value="">-- Category --</option>
                                                    <?php
                                                    $catParam = array("tbl_scheme" => 'app_category', "condition" => ["active_status" => 1, "parent_id" => 0]);
                                                    $listArray = $module->getRecord($catParam);
                                                    $dropDownArray = array();
                                                    foreach ($listArray['dataArray'] as $cat):
                                                        echo $app->dropDownList($cat['id'], $cat['name'], @$category_id);
                                                    endforeach; ?>
                                                </select>
                                                <div class="invalid-feedback">* Required field</div>
                                            </div>

                                        </div>
                                    </div>
                                    <div class="col-6">
                                        <div class="form-group">
                                            <label class="w-100"> Subcategory
                                                <a href="javascript:void (0)"
                                                   onclick="AppModalLoader({modalId:'ModuleModal', modalTitle:'Category/Subcategory', required:'../manage-inventory/inc/category_form', afterEvent: 'reloadSubcategory()'});"
                                                   class="pointer  bg-transparent border-0 float-right"> [ <i
                                                            class="fal fa-plus m-0"></i> ] </a>
                                            </label>
                                            <select name="subcategory"
                                                    class="form-control form-control-sm select2 w-100"
                                                    id="subcategory" style="width: 100%;">
                                                <option value="">-- Select --</option>
                                                <?php if (@$getUpdate['response'] === "200"):
                                                    $listArray = $module->getRecord(["tbl_scheme" => 'app_category', "condition" => ["parent_id" => $category_id], "active_status" => 1]);
                                                    foreach ($listArray['dataArray'] as $subCat):
                                                        echo $app->dropDownList($subCat['id'], $subCat['name'], @$subcategory);
                                                    endforeach; endif; ?>
                                            </select>
                                            <small class="text-muted">(Optional)</small>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-6">
                                        <div class="form-group">
                                            <label for=""><span class="required">*</span> Store</label>
                                            <select name="store_id"
                                                    class="form-control form-control-sm select2"
                                                    id="store" required style="width: 100%;"
                                                    onchange='dropDownList("{\"request\":\"dropDownList\",\"pkField\":\"store_id\",\"pk\":"+ this.value +",\"target_scheme\":\"app_storage_location\",\"key\":\"id\",\"label\":\"name\",\"target\":\"storage_location\"}")'>
                                                <option value="">-- Store --</option>
                                                <?php
                                                $storeParam = array("tbl_scheme" => 'app_stores', "condition" => ["active_status" => 1]);
                                                $listArray = $module->getRecord($storeParam);
                                                $dropDownArray = array();
                                                foreach ($listArray['dataArray'] as $store):
                                                    echo $app->dropDownList($store['app_id'], $store['store_name'], @$store_id);
                                                endforeach; ?>
                                            </select>
                                            <div class="invalid-feedback">* Required field</div>
                                        </div>
                                    </div>
                                    <div class="col-6">
                                        <div class="form-group">
                                            <label>Customer ID</label>
                                            <input type="text" name="customer_id"
                                                   class="form-control form-control-sm"
                                                   autocomplete="off" placeholder="Customer ID"
                                                   value="<?php echo @$customer_id; ?>">
                                            <small class="text-muted">Vendor customer ID(Optional)</small>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>

                    </div>
                    <div class="tab-pane text-left fade" id="others-tabs-panel" role="tabpanel"
                         aria-labelledby="others-tabs">
                        <div class="row">
                            <div class="col-md-9 col-lg-8">
                                <div class="row">
                                    <div class="col-5">
                                        <div class="form-group">
                                            <label>Accepted Options</label>
                                            <select class="select2" name="payment_methods[]" multiple
                                                    data-placeholder="-- Select --"
                                                    style="width: 100%; min-height: 160px;">
                                                <option value="">-- Select --</option>
                                                <?php
                                                $itemArray = array("Cash Payment", "Transfer", "POS", "Others");
                                                foreach ($itemArray as $item):
                                                    if (@$getUpdate['response'] === "200"):
                                                        $selected = "";
                                                        foreach (json_decode($payment_methods) as $sel): if ($sel == $item): $selected = 1; endif; endforeach;
                                                    else:
                                                        $selected = "";
                                                    endif;
                                                    ?>
                                                    <option value="<?php echo $item ?>" <?php if (@$selected === 1) echo 'selected'; ?>><?php echo $item; ?></option>
                                                <?php endforeach; ?>
                                            </select>
                                            <small class="text-muted">(Optional)</small>
                                            <?php //$itemsS = json_decode($payment_methods);
                                            //print_r($itemsS) ?>
                                        </div>
                                    </div>
                                    <div class="col-3">
                                        <div class="form-group">
                                            <label>Payment Term</label>
                                            <select name="payment_term"
                                                    class="form-control form-control-sm select2" style="width: 100%;">
                                                <option value="">-- Select --</option>
                                                <?php $itemArray = array("Full Payment", "Installment's");
                                                foreach ($itemArray as $item): ?>
                                                    <option value="<?php echo $item ?>" <?php if ($item === @$payment_term): echo 'selected';endif; ?>><?php echo $item; ?></option>
                                                <?php endforeach; ?>
                                            </select>
                                            <small class="text-muted">(Optional)</small>
                                        </div>
                                    </div>
                                    <div class="col-4">
                                        <div class="form-group">
                                            <label>Discount Type</label>
                                            <select name="discount_type"
                                                    class="form-control form-control-sm select2" style="width: 100%;">
                                                <option value="">-- Select --</option>
                                                <?php
                                                $storeParam = array("tbl_scheme" => 'app_discount_vat_type');
                                                $listArray = $module->getRecord($storeParam);
                                                $dropDownArray = array();
                                                foreach ($listArray['dataArray'] as $store):
                                                    echo $app->dropDownList($store['name'], $store['name'], @$discount_type);
                                                endforeach; ?>
                                            </select>
                                            <small class="text-muted">(Optional)</small>
                                        </div>
                                    </div>
                                </div>
                                <label class="text-muted">Bank Account Details</label>
                                <div class="row">
                                    <div class="col-md-4 col-xs-6">
                                        <div class="form-group">
                                            <label for="">Account Name</label>
                                            <input type="text" class="form-control form-control-sm"
                                                   name="account_name" placeholder="Account Name"
                                                   value="<?php echo @$account_name; ?>">
                                            <small class="text-muted">(Optional)</small>
                                        </div>
                                    </div>
                                    <div class="col-md-4 col-xs-6">
                                        <div class="form-group">
                                            <label for="">Account Number</label>
                                            <input type="text" class="form-control form-control-sm" date-regex="number"
                                                   name="account_number" placeholder="Account Number"
                                                   value="<?php echo @$account_number; ?>">
                                            <div class="invalid-feedback">* Accpets integer only</div>
                                            <small class="text-muted">(Optional)</small>

                                        </div>
                                    </div>
                                    <div class="col-md-4 col-xs-6">
                                        <div class="form-group">
                                            <label for="">Bank Name</label>
                                            <input type="text" class="form-control form-control-sm"
                                                   name="bank_name" placeholder="Bank Name"
                                                   value="<?php echo @$bank_name; ?>">
                                            <small class="text-muted">(Optional)</small>

                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="">Additional Note</label>
                                    <textarea name="additional_note" class="form-control form-control-sm text-editor"
                                              rows="4" placeholder="Additional Note"
                                              autocomplete="off"><?php echo @$additional_note; ?></textarea>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
        <input type="hidden" name="className" value="Module_Class" readonly>
        <?php if (@$getUpdate['response'] === "200"): ?>
            <input type="hidden" name="functionName" value="updateRecord" readonly>
            <input type="hidden" name="pk" value="<?php echo @$pk; ?>" readonly>
            <input type="hidden" name="pkField" value="<?php echo @$pkField; ?>" readonly>
        <?php else: ?>
            <input type="hidden" name="functionName" value="createRecord" readonly>
            <input type="hidden" name="pk" value="vendor_id" readonly>
        <?php endif; ?>
        <input type="hidden" name="callback[type]" value="actionEvent" readonly>
        <input type="hidden" name="callback[redirect]" value="formEditCallback()" readonly>
        <input type="hidden" name="tbl_scheme" value="app_vendors" readonly>
        <input type="hidden" name="created_by"
               value="<?php echo trim(@$auth['firstname'] . ' ' . @$auth['lastname']); ?>" readonly>
        <input type="hidden" name="app_id" value="<?php echo $app_id; ?>" readonly>
        <hr class="my-2">
        <div class="row">
            <div class="col-2"></div>
            <div class="col-10">
                <div class="col-md-9 col-lg-10 pl-0">
                    <button class="btn btn-default actionButton"><i class="fal fa-check-circle"></i> Submit
                    </button>
                </div>
            </div>
        </div>
    </form>
</div>

<div id="actionEvents"></div>
<script>
    $('.focus_vendor_id').focus();

    function reloadCategory() {
        dropDownList("{\"request\":\"dropDownList\",\"pkField\":\"parent_id\",\"pk\":\"0\",\"target_scheme\":\"app_category\",\"key\":\"id\",\"label\":\"name\",\"target\":\"category_id\"}");
    };

    function reloadSubcategory() {
        dropDownList("{\"request\":\"dropDownList\",\"pkField\":\"parent_id\",\"pk\":" + $("#category_id").val() + ",\"target_scheme\":\"app_category\",\"key\":\"id\",\"label\":\"name\",\"target\":\"subcategory\"}")
    }

    function formEditCallback() {
        var obj = "<?php echo urlencode('"pkField":"app_id","pk":"' . $app_id . '","view":"/#/create-vendor/","request":"update"'); ?>";
        moduleEditRequest(obj);

    }
</script>

