<?php
//--------------------------------------------------------------------

//--------------------------------------------------------------------
if (isset($_POST['filterRequest']) && $_POST['filterRequest'] !== NULL):
    $filterParam = $_POST['filterRequest'];
//print_r($filterParam);
    $condition = array();
    foreach ($filterParam as $criteria => $value):
        if ($criteria !== "view"):
            if ($value != ""):
                $condition += array($criteria => $value);
            endif;
        endif;
    endforeach;
    // print_r($condition);
    if ($condition == NULL):
        $condition = NULL;
    else:
        $order = "";
        $condition = $condition;
        // print_r($condition);
        foreach ($condition as $order_field => $value):
            $order .= $order_field . ', ';
        endforeach;
        $order = rtrim($order, ', ');
    endif;
    @$requestArray = array(
        "tbl_scheme" => 'app_vendors', "condition" => $condition,
        "order" => $order . ' ASC');
else:
    @$requestArray = array(
        "tbl_scheme" => 'app_vendors', "condition" => ["delete_status" => 0],
        "order" => 'company_name, contact_name ASC');

endif;


@$recordRequest = $module->getRecord($requestArray);
@$recordsArray = $recordRequest['dataArray'];
?>
<div class="row mb-3">
    <div class="col-lg-6">
        <div id="ModuleResponse"></div>
    </div>
    <div class="col-6 ml-auto">
        <div class="row">

            <div class="col ml-auto hide">
                <div class="input-group input-group-sm mr-2">
                    <input type="search" class="form-control border-right-0 dataTables_filter"
                           placeholder="Search keyword..">
                    <div class="input-group-append">
                        <span class="input-group-text border-left-0 bg-transparent"><i class="fal fa-search"></i></span>
                    </div>

                </div>
            </div>
            <div class="col-auto ml-auto">
                <div class="app-collapse">
                    <button class="btn btn-default btn-sm dropdown-toggle" data-toggle="collapse"
                            href="#collapseUsersFilter"
                            aria-expanded="false" aria-controls="collapseUsersFilter"><i
                                class="fal fa-filter"></i> Advance Filter
                    </button>
                    <div class="collapse collapse-container" id="collapseUsersFilter">
                        <div class="card-body elevation-1 bg-light">
                            <form method="post" action="#" id="userAccountFilter">
                                <div class="form-group">
                                    <label for="">Users Group</label>
                                    <select name="user_group" class="form-control form-control-sm select2">
                                        <option value="">-- Users Group --</option>
                                        <?php
                                        $groupParam = array("tbl_scheme" => 'app_vendors_group', "condition" => ['active_status' => 1]);
                                        $listArray = $module->getRecord($groupParam);
                                        $dropDownArray = array();
                                        foreach ($listArray['dataArray'] as $dept_unit):
                                            echo $app->dropDownList($dept_unit['group_id'], $dept_unit['name'], @$user_group);
                                        endforeach; ?>
                                    </select>
                                </div>
                                <div class="row">
                                    <div class="col-6">
                                        <div class="form-group">
                                            <label for="">Users Store</label>
                                            <select name="store_id" class="form-control form-control-sm select2">
                                                <option value="">-- Users Store --</option>
                                                <?php
                                                $storeParam = array("tbl_scheme" => 'app_stores', "condition" => ['active_status' => 1]);
                                                $listArray = $module->getRecord($storeParam);
                                                $dropDownArray = array();
                                                foreach ($listArray['dataArray'] as $dept_unit):
                                                    echo $app->dropDownList($dept_unit['store_id'], $dept_unit['store_name'], @$store_id);
                                                endforeach; ?>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-6">
                                        <div class="form-group">
                                            <label for="">Department/Unit</label>
                                            <select name="dept_id" class="form-control form-control-sm select2">
                                                <option value="">-- Select --</option>
                                                <?php
                                                $storeParam = array("tbl_scheme" => 'app_department_unit');
                                                $listArray = $module->getRecord($storeParam);
                                                $dropDownArray = array();
                                                foreach ($listArray['dataArray'] as $dept_unit):
                                                    echo $app->dropDownList($dept_unit['id'], $dept_unit['name'], @$store_id);
                                                endforeach; ?>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-6">
                                        <div class="form-group mb-0">
                                            <label for="">Active Status</label>
                                            <select name="activation" class="form-control form-control-sm select2">
                                                <option value="">-- Active Status --</option>
                                                <?php $itemArray = array("Active" => 1, "Inactive" => 0);
                                                foreach ($itemArray as $item => $val): ?>
                                                    <option value="<?php echo $val ?>"><?php echo $item; ?></option>
                                                <?php endforeach; ?>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <input type="hidden" readonly name="delete_status" value="0">
                                <hr class="my-3">
                                <button class="btn btn-default btn-sm btn-block" id="appFilterBtn">
                                    <i class="fal fa-check-circle"></i>
                                    Submit
                                </button>
                                <input type="hidden" readonly name="view" value="/#/users-account/">
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="table-responsive">
    <table class="table data-tables dataTables-Sort table-sm elevation-1">
        <?php if (isset($condition) && $condition != NULL): ?>
            <caption>View filtered record [ <a class="small text-muted" href="#/users-account/"
                                               onclick="fetchURL(this.href);">Reset Filter </a>]
            </caption>
        <?php else: ?>
            <caption>View all record(s)</caption>
        <?php endif; ?>
        <thead>
        <tr>
            <th>Vendor ID</th>
            <th>Company Name</th>
            <th>Contact Number</th>
            <th>Vendor Type</th>
            <th>Store</th>
            <th>Active Status</th>
            <th><i class="fal fa-cogs"></i></th>
        </tr>
        </thead>
        <tbody class="card-body">
        <?php
        if (isset($recordsArray)):
            foreach (@$recordsArray as $user): extract($user);
                @$group = $module->getRecord(["tbl_scheme" => 'app_vendors_group', "condition" => ["group_id" => @$user_group]])['dataArray'][0]['name'];
                @$store = $module->getRecord(["tbl_scheme" => 'app_stores', "condition" => ["app_id" => @$store_id]])['dataArray'][0]['store_name']; ?>
                <tr>
                    <td><?php echo $vendor_id; ?></td>
                    <td><?php echo trim($company_name); ?></td>
                    <td><?php echo @$contact_phone; ?></td>
                    <td><?php echo $vendor_type; ?></td>
                    <td><?php echo @$store; ?></td>
                    <td><?php if (@$active_status == 1):echo 'Active'; else:echo 'Inactive'; endif; ?></td>
                    <td style="width:5%;" class="py-1" nowrap="nowrap">
                        <div class="btn-group-justify btn-group-sm float-right">
                            <?php if (@$access['access_right'] = 1) { ?>
                                <button class="btn btn-default" href="#"
                                        onclick="location.replace('?p=access-right&&type=user&&id=<?php echo $user_id ?>');"
                                        title="Transactions"><i
                                            class="fal fa-folder-open"></i>
                                </button>
                            <?php }

                            if (@$access['edit_user'] = 1) { ?>
                                <button type="button" class="btn btn-default"
                                        onclick='javascript: var obj = "<?php echo urlencode('"pkField":"app_id","pk":"' . $app_id . '","view":"/#/create-vendor/","request":"update"'); ?>"; moduleEditRequest(obj)'
                                        title=" Edit Record"><i
                                            class="fal fa-edit"></i>
                                </button>
                            <?php }
                            if (@$access['delete_user'] = 1) { ?>
                                <button type="button" class="btn btn-default"
                                        onclick='javascript: var obj = "<?php echo urlencode('"className":"Module_Class","functionName":"updateRecord","tbl_scheme":"app_vendors","delete_status":1,"pkField":"app_id","pk":"' . $app_id . '","callback":{"type":"self","redirect":""},"notification":{"message":"Are you sure to delete this record?","title":"Delete Warning"}'); ?>";  moduleRequest(obj);'
                                        title=" Edit Record"><i
                                            class="fal fa-trash-alt"></i>
                                </button>
                            <?php } ?>
                        </div>
                    </td>
                </tr>
            <?php endforeach;
        endif;
        ?>
        </tbody>
        <tfoot>

        </tfoot>
    </table>
</div>
