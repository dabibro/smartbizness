<?php
/**
 * Created by DTMGS Limited.
 * User: Dauda Ibrahim
 * Date: 6/23/2020
 * Time: 9:40 PM
 * File: Module Classes
 */
if (file_exists("../../../helpers/config/config.inc.php")):
    require "../../../helpers/config/config.inc.php";
endif;
require "../../../helpers/handlers/app_autoloader.php";
require "Module_Class.php";
$engine = new SMBEngine;
$AppResponse = new App_Response;
$appAuth = new Auth_Access;
$auth = $appAuth->AppAuthChecker();
$requestMethod = $_SERVER['REQUEST_METHOD'];
if (in_array($requestMethod, ["GET", "POST", "PUT", "DELETE", "OPTIONS"])):
    $requestMethodArray = array();
    $requestMethodArray = $_REQUEST;
    //print_r($requestMethodArray);
    if (isset($requestMethodArray['notification']) && !isset($requestMethodArray['confirmed'])):
        $tmpl = "../../tmpl/notification.html";
        echo $engine->fileTempParse($tmpl, $requestMethodArray);
        exit;
    endif;

    if (isset($requestMethodArray['className']) && isset($requestMethodArray['functionName'])):
        $getCommandArray = array(
            "class" => $requestMethodArray['className'],
            "function_name" => $requestMethodArray['functionName']);
        $functionArray = [];
        foreach ($requestMethodArray as $key => $val):
            if ($key !== "className" && $key !== "functionName" && $key !== "callback")
                $functionArray += array($key => $val);
        endforeach;
        $module = new $requestMethodArray['className'];
        $execution = $module->execCommand($getCommandArray, $functionArray);
        if ($execution['response'] === "200"):
            //print_r($execution);
            if ($requestMethodArray['callback']['type'] == 'actionEvent'):
                $requestMethodArray['callback'] += array("event" => '<script>' . $requestMethodArray['callback']['redirect'] . '</script>');
            endif;
            $responseMessage = App_Response::alertResponse($execution['message'], 'success');
            $responseArray = array("success" => 1, "message" => ($responseMessage), "callback" => $requestMethodArray['callback']);
        else:
            $responseMessage = App_Response::alertResponse($execution['message'], 'danger');
            $responseArray = array("success" => 0, "message" => ($responseMessage), "callback" => $requestMethodArray['callback']);
        endif;
        // print_r($responseArray);
        echo @json_encode($responseArray);
    endif;
endif;
if (isset($requestMethodArray['dropDownRequest'])):
    $module = new Module_Class;
    $tbl_scheme = $requestMethodArray['dropDownRequest']['target_scheme'];
    $pkField = $requestMethodArray['dropDownRequest']['pkField'];
    $pk = $requestMethodArray['dropDownRequest']['pk'];
    $key = $requestMethodArray['dropDownRequest']['key'];
    $label = $requestMethodArray['dropDownRequest']['label'];

    $listParam = array(
        "tbl_scheme" => $tbl_scheme,
        "condition" => [$pkField => $pk]);
    $listArray = $module->getRecord($listParam);
    echo '<option value="">-- Select --</option>';
    foreach ($listArray['dataArray'] as $list):
        if (isset($key) && $key != ""):
            echo $engine->dropDownList($list[$key], $list[$label]);
        else:
            echo $engine->dropDownList($list[$label]);
        endif;
    endforeach;
endif;
//---------------------------------------------------------------------------
if (isset($requestMethodArray['formLookupRequest']) && $requestMethodArray['formLookupRequest']['term'] != ""):
    $module = new Module_Class;
    $request = $requestMethodArray['formLookupRequest']['request'];
    $tbl_scheme = $requestMethodArray['formLookupRequest']['target_scheme'];
    $field = $requestMethodArray['formLookupRequest']['fields'];
    $term = $requestMethodArray['formLookupRequest']['term'];
    $key = $requestMethodArray['formLookupRequest']['key'];
    $label = $requestMethodArray['formLookupRequest']['labels'];
    $condition = $requestMethodArray['formLookupRequest']['condition'];
    $order = $requestMethodArray['formLookupRequest']['order'];
    $limit = $requestMethodArray['formLookupRequest']['limit'];
    $lookupDestination = $requestMethodArray['formLookupRequest']['destination'];
    $target = $requestMethodArray['formLookupRequest']['target'];

    if ($request == "search"):
        $searchParam = [
            "tbl_scheme" => $tbl_scheme,
            "fields" => $field,
            "term" => $term,
            "condition" => $condition,
            "order" => $order,
            "limit" => $limit,
        ];
        $query = $module->searchRecord($searchParam);
        if ($query['response'] == "200"):
            $dataArray = $query['dataArray'];
            if (count($dataArray) === 0):

            else:
                echo '<div class="search-result position-relative">';
                echo '<a class="small text-right result-close text-muted" href="javasctipy:void(0)" onclick=\'$("."+"' . $target . '").html("");\'>[ x close ]</a>';
                foreach ($dataArray as $results):
                    $labels = "";
                    foreach ($label as $lbl):
                        $labels .= $results[$lbl] . ' ';
                    endforeach;

                    echo '<button type="button" class="list-group-item" onclick=\'javascript:$("#"+"' . $lookupDestination . '").val(this.innerHTML); $("."+"' . $target . '").html("");\'>[' . $results[$key] . '] ' . $labels . '</a>';
                endforeach;
                echo '</div>';
            endif;
        else:
            echo '<li class="list-group-item">No result(s) found lookup</li>';
        endif;

    else:

    endif;
endif;
//-------------------------------------------------------------------------------
if (isset($requestMethodArray['AppModalLoader'])):
    $required = $requestMethodArray['AppModalLoader'];
    $modulePath = str_ireplace($engine->dashboard, '', $required['path']);
    $modalRequest = 1;
    $modalRequestParam = "";
    if ($required['modalRequestParam'] != NULl):
        $modalRequestParam = $required['modalRequestParam'];
    endif;
    $app = $engine;
    if (@$required['DataTable'] == 1):
        require '../../includes/dataTables.php';
    endif;
    $module = new Module_Class;
    require $required['required'] . '.php';
endif;
//--------------------------------------------------------------------------------
if (isset($requestMethodArray['AppIDAutoGen'])):
    if ($requestMethodArray['AppIDAutoGen'] != NULL):
        extract($requestMethodArray['AppIDAutoGen']);
        echo $appIdGen = $engine->generateAppId($prefix, $suffix, $strlen, $pattern);
    endif;
endif;