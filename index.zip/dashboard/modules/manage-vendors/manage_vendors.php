<?php
//----------------------------------------------------------------------------------
require "Module_Class.php";
$module = new Module_Class;
$modulePath = @$appSwitcher->modulePath($AppModule);
$req = $AppModuleRequest;
$view = $AppModuleView;
//----------------------------------------------------------------------------------
@$getView = explode('?page', @$url);
if (isset($getView[1]) && $getView[1] != ""):
    @$getView2 = explode('accounts/', @$getView[0]);
    if (isset($getView2[1])) :
        @$view = 'accounts/';
    else:
        $view = "";
    endif;
endif;
@$getRecord = explode('record/', $view);
if (isset($getRecord[1]) && $getRecord[1] != ""):
    @$view = 'record/';
    @$customer_folder = trim($getRecord[1], '/');
endif;
//----------------------------------------------------------------------------------

?>
<input type="hidden" value="<?php echo $modulePath; ?>" id="ModulePath" readonly>
<div class="card card-primary card-outline card-outline-tabs">
    <div class="card-header p-0 border-bottom-0">
        <ul class="nav nav-tabs app-menu" id="manage-vendors-tabs" role="tablist">
            <li class="nav-item">
                <a class="nav-link  <?php if ($view == 'record/'): echo 'active show'; endif; ?>"
                   href="#/vendors/record/" onclick="fetchURL(this.href)"> <i class="fal fa-file-edit"></i>
                    Create/Update Vendor</a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php if (@$req === 'vendors/' && @$view != "record/" && @$view != "accounts/"): echo 'active'; endif; ?>"
                   href="#/vendors/" onclick="fetchURL(this.href)"><i class="fal fa-folder"></i> Vendors Records</a>
            </li>

            <li class="nav-item">
                <a class="nav-link <?php if ($req == 'vendors-payment/'): echo 'active'; endif; ?>"
                   href="#/vendors-payment/"
                   onclick="fetchURL(this.href)"><i class="fal fa-coin"></i> Vendors Payment</a>
            </li>

        </ul>
    </div>
    <div class="card-body">
        <div class="tab-content" id="manage-vendors-tabContent">
            <div class="tab-pane fade <?php if ($req == 'vendors-list/'): echo 'active show'; endif; ?>"
                 id="vendors-tab" role="tabpanel" aria-labelledby="tabs-vendors-tabs">
                <?php if ($req == 'vendors-list/'): require "inc/vendors_list.php";endif; ?>
            </div>
            <div class="tab-pane fade <?php if (@$view == 'record/'): echo 'active show'; endif; ?>"
                 id="create-new-tab" role="tabpanel" aria-labelledby="tabs-create-new-tab">
                <?php if ($view == 'record/'): require "inc/create_vendor.php"; endif; ?>
            </div>
            <div class="tab-pane fade <?php if ($req == 'vendors-payment/'): echo 'active show'; endif; ?>"
                 id="payment-tab" role="tabpanel" aria-labelledby="tabs-payment-tab">
                <?php if ($req == 'vendors-payment/'): require_once "inc/vendors_payment.php"; endif; ?>
            </div>

        </div>
    </div>
    <!-- /.card -->
</div>

<script src="<?php echo $modulePath ?>js.js"></script>