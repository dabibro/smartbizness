<?php
if (isset($_POST['filterRequest']) && $_POST['filterRequest'] !== NULL):
    if (file_exists("../../../../helpers/config/config.inc.php")):
        require "../../../../helpers/config/config.inc.php";
    endif;
    require "../../../../helpers/handlers/app_autoloader.php";
    require "../Module_Class.php";
    $app = new SMBEngine;
    $appSwitcher = new App_Switcher;
    $biz = new BIZConfig;
    $module = new Module_Class;
    $transRef = $_POST['filterRequest']['reference'];
    $src['app_id'] = $_POST['filterRequest']['src_id'];
    $dst['app_id'] = $_POST['filterRequest']['dst_id'];
endif;
//--------------------------------------------------------------------------------------------------
$store = "";
if (isset($transRef) && isset($src['app_id'])):
    $store = "AND app_inventory.store_id = '" . $src['app_id'] . "' ";
else:
    if (isset($auth['store_id']) && $auth['store_id'] != ""):
        $store = "AND app_inventory.store_id = '" . $auth['store_id'] . "' ";
    endif;
endif;

//--------------------------------------------------------------------------------------------------
$condition = "";
$default = "app_inventory.app_id = app_products.app_id " . $store . " AND app_inventory.active_status = '1' ";
$condition = $default;
//--------------------------------------------------------------------------------------------------
if (isset($_POST['filterRequest']) && $_POST['filterRequest'] !== NULL):
    $filterParam = $_POST['filterRequest'];
    if ($filterParam['search'] != ""):
        $search_query = trim($filterParam['search']);
        $condition = "$default" . "AND app_inventory.app_id LIKE '%" . $search_query . "%'";
        $condition .= " OR " . $default . " AND app_products.sku_barcode LIKE '%" . $search_query . "%' ";
        $condition .= " OR " . $default . " AND app_products.batch_sku_barcode LIKE '%" . $search_query . "%' ";
        $condition .= " OR " . $default . " AND app_products.name LIKE '%" . $search_query . "%' ";
        $condition .= " OR " . $default . " AND app_products.description LIKE '%" . $search_query . "%' ";
    endif;
endif;

@$paginate_exp = explode('?page=', $url);
if (isset($paginate_exp[1]) && $paginate_exp[1] != ""):
    $ipp_exp = explode('&ipp=', $paginate_exp[1]);
    if (isset($ipp_exp[0]) && $ipp_exp[0] != ""):
        define('page', $ipp_exp[0]);
    else:
    endif;
    if (isset($ipp_exp[1]) && $ipp_exp[1] != ""):
        define('ipp', $ipp_exp[1]);
    else:
    endif;
else:
    define('page', '');
    define('ipp', '');
endif;
define('self', '#/inventory/transfer/' . $transRef . '/');
$pages = new Paginator_Class;
if (ipp != ""):
    $pages->default_ipp = ipp;
else:
    $pages->default_ipp = 25;
endif;
$sql_forms = Data_Access::execSQL("SELECT app_inventory.app_id FROM " . $app->dbScheme . ".app_inventory, " . $app->dbScheme . ".app_products  WHERE  " . $condition . "  ");
@$pages->items_total = $sql_forms['dataArray']->num_rows;
$pages->mid_range = 2;
$pages->paginate();

$sql = "SELECT app_inventory.app_id, app_inventory.stock_qty, app_products.name, app_products.sale_price FROM " . $app->dbScheme . ".app_inventory, " . $app->dbScheme . ".app_products  WHERE  " . $condition . " ORDER BY app_products.name ASC " . $pages->limit . " ";
if (!($result = Data_Access::execSQL($sql))) {
    die(mysqli_error());
} else {
    @$recordsArray = Data_Access::fetchAssoc($result['dataArray'])['dataArray'];
}
?>
<div id="ModuleResponse"></div>
<div class="row marginTop mx-0">
    <div class="col-12 pl-0 paddingLeft pagerfwt">
        <?php if ($pages->items_total > 0) { ?>
            <?php echo $pages->display_pages(); ?>
            <?php echo $pages->display_items_per_page(); ?>
            <?php echo $pages->display_jump_menu(); ?>
        <?php } ?>
    </div>
    <div class="clearfix"></div>
    <hr>
</div>
<div class="table-responsive">
    <table class="table table-sm data-tables elevation-1">
        <?php if (@$filterParam != NULL): ?>
            <caption>Currently viewing filter record(s) [ <a href="javascript:void(0);" onclick="fetchURL('');"
                                                             class="small">Reset Filter</a> ]
            </caption>
        <?php else: ?>
            <caption>Viewing current month record(s)</caption>
        <?php endif; ?>
        <thead>
        <tr>
            <th class="text-center"><input type="checkbox" class="transToggle  mt-0"></th>
            <th class="text-center">Transfer Qty</th>
            <th>Product Description</th>
            <th>Stock</th>
            <th>Cost Price <?php echo $biz->currency['currency']; ?></th>
        </tr>
        </thead>
        <tbody class="card-body" id="inventory-list">
        <?php
        if (isset($recordsArray) && $recordsArray != NULL):
            $selected = 0;
            foreach (@$recordsArray as $transactions): extract($transactions);
                @$selector = $module->getRecord([
                    "tbl_scheme" => "app_stock_transfers",
                    "condition" => [
                        "reference" => $transRef,
                        "product_id" => $app_id,
                        "source_inventory" => $src['app_id'],
                        "destination_inventory" => $dst['app_id']
                    ]
                ])['dataArray'];
                if ($selector != NULL): $selected++;endif;
                ?>
                <tr>
                    <td align="center">
                        <input type="checkbox" id="<?php echo $app_id; ?>" name="selection[<?php echo @$app_id; ?>]"
                               class="selector pointer" <?php if (@$selector != NULL): echo 'checked'; endif; ?>
                               onclick="selector({id:this.id})">
                    </td>
                    <td><input type="text" size="4" id="qty-<?php echo $app_id; ?>"
                               class="form-control-sm num form-control text-center"
                               placeholder="QTY" onchange="selector({id:'<?php echo $app_id; ?>',update:1})"
                               style="font-size: 0.65rem !important; padding: 0.1rem; margin: 0.2rem auto; height: 24px;"
                               value="<?php echo @$selector[0]['stock_qty']; ?>">
                    </td>
                    <td><label class="pointer m-0" for="<?php echo $app_id; ?>"><?php echo $name; ?></label></td>
                    <td><?php echo $stock_qty; ?></td>
                    <td><?php echo $app->valueSign(@number_format(@$sale_price, 2)); ?></td>
                </tr>
            <?php endforeach; else: ?>
            <tr>
                <td colspan="9" align="center">No data available</td>
            </tr>
        <?php endif; ?>
        </tbody>
    </table>
</div>
<div class="row marginTop mx-0">
    <div class="col-12 pl-0 paddingLeft pagerfwt">
        <?php if ($pages->items_total > 0) { ?>
            <?php echo $pages->display_pages(); ?>
            <?php echo $pages->display_items_per_page(); ?>
            <?php echo $pages->display_jump_menu(); ?>
        <?php } ?>
    </div>
    <div class="clearfix"></div>
    <hr>
</div>
<?php if (isset($_POST['filterRequest']) && $_POST['filterRequest'] !== NULL): ?>
    <script src="<?php echo $_POST['filterRequest']['modulePath']; ?>js.js"></script>
    <script>var modulePath = "<?php echo $_POST['filterRequest']['modulePath']; ?>"</script>
<?php endif; ?>

<script>
    <?php
    if (@$selected > 0): echo '$(".transToggle").prop("checked", true);'; endif;
    ?>
    $(".transToggle").on('click', function () {
        if (this.checked) {
            $("#inventory-list .selector").each(function () {
                if (!$("#" + this.id).is(':checked')) {
                    $("#" + this.id).prop("checked", true);
                    console.log(selector({id: this.id}));
                }
            });
        } else {
            $("#inventory-list .selector").each(function () {
                if ($("#" + this.id).is(':checked')) {
                    $("#" + this.id).prop("checked", false);
                    console.log(selector({id: this.id}));
                }
            });
        }
    });

    function selector(obj) {
        var qty;
        var actionEvent;
        if ($("#qty-" + obj.id).val() !== "") {
            qty = $("#qty-" + obj.id).val();
        } else {
            qty = 1;
        }

        if ($("#" + obj.id).is(':checked')) {
            if (obj.update && obj.update === '1') {
                actionEvent = "Update"
            } else {
                actionEvent = "add"
            }
        } else {
            actionEvent = "remove"
        }
        var reference = "<?php echo $transRef;?>";
        $.post(modulePath + 'ajaxRequest.php', {
            transferSelect: {
                product_id: obj.id,
                stock_qty: qty,
                reference: reference,
                action: actionEvent,
            }
        }, function (response) {
            $("#ModuleResponse").html(response);
        });
    }

</script>
