<?php
/**
 * Created by PhpStorm.
 * User: DBlasterMaster
 * Date: 4/11/2020
 * Time: 2:55 AM
 */

$condition = "";

if (isset($_POST['filter-stocking'])) {
    $item = explode(' -> ', $_POST['item-name']);
    $item = getInventoryByID($item[0]);
    $item_id = $item['id'];
    $category = $_POST['category'];
    $start = $_POST['start_date'];
    $stop = $_POST['stop_date'];

    if ($item_id != '' && $category == '' && $start == '' && $stop == '') {
        $condition = "AND item_id = '$item_id'";
    } else if ($item_id != '' && $category == '' && $start != '' && $stop != '') {
        $condition = "AND item_id = '$item_id' AND entry_date BETWEEN '$start' AND DATE_ADD('$stop', INTERVAL 1 DAY)";
    } else if ($item_id == '' && $category != '' && $start == '' && $stop == '') {
        $condition = "AND app_inventory.category = '$category'";
    } else if ($item_id == '' && $category != '' && $start != '' && $stop != '') {
        $condition = "AND app_inventory.category = '$category' AND entry_date BETWEEN '$start' AND DATE_ADD('$stop', INTERVAL 1 DAY)";
    } else if ($item_id == '' && $category == '' && $start != '' && $stop != '') {
        $condition = " AND entry_date BETWEEN '$start' AND DATE_ADD('$stop', INTERVAL 1 DAY)";
    }

}


$stocking_sql = "SELECT app_inventory.id as id, app_inventory.menu_id, item_name,  menu_id, app_inventory_stocking.unit_price, app_inventory_stocking.sales_price, SUM(current_qty) as current_qty, add_qty, SUM(add_qty) as new_qty, app_inventory.unit_price as stock_amt 
              FROM app_inventory_stocking, app_inventory 
              WHERE app_inventory_stocking.item_id = app_inventory.id " . $condition . " 
              GROUP BY app_inventory_stocking.item_id ORDER BY menu_name";

?>
<div class="hide print-title">
    <h6 class="font-weight-bold text-center h6" style="font-size: 16px !important;">Inventory Stocking
        History </h6>
</div>

<div class="row mb-3">
    <div class="col-lg-6 ml-auto text-right">
        <button class="btn btn-dark px-4"
                onclick="$('#inventory-stocking-modal').modal({backdrop:'static'}); "><i
                    class="fal fa-plus-square"></i> Stock Item
        </button>
        <button type="button" class="btn btn-dark dropdown-toggle px-4" data-toggle="collapse"
                aria-expanded="false" data-target="#filterCriteria" aria-controls="filterCriteria">
            <i class="fal fa-filter"></i> Filter Records
        </button>
        <div class="collapse" aria-labelledby="dLabel" id="filterCriteria"
             style="z-index: 1 !important; position: absolute; right: 8px;">
            <div class="card border shadow-sm text-left">
                <div class="card-body">
                    <form method="post">
                        <div class="row">
                            <div class="col-12">
                                <div class="form-group">
                                    <label>Item Name</label>
                                    <input type="text" name="item-name"
                                           class="form-control form-control-sm inventory-lookup"
                                           placeholder="Item Name/Item ID">
                                </div>
                            </div>
                            <div class="col-6 hide">
                                <div class="form-group">
                                    <label>Item Category</label>
                                    <select name="category" class="form-control form-control-sm select2"
                                            style="width: 100%;">
                                        <option value="">-- Select Category --</option>
                                        <?php
                                        $category_query = dbQuery($menu_category_sql);
                                        while ($category = dbFetchAssoc($category_query)):
                                            ?>
                                            <option value="<?php echo $category['id'] ?>" <?php if (@$edit['category'] == @$category['id']) {
                                                echo 'selected';
                                            } ?>><?php echo $category['category_name'] ?></option>
                                        <?php endwhile; ?>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Start Date</label>
                                    <input type="text" class="form-control datepicker form-control-sm"
                                           name="start_date" placeholder="Start Date" autocomplete="off">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Stop Date</label>
                                    <input type="text" class="form-control datepicker form-control-sm"
                                           name="stop_date" id="stop_date" placeholder="Stop Date" autocomplete="off">
                                </div>
                            </div>
                        </div>
                        <button class="btn btn-dark btn-block btn-sm" type="submit"> Apply
                            Filter <i class="fal fa-angle-double-right"></i>
                        </button>
                        <input type="hidden" name="filter-stocking" value="1">

                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="table-responsive datatable-buttons">
    <table class="table table-striped datatable-btn table-sm">
        <?php if (isset($_POST['filter-stocking'])) { ?>
            <caption>Displaying filtered record(s) <?php if ($start != "" && $stop != "") {
                    echo 'Date: ' . $start . ' - ' . $stop;
                } ?> [<a href="#"
                         onclick="location.replace('?p=manage-inventory&inventory&manage-stocking')">
                    Reset Filter</a>]
            </caption>
        <?php } else { ?>
            <caption>Currently displaying current month record(s)</caption>
        <?php } ?>
        <thead>
        <tr>
            <th>Item ID</th>
            <th>Item Name</th>
            <th>In Stock</th>
            <th>Added Stock</th>
            <th>New Quantity</th>
            <th>Stocking Cost <?php echo $currency; ?></th>
        </tr>
        </thead>
        <tbody>
        <?php
        $query = dbQuery($stocking_sql);
        while ($menu = dbFetchAssoc($query)):
            extract($menu);
            ?>
            <tr>
                <td><?php echo $menu_id; ?></td>
                <td><?php echo $item_name; ?></td>
                <td><?php echo number_format($current_qty); ?></td>
                <td><?php echo number_format($add_qty); ?></td>
                <td><?php echo number_format($new_qty); ?></td>
                <td><?php echo number_format($stock_amt); ?></td>
            </tr>
        <?php endwhile; ?>
        </tbody>

    </table>
</div>
