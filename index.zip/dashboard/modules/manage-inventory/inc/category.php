<?php
/**
 * Created by DTMGS Limited.
 * User: Dauda Ibrahim
 * Date: 6/24/2020
 * Time: 1:45 AM
 */
@$requestArray = array(
    "tbl_scheme" => 'app_category',
    "condition" => [
        "delete_status" => 0,
    ],
    "order" => 'parent_id, name ASC');
@$recordRequest = $module->getRecord($requestArray);
@$recordsArray = $recordRequest['dataArray'];
if (@$requestMethodArray['request'] == "update" && @$requestMethodArray['pk'] != "" && @$requestMethodArray['pkField'] != ""):
    $pk = $requestMethodArray['pk'];
    $pkField = $requestMethodArray['pkField'];
    $getUpdateArray = array(
        "tbl_scheme" => 'app_category',
        "condition" => [$pkField => $pk],
        "limit" => 1
    );
    $getUpdate = $module->getRecord($getUpdateArray);
    extract($getUpdate['dataArray'][0]);
endif;
?>
<div class="row">
    <div class="col-md-5 col-lg-4 col-sm-12 mb-lg-0 mb-3">
        <fieldset class="border card-body">
            <legend class="col-auto h6">Category/Subcategory</legend>
            <div id="ModuleResponse"></div>
            <?php require "category_form.php"; ?>
        </fieldset>
    </div>
    <div class="col-md-7 col-lg-8 col-sm-12">
        <div class="table-responsive">
            <table class="table data-tables dataTables table-sm elevation-1">
                <thead class="p-0">
                <tr>
                    <th class="p-0 border-0" style="padding: 0 !important;">
                        <div class="mb-0" style="width:100%">
                            <div class="row mx-0 bg-transparent">
                                <div class="col-2 th">Code</div>
                                <div class="col-4 th">Name/Description</div>
                                <div class="col-2 th">Count</div>
                                <div class="col-2 th">Status</div>
                                <div class="col-2 th text-center"><span class="pointer" title="Action"><i
                                                class="fal fa-cogs"></i></span></div>
                            </div>
                        </div>
                    </th>
                </tr>
                </thead>
                <tbody>
                <?php if (isset($recordsArray)):
                    foreach (@$recordsArray as $record):
                        extract($record);
                        if ($parent_id == 0):
                            if ($parent_id == 0):
                                $getChildParam = array(
                                    "tbl_scheme" => 'app_category',
                                    "condition" => ["parent_id" => $id, "delete_status" => 0]);
                                $getChild = $module->getRecord($getChildParam);
                            endif;
                            ?>
                            <tr>
                                <td class="p-0">
                                    <div>
                                        <div style="width: 100%" class="my-1">
                                            <div class="row mx-0">
                                                <div class="col-2"><?php echo @$reference; ?></div>
                                                <div class="col-4"><?php echo @$name; ?></div>
                                                <div class="col-2">
                                                    <?php echo @count($module->getRecord(['tbl_scheme' => 'app_products', 'condition' => ['category_id' => @$id, 'active_status' => 1]])['dataArray']); ?>
                                                </div>
                                                <div class="col-2"><?php if (@$active_status == 1):echo 'Active'; else:echo 'Inactive'; endif; ?></div>
                                                <div class="col-2">
                                                    <div class="btn-group-justify btn-group-sm float-right">
                                                        <button type="button" class="btn btn-default"
                                                                onclick='javascript: var obj = "<?php echo urlencode('"pkField":"id","pk":' . $id . ',"view":"/#/inventory/category/","request":"update"'); ?>"; moduleEditRequest(obj)'
                                                                title=" Edit Record"><i
                                                                    class="fal fa-edit"></i>
                                                        </button>
                                                        <button type="button" class="btn btn-default"
                                                                onclick='javascript: var obj = "<?php echo urlencode('"className":"Module_Class","functionName":"deleteRecord","tbl_scheme":"app_category","pk":{"id":' . $id . '},"fk":["parent_id"],"callback":{"type":"self","redirect":""},"notification":{"message":"Are you sure to delete this record? <\/br> System will also delete child records.","title":"Delete Warning"}'); ?>";  moduleRequest(obj);'
                                                                title=" Edit Record"><i
                                                                    class="fal fa-trash-alt"></i>
                                                        </button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <?php if (isset($getChild['dataArray'])): ?>
                                        <div style="width: 100%" class="my-1">
                                            <?php foreach ($getChild['dataArray'] as $child): ?>
                                                <div>
                                                    <div class="row mx-0">
                                                        <div class="col-2">
                                                            &angrt; <?php echo $child['reference']; ?></div>
                                                        <div class="col-4"><?php echo $child['name']; ?></div>
                                                        <div class="col-2">
                                                            <?php echo @count($module->getRecord(['tbl_scheme' => 'app_products', 'condition' => ['subcategory' => @$child['id'], 'active_status' => 1]])['dataArray']); ?>
                                                        </div>
                                                        <div class="col-2"><?php if (@$child['active_status'] == 1):echo 'Active'; else:echo 'Inactive'; endif; ?></div>
                                                        <div class="col-2">
                                                            <div class="btn-group-justify btn-group-sm float-right">
                                                                <div class="btn-group-justify btn-group-sm float-right">
                                                                    <button type="button" class="btn btn-default"
                                                                            onclick='javascript: var obj = "<?php echo urlencode('"pkField":"id","pk":' . $child['id'] . ',"view":"/#/inventory/category/","request":"update"'); ?>"; moduleEditRequest(obj)'
                                                                            title=" Edit Record">
                                                                        <i
                                                                                class="fal fa-edit"></i>
                                                                    </button>
                                                                    <button type="button" class="btn btn-default"
                                                                            onclick='javascript: var obj = "<?php echo urlencode('"className":"Module_Class","functionName":"deleteRecord","tbl_scheme":"app_category","pk":{"id":' . $child['id'] . '},"callback":{"type":"self","redirect":""},"notification":{"message":"Are you sure to delete this record?","title":"Delete Warning"}'); ?>";  moduleRequest(obj);'
                                                                            title=" Edit Record">
                                                                        <i
                                                                                class="fal fa-trash-alt"></i>
                                                                    </button>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            <?php endforeach; ?>
                                        </div>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endif;
                    endforeach;
                endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
