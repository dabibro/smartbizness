<?php
/**
 * Created by PhpStorm.
 * User: Dauda Ibrahim
 * Date: 8/24/2020
 * Time: 11:12 AM
 */


@$getTransfer = "SELECT * FROM app_stock_transfer WHERE reference = '" . $transRef . "'";
@$getTransferQuery = Data_Access::execSQL($getTransfer)['dataArray'];
if (@$getTransferQuery):
    @$transfer = Data_Access::fetchAssoc($getTransferQuery)['dataArray'][0];
endif;
$src = $module->getRecord(["tbl_scheme" => "app_stores", "condition" => ["app_id" => $transfer['source_inventory']]])['dataArray'][0];
$dst = $module->getRecord(["tbl_scheme" => "app_stores", "condition" => ["app_id" => $transfer['destination_inventory']]])['dataArray'][0];

@$selection = $module->getRecord([
    "tbl_scheme" => "app_stock_transfers",
    "condition" => [
        "reference" => $transfer['reference'],
        "source_inventory" => $src['app_id'],
        "destination_inventory" => $dst['app_id']
    ],
    "order" => "product_description ASC"
])['dataArray'];

?>
<div class="row mb-2">
    <?php if ($transfer['submission_status'] == 0): ?>
        <div class="col-lg-3">
            <div class="form-group">
                <select name="source_inventory"
                        class="form-control form-control-sm select2"
                        id="source_inventory" required style="width:100%">
                    <option value="">-- Select Source --</option>
                    <?php
                    $storeParam = array("tbl_scheme" => 'app_stores', "condition" => ["active_status" => 1]);
                    $listArray = $module->getRecord($storeParam);
                    $dropDownArray = array();
                    foreach ($listArray['dataArray'] as $store):
                        if ($store['app_id'] != $src['app_id'])
                            echo $app->dropDownList($store['app_id'], $store['store_name'], @$src['app_id']);
                    endforeach; ?>
                </select>
                <label for=""><span class="required">*</span> Source Inventory</label>

                <div class="invalid-feedback">* Required field: Select transfer source</div>
            </div>
        </div>
        <div class="col-lg-2">
            <button class="btn btn-default btn-sm" onclick='javascript: switchInventory();'><i
                        class="fal fa-exchange"></i> Change Source
            </button>
        </div>
    <?php endif; ?>
    <div class="col-lg-auto col-12 ml-auto">
        <div class="btn-group-justified float-right">
            <?php if ($transfer['submission_status'] == 0): ?>
                <button class="btn btn-default btn-sm" onclick="executeTransfer()"><i class="fal fa-cogs"></i> Execute
                    Transfer
                </button>
            <?php endif; ?>
            <button class="btn btn-danger btn-sm" onclick="location.replace('#/inventory/transfer/'); fetchURL('');"><i
                        class="fal fa-times-circle"></i> Close
            </button>
            <?php if ($transfer['submission_status'] == 0): ?>
                <button class="btn btn-danger btn-sm" onclick="discardTransfer();"><i class="fal fa-save"></i> Discard
                </button>
            <?php endif; ?>

        </div>

    </div>
</div>
<div id="ModuleResponse"></div>
<div class="row mb-2">
    <?php if ($transfer['submission_status'] == 0): ?>
        <div class="col-lg-6">
            <label for="">Source Inventory </label>
            <div class="small">
                <div><span><label for="">Store Name: </label> <?php echo $src['store_name']; ?></span><span
                            class="float-right"><label
                                for="">Location Name:</label>
                        <?php echo trim(trim($app->getLocation('CN', $src['country']) . ', ' . $app->getLocation('S', $src['state']) . ', ' . $app->getLocation('C', $src['city'])), ', '); ?></span>
                </div>
                <div><span><label for="">&nbsp;</label></span>
                    <span class="float-left"><label
                                for="">Contact Info:</label> <?php echo $src['contact_name']; ?>
                        [ <?php echo $src['contact_phone']; ?> ]</span></div>

            </div>
            <div class="row mb-2">
                <div class="col-auto">
                    <button class="btn btn-default btn-sm" type="button" onclick="fetchURL('');"><i
                                class="fal fa-sync-alt"></i> Refresh Selection
                    </button>
                </div>
                <div class="col-6 ml-auto">
                    <div class="form-group mb-1">
                        <div class="input-group input-group-sm">
                            <input type="search" class="form-control form-control-sm border-right-0" name="search"
                                   placeholder="Search keyword..." id="search_query"
                                   style="border-radius: 0;">
                            <div class="btn-group">
                                <button class="btn mr-2 btn-default btn-sm pr-2"
                                        style="height: 31px" type="button"
                                        onclick="javascript:loadInventory($('#search_query').val());">
                                    <i
                                            class="fal fa-search m-0"
                                            style="font-size: 0.70rem;"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div id="transfer_inventory">
                <?php
                require 'transfer_inventory.php';
                ?>
            </div>
        </div>
    <?php endif; ?>

    <div class="col-lg-6">
        <label for="" class="w-100">Destination Inventory <span
                    class="float-right"><label>Reference #:</label><?php echo $transfer['reference']; ?></span></label>
        <div class="small">
            <div><span><label for="">Store Name:</label> <?php echo $dst['store_name']; ?></span><span
                        class="float-right"><label
                            for="">Location Name:</label>
                    <?php echo trim(trim($app->getLocation('CN', $dst['country']) . ', ' . $app->getLocation('S', $dst['state']) . ', ' . $app->getLocation('C', $dst['city'])), ', '); ?>
                </span></div>
            <div><span><label for="">&nbsp;</label></span> <span
                        class="float-left"><label
                            for="">Contact Info:</label> <?php echo $dst['contact_name']; ?>
                    [ <?php echo $dst['contact_phone']; ?> ]</span></div>

        </div>
        <table class="table table-sm data-tables elevation-1">
            <thead>
            <th>#</th>
            <th>Product Description</th>
            <th>Source</th>
            <th>Stock Qty</th>
            <th>Cost Price <?php echo $biz->currency['currency']; ?></th>
            <th>Amount <?php echo $biz->currency['currency']; ?></th>
            <?php if ($transfer['submission_status'] == 1): ?>
                <th></th>
            <?php endif; ?>
            </thead>
            <tbody class="card-body">
            <?php if (@$selection != NULL): $index = 0;
                $total_selected = 0;
                foreach (@$selection as $trans): $index++;
                    $amount = $trans['stock_price'] * $trans['stock_qty'];
                    $total_selected = $total_selected + $amount;
                    ?>
                    <tr>
                        <td><?php echo @$index; ?></td>
                        <td><?php echo $trans['product_description']; ?></td>
                        <td><?php echo $module->getRecord(["tbl_scheme" => "app_stores", "condition" => ["app_id" => $trans['source_inventory']]])['dataArray'][0]['store_name']; ?></td>
                        <td><?php echo $trans['stock_qty']; ?></td>
                        <td><?php echo number_format($trans['stock_price'], 2); ?></td>
                        <td><?php echo number_format($amount, 2); ?></td>
                        <?php if ($transfer['submission_status'] == 1): ?>
                            <th><?php if (@$trans['post_status'] == 1): echo '<i class="fal fa-check-square"></i>'; else: echo '<i class="fal fa-times-circle"></i>'; endif;; ?></th>
                        <?php endif; ?>
                    </tr>
                <?php endforeach; else: ?>
                <tr>
                    <td colspan="6" align="center">No table data available</td>
                </tr>
            <?php endif; ?>
            </tbody>
            <?php if (@$selection != NULL): ?>
                <tfoot>
                <tr>
                    <td colspan="5" align="right">TOTAL <?php echo $biz->currency['currency']; ?></td>
                    <th><?php echo number_format(@$total_selected, 2); ?></th>
                    <?php if ($transfer['submission_status'] == 1): ?>
                        <th></th>
                    <?php endif; ?>
                </tr>
                </tfoot>
            <?php endif; ?>
        </table>
    </div>
</div>

<script>
    function switchInventory() {
        $.post(modulePath + 'ajaxRequest.php',
            {
                className: "Module_Class",
                functionName: "updateRecord",
                tbl_scheme: "app_stock_transfer",
                source_inventory: $("#source_inventory").val(),
                pkField: "reference",
                pk: "<?php echo @$transfer['reference']; ?>",
                callback: {type: "self", redirect: ""},
                notification: {message: "Are you sure to switch inventory source", title: "Inventory Switch"}
            }, function (response) {
                $("#ModuleResponse").html(response);
            });
    }

    function loadInventory(query) {
        $.post(modulePath + 'inc/transfer_inventory.php',
            {
                filterRequest: {
                    search: query,
                    modulePath: modulePath,
                    reference: "<?php echo @$transfer['reference']; ?>",
                    src_id: "<?php echo @$src['app_id']; ?>",
                    dst_id: "<?php echo @$dst['app_id']; ?>"
                },
            }, function (response) {
                $("#transfer_inventory").html(response);
            });
    }

    function executeTransfer() {
        $.post(modulePath + 'ajaxRequest.php',
            {
                executeTransfer: {
                    reference: "<?php echo $transfer['reference']; ?>",
                },
                callback: {type: "self", redirect: ""},
                notification: {
                    message: "Are you sure to execute transfer process?<\/br> All selections will be transferred?",
                    title: "Transfer Warning"
                }
            }, function (response) {
                $("#ModuleResponse").html(response);
            });
    }

    function discardTransfer() {
        $.post(modulePath + 'ajaxRequest.php',
            {
                discardTransfer: {
                    reference: "<?php echo $transfer['reference']; ?>",
                },
                callback: {type: "redirect", redirect: "#/inventory/transfer/"},
                notification: {
                    message: "Are you sure to discard transfer process?<\/br> All selections will be erased?",
                    title: "Discard Warning"
                }
            }, function (response) {
                $("#ModuleResponse").html(response);
            });
    }
</script>