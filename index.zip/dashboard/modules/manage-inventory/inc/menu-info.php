<?php
/**
 * Created by PhpStorm.
 * User: DBlasterMaster
 * Date: 4/12/2020
 * Time: 1:54 PM
 */

$menu = getMenu($_GET['menu-id']);
extract($menu);
$category = getMenuCategory($category);
?>
<div class="modal-header bg-light">
    <h6 class="modal-title"><i class="fal fa-box"></i> Menu Item Information</h6>
    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
        <span aria-hidden="true">&times;</span>
    </button>
</div>
<div class="modal-body">
    <div class="row">
        <div class="col-6 ml-auto">
            <div class="form-group">
                <label>Menu ID/Barcode:</label>
                <p> <?php echo $menu_id; ?></p>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-6">
            <div class="form-group">
                <label for="">Menu Item Name</label>
                <p><?php echo $menu_name; ?></p>
            </div>
        </div>
        <div class="col-lg-6">
            <div class="form-group">
                <label for="">Item Category</label>
                <p><?php echo $category['category_name']; ?></p>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-6">
            <div class="form-group">
                <label for="">Unit/Prodcution Price <?php echo $currency; ?></label>
                <p><?php echo $unit_price; ?></p>
            </div>
        </div>
        <div class="col-lg-6">
            <div class="form-group">
                <label for="">Sales Price <?php echo $currency; ?></label>
                <p><?php echo $sales_price; ?></p>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-6">
            <div class="form-group">
                <label for="">Quantity</label>
                <p><?php echo $quantity; ?></p>
            </div>
        </div>
        <div class="col-lg-6">
            <div class="form-group">
                <label for="">Warning Level</label>
                <p><?php echo $warning_level; ?></p>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-7">
            <h6 class="text-muted"><i class="fal fa-sticky-note"></i> Additional Description</h6>
            <hr>
            <?php if ($additional_description != "") { ?>

                <div style="min-height: 180px; max-height: 180px; overflow-x: hidden; overflow-y: auto">
                    <?php echo htmlspecialchars_decode($additional_description); ?>
                </div>
            <?php } else {
                echo 'No additional Description.';
            } ?>
        </div>
        <div class="col-lg-5">
            <div class="" style="max-width: 235px;">
                <div class="form-group position-relative">
                    <div class="" style="width:180px; height: 160px;">
                        <?php if (file_exists('../../../files/item-images/' . $item_image) && $item_image != "") {
                            $file_src = WEB_ROOT . 'files/item-images/' . $item_image;
                        } else {
                            $file_src = WEB_ROOT . 'files/item-images/no image.jpg';
                        } ?>
                        <img src="<?php echo $file_src; ?>" id="item-image"
                             style="width: auto; max-width:100% !important; height: auto; max-height:100% !important;"
                             class="img-thumbnail br-0"/>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>