<?php
if (@$modalRequest == 1):
    @$requestArray = array(
        "tbl_scheme" => 'app_category',
        "condition" => [
            "delete_status" => 0,
        ],
        "order" => 'parent_id, name ASC');
    @$recordRequest = $module->getRecord($requestArray);
    @$recordsArray = $recordRequest['dataArray'];
endif; ?>
    <form method="post" class="AppForm" id="inventory-category-form">
        <div class="row">
            <div class="col-6 ml-auto">
                <div class="form-group mb-3">
                    <label for=""><span class="required">*</span> Code/ID</label>
                    <div class="input-group">
                        <input type="text" class="form-control form-control-sm" name="reference"
                               value="<?php echo @$reference; ?>"
                               required autofocus id="category-code"
                               placeholder="Code/ID" autocomplete="off">
                        <div class="btn-group">
                            <button class="btn btn-default btn-sm appAutoIDGen pr-2"
                                    type="button"
                                    AppId-AutoGen='{"prefix":"CAT","suffix":"<?php echo date('my', time()) ?>","strlen":"4","pattern":"0123456789","target":"category-code"}'
                                    id="vendorIdGen" title="Auto Generate" data-toggle="tooltip"><i
                                        class="fal fa-barcode m-0"></i></button>
                        </div>
                        <div class="invalid-feedback">* Required field</div>
                    </div>
                </div>
            </div>
            <div class="col-6">
                <div class="form-group">
                    <label for="">Parent Category</label>
                    <select name="parent_id" class="form-control form-control-sm select2" style="width:100%">
                        <option value="">-- Select --</option>
                        <?php if (isset($recordsArray)):
                            foreach ($recordsArray as $list):
                                if ($list['parent_id'] == 0): ?>
                                    <option value="<?php echo $list['id']; ?>" <?php if ($list['id'] == @$parent_id):echo "selected";endif; ?>>
                                        <?php echo $list['name']; ?>
                                    </option>
                                <?php endif;
                            endforeach;
                        endif;
                        ?>
                    </select>
                </div>
            </div>
        </div>
        <div class="form-group">
            <label for=""><span class="required">*</span> Name/Description</label>
            <input type="text" class="form-control form-control-sm" name="name"
                   value="<?php echo @$name; ?>" required
                   placeholder="Name/Description" autocomplete="off">
            <div class="invalid-feedback">* Required field</div>
        </div>
        <div class="form-group">
            <label for="">Additional Note</label>
            <textarea name="description" rows="3" placeholder="Additional Note" autocomplete="off"
                      class="form-control form-control-sm"><?php echo @$description; ?></textarea>
        </div>
        <?php if (@$getUpdate['response'] === "200"): ?>
            <div class="form-group mt-3">
                <div class="custom-control custom-switch">
                    <input type="checkbox" <?php if (@$active_status == 1): echo 'checked';endif; ?>
                           class="custom-control-input propToggle" id="active_status">
                    <label class="custom-control-label" for="active_status"> Active Status</label>
                    <input type="hidden" readonly name="active_status" class="active_status"
                           value="<?php if (@$active_status == 1): echo 1; else: echo 0;endif; ?>">
                </div>
            </div>
        <?php endif; ?>
        <hr class="my-3">
        <input type="hidden" name="className" value="Module_Class" readonly>
        <?php if (@$getUpdate['response'] === "200"): ?>
            <input type="hidden" name="functionName" value="updateRecord" readonly>
            <input type="hidden" name="pk" value="<?php echo @$pk; ?>" readonly>
            <input type="hidden" name="pkField" value="<?php echo @$pkField; ?>" readonly>
        <?php else: ?>
            <input type="hidden" name="functionName" value="createRecord" readonly>
            <input type="hidden" name="pk" value="reference" readonly>
        <?php endif; ?>
        <?php if (@$modalRequest == 1): ?>
            <input type="hidden" name="callback[type]" value="modal" readonly>
            <input type="hidden" name="callback[redirect]" value="" readonly>
        <?php else: ?>
            <input type="hidden" name="callback[type]" value="self" readonly>
            <input type="hidden" name="callback[redirect]" value="" readonly>
        <?php endif; ?>
        <input type="hidden" name="tbl_scheme" value="app_category" readonly>
        <input type="hidden" name="created_by"
               value="<?php echo trim(@$auth['firstname'] . ' ' . @$auth['lastname']); ?>" readonly>
        <button class="btn btn-default btn-sm actionButton"><i class="fal fa-check-circle"></i>
            Submit
        </button>
    </form>
<?php
if (@$modalRequest == 1):echo '<script src="' . $modulePath . 'js.js"></script>'; ?>
    <script> $('.select2').select2();</script>
<?php endif; ?>