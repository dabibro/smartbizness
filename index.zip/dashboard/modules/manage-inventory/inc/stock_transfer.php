<?php
/**
 * Created by PhpStorm.
 * User: Dauda Ibrahim
 * Date: 8/24/2020
 * Time: 2:36 AM
 */
$reference = $engine->generateAppId('T', date('my', time()), 6, '9876543210ABCDEFGHIJKLMNOP');
?>
<form action="" class="AppForm" id="transferForm">
    <div id="ModuleResponse"></div>
    <div class="row">
        <div class="col-4 ml-auto">
            <div class="form-group">
                <label for="">Reference #:</label>
                <input type="text" name="reference" class="form-control form-control-sm" placeholder="Transfer Ref #"
                       value="<?php echo @$reference; ?>" required>
            </div>
        </div>
    </div>
    <div class="form-group">
        <label for=""><span class="required">*</span> Source Inventory</label>
        <select name="source_inventory"
                class="form-control form-control-sm select2"
                id="source_inventory" required
                tabindex="7">
            <option value="">-- Select Source --</option>
            <?php
            $storeParam = array("tbl_scheme" => 'app_stores', "condition" => ["active_status" => 1]);
            $listArray = $module->getRecord($storeParam);
            $dropDownArray = array();
            foreach ($listArray['dataArray'] as $store):
                echo $engine->dropDownList($store['app_id'], $store['store_name'], @$store_id);
            endforeach; ?>
        </select>
        <div class="invalid-feedback">* Required field: Select transfer source</div>
    </div>
    <div class="form-group">
        <label for=""><span class="required">*</span> Destination Inventory</label>
        <select name="destination_inventory"
                class="form-control form-control-sm select2"
                id="destination_inventory" required
                tabindex="7">
            <option value="">-- Select Destination --</option>
            <?php
            $storeParam = array("tbl_scheme" => 'app_stores', "condition" => ["active_status" => 1]);
            $listArray = $module->getRecord($storeParam);
            $dropDownArray = array();
            foreach ($listArray['dataArray'] as $store):
                echo $engine->dropDownList($store['app_id'], $store['store_name'], @$store_id);
            endforeach; ?>
        </select>
        <div class="invalid-feedback">* Required field: Select transfer destination</div>
    </div>
    <div class="form-group mb-0">
        <label for="">Additional Note</label>
        <textarea name="additional_note" class="form-control" rows="4" placeholder="Additional Note"></textarea>
    </div>
    <div id="verifyResponse"></div>
    <hr>
    <button class="btn btn-default btn-block" onclick="return verifyTransfer();">Start Transfer <i
                class="fal fa-arrow-right"></i></button>
    <input type="hidden" name="className" value="Module_Class" readonly>
    <input type="hidden" name="functionName" value="createRecord" readonly>
    <input type="hidden" name="callback[type]" value="actionEvent" readonly>
    <input type="hidden" name="callback[redirect]" value="transferStock()" readonly>
    <input type="hidden" name="tbl_scheme" value="app_stock_transfer" readonly>
    <input type="hidden" name="created_by"
           value="<?php echo trim(@$auth['firstname'] . ' ' . @$auth['lastname']); ?>" readonly>
    <input type="hidden" name="store_id"
           value="<?php echo trim(@$auth['store_id']); ?>" readonly>
</form>
<div id="actionEvents"></div>
<script src="<?php echo $modulePath ?>js.js"></script>
<script>
    function verifyTransfer() {
        var src = $('#source_inventory').val();
        var dst = $('#destination_inventory').val();
        if (src !== "" && dst !== "") {
            if (src === dst) {
                $("#verifyResponse").html('<i class="fal fa-exclamation-triangle"></i> Error: Cannot perform same location transfer');
                $('#verifyResponse').addClass('alert alert-danger mt-2');
                return false;
            }
        }
    }

    function transferStock() {
        location.replace("#/inventory/transfer/<?php echo @$reference; ?>/");
        //$('#ModuleModal').modal('hide');
        location.reload();
    }

    $(".select2").select2();
</script>