<?php
@$imageArray = array(
    "tbl_scheme" => 'app_products_images',
    "condition" => ["app_id" => @$app_id],
    "order" => 'created_on DESC, description ASC');
@$imageRecord = $module->getRecord($imageArray);
@$imageList = $imageRecord['dataArray'];
?>
<div class="row">
    <?php
    if ($imageList != NULL):
        foreach ($imageList as $images => $img):
            ?>
            <div class="<?php if (@$modalRequest): echo 'col-4'; else: echo 'col-3';endif; ?>">
                <div class="card p-0">
                    <div class="card-body p-0">
                        <img src="<?php echo $app->inventory_images . $img['image_file']; ?>" alt="Image"
                             class="img-fluid img-thumbnail">
                    </div>
                    <div class="card-footer px-2 py-1">
                        <a href="<?php echo $app->inventory_images . $img['image_file']; ?>" data-toggle="lightbox"
                           data-title="<?php echo $img['description']; ?>" data-gallery="ImageGallery">
                            <i class="fal fa-image"></i>
                        </a>
                        <?php if (!@$modalRequest): ?>
                            <a href="javascript:void(0)" class="float-right" role="button"
                               onclick='javascript: var obj = "<?php echo urlencode('"deleteImage":"1","img_id":"' . $img['id'] . '","callback":{"type":"actionEvent","redirect":"loadImages()"},"notification":{"message":"Are you sure to delete this image?","title":"Delete Warning"}'); ?>";  moduleRequest(obj);'
                               title="Delete"><i
                                        class="fal fa-trash-alt"></i>
                            </a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        <?php endforeach; else: ?>
        <div class="col m-auto text-center py-5">
            <h4 class="text-muted my-5"><i class="fal fa-image fa-3x"></i></h4>
            <div class="text-muted h5"> No Image Uploaded</div>
        </div>
    <?php endif; ?>

</div>

<script>
    $(document).on('click', '[data-toggle="lightbox"]', function (event) {
        event.preventDefault();
        $(this).ekkoLightbox({
            alwaysShowClose: true,
        });
    });
</script>