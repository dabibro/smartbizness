<?php
/**
 * Created by PhpStorm.
 * User: DBlasterMaster
 * Date: 4/12/2020
 * Time: 1:54 PM
 */
$app = $engine;
$app_idd = $varParam['app_id'];
$store_id = @$auth['store_id'];
@$product = $module->getRecord([
    "tbl_scheme" => 'app_products',
    "condition" => ["app_id" => $app_idd]
])['dataArray'][0];
@extract($product);
@$category = $module->getRecord(["tbl_scheme" => 'app_category', "condition" => ["id" => @$category_id]])['dataArray'][0]['name'];
@$subcategory = $module->getRecord(["tbl_scheme" => 'app_category', "condition" => ["id" => @$subcategory]])['dataArray'][0]['name'];
@$inventory = $module->getRecord(["tbl_scheme" => 'app_inventory', "condition" => ["app_id" => @$app_id, "store_id" => $store_id]])['dataArray'][0];


?>

<div class="row">
    <div class="col-auto ml-auto">
        <div class="form-group">
            <label class="mb-0">SKU/Barcode: <?php echo $sku_barcode; ?></label>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-lg-4">
        <div class="form-group">
            <label class="mb-0">Product Name/Description:</label>
            <p><?php echo $name; ?></p>
        </div>
    </div>
    <div class="col-lg-6">
        <div class="form-group">
            <label class="mb-0">Category/Subcategory</label>
            <p><?php echo $category;
                if ($subcategory != ""): echo '/' . $subcategory;endif; ?></p>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-lg-4">
        <div class="form-group">
            <label class="mb-0">Cost Price <?php echo $biz->currency['currency']; ?></label>
            <p><?php echo number_format($price, 2); ?></p>
        </div>
    </div>
    <div class="col-lg-4">
        <div class="form-group">
            <label class="mb-0">Sales Price <?php echo $biz->currency['currency']; ?></label>
            <p><?php echo number_format($sale_price, 2); ?></p>
        </div>
    </div>
    <div class="col-lg-4">
        <div class="form-group">
            <label class="mb-0">Sales Price <?php echo $biz->currency['currency']; ?></label>
            <p><?php echo number_format($wholesale_price, 2); ?></p>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-lg-3">
        <div class="form-group">
            <label class="mb-0">Stock Quantity</label>
            <p><?php echo $inventory['stock_qty']; ?></p>
        </div>
    </div>
    <div class="col-lg-3">
        <div class="form-group">
            <label class="mb-0">Measure Unit</label>
            <p><?php echo $inventory['measure_unit']; ?></p>
        </div>
    </div>
    <div class="col-lg-3">
        <div class="form-group">
            <label class="mb-0">Warning Level</label>
            <p><?php echo $inventory['warning_level']; ?></p>
        </div>
    </div>
    <div class="col-lg-3">
        <div class="form-group">
            <label class="mb-0">Expiry Date</label>
            <p><?php echo $inventory['expiry_date']; ?></p>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-lg-6">
        <div class="text-muted"><i class="fal fa-sticky-note"></i> Additional Description</div>
        <hr class="my-2">
        <?php if ($description != ""): ?>
            <div style="max-height: 180px; overflow-x: hidden; overflow-y: auto">
                <?php echo htmlspecialchars_decode($description); ?>
            </div>
        <?php else:echo '<p>No Description Available.</p>';endif; ?>
        <?php require 'attributes_list.php'; ?>
    </div>
    <div class="col-lg-6">
        <div class="" style="max-height: 235px; overflow-y: auto; overflow-x:hidden">
            <?php require 'images_list.php'; ?>
        </div>

    </div>
</div>
