<?php
if (@$loader == 1):
    @$decode_packaging = $packaging;
    $packaging = $engine->verify_input(json_encode($packaging));
else:
    @$decode_packaging = @json_decode(@htmlspecialchars_decode(@$packaging), true);
endif;
asort($decode_packaging);
?>
<div class="table-responsive">
    <table class="data-tables table table-striped table-borderless table-sm elevation-1">
        <thead>
        <tr>
            <th>Measure Unit</th>
            <th>Per Unit</th>
            <?php if (!@$modalRequest): ?>
                <th></th>
            <?php endif; ?>
        </tr>
        </thead>
        <tbody id="attrib-list" class="card-body">
        <?php
        if ($decode_packaging != NULL):
            foreach ($decode_packaging as $measure => $unit):
                ?>
                <tr>
                    <td><?php echo $measure; ?></td>
                    <td><?php echo $unit; ?></td>
                    <?php if (!@$modalRequest): ?>
                        <td>
                            <div class="btn-group-justify btn-group-sm float-right">
                                <button type="button" class="btn btn-default"
                                        onclick='javascript: var obj = "<?php echo urlencode('"className":"Module_Class","deletePackagingParam":"' . @$rec_id . '","packaging":"' . @$packaging . '","measure":"' . $measure . '","callback":{"type":"actionEvent","redirect":"PackagingList()"},"notification":{"message":"Are you sure to delete this record?","title":"Delete Warning"}'); ?>";  moduleRequest(obj);'
                                        title="Delete"><i
                                            class="fal fa-trash-alt"></i>
                                </button>
                            </div>
                        </td>
                    <?php endif; ?>

                </tr>
            <?php endforeach; else: ?>
            <tr>
                <td colspan="3" class="text-center"> No Packaging Parameter Added</td>
            </tr>
        <?php endif; ?>
        </tbody>
    </table>
</div>
