<?php
@$attribArray = array(
    "tbl_scheme" => 'app_products_attribute',
    "condition" => ["app_id" => @$app_id, "active_status" => 1],
    "order" => 'created_on DESC, name ASC');
@$attribRecords = $module->getRecord($attribArray);
@$attribListArray = $attribRecords['dataArray'];
?>
<div class="table-responsive">
    <table class="data-tables table table-striped table-borderless table-sm elevation-1">
        <thead>
        <tr>
            <th>Attribute Name</th>
            <th>Description</th>
            <?php if (!@$modalRequest): ?>
                <th></th>
            <?php endif; ?>
        </tr>
        </thead>
        <tbody id="attrib-list" class="card-body">
        <?php
        if ($attribListArray != NULL):
            foreach ($attribListArray as $attrib => $attribVal):
                ?>
                <tr>
                    <td><?php echo $attribVal['name']; ?></td>
                    <td><?php echo $attribVal['description']; ?></td>
                    <?php if (!@$modalRequest): ?>
                        <td>
                            <div class="btn-group-justify btn-group-sm float-right">
                                <?php
                                if (@$access['edit_user'] = 1) { ?>
                                    <button type="button" class="btn btn-default"
                                            onclick='javascript: var obj = "<?php echo urlencode('"pkField":"id","pk":"' . $attribVal['id'] . '","tbl_schema":"","request":"update"'); ?>"; attribEditRequest(obj)'
                                            title="Edit"><i
                                                class="fal fa-edit"></i>
                                    </button>
                                <?php }
                                if (@$access['delete_user'] = 1) { ?>
                                    <button type="button" class="btn btn-default"
                                            onclick='javascript: var obj = "<?php echo urlencode('"className":"Module_Class","functionName":"deleteRecord","tbl_scheme":"app_products_attribute","pk":{"id":"' . $attribVal['id'] . '"},"callback":{"type":"actionEvent","redirect":"attribList()"},"notification":{"message":"Are you sure to delete this record?","title":"Delete Warning"}'); ?>";  moduleRequest(obj);'
                                            title="Delete"><i
                                                class="fal fa-trash-alt"></i>
                                    </button>
                                <?php } ?>
                            </div>
                        </td>
                    <?php endif; ?>

                </tr>
            <?php endforeach; else: ?>
            <tr>
                <td colspan="3" class="text-center"> No Attribute Added</td>
            </tr>
        <?php endif; ?>
        </tbody>
    </table>
</div>
