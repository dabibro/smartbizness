<?php
/**
 * Created by PhpStorm.
 * User: DBlasterMaster
 * Date: 4/11/2020
 * Time: 2:54 AM
 */
if (isset($_GET['edit']) && $_GET['id'] != '') {
    $record = getMenuCategory($_GET['id']);
    if ($record) {
        $edit = $record;
    }
}
?>
<div id="menu-category-response"></div>
<form action="" method="post" id="submit-menu-category-form">
    <div class="alert alert-danger py-2 px-3 hide"></div>
    <div class="form-group">
        <label>Category Name</label>
        <input type="text" name="category-name" class="form-control" placeholder="Enter Category Name" required
               value="<?php echo @$edit['category_name']; ?>" autofocus autocomplete="off">
    </div>
    <div class="form-group">
        <label>Category Description</label>
        <textarea class="form-control" name="description" rows="3"
                  placeholder="Enter Category Description"><?php echo @$edit['description']; ?></textarea>
    </div>
    <hr>
    <button class="btn btn-dark menu-category-btn px-4"><i class="fal fa-check-circle"></i> Submit</button>

    <?php if (@$edit) { ?>
        <button class="btn btn-danger px-4" type="button"
                onclick="location.replace('?p=manage-restaurant&menu&manage-category')"><i
                    class="fal fa-times-circle"></i>
            Cancel
        </button>
        <input type="hidden" name="isset-menu-category" value="2">
        <input type="hidden" name="id" value="<?php echo $edit['id']; ?>">
    <?php } else { ?>
        <input type="hidden" name="isset-menu-category" value="1">
    <?php } ?>
</form>