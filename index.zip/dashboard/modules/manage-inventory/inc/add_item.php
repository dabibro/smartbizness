<?php
if (@$requestMethodArray['request'] == "update" && @$requestMethodArray['pk'] != "" && @$requestMethodArray['pkField'] != ""):
    $pk = $requestMethodArray['pk'];
    $pkField = $requestMethodArray['pkField'];
    $getUpdateArray2 = array(
        "tbl_scheme" => 'app_inventory',
        "condition" => [$pkField => $pk],
        "limit" => 1
    );
    $getUpdate2 = $module->getRecord($getUpdateArray2);
    @extract($getUpdate2['dataArray'][0]);
    @$rec_id = $id;
    @$getUpdateArray = array(
        "tbl_scheme" => 'app_products',
        "condition" => ["app_id" => $app_id],
        "limit" => 1
    );
    $getUpdate = $module->getRecord($getUpdateArray);
    @extract($getUpdate['dataArray'][0]);
    $update = 1;
else:
    $app_id = $app->generateAppId('INV_', '', 8, '1234567890');
endif;
?>
<style>
    label.cabinet {
        display: block;
        cursor: pointer;
    }

    label.cabinet input.file {
        position: relative;
        height: 100%;
        width: auto;
        opacity: 0;
        -moz-opacity: 0;
        filter: progid:DXImageTransform.Microsoft.Alpha(opacity=0);
        margin-top: -30px;
    }

    #item-upload {
        width: 100%;
        height: 30rem;
        padding-bottom: 1.5625rem;
    }

    #vendors-list .select2-selection--multiple .select2-selection__rendered {
        min-height: 98px;
        max-height: 98px;
        overflow-x: hidden;
        overflow-y: auto !important;
    }
</style>
<div class="position-relative">
    <div class="row">
        <div class="col-2"></div>
        <div class="col-10">
            <div class="row">
                <div class="col-md-10">
                    <div class="row">
                        <div class="col-5 ml-auto">
                            <div class="form-group position-relative">
                                <div class="input-group">
                                    <input type="search" class="form-control-sm form-control" id="inventory_lookup"
                                           autocomplete="off"
                                           placeholder="Inventory Lookup ..."
                                           onkeyup='recordFormLookup("{\"request\":\"search\",\"target_scheme\":\"app_products\",\"term\":\"" + this.value + "\",\"fields\":[\"app_id\",\"sku_barcode\",\"batch_sku_barcode\",\"name\",\"description\"],\"condition\":{\"active_status\":\"1\"},\"limit\":\"10\",\"order\":{\"order_fields\":[\"name\"],\"sort\":\"ASC\"}, \"key\":\"app_id\",\"labels\":[\"name\"],\"target\":\"lookup_response\",\"destination\":\"inventory_lookup\",\"callback\":\"self\",\"action_button\":\"inventory_lookup_btn\"}");'>
                                    <div class="input-group-btn">
                                        <button class="btn btn-default btn-sm pr-2" type="button"
                                                id="inventory_lookup_btn"
                                                onclick='javascript:var obj; obj = $("#inventory_lookup").val(); obj = obj.split("]"); obj = obj[0].split("["); moduleEditRequest("\"request\":\"update\",\"pkField\":\"app_id\",\"pk\":\""+obj[1]+"\",\"view\":\"/#/inventory/add-item/\"")'>
                                            <i class="fal fa-search m-0"></i>
                                        </button>
                                    </div>
                                </div>
                                <div class="lookup_response app-autolookup"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <form method="post" class="AppForm" id="inventory-item-form">
        <div class="row">
            <div class="col-2">
                <div class="nav flex-column nav-tabs h-100" id="vert-tabs-tab" role="tablist"
                     aria-orientation="vertical">
                    <a class="nav-link active" id="basic-tabs" data-toggle="pill" href="#basic-tabs-panel" role="tab"
                       aria-controls="basic-tabs-panel" aria-selected="false"><i class="fal fa-info-circle"></i> Basics
                        Data
                        <hr class="my-1">
                        <small class="text-muted">Fill in the item basic details.
                        </small>
                    </a>
                    <a class="nav-link <?php if (@$update != 1):echo "disabled"; endif; ?>" id="advance-tabs"
                       data-toggle="pill" href="#advance-tabs-panel"
                       role="tab"
                       aria-controls="advance-tabs-panel" aria-selected="false"><i class="fal fa-cog"></i> Advance
                        Options
                        <hr class="my-1">
                        <small class="text-muted">Advance item attributes
                        </small>
                    </a>
                    <a class="nav-link <?php if (@$update != 1):echo "disabled"; endif; ?>" id="image-tabs"
                       data-toggle="pill" href="#image-tabs-panel" role="tab"
                       aria-controls="image-tabs-panel" aria-selected="false"><i class="fal fa-images"></i> Image Upload
                        <hr class="my-1">
                        <small class="text-muted">Upload item images files.
                        </small>
                    </a>
                </div>
            </div>
            <div class="col-10">
                <div class="tab-content" id="add-item-tabContent">
                    <div class="row">
                        <div class="col-md-3 col-lg-2"></div>
                        <div class="col-md-9 col-lg-8">
                            <div id="ModuleResponse"></div>
                        </div>
                    </div>
                    <div class="tab-pane text-left fade  active show" id="basic-tabs-panel" role="tabpanel"
                         aria-labelledby="basic-tabs">
                        <div class="row">
                            <div class="col-md-9 col-lg-10">
                                <div class="row">
                                    <div class="col-auto ml-auto form-inline">
                                        <div class="form-group mr-2">
                                            <div class="custom-control custom-switch">
                                                <input type="checkbox" <?php if (@$sales_point == 1): echo 'checked';endif; ?>
                                                       class="custom-control-input propToggle" id="sales_point">
                                                <label class="custom-control-label" for="sales_point"> On Sales
                                                    Point</label>
                                                <input type="hidden" readonly name="app_inventory[sales_point]"
                                                       class="sales_point"
                                                       value="<?php if (@$sales_point == 1): echo 1; else: echo 0;endif; ?>">
                                            </div>
                                        </div>
                                        <?php if (@$getUpdate['response'] === "200"): ?>
                                            <div class="form-group">
                                                <div class="custom-control custom-switch">
                                                    <input type="checkbox" <?php if (@$active_status == 1): echo 'checked';endif; ?>
                                                           class="custom-control-input propToggle" id="active_status">
                                                    <label class="custom-control-label" for="active_status"> Active
                                                        Status</label>
                                                    <input type="hidden" readonly name="app_inventory[active_status]"
                                                           class="active_status"
                                                           value="<?php if (@$active_status == 1): echo 1; else: echo 0;endif; ?>">
                                                </div>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <label class="text-muted"> Identification</label>
                                <div class="row">
                                    <div class="col-4">
                                        <div class="form-group">
                                            <label for=""> <span class="required">*</span> SKU/Barcode</label>
                                            <div class="input-group input-group-sm">
                                                <input type="text" name="app_products[sku_barcode]"
                                                       id="inv_sku_barcode_field"
                                                       class="form-control focus_sku"
                                                       value="<?php echo @$sku_barcode; ?>"
                                                       required placeholder="SKU/Barcode"
                                                       autocomplete="off" tabindex="1">
                                                <input type="hidden" name="app_products[batch_sku_barcode]"
                                                       id="sku-input-list"
                                                       value="<?php echo @$batch_sku_barcode; ?>">
                                                <div class="btn-group">
                                                    <button class="btn btn-default btn-sm appAutoIDGen pr-2"
                                                            type="button"
                                                            AppId-AutoGen='{"prefix":"A","suffix":"", "strlen":"5","pattern":"0123456789ABCDEFGHIJKLM","target":"inv_sku_barcode_field"}'
                                                            id="vendorIdGen"
                                                            title="Auto Generate"><i
                                                                class="fal fa-barcode m-0"></i></button>
                                                </div>
                                                <div class="invalid-feedback">* This field is required</div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-auto">
                                        <div class="form-group ml-2">
                                            <label for="">&nbsp;</label> <br>
                                            <a class="btn btn-default btn-sm" href="javascript:void(0)"
                                               onclick="batchSKU();">
                                                <i class="fal fa-layer-group"></i> Batch SKU/Barcode</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <label class="text-muted"> Basic Data</label>
                        <div class="row">
                            <div class="col-md-9 col-lg-10">
                                <div class="row">
                                    <div class="col-12">
                                        <div class="form-group">
                                            <label><span class="required">*</span> Product Name/Description</label>
                                            <input type="text" name="app_products[name]"
                                                   class="form-control form-control-sm"
                                                   autocomplete="off"
                                                   placeholder="Item Name/Label" required
                                                   value="<?php echo @$name ?>" tabindex="2">
                                            <div class="invalid-feedback">* This field is required</div>
                                        </div>
                                        <div class="form-group">
                                            <label>Additional Description</label>
                                            <textarea class="text-editor" name="app_products[description]"
                                                      placeholder="Additional Description"
                                                      style="width: 100%; height: 250px; font-size: 14px; line-height: 18px; border: 1px solid #dddddd; padding: 10px;"><?php echo @$description; ?></textarea>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-4">
                                        <div class="form-group">
                                            <label for=""><span class="required">*</span>
                                                Price <?php echo $biz->currency['currency']; ?></label>
                                            <input type="text" name="app_products[price]"
                                                   class="form-control form-control-sm num"
                                                   placeholder="Price" required
                                                   value="<?php echo @$price; ?>" tabindex="3">
                                            <div class="invalid-feedback">* Required integer field</div>
                                        </div>
                                    </div>
                                    <div class="col-4">
                                        <div class="form-group">
                                            <label for=""><span class="required">*</span> Sale
                                                Price <?php echo $biz->currency['currency']; ?></label>
                                            <input type="text" name="app_products[sale_price]" required
                                                   class="form-control form-control-sm num"
                                                   placeholder="Sale Price"
                                                   value="<?php echo @$sale_price; ?>" tabindex="4">
                                            <div class="invalid-feedback">* Required integer field</div>
                                        </div>
                                    </div>
                                    <div class="col-4">
                                        <div class="form-group">
                                            <label for=""
                                                   class="w-100">Wholesale <?php echo $biz->currency['currency']; ?> </label>
                                            <input type="text" name="app_products[wholesale_price]"
                                                   class="form-control form-control-sm num"
                                                   placeholder="Wholesale Price"
                                                   value="<?php echo @$wholesale_price; ?>" tabindex="5">
                                            <div class="invalid-feedback">* Required integer field</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-9 col-lg-10">
                                <div class="row">
                                    <div class="col-4">
                                        <div class="form- ">
                                            <div class="form-group">
                                                <label class="w-100">
                                                    <span class="required">*</span> Category
                                                    <a href="javascript:void(0)" title="Create new category"
                                                       onclick="AppModalLoader({modalId:'ModuleModal', modalTitle:'Category/Subcategory', required:'inc/category_form', afterEvent:'reloadCategory()'});"
                                                       class="bg-transparent border-0 text-muted pointer float-right">[
                                                        <i
                                                                class="fal fa-plus m-0"></i> ]</a>
                                                </label>
                                                <select name="app_products[category_id]" tabindex="6"
                                                        class="form-control form-control-sm select2"
                                                        id="category_id"
                                                        required style="width: 100%;"
                                                        onchange='dropDownList("{\"request\":\"dropDownList\",\"pkField\":\"parent_id\",\"pk\":"+ this.value +",\"target_scheme\":\"app_category\",\"key\":\"id\",\"label\":\"name\",\"target\":\"subcategory\"}")'

                                                >
                                                    <option value="">-- Category --</option>
                                                    <?php
                                                    $catParam = array("tbl_scheme" => 'app_category', "condition" => ["active_status" => 1, "parent_id" => 0]);
                                                    $listArray = $module->getRecord($catParam);
                                                    $dropDownArray = array();
                                                    foreach ($listArray['dataArray'] as $cat):
                                                        echo $app->dropDownList($cat['id'], $cat['name'], @$category_id);
                                                    endforeach; ?>
                                                </select>
                                                <div class="invalid-feedback">* Required field</div>
                                            </div>

                                        </div>
                                    </div>
                                    <div class="col-4">
                                        <div class="form-group">
                                            <label class="w-100">
                                                Subcategory
                                                <a href="javascript:void(0)" title="Create new subcategory"
                                                   onclick="AppModalLoader({modalId:'ModuleModal', modalTitle:'Category/Subcategory', required:'inc/category_form', afterEvent: 'reloadSubcategory()'});"
                                                   class="bg-transparent border-0 pointer text-muted float-right">[ <i
                                                            class="fal fa-plus m-0"></i> ]
                                                </a>
                                            </label>
                                            <select name="app_products[subcategory]"
                                                    class="form-control form-control-sm select2"
                                                    id="subcategory" style="width: 100%;">
                                                <option value="">-- Select --</option>
                                                <?php if (@$getUpdate['response'] === "200"):
                                                    $listArray = $module->getRecord(["tbl_scheme" => 'app_category', "condition" => ["parent_id" => $category_id], "active_status" => 1]);
                                                    foreach ($listArray['dataArray'] as $subCat):
                                                        echo $app->dropDownList($subCat['id'], $subCat['name'], @$subcategory);
                                                    endforeach; endif; ?>
                                            </select>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <label class="text-muted"> Inventory</label>
                        <div class="row">
                            <div class="col-md-9 col-lg-10">
                                <div class="row">
                                    <div class="col-4">
                                        <div class="form-group">
                                            <label for=""><span class="required">*</span> Store</label>
                                            <select name="app_inventory[store_id]"
                                                    class="form-control form-control-sm select2"
                                                    id="store" required
                                                    onchange='dropDownList("{\"request\":\"dropDownList\",\"pkField\":\"store_id\",\"pk\":"+ this.value +",\"target_scheme\":\"app_storage_location\",\"key\":\"id\",\"label\":\"name\",\"target\":\"storage_location\"}")'
                                                    tabindex="7" style="width: 100%;">
                                                <option value="">-- Store --</option>
                                                <?php
                                                $storeParam = array("tbl_scheme" => 'app_stores', "condition" => ["active_status" => 1]);
                                                $listArray = $module->getRecord($storeParam);
                                                $dropDownArray = array();
                                                foreach ($listArray['dataArray'] as $store):
                                                    echo $app->dropDownList($store['app_id'], $store['store_name'], @$store_id);
                                                endforeach; ?>
                                            </select>
                                            <div class="invalid-feedback">* Required field</div>
                                        </div>
                                        <div class="form-group">
                                            <label for="">Storage Location</label>
                                            <select name="app_inventory[storage_id]"
                                                    class="form-control form-control-sm select2"
                                                    id="storage_location" tabindex="8" style="width: 100%;">
                                                <option value="">-- Storage Location --</option>
                                                <?php if (@$getUpdate['response'] === "200"):
                                                    $listArray = $module->getRecord(["tbl_scheme" => 'app_storage_location', "condition" => ["active_state" => 1]]);
                                                    foreach ($listArray['dataArray'] as $storage_location):
                                                        echo $app->dropDownList($storage_location['id'], $storage_location['name'], @$storage_id);
                                                    endforeach; endif; ?>
                                            </select>

                                        </div>
                                    </div>
                                    <div class="col-8">
                                        <div class="form-group" id="vendors-list">
                                            <label for="">Vendors</label>
                                            <select name="app_inventory[vendor_id][]" multiple
                                                    data-placeholder="-- Select Vendors --"
                                                    class="form-control form-control-sm select2" style="width: 100%;">
                                                <option value="">-- Vendor --</option>
                                                <?php
                                                $listArray = $module->getRecord(["tbl_scheme" => 'app_vendors', "condition" => ["active_status" => 1, "delete_status" => 0]]);
                                                foreach ($listArray['dataArray'] as $vendors):
                                                    if (@$getUpdate['response'] === "200"):
                                                        foreach (json_decode(@$vendor_id) as $ven):
                                                            if ($vendors['vendor_id'] === $ven): $selected = $ven; endif;
                                                        endforeach;
                                                    endif;
                                                    echo $app->dropDownList($vendors['vendor_id'], $vendors['company_name'], @$selected);
                                                endforeach; ?>
                                            </select>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-9 col-lg-10">
                                <div class="row">
                                    <div class="col-4">
                                        <div class="form-group">
                                            <label for="">Stock Qty</label>
                                            <input type="text" name="app_inventory[stock_qty]"
                                                   class="form-control-sm form-control num"
                                                   placeholder="Stock Qty" value="<?php echo @$stock_qty; ?>"
                                                   tabindex="9">
                                            <div class="invalid-feedback">* Required integer field</div>

                                        </div>
                                    </div>
                                    <div class="col-4">
                                        <div class="form-group">
                                            <label class="w-100">
                                                Measure Unit
                                                <a href="javascript:void(0)"
                                                   onclick="AppModalLoader({modalId:'ModuleModal', modalTitle:'Measure Units', required:'../manage-app/inc/measure_unit_form', afterEvent: 'reloadMeasure(\'measure_unit\')'});"
                                                   class="bg-transparent border-0 pointer float-right text-muted">[
                                                    <i
                                                            class="fal fa-plus m-0"></i> ]</a>
                                            </label>
                                            <select name="app_inventory[measure_unit]" id="measure_unit"
                                                    class="form-control form-control-sm select2" tabindex="10"
                                                    style="width: 100%;">
                                                <option value="">-- Measure Units --</option>
                                                <?php
                                                $listArray = $module->getRecord(["tbl_scheme" => 'app_measure_unit', "condition" => ["active_status" => 1]]);
                                                foreach ($listArray['dataArray'] as $units):
                                                    echo $app->dropDownList($units['name'], $units['name'], @$measure_unit);
                                                endforeach; ?>
                                            </select>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-9 col-lg-10">
                                <div class="row">
                                    <div class="col-4">
                                        <div class="form-group">
                                            <label>Warning Level</label>
                                            <input type="text" name="app_inventory[warning_level]"
                                                   class="form-control form-control-sm num"
                                                   autocomplete="off" placeholder="Warning Level"
                                                   value="<?php echo @$warning_level; ?>" tabindex="11">

                                        </div>
                                    </div>
                                    <div class="col-4">
                                        <div class="form-group">
                                            <label>Expiry Date</label>
                                            <input type="text" name="app_inventory[expiry_date]"
                                                   class="form-control form-control-sm datepicker" autocomplete="off"
                                                   placeholder="Expiry Date"
                                                   value="<?php if (@$expiry_date != '0000-00-00'): echo @$expiry_date; endif; ?>"
                                                   tabindex="12">

                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                        <input type="hidden" name="app_products[app_id]" value="<?php echo @$app_id; ?>" readonly>
                        <input type="hidden" name="app_inventory[app_id]" value="<?php echo @$app_id; ?>" readonly>
                        <input type="hidden" name="className" value="Module_Class" readonly>
                        <?php if (@$getUpdate['response'] === "200"): ?>
                            <input type="hidden" name="functionName" value="updateInventoryItem" readonly>
                            <input type="hidden" name="app_products[pk]" value="<?php echo @$app_id; ?>" readonly>
                            <input type="hidden" name="app_inventory[pk]"
                                   value="<?php echo @$getUpdate2['dataArray'][0]['id']; ?>" readonly>
                            <input type="hidden" name="app_products[pkField]" value="app_id" readonly>
                            <input type="hidden" name="app_inventory[pkField]" value="id"
                                   readonly>
                        <?php else: ?>
                            <input type="hidden" name="functionName" value="createInventoryItem" readonly>
                            <input type="hidden" name="pk" value="sku_barcode" readonly>
                        <?php endif; ?>
                        <?php if (@$modalRequest == 1): ?>
                            <input type="hidden" name="callback[type]" value="modal" readonly>
                            <input type="hidden" name="callback[redirect]" value="" readonly>
                        <?php else: ?>
                            <input type="hidden" name="callback[type]" value="actionEvent" readonly>
                            <input type="hidden" name="callback[redirect]" value="itemCallback()" readonly>
                        <?php endif; ?>
                        <input type="hidden" name="app_products[tbl_scheme]" value="app_products" readonly>
                        <input type="hidden" name="app_inventory[tbl_scheme]" value="app_inventory" readonly>
                        <input type="hidden" name="created_by"
                               value="<?php echo trim(@$auth['firstname'] . ' ' . @$auth['lastname']); ?>" readonly>
                        <hr class="my-3">
                        <div class="row">
                            <div class="col-md-9 col-lg-10">
                                <button class="btn btn-default btn-sm actionButton" tabindex="13"><i
                                            class="fal fa-check-circle"></i>
                                    Submit
                                </button>
                                <div class="float-right text-muted py-2"><i class="fal fa-info-circle"></i> Submit
                                    basics
                                    information to enable Advance/Image upload page
                                </div>
                            </div>
                        </div>

                    </div>
                    <div class="tab-pane text-left fade" id="advance-tabs-panel" role="tabpanel"
                         aria-labelledby="advance-tabs">
                        <div class="row">
                            <div class="col-md-9 col-lg-10">
                                <div class="row">
                                    <div class="col-lg-5">
                                        <label class="text-muted mb-1 w-100">Special Price/Promo
                                            <div class="float-right">
                                                <div class="form-group mb-0">
                                                    <div class="custom-control custom-switch">
                                                        <input type="checkbox" class="custom-control-input propToggle"
                                                               id="promo_active_status">
                                                        <label class="custom-control-label pt-1"
                                                               for="promo_active_status">
                                                            Active
                                                            Status</label>
                                                        <input type="hidden" readonly name="active_status"
                                                               class="promo_active_status" form="promo"
                                                               value="">
                                                    </div>
                                                </div>
                                            </div>
                                        </label>
                                        <div class="row mb-2">
                                            <div class="col-md-4">
                                                <div class="form-group mb-0">
                                                    <label class="mb-1"><span class="required">*</span> Quantity</label>
                                                    <input type="text" required class="form-control form-control-sm num"
                                                           name="quantity_limit" form="promo"
                                                           placeholder="Quantity"
                                                           value="<?php echo @$quantity_limit; ?>">
                                                    <div class="invalid-feedback">* Required field</div>
                                                </div>
                                            </div>
                                            <div class="col-md-8">
                                                <div class="form-group mb-0">
                                                    <label class="mb-1"><span class="required">*</span> Promo
                                                        Price <?php echo $biz->currency['currency'] ?>
                                                    </label>
                                                    <div class="input-group">
                                                        <input type="text" class="form-control form-control-sm num"
                                                               required
                                                               autocomplete="off" form="promo"
                                                               name="promo_price" placeholder="Promo Price"
                                                               value="<?php echo @$promo_price; ?>">
                                                        <button class="btn btn-default btn-sm pr-2" form="promo"
                                                                type="submit"><i
                                                                    class="fal fa-save m-0"></i></button>
                                                    </div>
                                                    <div class="invalid-feedback">* Required field</div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group mb-2">
                                            <div class="custom-control custom-switch">
                                                <input type="checkbox" <?php if (@$time_based == 1): echo 'checked';endif; ?>
                                                       class="custom-control-input propToggle" id="time_based">
                                                <label class="custom-control-label pt-1" for="time_based"> Time based
                                                    <small class="text-muted">Specify Start & End date</small>
                                                </label>

                                                <input type="hidden" readonly name="time_based" form="promo"
                                                       class="time_based"
                                                       value="<?php if (@$time_based == 1): echo 1; else: echo 0;endif; ?>">
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group mb-0">
                                                    <label class="mb-1">Start Date</label>
                                                    <input type="text" class="form-control form-control-sm datepicker"
                                                           name="start_date" form="promo"
                                                           placeholder="Start Date"
                                                           value="<?php if (@$start_date != "0000-00-00") echo @$start_date; ?>">
                                                    <div class="invalid-feedback">* Required field</div>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group mb-0">
                                                    <label class="mb-1">End Date</label>
                                                    <input type="text" class="form-control form-control-sm datepicker"
                                                           autocomplete="off" form="promo"
                                                           name="end_date" placeholder="End Date"
                                                           value="<?php if (@$end_date != "0000-00-00") echo @$end_date; ?>">
                                                    <div class="invalid-feedback">* Required field</div>
                                                </div>
                                            </div>
                                        </div>
                                        <small class="text-muted">Record will be added to special prices/promo <a
                                                    href="javascript:void(0);"
                                                    onclick="location.replace('#/sales-point/items/promo'); fetchURL('')">list</a>
                                        </small>
                                        <hr class="my-2">
                                        <label class="text-muted mb-2">Product Packing</label>
                                        <div class="row">
                                            <div class="col-6">
                                                <div class="form-group">
                                                    <label class="w-100 mb-1">
                                                        <span class="required">*</span> Measure Unit
                                                        <a href="javascript:void(0)"
                                                           onclick="AppModalLoader({modalId:'ModuleModal', modalTitle:'Measure Units', required:'../manage-app/inc/measure_unit_form', afterEvent: 'reloadMeasure(\'ppk_measure_unit\')'});"
                                                           class="bg-transparent border-0 pointer float-right text-muted">[
                                                            <i
                                                                    class="fal fa-plus m-0"></i> ]</a>
                                                    </label>
                                                    <select name="product_packaging[measure_unit]" id="ppk_measure_unit"
                                                            class="form-control form-control-sm select2 ppkMeasureSelect"
                                                            tabindex="10"
                                                            style="width: 100%;" form="product-packaging" required>
                                                        <option value="">-- Measure Units --</option>
                                                        <?php
                                                        $listArray = $module->getRecord(["tbl_scheme" => 'app_measure_unit', "condition" => ["active_status" => 1]]);
                                                        foreach ($listArray['dataArray'] as $units):
                                                            echo $app->dropDownList($units['name'], $units['name'], @$measure_unit);
                                                        endforeach; ?>
                                                    </select>
                                                    <div class="invalid-feedback">* Required</div>
                                                </div>
                                            </div>
                                            <div class="col-6">
                                                <div class="form-group">
                                                    <label class="mb-1"><span class="required">*</span> Per Unit</label>
                                                    <div class="input-group">
                                                        <input type="text" name="product_packaging[per_unit]"
                                                               class="form-control form-control-sm num"
                                                               placeholder="Per Unit" form="product-packaging" required>
                                                        <button class="btn btn-default btn-sm pr-2 ppkBtn" type="submit"
                                                                form="product-packaging"><i
                                                                    class="fal fa-plus-square m-0"></i></button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div id="ppkResponse"></div>
                                        <div style="min-height: 145px; max-height: 145px; overflow: auto"
                                             id="packaging-container"
                                             class="card-body p-1 elevation-1">
                                            <?php require "packaging_list.php"; ?>
                                        </div>
                                    </div>
                                    <div class="col-7">
                                        <label class="text-muted">Additional Attribute</label>
                                        <div class="row">
                                            <div class="col-lg-4">
                                                <div class="form-group">
                                                    <label class="mb-1"><span class="required">*</span> Attribute
                                                        Name</label>
                                                    <input type="text" name="name" class="form-control form-control-sm"
                                                           required id="attrib-name" tabindex="1"
                                                           placeholder="Attribute Name" form="attributes-form">
                                                    <div class="invalid-feedback">* Required field</div>
                                                </div>
                                                <button class="btn btn-default btn-sm attribActionButton" tabindex="3"
                                                        form="attributes-form"><i
                                                            class="fal fa-save"></i> Save
                                                </button>
                                            </div>
                                            <div class="col-lg-8">
                                                <div class="form-group">
                                                    <label class="mb-1"><span class="required">*</span> Attribute
                                                        Description</label>
                                                    <textarea name="description" class="form-control form-control-sm"
                                                              rows="3"
                                                              form="attributes-form" id="attrib-desc" tabindex="2"
                                                              required
                                                              placeholder="Attribute Description"></textarea>
                                                    <div class="invalid-feedback">* Required field</div>
                                                </div>

                                            </div>
                                        </div>
                                        <div id="attribute-response"></div>
                                        <div style="min-height: 320px; max-height: 320px; overflow: auto"
                                             id="attrib-container" class="card-body p-1 elevation-1">
                                            <?php require "attributes_list.php"; ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane text-left fade" id="image-tabs-panel" role="tabpanel"
                         aria-labelledby="image-tabs">
                        <div class="row">
                            <div class="col-8">
                                <div class="">
                                    <i class="fal fa-images"></i> Image Gallery
                                </div>
                                <hr>
                                <div class="px-2" style="max-height: 350px; overflow: auto"
                                     id="image-gallery-container">
                                    <?php require "images_list.php"; ?>
                                </div>
                            </div>
                            <div class="col-4">
                                <div id="image-upload-response" class="actionEventResponse"></div>
                                <div class="form-group">
                                    <label for="">Description</label>
                                    <input type="text" name="image_description" form="image-form"
                                           class="form-control form-control-sm"
                                           autocomplete="off"
                                           placeholder="Description">
                                    <small class="text-muted">(Optional)</small>
                                </div>

                                <div class="form-group">
                                    <div class="custom-file">
                                        <input type="file" required name="file-link"
                                               class="custom-file-input item-image pointer" id="imageFileField">
                                        <label class="custom-file-label" for="imageFileField">Choose image
                                            file</label>
                                    </div>
                                    <small class="text-muted">Formats: jpg,jpeg,png | Dimension: 500x500</small>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </form>
</div>
<form method="post" class="AppForm" id="promo">
    <input type="hidden" name="className" value="Module_Class" readonly>
    <input type="hidden" name="functionName" value="createRecord" readonly>
    <input type="hidden" name="callback[type]" value="actionEvent" readonly>
    <input type="hidden" name="callback[redirect]" value="promoAlert()" readonly>
    <input type="hidden" name="tbl_scheme" value="app_promo" readonly>
    <?php @$promo_code = $app->generateAppId('', '', 8, '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ'); ?>
    <input type="hidden" name="product_name" value="<?php echo @$name; ?>" readonly>
    <input type="hidden" name="promo_code" value="<?php echo @$promo_code; ?>" readonly>
    <input type="hidden" name="app_id" value="<?php echo @$app_id; ?>" readonly>
    <input type="hidden" name="store_id" value="<?php echo @$store_id; ?>" readonly>
    <input type="hidden" name="created_by"
           value="<?php echo trim(@$auth['firstname'] . ' ' . @$auth['lastname']); ?>" readonly>
</form>
<form method="post" id="product-packaging">
    <input type="hidden" name="AddProductPackaging" value="1" readonly>
    <input type="hidden" name="product_packaging[app_id]" value="<?php echo @$app_id; ?>" readonly>
    <input type="hidden" name="product_packaging[store_id]" value="<?php echo @$store_id; ?>" readonly>
</form>
<form method="post" id="attributes-form">
    <input type="hidden" name="app_id" value="<?php echo $app_id; ?>" readonly>
    <input type="hidden" name="className" value="Module_Class" readonly>
    <input type="hidden" name="functionName" id="attrib_function" value="createRecord" readonly>
    <input type="hidden" name="pk" id="attribPK" value="" readonly disabled>
    <input type="hidden" name="pkField" id="attribPKField" value="" readonly disabled>
    <input type="hidden" name="tbl_scheme" value="app_products_attribute" readonly>
    <input type="hidden" name="callback[type]" value="self" readonly>
    <input type="hidden" name="callback[redirect]" value="" readonly>
</form>
<form method="post" id="image-form">
    <input type="hidden" form="image-form" id="image-field" name="image_file">
    <input type="hidden" name="app_id" value="<?php echo $app_id; ?>" readonly>
    <input type="hidden" name="ImageUpload" value="1" readonly>
    <input type="hidden" name="tbl_scheme" value="app_products_images" readonly>
    <input type="hidden" name="callback[type]" value="self" readonly>
    <input type="hidden" name="callback[redirect]" value="" readonly>
</form>

<div id="actionEvents"></div>
<div class="modal fade" id="batch-sku-upload" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog" role="document" style="max-width: 350px !important; margin: 3rem auto;">
        <div class="modal-content card">
            <div class="card-header">
                <h6 class="mb-0"><i class="fal fa-layer-group"></i> SKU/Barcode Batch Upload</h6>
            </div>
            <div class="modal-body card-body p-3">
                <div id="batchSKUResponse"></div>
                <form id="sku-form" method="post">
                    <div class="form-group">
                        <div class="input-group">
                            <input type="text" name="sku-barcode" id="sku_barcode" class="form-control-sm form-control"
                                   required autocomplete="off"
                                   placeholder="SKU/Barcode">
                            <div class="input-group-append">
                                <button class="btn btn-default btn-sm"><i class="fal fa-check-circle mr-0 pr-0"></i>
                                    Submit
                                </button>
                            </div>
                        </div>
                        <div class="invalid-feedback">* Require field</div>
                    </div>
                    <div id="SKU-list" style="max-height: 145px; overflow: auto">
                        <table class="table table-striped table-sm">
                            <?php if (@$getUpdate['response'] === "200"):
                                $batch_list = explode(',', $batch_sku_barcode);
                                if ($batch_list != NULL):
                                    foreach ($batch_list as $batch_id):
                                        if ($batch_id != ""):
                                            echo '<tr id="' . $batch_id . '"><td>' . $batch_id . '</td><td class="text-right"><a href="javascript:void(0)" onclick="delSKU(\'' . $batch_id . '\')"><i class="fal fa-trash-alt"></i></a></td></tr>';
                                        endif;
                                    endforeach;
                                endif;
                            endif; ?>
                        </table>
                    </div>
                </form>
                <span id="cache-sku"
                      class="hide"><?php if (@$getUpdate['response'] === "200" && $batch_sku_barcode != ""): echo @$batch_sku_barcode . ','; endif; ?></span>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-danger btn-sm" data-dismiss="modal"><i
                            class="fal fa-times-circle"></i>
                    Close
                </button>
                <button type="button" class="btn btn-danger btn-sm" onclick="discardSKU();"><i
                            class="fal fa-eraser"></i>
                    Discard
                </button>
            </div>
        </div>
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->
<!-- cropper loader  -->
<div class="modal fade" id="item-cropper-loader" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog" role="document" style="max-width: 31.875rem !important; ">
        <div class="modal-content card">
            <div class="modal-body card-body text-center  p-3" id="cropper-loader-contents">
                <div id="item-upload" class="center-block"></div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-danger btn-sm" data-dismiss="modal"><i
                            class="fal fa-times-circle"></i>
                    Close
                </button>
                <button type="button" id="cropImageBtn" class="btn btn-default btn-sm"><i class="fal fa-save"></i> Crop
                    & Save
                </button>
            </div>
        </div>
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->
<script>
    //--------------------------------------------------

    $('.focus_sku').focus();
    $('#batch-sku-upload').on('shown.bs.modal', function (e) {
        $("#sku_barcode").focus();
    })

    function batchSKU() {
        $("#batch-sku-upload").modal({backdrop: "static"})
    }

    $("#sku-form").on('submit', function (e) {
        e.preventDefault();
        var formData = $("#" + this.id).serializeArray();
        var fields = $("#SKU-list table");
        var field_val;
        $.each(formData, function (i, field) {
            fields.append("<tr id='" + field.value + "'><td>" + field.value + "</td><td class='text-right'><a href='javascript:void(0)' onclick=\"delSKU(\'" + field.value + "\')\"><i class='fal fa-trash-alt'></i></a></td></tr>");
            field_val = (field.value + ',');
        });
        $("#cache-sku").append(field_val.replace(',,', ','));
        $("#sku-input-list").val($("#cache-sku").html());
        $("#" + this.id)[0].reset();
        $("#sku_barcode").focus();
    });

    function delSKU(sku) {
        $("#" + sku).html('');
        var sku_list = $("#cache-sku").html();
        var new_sku_list = (sku_list.replace(sku, ''));
        $("#cache-sku").html(new_sku_list.replace(',,', ','));
        $("#sku-input-list").val($("#cache-sku").html())
    }

    function discardSKU() {
        var sku_barcodes = $("#sku-input-list").val();
        if (sku_barcodes !== "") {
            if (confirm("Are sure you want to discard the Batched SKU/Barcode")) {
                $("#sku-input-list").val('');
                $("#cache-sku").html('');
                var fields = $("#SKU-list table").html('');
            }
        }
    }

    //--------------------------------------------------

    function reloadCategory() {
        dropDownList("{\"request\":\"dropDownList\",\"pkField\":\"parent_id\",\"pk\":\"0\",\"target_scheme\":\"app_category\",\"key\":\"id\",\"label\":\"name\",\"target\":\"category_id\"}");
    };

    function reloadSubcategory() {
        dropDownList("{\"request\":\"dropDownList\",\"pkField\":\"parent_id\",\"pk\":" + $("#category_id").val() + ",\"target_scheme\":\"app_category\",\"key\":\"id\",\"label\":\"name\",\"target\":\"subcategory\"}")
    }

    function reloadMeasure(trg) {
        dropDownList("{\"request\":\"dropDownList\",\"pkField\":\"active_status\",\"pk\":\"1\",\"target_scheme\":\"app_measure_unit\",\"key\":\"name\",\"label\":\"name\",\"target\":\"" + trg + "\"}")
    }

    function itemCallback() {
        var obj = "<?php echo urlencode('"pkField":"id","pk":"' . @$getUpdate2['dataArray'][0]['id'] . '","view":"/#/inventory/add-item/","request":"update"'); ?>";
        moduleEditRequest(obj);

    }

    //-------------------------------------------------
    function promoAlert() {
        alert("Special Price/Promo successfully added");
        $("#promo")[0].reset();
    }

    //-------------------------------------------------
    $("#product-packaging").on('submit', function (e) {
        e.preventDefault();
        $(".ppkBtn").html('<i class="fal fa-spin fa-spinner"></i>');
        $.ajax({
            url: modulePath + "ajaxRequest.php",
            type: "POST",
            data: new FormData(this),
            contentType: false,
            cache: false,
            processData: false,
            success: function (data) {
                $("#ppkResponse").html(data);
                $(".ppkBtn").html('<i class="fal fa-plus-square m-0"></i>');
            },
            error: function () {
            }
        });
    });

    //-------------------------------------------------
    function PackagingList(packaging) {
        $.post(modulePath + "ajaxRequest.php",
            {
                PackagingListView: 1,
                packaging: packaging,
                rec_id: "<?php echo @$rec_id;?>"
            }, function (response) {
                $("#packaging-container").html(response);
            });
    }

    //-------------------------------------------------
    $("#attributes-form").on('submit', function (e) {
        e.preventDefault();
        $(".attribActionButton").html('<i class="fal fa-spin fa-spinner"></i> Processing...');
        $.ajax({
            url: modulePath + "ajaxRequest.php",
            type: "POST",
            data: new FormData(this),
            contentType: false,
            cache: false,
            processData: false,
            success: function (data) {
                var response = JSON.parse(data);
                $("#attribute-response").html(response['message']);
                if (response['success'] === 1) {
                    attribList();
                    $("#attributes-form")[0].reset();
                }
                if ($("#attrib_function").val() == 'updateRecord') {
                    $("#attribPK").val('');
                    $("#attribPKField").val('');
                    $("#attribPK").attr('disabled', 'disabled');
                    $("#attribPKField").attr('disabled', 'disabled');
                    $("#attrib_function").val("createRecord");
                }
                $(".attribActionButton").html('<i class="fal fa-save"></i> Save');
            },
            error: function () {
            }
        });
    });

    function attribList() {
        $.post(modulePath + "ajaxRequest.php",
            {
                AttribListView: 1,
                app_id: "<?php echo @$app_id;?>",
            }, function (response) {
                $("#attrib-container").html(response);
            });
    }

    function attribEditRequest(param) {
        var moduleRequest = ('{' + decodeURIComponent(param) + '}');
        var objJSON = JSON.parse(moduleRequest);
        var reqObj = {
            className: "Module_Class",
            functionName: "getRecord",
            tbl_scheme: "app_products_attribute",
            condition: {"id": objJSON['pk']},
        }
        $.post(modulePath + "ajaxRequest.php", reqObj
            , function (response) {
                var responseJSON = JSON.parse(response);
                if (responseJSON['success'] === 1) {
                    $("#attrib-name").val(responseJSON['dataArray'][0]['name']);
                    $("#attrib-desc").val(responseJSON['dataArray'][0]['description']);
                    $("#attribPK").val(responseJSON['dataArray'][0]['id']);
                    $("#attribPKField").val('id');
                    $("#attribPK").removeAttr('disabled');
                    $("#attribPKField").removeAttr('disabled');
                    $("#attrib_function").val("updateRecord");
                }
                //$("#attrib-container").html(response);
            });
    }

    //--------------------------------------------------
    var $uploadCrop,
        tempFilename,
        rawImg,
        imageId;

    function readFile(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            reader.onload = function (e) {
                $('.item-upload').addClass('ready');
                $('#item-cropper-loader').modal('show');
                rawImg = e.target.result;
            }
            reader.readAsDataURL(input.files[0]);
        }
        else {
            swal("Sorry - you're browser doesn't support the FileReader API");
        }
    }

    $uploadCrop = $('#item-upload').croppie({
        viewport: {
            width: 420,
            height: 420,
        },
        enforceBoundary: false,
        enableExif: true
    });
    $('#item-cropper-loader').on('shown.bs.modal', function () {
        // alert('Shown pop');
        $uploadCrop.croppie('bind', {
            url: rawImg
        }).then(function () {
            console.log('jQuery bind complete');
        });
    });
    $('.item-image').on('change', function () {
        imageId = $(this).data('id');
        tempFilename = $(this).val();
        $('#cancelCropBtn').data('id', imageId);
        readFile(this);
    });
    $('#cropImageBtn').on('click', function (ev) {
        $uploadCrop.croppie('result', {
            type: 'base64',
            format: 'png',
            size: {width: 500, height: 500}
        }).then(function (resp) {
            $('#item-image').attr('src', resp);
            $("#image-field").val(resp);
            $("#image-form").submit();
            $('#item-cropper-loader').modal('hide');

        });
    });

    function loadImages() {
        $.post(modulePath + "ajaxRequest.php",
            {
                ImageListView: 1,
                app_id: "<?php echo $app_id;?>",
            }, function (response) {
                $("#image-gallery-container").html(response);
            });
    }

    $("#image-form").on('submit', function (e) {
        e.preventDefault();
        // $(".attribActionButton").html('<i class="fal fa-spin fa-spinner"></i> Processing...');
        $.ajax({
            url: modulePath + "ajaxRequest.php",
            type: "POST",
            data: new FormData(this),
            contentType: false,
            cache: false,
            processData: false,
            success: function (data) {
                var response = JSON.parse(data);
                if (response['success'] === 1) {
                    $("#image-upload-response").html(response['message']);
                    $("#image-form")[0].reset();
                    loadImages();
                } else {
                    $("#image-upload-response").html(response['message']);
                }
            },
            error: function () {
            }
        });
    });
</script>