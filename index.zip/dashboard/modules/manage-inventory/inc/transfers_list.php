<?php
//--------------------------------------------------------------------------------------------------
$store = "";
if (isset($auth['store_id']) && $auth['store_id'] != ""):
    $store = "AND app_stock_transfer.store_id = '" . $auth['store_id'] . "' ";
endif;
//--------------------------------------------------------------------------------------------------
$default = "app_stock_transfer.destination_inventory = app_stores.app_id " . $store;
$condition = $default;
//--------------------------------------------------------------------------------------------------
if (isset($_POST['filterRequest']) && $_POST['filterRequest'] !== NULL):
    $filterParam = $_POST['filterRequest'];
    if ($filterParam['search'] != ""):
        $condition = "";
        $search_query = trim($filterParam['search']);
        $condition = $default . "AND app_products.sku_barcode LIKE '%" . $search_query . "%'";
        $condition .= "OR " . $default . " AND app_products.app_id LIKE '%" . $search_query . "%' ";
        $condition .= "OR " . $default . " AND app_products.batch_sku_barcode LIKE '%" . $search_query . "%' ";
        $condition .= "OR " . $default . " AND app_products.name LIKE '%" . $search_query . "%' ";
        $condition .= "OR " . $default . " AND app_products.description LIKE '%" . $search_query . "%' ";
    else:
        @$category_id = @$filterParam['category_subcategory'];
        @$warning_level = @$filterParam['warning_level'];
        @$expiry_warning = @$filterParam['expiry_warning'];
        if ($category_id != "" || $warning_level != "" || $expiry_warning != ""):
            $condition = "";
        endif;
        if (@$category_id != ""):
            $condition .= $default . " AND app_products.category_id = '$category_id'";
        endif;
        if (@$warning_level != ""):
            $condition .= $default . " AND app_inventory.stock_qty < app_inventory.warning_level ";
        endif;
        if (@$expiry_warning != ""):
            $condition .= $default . " AND app_inventory.expiry_date != '' 
            AND app_inventory.expiry_date != '0000-00-00' 
            AND app_inventory.expiry_date <= DATE_ADD(CURRENT_DATE(), INTERVAL '$expiry_warning' DAY)";
        endif;
    endif;
endif;
$paginate_exp = explode('?page=', $url);
if (isset($paginate_exp[1]) && $paginate_exp[1] != ""):
    $ipp_exp = explode('&ipp=', $paginate_exp[1]);
    if (isset($ipp_exp[0]) && $ipp_exp[0] != ""):
        define('page', $ipp_exp[0]);
    else:
    endif;
    if (isset($ipp_exp[1]) && $ipp_exp[1] != ""):
        define('ipp', $ipp_exp[1]);
    else:
    endif;
else:
    @define('page', '');
    @define('ipp', '');
endif;
@define('self', '#/sales-point/items/');
$pages = new Paginator_Class;
if (ipp != ""):
    $pages->default_ipp = ipp;
else:
    $pages->default_ipp = 50;
endif;

$sql_forms = Data_Access::execSQL("SELECT app_inventory.app_id FROM " . $app->dbScheme . ".app_inventory, " . $app->dbScheme . ".app_products WHERE " . $condition . "  ");
@$pages->items_total = $sql_forms['dataArray']->num_rows;
$pages->mid_range = 4;
$pages->paginate();
@$sql = "SELECT app_stock_transfer.reference, app_stock_transfer.created_by, app_stock_transfer.created_on, app_stock_transfer.submission_status, app_stores.app_id, app_stores.store_name, 
app_stores.country, app_stores.state, app_stores.city  ";
@$sql .= "FROM " . $app->dbScheme . ".app_stock_transfer, " . $app->dbScheme . ".app_stores ";
@$sql .= "WHERE   " . $condition . " ORDER BY app_stock_transfer.created_on DESC " . $pages->limit . " ";

if (!($result = Data_Access::execSQL($sql))):
    die(mysqli_error());
else :
    @$recordsArray = Data_Access::fetchAssoc($result['dataArray'])['dataArray'];
endif;
?>
<div id="ModuleResponse"></div>
<div class="row marginTop mx-0">
    <div class="col-12 pl-0 paddingLeft pagerfwt">
        <?php if ($pages->items_total > 0) { ?>
            <?php echo $pages->display_pages(); ?>
            <?php echo $pages->display_items_per_page(); ?>
            <?php echo $pages->display_jump_menu(); ?>
        <?php } ?>
    </div>
    <div class="clearfix"></div>
    <hr>
</div>
<div class="table-responsive">
    <table class="table data-tables table-sm elevation-1">
        <?php if (@$filterParam != NULL): ?>
            <caption>Currently viewing filter product(s) [ <a href="javascript:void(0);" onclick="fetchURL('');"
                                                              class="small">Reset Filter</a> ]
            </caption>
        <?php else: ?>
            <caption>Current viewing all product(s)</caption>
        <?php endif; ?>
        <thead>
        <tr>
            <th>Reference</th>
            <th>Destination Name</th>
            <th>Location</th>
            <th>Products #</th>
            <th>Amount <?php echo $biz->currency['currency']; ?></th>
            <th>Status</th>
            <th>Created By</th>
            <th></th>
            <th><i class="fal fa-cogs"></i></th>
        </tr>
        </thead>
        <tbody class="card-body">
        <?php
        if (isset($recordsArray) && $recordsArray != NULL):
            foreach (@$recordsArray as $transfer):
                extract($transfer);
                @$transfers = $module->getRecord([
                    "tbl_scheme" => "app_stock_transfers",
                    "condition" => ["reference" => $reference]
                ])['dataArray'];
                if ($transfers != NULL):
                    $amount = 0;
                    foreach ($transfers as $product):
                        $amount = $amount + $product['stock_qty'] * $product['stock_price'];
                    endforeach;
                endif;
                ?>
                <tr>
                    <td><?php echo @$reference; ?></td>
                    <td><?php echo @trim(@$store_name); ?></td>
                    <td><?php echo trim(trim($app->getLocation('CN', $country) . ', ' . $app->getLocation('S', $state) . ', ' . $app->getLocation('C', $city)), ', '); ?></td>
                    <td><?php echo @count($transfers); ?></td>
                    <td><?php echo @number_format($amount, 2); ?></td>
                    <td><?php if (@$submission_status == 0): echo "Pending Transfer"; else: echo "Transferred"; endif; ?></td>
                    <td><?php echo @$created_by; ?></td>
                    <td><?php echo @$created_on; ?></td>
                    <td style="width:5%;" class="py-1" nowrap="nowrap">
                        <div class="btn-group-justify btn-group-sm float-right">
                            <?php if (@$submission_status == 1): ?>

                                <button type="button" class="btn btn-default"
                                        onclick="AppModalLoader({modalId:'ModuleModal', modalSize:'modal-lg', modalTitle:'Product Information', required:'../manage-inventory/inc/product_info', afterEvent: '', modalRequest:{'app_id':'<?php echo $reference; ?>'}});"
                                        title="View Record"><i
                                            class="fal fa-info-circle"></i>
                                </button>
                            <?php else: ?>
                                <button type="button" class="btn btn-default"
                                        onclick='location.replace("#/inventory/transfer/<?php echo $reference; ?>/"); fetchURL("")'
                                        title=" Edit Record"><i
                                            class="fal fa-edit"></i>
                                </button>
                                <button type="button" class="btn btn-default"
                                        onclick='javascript: var obj = "<?php echo urlencode('"discardTransfer":{"reference":"' . $reference . '"},"callback":{"type":"self","redirect":""},"notification":{"message":"Are you sure to discard this transfer record?<\/br> All information will erased!!","title":"Delete Warning"}'); ?>";  moduleRequest(obj);'
                                        title=" Edit Record"><i
                                            class="fal fa-trash-alt"></i>
                                </button>
                            <?php endif; ?>

                    </td>
                </tr>
            <?php endforeach;
        else: ?>
            <tr>
                <td colspan="7" align="center">No data available</td>
            </tr>
        <?php endif; ?>
        </tbody>
    </table>
</div>
<div class="row marginTop mx-0">
    <div class="col-12 pl-0 paddingLeft pagerfwt">
        <?php if ($pages->items_total > 0) { ?>
            <?php echo $pages->display_pages(); ?>
            <?php echo $pages->display_items_per_page(); ?>
            <?php echo $pages->display_jump_menu(); ?>
        <?php } ?>
    </div>
    <div class="clearfix"></div>
    <hr>
</div>
