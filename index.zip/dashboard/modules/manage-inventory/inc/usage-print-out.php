<?php
/**
 * Created by PhpStorm.
 * User: DBlasterMaster
 * Date: 5/4/2020
 * Time: 10:18 PM
 */
$decodeRef = base64_decode($_GET['usage-print']);
$exp_ref = explode('&ref=', $decodeRef);
$ref = $exp_ref[1];

$usage = dbFetchAssoc(dbQuery("SELECT * FROM app_inventory_usage WHERE ref_no = '$ref'"));

?>


<div class="row">

    <div class="col-md-8 m-auto">
        <div class="row mt-3">
            <div class="col-lg-12 text-right">
                <div class="btn-group-justified">
                    <button onClick="printReceipt('receiptPrint');"
                            class="btn btn-dark br-0 px-4 receipt-print-btn" id="printReceipt"
                            title="Print Receipt" data-toggle="tooltip" data-placement="top"><i
                                class="fal fa-print fa-lg"></i>
                        Print
                    </button>
                    <a class="btn btn-danger br-0 pl-3 pr-3" href="#"
                       onclick="location.replace('?p=manage-inventory&consumption');" title="Close"
                       data-toggle="tooltip" data-placement="top"><i class="fal fa-times-circle fa-lg"></i> Close</a>

                </div>
            </div>
        </div>
        <div class="panel panel-primary border shadow-sm"
             <?php if (!isset($_GET['id'])) { ?>style="max-height:565px; overflow:auto"
            <?php } ?>>
            <div class="panel-body position-relative" style="background:#fff; padding:30px; font-family: receipt;">
                <div id="receiptPrint" class="sales-receipt">
                    <div class="text-center" style="text-transform:uppercase;">
                        <h3 style="margin:0" class="s_name">
                            <?php echo $appinfo['app_shop']; ?>
                        </h3>
                    </div>
                    <div class="text-center address">
                        <?php echo $appinfo['shop_address']; ?><br>
                        <label for="">CALL US:</label>
                        <?php echo $appinfo['shop_mobile']; ?>
                    </div>
                    <h4 class="text-center" id="r_title">Inventory Usage</h4>
                    <div class="row r_ref">
                        <div class="col-md-12 text-left">
                            <div><label for="">Reference #:</label>
                                <?php echo $usage['ref_no']; ?>
                            </div>
                        </div>
                    </div>
                    <div class="row r_ref">
                        <div class="col-md-12 text-left pull-right">
                            <div><label for="">Created By:</label>
                                <?php echo $usage['created_by']; ?>
                            </div>
                        </div>
                    </div>
                    <div class="row r_ref">
                        <div class="col-md-12 text-left pull-right">
                            <div><label for="">Created On:</label>
                                <?php echo $usage['created_on']; ?>
                            </div>
                        </div>
                    </div>
                    <table width="100%" border="0" cellpadding="0" cellspacing="0" class="table">
                        <thead id="rcp_head">
                        <td>#</td>
                        <td align="left">Description</td>
                        <td>Qty</td>
                        <td nowrap>Amount <?php echo $currency; ?></td>
                        </thead>
                        <tbody>
                        <?php
                        $index = 0;
                        $total = 0;
                        $items = dbQuery("SELECT id, item_id, item_name, item_qty, amount 
                                              FROM app_inventory_transacts WHERE transact_id = '" . $usage['ref_no'] . "'");
                        while ($dn2 = dbFetchAssoc($items)): $index++;
                            $total = $total + ($dn2['item_qty'] * $dn2['amount']);
                            ?>
                            <tr>
                                <td>
                                    <?php echo $index; ?>
                                </td>
                                <td>
                                    <?php echo $dn2['item_name']; ?>
                                </td>
                                <td>
                                    <?php echo number_format($dn2['item_qty']); ?>
                                </td>
                                <td>
                                    <?php echo number_format($dn2['amount'] * $dn2['item_qty']); ?>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                        <tr class="t_row">
                            <th colspan="3" style="padding-right: 1px" class=" text-right">TOTAL
                                <?php echo $currency; ?>
                            </th>
                            <td align="left" class="">
                                <?php echo number_format($total); ?>
                            </td>
                        </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>


        <!--
        <script>

            function printReceipt(id) {
                var contents = $('#' + id).html();
                alert(contents);
                $('#' + id).printThis();
            }

        </script> -->

    </div>
</div>