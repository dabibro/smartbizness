<?php
$store = "";
if (isset($auth['store_id']) && $auth['store_id'] != ""):
    $store = " AND app_inventory.store_id = '" . $auth['store_id'] . "' ";
endif;
//------------------------------------------------------------------------------------
$default = "app_products.app_id = app_inventory.app_id " . $store;
$condition = $default;
$paginate_exp = explode('?page=', $url);
if (isset($paginate_exp[1]) && $paginate_exp[1] != ""):
    $ipp_exp = explode('&ipp=', $paginate_exp[1]);
    if (isset($ipp_exp[0]) && $ipp_exp[0] != ""):
        define('page', $ipp_exp[0]);
    else:
    endif;
    if (isset($ipp_exp[1]) && $ipp_exp[1] != ""):
        define('ipp', $ipp_exp[1]);
    else:
    endif;
else:
    define('page', '');
    define('ipp', '');
endif;
define('self', '#/inventory/');
$pages = new Paginator_Class;
if (ipp != ""):
    $pages->default_ipp = ipp;
else:
    $pages->default_ipp = 50;
endif;
$sql_forms = Data_Access::execSQL("SELECT * FROM app_inventory");
@$pages->items_total = $sql_forms['dataArray']->num_rows;
$pages->mid_range = 4;
$pages->paginate();

$sql = "SELECT app_inventory.id, app_inventory.app_id, app_inventory.active_status, app_inventory.store_id, app_inventory.stock_qty,
        app_products.sku_barcode, app_products.name, app_products.category_id, app_products.price, app_products.sale_price
        FROM app_inventory, app_products 
        WHERE " . $condition . " ORDER BY app_products.name, app_inventory.store_id ASC " . $pages->limit . " ";
if (!($result = Data_Access::execSQL($sql))) {
    die(mysqli_error());
} else {
    @$recordsArray = Data_Access::fetchAssoc($result['dataArray'])['dataArray'];
}

/*
$requestArray = array(
    "tbl_scheme" => 'app_inventory',
    "order" => 'store_id ASC');
$recordRequest = $module->getRecord($requestArray);
$recordsArray = $recordRequest['dataArray'];
*/
?>
<div id="ModuleResponse"></div>

<div class="text-right mb-3">
    <button class="btn btn-default btn-sm"><i class="fal fa-box-check"></i>Stock Check</button>
    <button class="btn btn-default btn-sm"><i class="fal fa-box-check"></i> Print Inventory</button>
</div>

<div class="row marginTop mx-0">
    <div class="col-12 pl-0 paddingLeft pagerfwt">
        <?php if ($pages->items_total > 0) { ?>
            <?php echo $pages->display_pages(); ?>
            <?php echo $pages->display_items_per_page(); ?>
            <?php echo $pages->display_jump_menu(); ?>
        <?php } ?>
    </div>
    <div class="clearfix"></div>
    <hr>
</div>
<div class="table-responsive">
    <table class="table data-tables table-sm elevation-1">
        <caption>View All Record</caption>
        <thead>
        <tr>
            <th>SKU/Barcode</th>
            <th>Name/Description</th>
            <th>Store Name</th>
            <th>Category</th>
            <th>Stock Qty</th>
            <th>Price</th>
            <th>Sale Price</th>
            <th>Status</th>
            <th><i class="fal fa-cogs"></i></th>
        </tr>
        </thead>
        <tbody class="card-body">
        <?php
        if (isset($recordsArray)):
            foreach (@$recordsArray as $inventory): extract($inventory); ?>
                <tr>
                    <td><?php echo @$sku_barcode; ?></td>
                    <td><?php echo @trim(@$name); ?></td>
                    <td><?php echo trim(@$module->getRecord(["tbl_scheme" => 'app_stores', "condition" => ["app_id" => @$store_id]])['dataArray'][0]['store_name']); ?></td>
                    <td><?php echo @trim(@$module->getRecord(["tbl_scheme" => 'app_category', "condition" => ["id" => @$category_id]])['dataArray'][0]['name']); ?></td>
                    <td><?php echo @$stock_qty; ?></td>
                    <td><?php echo @number_format($price, 2); ?></td>
                    <td><?php echo @number_format($sale_price, 2); ?></td>
                    <td><?php if (@$active_status == 1):echo 'Active'; else:echo 'Inactive'; endif; ?></td>
                    <td style="width:5%;" class="py-1" nowrap="nowrap">
                        <div class="btn-group-justify btn-group-sm float-right">
                            <button type="button" class="btn btn-default"
                                    onclick='javascript: var obj = "<?php echo urlencode('"pkField":"store_id","pk":' . $store_id . ',"view":"/#/create-store/","request":"update"'); ?>"; moduleEditRequest(obj)'
                                    title="View Record"><i
                                        class="fal fa-info-circle"></i>
                            </button>
                            <button type="button" class="btn btn-default"
                                    onclick='javascript: var obj = "<?php echo urlencode('"pkField":"id","pk":"' . $id . '","view":"/#/inventory/add-item/","request":"update"'); ?>"; moduleEditRequest(obj)'
                                    title=" Edit Record"><i
                                        class="fal fa-edit"></i>
                            </button>
                            <button type="button" class="btn btn-default"
                                    onclick='javascript: var obj = "<?php echo urlencode('"className":"Module_Class","functionName":"deleteInventoryItem","tbl_scheme":"","pk":{"app_id":"' . $app_id . '"},"callback":{"type":"self","redirect":""},"notification":{"message":"Are you sure to delete this inventory record?","title":"Delete Warning"}'); ?>";  moduleRequest(obj);'
                                    title=" Edit Record"><i
                                        class="fal fa-trash-alt"></i>
                            </button>
                    </td>
                </tr>
            <?php endforeach;
        endif;
        ?>
        </tbody>
    </table>
</div>
<div class="row marginTop mx-0">
    <div class="col-12 pl-0 paddingLeft pagerfwt">
        <?php if ($pages->items_total > 0) { ?>
            <?php echo $pages->display_pages(); ?>
            <?php echo $pages->display_items_per_page(); ?>
            <?php echo $pages->display_jump_menu(); ?>
        <?php } ?>
    </div>
    <div class="clearfix"></div>
    <hr>
</div>
