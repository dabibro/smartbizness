<?php

require "Module_Class.php";
$module = new Module_Class;
$modulePath = @$appSwitcher->modulePath($AppModule);
$req = $AppModuleRequest;
$view = $AppModuleView;
$getSubView = explode('transfer/', $view);
if (isset($getSubView[1]) && $getSubView[1] != ""):
    $view = "transfer/";
    $getPaging = explode('?page', $getSubView[1]);
    if (isset($getPaging) && @$getPaging[1] != ""):
        $transRef = trim($getPaging[0], '/');
    else:
        $transRef = trim($getSubView[1], '/');
    endif;
endif;
//$appUsers = new App_Users;
//$req = $AppModuleRequest;
//$modulePath = @$appSwitcher->modulePath($AppModule);
?>
<script src="<?php echo $modulePath ?>js.js"></script>
<input type="hidden" value="<?php echo $modulePath; ?>" id="ModulePath" readonly>
<div class="card card-primary card-outline card-outline-tabs" id="manage-inventory">
    <div class="card-header p-0 border-bottom-0">
        <ul class="nav nav-tabs app-menu" id="manage-users-tabs" role="tablist">
            <li class="nav-item">
                <a class="nav-link <?php if ($req == 'inventory/' && $view != 'import/' && $view != 'transfer/'): echo 'active'; endif; ?>"
                   href="#/inventory/" onclick="fetchURL(this.href)"><i class="fal fa-inventory"></i> Product Inventory</a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php if ($view == 'transfer/'): echo 'active'; endif; ?>"
                   href="#/inventory/transfer/" onclick="fetchURL(this.href)"><i class="fal fa-exchange"></i> Stock
                    Transfer</a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php if ($view == 'import/'): echo 'active'; endif; ?>"
                   href="#/inventory/import/" onclick="fetchURL(this.href)"><i class="fal fa-file-csv"></i>
                    Import/Export Data (CSV)</a>
            </li>
        </ul>
    </div>
    <div class="card-body">
        <div class="tab-content" id="manage-users-tabContent">
            <div class="tab-pane fade <?php if ($req == 'inventory/' && $view != 'import/' && $view != "transfer/"): echo 'active show'; endif; ?>"
                 id="users-tab" role="tabpanel" aria-labelledby="tabs-users-tabs">
                <?php if ($req == 'inventory/' && $view != 'import/' && $view != "transfer/"): require "inc/inventory.php";endif; ?>
            </div>
            <div class="tab-pane fade <?php if ($view == 'import/'): echo 'active show'; endif; ?>"
                 id="create-new-tab" role="tabpanel" aria-labelledby="tabs-create-new-tab">
                <?php if ($view == 'import/'): require "inc/import_data.php"; endif; ?>

            </div>
            <div class="tab-pane fade <?php if ($view == 'transfer/'): echo 'active show'; endif; ?>"
                 id="create-new-tab" role="tabpanel" aria-labelledby="tabs-create-new-tab">
                <?php if ($view == 'transfer/'): require "inc/transfers.php"; endif; ?>

            </div>
        </div>
    </div>
    <!-- /.card -->
</div>

          