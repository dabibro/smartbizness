<?php

//--------------------------------------------------------------------
if (file_exists("../../../../helpers/config/config.inc.php")):
    require "../../../../helpers/config/config.inc.php";
endif;
require "../../../../helpers/handlers/app_autoloader.php";
require "../Module_Class.php";
//--------------------------------------------------------------------
$module = new Module_Class;
//--------------------------------------------------------------------
$appAuth = new Auth_Access;
$auth = $appAuth->AppAuthChecker();
//--------------------------------------------------------------------
$store = "";
if (isset($auth['store_id']) && $auth['store_id'] != ""):
    $store = "app_inventory.store_id = '" . trim($auth['store_id']) . "' AND ";
endif;
//-------------------------------------------------------------------------------
$search_term = $_GET['term'];
//-------------------------------------------------------------------------------
$condition = $store . "app_inventory.app_id = app_products.app_id AND app_inventory.active_status = '1' AND ";
$default = ltrim($condition, 'AND ');
//-------------------------------------------------------------------------------
$sql = "SELECT app_products.app_id, app_products.name  
        FROM " . $module->dbScheme . ".app_inventory, " . $module->dbScheme . ".app_products 
        WHERE " . $default . " app_inventory.app_id LIKE '%" . $search_term . "%'
        OR " . $default . " app_products.sku_barcode LIKE '%" . $search_term . "%' 
        OR " . $default . " app_products.batch_sku_barcode LIKE '%" . $search_term . "%'  
        OR " . $default . " app_products.name LIKE '%" . $search_term . "%'  
        OR " . $default . " app_products.description LIKE '%" . $search_term . "%'          
        ORDER BY app_products.name ASC LIMIT 25";
$query = $module->exeSQL($sql);
if (@$query['dataArray']->num_rows === 0):
    $data[] = 'No record found';
else:
    foreach ($query['dataArray'] as $field):
        $data[] = '' . $field['app_id'] . ' -> ' . $field['name'];
    endforeach;
endif;

echo json_encode($data);
