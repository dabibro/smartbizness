<?php
/**
 * Created by PhpStorm.
 * User: DBlasterMaster
 * Date: 4/12/2020
 * Time: 5:16 PM
 */

require '../../../helpers/config.php';
require '../../../helpers/functions.php';

//submit menu form
if (isset($_POST['submit-inventory-form'])) {
    $menu_id = $_POST['menu-id'];
    $menu_name = $_POST['menu-name'];
    $category = $_POST['category'];
    $unit_price = $_POST['unit-price'];
    @$sales_price = @$_POST['sales-price'];
    $expiry_date = $_POST['expiry-date'];
    $warning_level = $_POST['warning-level'];
    $packaging = $_POST['packaging'];
    $additional_description = test_input($_POST['additional-description']);
    $check = "SELECT id FROM app_inventory WHERE menu_name = '$menu_name' AND category = '$category'";
    if (dbNumRows(dbQuery($check)) != 0 && $_POST['submit-inventory-form'] == 1) {
        echo '<div class="alert alert-danger py-2 px-3"> <i class="fal fa-exclamation-triangle"></i> Item with name already exist in selected category</div>';
    } else {
        if ($_POST['submit-inventory-form'] == 1) {
            $sql = "INSERT INTO app_inventory (menu_id, menu_name, category, unit_price, sales_price, expiry_date, warning_level, packaging, additional_description)
                    VALUES ('$menu_id', '$menu_name', '$category', '$unit_price', '$sales_price', '$expiry_date', '$warning_level', '$packaging', '$additional_description')";
            if (!$query = dbQuery($sql)) {
                echo '<div class="alert alert-danger py-2 px-3"> <i class="fal fa-exclamation-triangle"></i> Could not add menu record, try again</div>';
            } else {
                echo '<div class="alert alert-success py-2 px-3"> <i class="fal fa-check-circle"></i> Item record successfully created!!</div>';
                echo '<script>location.replace("?p=manage-inventory&inventory&create-item=' . base64_encode(sixRandomNumbers()) . '")</script>';
            }
        } else {
            $sql = "UPDATE app_inventory SET 
                    menu_id = '$menu_id',
                    menu_name = '$menu_name',
                    category = '$category',
                    unit_price = '$unit_price',
                    sales_price = '$sales_price',
                    expiry_date = '$expiry_date',
                    warning_level = '$warning_level',
                    packaging = '$packaging',
                    additional_description = '$additional_description'
                    WHERE id = '" . $_POST['id'] . "'";
            if (!$query = dbQuery($sql)) {
                echo '<div class="alert alert-danger py-2 px-3"> <i class="fal fa-exclamation-triangle"></i> Could not update menu record, try again</div>';
            } else {
                echo '<div class="alert alert-success py-2 px-3"> <i class="fal fa-check-circle"></i> Item record successfully updated!!</div>';
                echo '<script>location.reload();</script>';
            }
        }

        if (isset($_POST['image-file']) && $_POST['image-file'] != "") {
            $croped_image = $_POST['image-file'];
            list($type, $croped_image) = explode(';', $croped_image);
            list(, $croped_image) = explode(',', $croped_image);
            $croped_image = base64_decode($croped_image);
            $image_name = $menu_id . '.png';
            // upload cropped image to server
            $upload = file_put_contents('../../../files/item-images/' . $image_name, $croped_image);
            if ($upload) {
                dbQuery("UPDATE app_inventory SET item_image = '$image_name' WHERE id = '" . @$_POST['id'] . "' ");
            }
        }
    }
}


//get stock item information
if (isset($_GET['get-item-qty'])) {
    $id = ($_GET['id']);
    $query = dbQuery("SELECT id, menu_name, quantity, unit_price, sales_price FROM app_inventory WHERE menu_id ='$id' AND active_status = 1");
    if (dbNumRows($query) != 0) {
        $item = dbFetchAssoc($query);
        echo '<script>$("#stock-item-name").val("' . $item['menu_name'] . '");</script>';
        echo '<script>$("#stocking-info").removeClass("hide");</script>';
        echo '<script>$("#item-id").val(' . $item['id'] . ');</script>';
        echo '<script>$("#current-qty").val(' . $item['quantity'] . ');</script>';
        //echo '<script>$("#unit-price").val(' . $item['unit_price'] . ');</script>';
        echo '<script>$("#sales-price").val(' . $item['sales_price'] . ');</script>';
        echo '<script>$("#add-qty").focus();</script>';
    } else {
        echo '<div class="alert alert-danger animated fadeIn py-2 px-3"><i class="fal fa-exclamation-triangle"></i> Invalid Item Select, Try Again!!!</div>';
        echo '<script>$("#stocking-info").addClass("hide");</script>';

    }
}

//submit stocking record
if (isset($_POST['submit-item-stocking']) && $_POST['submit-item-stocking'] == 1) {

    $item_id = $_POST['item-id'];
    $item_name = $_POST['item-name'];
    $current_qty = $_POST['current-qty'];
    $unit_price = $_POST['unit-price'];
    $sales_price = $_POST['sales-price'];
    $add_qty = $_POST['add-qty'];
    $new_qty = $_POST['new-qty'];

    $item = getInventory($item_id);

    if ($unit_price != $item['unit_price']) {
        $unit_price = $unit_price;
    } else {
        $unit_price = $item['unit_price'];
    }
    if ($sales_price != $item['sales_price']) {
        $sales_price = $sales_price;
    } else {
        $sales_price = $item['sales_price'];
    }

    $sql_stock = "UPDATE app_inventory SET 
                  quantity = quantity + '$add_qty',
                  unit_price = '$unit_price',
                  sales_price = '$sales_price'
                  WHERE id = '$item_id'";

    $sql_stock_log = "INSERT INTO app_inventory_stocking (item_id, item_name, unit_price, sales_price, current_qty, add_qty, new_qty, entry_by)VALUE('$item_id', '$item_name', '$unit_price', '$sales_price', '$current_qty', '$add_qty', '$new_qty', '$user_name' )";


    if (!$query = dbQuery($sql_stock)) {
        echo mysqli_error();
    } else {
        dbQuery($sql_stock_log);
        echo '<div class="alert alert-success animated fadeIn py-2 px-3"><i class="fal fa-check-circle"></i> Item Stocking successful!!</div>';
        echo '<script>$("#submit-stocking-form")[0].reset();</script>';
        echo '<script>$(".stocking-item-lookup").focus();</script>';
    }
}

//inventory item info
if (isset($_GET['inventory-item-info']) && $_GET['item-id'] != "") {
    $exp = explode(' -> ', $_GET['item-id']);
    $item_id = $exp[0];
    @$item_name = $exp[1];
    $item = dbFetchAssoc(dbQuery("SELECT * FROM app_inventory WHERE menu_id = '$item_id'"));
    if ($item_id) {
        echo '<script>$("#item-id").val("' . $item['id'] . '")</script>';
        echo '<script>$("#rate").val("' . number_format($item['sales_price'], 2) . '")</script>';
        echo '<script>$("#item-name").val("' . $item_name . '")</script>';
        echo '<script>calcUsageItem();</script>';
    } else {
        echo '<script>$("#item-id").val("")</script>';
        echo '<script>$("#rate").val("")</script>';
        echo '<script>$("#item-name").val("")</script>';
        echo '<script>$("#amount").val("")</script>';
    }


}

//submit selected usage item
if (isset($_POST['add-usage-item']) && $_POST['add-usage-item'] == 1) {
    $ref_no = $_POST['ref-no'];
    $item_id = $_POST['item-id'];
    $getItem = getInventory($item_id);
    $item_name = $getItem['menu_name'];
    $item_qty = $_POST['qty'];
    $amount = $getItem['sales_price'];

    //check record entry
    $check = dbNumRows(dbQuery("SELECT id FROM app_inventory_transacts WHERE transact_id = '$ref_no' AND item_id = '$item_id' AND status != 'Cleared'"));
    if ($check == 0) {
        $sql = "INSERT INTO app_inventory_transacts (transact_id, item_id, item_name, item_qty, amount, entry_by) VALUES ('$ref_no', '$item_id', '$item_name', '$item_qty', '$amount* $item_qty', '$user_id')";
    } else {
        $sql = "UPDATE app_inventory_transacts SET item_qty = item_qty + '$item_qty' WHERE item_id = '$item_id' ";
    }
    if (!$query = dbQuery($sql)) {
        echo mysqli_error();
    } else {
        echo '<script>$("#item-usage-form")[0].reset();</script>';
        echo '<script>location.reload();</script>';
    }

}

//submit inventory usage
if (isset($_POST['submit-usage']) && $_POST['submit-usage'] != '') {
    $ref_no = $_POST['ref-no'];
    $total_amount = str_replace(',', '', $_POST['total-amount']);
    $created_by = $_POST['created-by'];
    $created_on = $_POST['created-on'];
    $additional_note = test_input($_POST['additional-note']);

    $check_row = dbQuery("SELECT id FROM app_inventory_usage WHERE ref_no = '$ref_no'");

    if (dbNumRows($check_row) == 0) {
        $sql = "INSERT INTO app_inventory_usage (ref_no, total_amount, created_by, created_on, additional_note) VALUES ('$ref_no', '$total_amount', '$created_by', '$created_on', '$additional_note')";
    } else {
        $sql = "UPDATE app_inventory_usage SET
                total_amount = '$total_amount',
                created_by = '$created_by',
                created_on '$created_on'
                WHERE id = '" . $_POST['id'] . "'";
    }
    if (!$query = dbQuery($sql)) {
        die(mysqli_error());
    } else {
        //deduct item quantity
        $getItems = dbQuery("SELECT * FROM app_inventory_transacts WHERE transact_id = '$ref_no' AND status = 'Pending'");
        if (dbNumRows($getItems) != 0) {
            while ($item = dbFetchAssoc($getItems)):
                //check item qty
                $itemInfo = getInventory($item['item_id']);
                if ($itemInfo['quantity'] < $item['item_qty']) {
                    echo '<div class="alert alert-danger py-2 px-3"><i class="fal fa-exclamation-triangle"></i> ' . $itemInfo['menu_name'] . ' is below requested quantity (In Stock ' . $itemInfo['quantity'] . ')</div>';
                    exit;
                } else {
                    dbQuery("UPDATE app_inventory SET quantity = quantity - '" . $item['item_qty'] . "' WHERE id = '" . $item['item_id'] . "' ");
                    dbQuery("UPDATE app_inventory_transacts SET status = 'Cleared' WHERE id = '" . $item['id'] . "' ");
                }
            endwhile;
        }
        if ($_POST['submit-usage'] == 1) {
            echo '<script>location.replace("?p=manage-inventory&consumption&create-usage=' . base64_encode(sixRandomNumbers()) . '")</script>';
        } else {
            echo '<script>location.reload();</script>';
        }

    }
}