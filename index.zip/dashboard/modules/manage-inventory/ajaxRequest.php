<?php
/**
 * Created by DTMGS Limited.
 * User: Dauda Ibrahim
 * Date: 6/23/2020
 * Time: 9:40 PM
 * File: Module Classes
 */
if (file_exists("../../../helpers/config/config.inc.php")):
    require "../../../helpers/config/config.inc.php";
endif;
require "../../../helpers/handlers/app_autoloader.php";
require "Module_Class.php";
$engine = new SMBEngine;
$AppResponse = new App_Response;
$appAuth = new Auth_Access;
$auth = $appAuth->AppAuthChecker();
$requestMethod = $_SERVER['REQUEST_METHOD'];
if (in_array($requestMethod, ["GET", "POST", "PUT", "DELETE", "OPTIONS"])):
    $requestMethodArray = array();
    $requestMethodArray = $_REQUEST;
    //print_r($requestMethodArray);
    if (isset($requestMethodArray['notification']) && !isset($requestMethodArray['confirmed'])):
        $tmpl = "../../tmpl/notification.html";
        echo $engine->fileTempParse($tmpl, $requestMethodArray);
        exit;
    endif;
    // print_r($requestMethodArray);
    //--------------------------------------------------------------------------
    if (isset($requestMethodArray['className']) && isset($requestMethodArray['functionName'])):
        $getCommandArray = array(
            "class" => $requestMethodArray['className'],
            "function_name" => $requestMethodArray['functionName']);
        $functionArray = [];
        foreach ($requestMethodArray as $key => $val):
            if ($key !== "className" && $key !== "functionName" && $key !== "callback")
                $functionArray += array($key => $val);
        endforeach;
        $module = new $requestMethodArray['className'];

        $execution = $module->execCommand($getCommandArray, $functionArray);

        if ($execution['response'] === "200"):
            $responseMessage = App_Response::alertResponse(@$execution['message'], 'success');
            if (@$requestMethodArray['callback']['type'] == 'actionEvent'):
                $requestMethodArray['callback'] += array("event" => '<script>' . $requestMethodArray['callback']['redirect'] . '</script>');
            endif;
            $responseArray = array("success" => 1, "message" => (@$responseMessage), "dataArray" => @$execution['dataArray'], "callback" => @$requestMethodArray['callback']);
        else:
            $responseMessage = App_Response::alertResponse(@$execution['message'], 'danger');
            $responseArray = array("success" => 0, "message" => (@$responseMessage), "callback" => @$requestMethodArray['callback']);
        endif;
        echo @json_encode($responseArray);
    endif;
    //---------------------------------------------------------------------------
    if (isset($requestMethodArray['dropDownRequest'])):
        $module = new Module_Class;
        $tbl_scheme = $requestMethodArray['dropDownRequest']['target_scheme'];
        $pkField = $requestMethodArray['dropDownRequest']['pkField'];
        $pk = $requestMethodArray['dropDownRequest']['pk'];
        $key = $requestMethodArray['dropDownRequest']['key'];
        $label = $requestMethodArray['dropDownRequest']['label'];

        $listParam = array(
            "tbl_scheme" => $tbl_scheme,
            "condition" => [$pkField => $pk]);
        $listArray = $module->getRecord($listParam);
        echo '<option value="">-- Select --</option>';
        foreach ($listArray['dataArray'] as $list):
            if (isset($key) && $key != ""):
                echo $engine->dropDownList($list[$key], $list[$label]);
            else:
                echo $engine->dropDownList($list[$label]);
            endif;
        endforeach;
    endif;
    //---------------------------------------------------------------------------
    if (isset($requestMethodArray['formLookupRequest']) && $requestMethodArray['formLookupRequest']['term'] != ""):
        $module = new Module_Class;
        $request = $requestMethodArray['formLookupRequest']['request'];
        $tbl_scheme = $requestMethodArray['formLookupRequest']['target_scheme'];
        $field = $requestMethodArray['formLookupRequest']['fields'];
        $term = $requestMethodArray['formLookupRequest']['term'];
        $key = $requestMethodArray['formLookupRequest']['key'];
        $label = $requestMethodArray['formLookupRequest']['labels'];
        $condition = $requestMethodArray['formLookupRequest']['condition'];
        $order = $requestMethodArray['formLookupRequest']['order'];
        $limit = $requestMethodArray['formLookupRequest']['limit'];
        $lookupDestination = $requestMethodArray['formLookupRequest']['destination'];
        $target = $requestMethodArray['formLookupRequest']['target'];
        $actionButton = $requestMethodArray['formLookupRequest']['action_button'];

        if ($request == "search"):
            $searchParam = [
                "tbl_scheme" => $tbl_scheme,
                "fields" => $field,
                "term" => $term,
                "condition" => $condition,
                "order" => $order,
                "limit" => $limit,
            ];
            $query = $module->searchRecord($searchParam);
            if ($query['response'] == "200"):
                $dataArray = $query['dataArray'];
                if (count($dataArray) === 0):

                else:
                    echo '<div class="search-result position-relative">';
                    echo '<a class="small text-right result-close text-muted" href="javasctipy:void(0)" onclick=\'$("."+"' . $target . '").html("");\'>[ x close ]</a>';
                    $index = 0;
                    foreach ($dataArray as $results): $index++;
                        $labels = "";
                        foreach ($label as $lbl):
                            $labels .= $results[$lbl] . ' ';
                        endforeach;
                        echo '<button tabindex = "' . $index . '"  type="button" class="list-group-item" onclick=\'javascript:$("#"+"' . $lookupDestination . '").val(this.innerHTML); $("."+"' . $target . '").html(""); $("#"+"' . $actionButton . '").click()\'>[' . $results[$key] . '] ' . $labels . '</a>';
                    endforeach;
                    echo '</div>';
                endif;
            else:
                echo '<li class="list-group-item">No result(s) found lookup</li>';
            endif;

        else:

        endif;
    endif;
    //---------------------------------------------------------------------------
    if (isset($requestMethodArray['AppModalLoader'])):
        $required = $requestMethodArray['AppModalLoader'];
        $modulePath = str_ireplace($engine->dashboard, '', $required['path']);
        $modalRequest = 1;
        $module = new Module_Class;
        require $required['required'] . '.php';
    endif;
    //---------------------------------------------------------------------------
    if (isset($requestMethodArray['AppIDAutoGen'])):
        if ($requestMethodArray['AppIDAutoGen'] != NULL):
            extract($requestMethodArray['AppIDAutoGen']);
            echo $appIdGen = $engine->generateAppId($prefix, $suffix, $strlen, $pattern);
        endif;
    endif;
    //---------------------------------------------------------------------------
    if (isset($requestMethodArray['AddProductPackaging']) && $requestMethodArray['AddProductPackaging'] === '1'):
        if ($requestMethodArray['product_packaging'] != NULL):
            extract($requestMethodArray['product_packaging']);
            $module = new Module_Class;
            @$inventory = $module->getRecord([
                "tbl_scheme" => "app_inventory",
                "condition" => ["app_id" => $app_id, "store_id" => $store_id]
            ])['dataArray'][0];
            if ($inventory == NULL):
                $response = ["message" => "Invalid product selected"];
            else:
                $packaging = $inventory['packaging'];
                if ($packaging == ""):
                    $package = array($measure_unit => $per_unit);
                else:
                    $packageArr = json_decode(htmlspecialchars_decode($inventory['packaging']), true);
                    $packageArr += array($measure_unit => $per_unit);
                    $package = $packageArr;
                endif;
                $updatePackaging = $module->updateRecord([
                    "tbl_scheme" => "app_inventory",
                    "pkField" => 'id',
                    "pk" => $inventory['id'],
                    "packaging" => json_encode($package)
                ]);
                if ($updatePackaging['response'] === "200"):
                    echo '<script>$("#product-packaging")[0].reset(); $(".ppkMeasureSelect").val("").trigger("change"); PackagingList(' . json_encode($package) . ');</script>';

                endif;
            endif;
        endif;
    endif;
    //---------------------------------------------------------------------------
    if (isset($requestMethodArray['deletePackagingParam']) && $requestMethodArray['deletePackagingParam'] != ""):
        $module = new Module_Class;
        $id = $requestMethodArray['deletePackagingParam'];
        $packaging = json_decode(htmlspecialchars_decode($requestMethodArray['packaging']), true);
        $measure = $requestMethodArray['measure'];
        $newArray = [];
        foreach ($packaging as $m => $p):
            if ($m != $measure) $newArray += array($m => $p);
        endforeach;
        $updatePackaging = $module->updateRecord([
            "tbl_scheme" => "app_inventory",
            "pkField" => 'id',
            "pk" => $id,
            "packaging" => json_encode($newArray)
        ]);
        if ($updatePackaging['response'] === "200"):
            $callback = [
                "type" => "actionEvent",
                "event" => '<script>PackagingList(' . json_encode($newArray) . ')</script>',
            ];
            $responseArray = array("success" => 1, "message" => (@$responseMessage), "dataArray" => "", "callback" => @$callback);
            echo @json_encode($responseArray);
        endif;
    endif;
    //---------------------------------------------------------------------------

    if (isset($requestMethodArray['PackagingListView'])):
        @$module = new Module_Class;
        @$loader = 1;
        @$packaging = $requestMethodArray['packaging'];
        @$rec_id = $requestMethodArray['rec_id'];
        require "inc/packaging_list.php";
    endif;
    //---------------------------------------------------------------------------
    if (isset($requestMethodArray['AttribListView'])):
        $app_id = $requestMethodArray['app_id'];
        $module = new Module_Class;
        require "inc/attributes_list.php";
    endif;
    //---------------------------------------------------------------------------
    if (isset($requestMethodArray['ImageUpload'])):
        $module = new Module_Class;
        $app_id = $requestMethodArray['app_id'];
        $description = $requestMethodArray['image_description'];
        $imageFile = $requestMethodArray['image_file'];
        list($type, $imageFile) = explode(';', $imageFile);
        list(, $imageFile) = explode(',', $imageFile);
        $imageFile = base64_decode($imageFile);
        $image_name = $app_id . '_' . time() . '.png';
        $upload = file_put_contents('../../uploads/inventory/' . $image_name, $imageFile);
        if ($upload):
            $imageParam = [
                "tbl_scheme" => 'app_products_images',
                "app_id" => $app_id,
                "image_file" => $image_name,
                "description" => $description,
            ];
            $insertImage = $module->createRecord($imageParam);
            if ($insertImage['response'] === '200'):
                $insertImage['message'] = "Image successfully uploaded!";
                $responseMessage = App_Response::alertResponse(@$insertImage['message'], 'success');
                $responseArray = array("success" => 1, "message" => (@$responseMessage));
            else:
                $insertImage['message'] = "Couldn't upload image!";
                $responseMessage = App_Response::alertResponse(@$insertImage['message'], 'danger');
                $responseArray = array("success" => 0, "message" => (@$responseMessage));
            endif;
            echo @json_encode($responseArray);
        endif;
    endif;
    //---------------------------------------------------------------------------
    if (isset($requestMethodArray['ImageListView'])):
        $app_id = $requestMethodArray['app_id'];
        $app = $engine;
        $module = new Module_Class;
        require "inc/images_list.php";
    endif;
    //---------------------------------------------------------------------------
    if (isset($requestMethodArray['deleteImage'])):
        @$img_id = @$requestMethodArray['img_id'];
        @$module = new Module_Class;
        @$getImage = @$module->getRecord([
            "tbl_scheme" => 'app_products_images',
            "condition" => ['id' => @$img_id]
        ]);
        if (@$getImage['response'] === '200'):
            @$img_file = $getImage['dataArray'][0]['image_file'];
            @$deleteImage = $module->deleteRecord([
                "tbl_scheme" => 'app_products_images',
                "pk" => ['id' => @$img_id]
            ]);
            if (@$deleteImage['response'] === '200'):
                $unlink = @unlink('../../uploads/inventory/' . $img_file);
                if (@$unlink):
                    if (@$requestMethodArray['callback']['type'] == 'actionEvent'):
                        $requestMethodArray['callback'] += array("event" => '<script>' . $requestMethodArray['callback']['redirect'] . '</script>');
                    endif;
                    $deleteImage['message'] = "Image successfully deleted!";
                    $responseMessage = App_Response::alertResponse(@$deleteImage['message'], 'success');
                    $responseArray = array("success" => 1, "message" => (@$responseMessage), "callback" => @$requestMethodArray['callback']);
                endif;
            else:
                $deleteImage['message'] = "Couldn't delete image!";
                $responseMessage = App_Response::alertResponse(@$deleteImage['message'], 'danger');
                $responseArray = array("success" => 0, "message" => (@$responseMessage));
            endif;
        endif;
        echo @json_encode($responseArray);
    endif;
    //---------------------------------------------------------------------------
    if (isset($requestMethodArray['transferSelect'])):
        $module = new Module_Class;
        $selection = $requestMethodArray['transferSelect'];
        extract($selection);
        $transfer = $module->getRecord([
            "tbl_scheme" => "app_stock_transfer",
            "condition" => [
                "reference" => $reference,
                "submission_status" => 0
            ]
        ]);
        if ($transfer['dataArray'] != NULL):
            $transfer = $transfer['dataArray'][0];

            @$verify = $module->getRecord([
                "tbl_scheme" => "app_stock_transfers",
                "condition" => [
                    "reference" => $reference,
                    "product_id" => $product_id,
                    "source_inventory" => $transfer['source_inventory'],
                    "destination_inventory" => $transfer['destination_inventory'],
                ]
            ])['dataArray'];

            if ($action === "remove"):
                @$module->deleteRecord([
                    "tbl_scheme" => "app_stock_transfers",
                    "pk" => ["id" => $verify[0]['id']]
                ]);
            else:
                @$product = $module->getRecord([
                    "tbl_scheme" => "app_products",
                    "condition" => [
                        "app_id" => $product_id
                    ]
                ])['dataArray'][0];
                if ($verify === NULL):
                    $submit = $module->createRecord([
                        "tbl_scheme" => "app_stock_transfers",
                        "reference" => $reference,
                        "product_id" => $product_id,
                        "product_description" => $product['name'],
                        "source_inventory" => $transfer['source_inventory'],
                        "destination_inventory" => $transfer['destination_inventory'],
                        "stock_qty" => $stock_qty,
                        "stock_price" => $product['sale_price'],
                        "added_by" => trim($auth['firstname'] . ' ' . $auth['lastname']),
                    ]);
                else:
                    $submit = $module->updateRecord([
                        "tbl_scheme" => "app_stock_transfers",
                        "pkField" => "id",
                        "pk" => $verify[0]['id'],
                        "reference" => $reference,
                        "product_id" => $product_id,
                        "product_description" => $product['name'],
                        "source_inventory" => $transfer['source_inventory'],
                        "destination_inventory" => $transfer['destination_inventory'],
                        "stock_qty" => $stock_qty,
                        "stock_price" => $product['sale_price'],
                        "added_by" => trim($auth['firstname'] . ' ' . $auth['lastname']),
                    ]);
                endif;

            endif;
        else:
            echo App_Response::alertResponse('Invalid stock transfer transactions!', 'danger');
        endif;

    endif;
    //---------------------------------------------------------------------------
    if (isset($requestMethodArray['discardTransfer'])):
        $module = new Module_Class;
        $request = $requestMethodArray['discardTransfer'];
        @$module->deleteRecord([
            "tbl_scheme" => "app_stock_transfers",
            "pk" => [
                "reference" => $request['reference']
            ]
        ]);
        @$transfer = $module->deleteRecord([
            "tbl_scheme" => "app_stock_transfer",
            "pk" => [
                "reference" => $request['reference']
            ]
        ]);
        if (@$transfer['response'] === "200"):
            if (@$requestMethodArray['callback']['type'] == 'actionEvent'):
                $requestMethodArray['callback'] += array("event" => '<script>' . $requestMethodArray['callback']['redirect'] . '</script>');
            endif;
            $deleteImage['message'] = "Transfer successfully discarded!";
            $responseMessage = App_Response::alertResponse(@$deleteImage['message'], 'success');
            $responseArray = array("success" => 1, "message" => (@$responseMessage), "callback" => @$requestMethodArray['callback']);
        endif;
        echo @json_encode($responseArray);
    endif;
    //---------------------------------------------------------------------------
    if (isset($requestMethodArray['executeTransfer'])):
        $module = new Module_Class;
        $request = $requestMethodArray['executeTransfer'];
        @$transfer = $module->getRecord([
            "tbl_scheme" => "app_stock_transfer",
            "condition" => [
                "reference" => $request['reference'],
                "submission_status" => 0
            ]
        ]);
        if (@$transfer['response'] === "200"):
            @$transfers = @$module->getRecord([
                "tbl_scheme" => "app_stock_transfers",
                "condition" => [
                    "reference" => $request['reference'],
                    "post_status" => 0
                ]
            ])['dataArray'];
            if (@$transfers == NULL):
                $responseMessage = App_Response::alertResponse('You have no products added to the transfers or all products are already transferred', 'danger');
                $responseArray = array("success" => 0, "message" => (@$responseMessage), "callback" => @$requestMethodArray['callback']);
            else:
                $stocks_error = 0;
                foreach ($transfers as $transfer_product):
                    @$check = $module->getRecord([
                        "tbl_scheme" => 'app_inventory',
                        "condition" => [
                            "app_id" => $transfer_product['product_id'],
                            "store_id" => $transfer_product['source_inventory']
                        ]
                    ])['dataArray'][0];
                    if ($check != NULL):
                        if ($check['stock_qty'] < $transfer_product['stock_qty']):
                            $responseMessage = App_Response::alertResponse("Low quantity stock level for " . $transfer_product['product_description'], 'danger');
                            $stocks_error = 1;
                        endif;
                    endif;
                endforeach;
                if ($stocks_error == 1):
                    $responseArray = array("success" => 0, "message" => (@$responseMessage), "callback" => @$requestMethodArray['callback']);
                else:
                    $src_clear_error = "";
                    $dst_clear_error = "";
                    $flag = 0;
                    foreach ($transfers as $transfer_product):
                        $update_source = "UPDATE " . $engine->dbScheme . ".app_inventory ";
                        $update_source .= "SET stock_qty = stock_qty - '" . $transfer_product['stock_qty'] . "' 
                                WHERE store_id = '" . $transfer_product['source_inventory'] . "' AND app_id = '" . $transfer_product['product_id'] . "' ";
                        $exec = Data_Access::execSQL($update_source);
                        if ($exec['response'] === '200'):
                            @$verify_destination = $module->getRecord([
                                "tbl_scheme" => "app_inventory",
                                "condition" => ["app_id" => $transfer_product['product_id'], "store_id" => $transfer_product['destination_inventory']]
                            ])['dataArray'];
                            if ($verify_destination != NULL):
                                $update_destination = "UPDATE " . $engine->dbScheme . ".app_inventory ";
                                $update_destination .= "SET stock_qty = stock_qty + '" . $transfer_product['stock_qty'] . "' 
                                WHERE store_id = '" . $transfer_product['destination_inventory'] . "' AND app_id = '" . $transfer_product['product_id'] . "' ";
                            else:
                                $update_destination = "INSERT INTO " . $engine->dbScheme . ".app_inventory (app_id, store_id, stock_qty) VALUES ";
                                $update_destination .= "('" . $transfer_product['product_id'] . "', '" . $transfer_product['destination_inventory'] . "', '" . $transfer_product['stock_qty'] . "');";
                            endif;
                            $exec = Data_Access::execSQL($update_destination);
                            if ($exec['response'] === '200'):
                                $module->updateRecord([
                                    "tbl_scheme" => 'app_stock_transfers',
                                    "pkField" => 'id',
                                    "pk" => $transfer_product['id'],
                                    "post_status" => 1
                                ]);
                            else:
                                $dst_clear_error .= $transfer_product['product_id'] . ', ';
                            endif;
                        else:
                            $src_clear_error .= $transfer_product['product_id'] . ', ';
                        endif;
                        $flag++;
                    endforeach;
                    if ($flag > 0):
                        $submitted = $module->updateRecord([
                            "tbl_scheme" => 'app_stock_transfer',
                            "pkField" => 'reference',
                            "pk" => $request['reference'],
                            "submission_status" => 1
                        ]);
                        if ($submitted['response'] === "200"):
                            // print_r($requestMethodArray['callback']);
                            $responseMessage = App_Response::alertResponse("Transfers successfully submitted, verify inventory!", 'success');
                            $responseArray = array("success" => 1, "message" => (@$responseMessage), "callback" => @$requestMethodArray['callback']);
                        endif;
                    endif;
                endif;
            endif;
        else:
            $responseMessage = App_Response::alertResponse("Invalid Transfers transaction!", 'danger');
            $responseArray = array("success" => 0, "message" => (@$responseMessage), "callback" => @$requestMethodArray['callback']);
        endif;
        echo @json_encode($responseArray);
    endif;

//---------------------------------------------------------------------------
    if (isset($requestMethodArray['AppDataImport'])):
        $biz = new BIZConfig;
        //$tbl_scheme = $requestMethodArray['tbl_scheme'];
        $store_id = $requestMethodArray['store_id'];
        $data_file = $_FILES['import-data-file'];
        $update = $requestMethodArray['update-request'];
        $primary_key = $requestMethodArray['primary-key'];
        @$remove_col_name = $requestMethodArray['remove-col-name'];
        $mapping = trim($requestMethodArray['data-import-mapping'], ',');
        $exec_by = $requestMethodArray['created_by'];
        $csvMimes = array(
            'text/x-comma-separated-values',
            'text/comma-separated-values',
            'application/octet-stream',
            'application/vnd.ms-excel',
            'application/x-csv',
            'text/x-csv',
            'text/csv',
            'application/csv',
            'application/excel',
            'application/vnd.msexcel',
            'text/plain'
        );
        $products_column = array("sku_barcode", "name", "description", "price", "sale_price", "wholesale_price", "category_id", "subcategory");
        $inventory_column = array();

        if (in_array($data_file['type'], $csvMimes)):
            if (($data_file["size"] > 2000000)):
                $responseArray['message'] = App_Response::alertResponse('CSV File size is too large.', 'danger');
            else:

                if ($update == 1 && $primary_key == ""):

                    $responseArray['message'] = App_Response::alertResponse("Update missing primary column selection key", 'danger');

                else:

                    if (@$mapping == "" || @$mapping == ","):
                        $responseArray['message'] = App_Response::alertResponse("Import missing table column mapping", 'danger');
                    else:

                        $arrEncode = (rtrim("{" . $mapping, ',')) . '}';
                        $mapArray = json_decode($arrEncode);
                        $strings = str_split("ABCDEFGHIJKLMNOPQRSTUVWXYZ");
                        $newMapArray = array();
                        $prod_columns = "";
                        $prod_ln = "";
                        $inv_columns = "";
                        $inv_ln = "";
                        foreach ($mapArray as $field => $col):
                            if ($col !== "" && $field !== ""):
                                if (in_array($field, $products_column)):
                                    $prod_columns .= $field . ', ';
                                    $prod_ln .= array_search($col, $strings) . ', ';
                                else:
                                    $inv_columns .= $field . ', ';
                                    $inv_ln .= array_search($col, $strings) . ', ';
                                endif;
                                $newMapArray += array($field => array_search($col, $strings));
                            endif;
                        endforeach;

                        $inv_columns = trim($inv_columns, ', ');
                        $inv_ln = trim($inv_ln, ', ');
                        $prod_columns = trim($prod_columns, ', ');
                        $prod_ln = trim($prod_ln, ', ');

                        $csvFile = fopen($data_file['tmp_name'], 'r');

                        if (@$remove_col_name == 1):
                            fgetcsv($csvFile);
                        endif;

                        $con = 0;
                        $app_inventory[] = ["store_id" => $store_id];
                        $app_products = [];
                        $app_products += array("tbl_scheme" => 'app_products');
                        if ($prod_columns != "" && $prod_ln != ""):
                            $product_sql = "INSERT INTO app_products (app_id, " . $prod_columns . ", import_reference) VALUES ";
                        endif;
                        if ($inv_columns != "" && $inv_ln != ""):
                            $inventory_sql = "INSERT INTO app_inventory (app_id, " . $inv_columns . ", import_reference) VALUES ";
                        endif;
                        $prodSQL = "";
                        $invSQL = "";
                        $im_ref = $engine->generateAppId('', '', 8, 'ABCDIMPORT1234567890');

                        while (($line = fgetcsv($csvFile)) !== FALSE) {
                            $con++;
                            if ($con < 500) {
                                $app_id = $engine->generateAppId('INV', '', 6, 'ABCDEFGHIJKLMNOPQRZTUVWXYZ1234567890');
                                $rows = "";
                                $rows2 = "";
                                if (@$product_sql != "") {
                                    $ln_explode = explode(', ', $prod_ln);
                                    foreach ($ln_explode as $n):
                                        $rows .= "'" . $engine->verify_input($line[$n]) . "', ";
                                    endforeach;
                                    $prodSQL .= '( \'' . $app_id . '\' ,' . trim($rows, ', ') . ', \'' . $im_ref . '\' ), ';
                                }
                                if (@$inventory_sql != "") {
                                    $ln2_explode = explode(', ', $inv_ln);
                                    foreach ($ln2_explode as $n2):
                                        $rows2 .= "'" . $engine->verify_input($line[$n2]) . "', ";
                                    endforeach;
                                    $invSQL .= '( \'' . $app_id . '\' ,' . trim($rows2, ', ') . ', \'' . $im_ref . '\'), ';
                                }

                            }


                        }

                        $product_sql .= trim($prodSQL, ', ');
                        $inventory_sql .= trim($invSQL, ', ');

                        if ($product_sql != "" && $prodSQL != "") {
                            $query = Data_Access::execSQL($product_sql);
                        }
                        if ($inventory_sql != "" && $invSQL != "") {
                            $query2 = Data_Access::execSQL($inventory_sql);
                        }
                        if (@$query['response'] === '200'):
                            echo App_Response::alertResponse('Data Import completed successfully!', 'success');
                            $biz->AppLogging([
                                "reference" => $im_ref,
                                "command_type" => 'Import',
                                "argument" => 'Inventory data import successful.'
                            ], FALSE);
                        else:
                            echo App_Response::alertResponse('Data Import failed!' . @$query['message'], 'danger');
                            $biz->AppLogging([
                                "reference" => $im_ref,
                                "command_type" => 'Import',
                                "argument" => 'Inventory data import failed. Error:' . @$query['message']
                            ], FALSE);
                        endif;
                    endif;
                endif;
            endif;
        else:
            $responseArray['message'] = App_Response::alertResponse('Please upload a valid CSV file.', 'danger');
        endif;


        //echo "We here";
        //$app_id = $requestMethodArray['app_id'];
        //$app = $engine;
        // $module = new Module_Class;
        //   require "inc/images_list.php";

        echo @$responseArray['message'];
    endif;
endif;