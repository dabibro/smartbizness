<table border="0" cellspacing="0" cellpadding="0">
    <tbody>
    <tr>
        <td></td>
        <td width="368" valign="top" style="width:276.1pt;padding:0in 5.4pt 0in 5.4pt">
            <table class="MsoTableGrid" border="0" cellspacing="0" cellpadding="0" style="border: none;">
                <tbody>
                <tr>
                    <td width="46" valign="top" style="width:34.25pt;padding:0in 5.4pt 0in 5.4pt">
                        <p class="MsoHeader"><img width="43" height="42"
                                                  src="file:///C:/Users/DAUDAI~1/AppData/Local/Temp/msohtmlclip1/01/clip_image002.gif"
                                                  v:shapes="Picture_x0020_2560"><!--[endif]--> </p>
                    </td>
                    <td width="288" valign="top" style="width:215.85pt;padding:0in 5.4pt 0in 5.4pt">
                        <p class="MsoHeader"><span style="font-size:10.0pt;
    mso-bidi-font-size:6.0pt;color:#C00000">DIGITAL TECHZ<o:p></o:p></span></p>
                        <p class="MsoNormal" style="margin-bottom:0in;margin-bottom:.0001pt;
    line-height:115%"><b><span style="font-size:8.0pt;mso-bidi-font-size:6.0pt;line-height:115%;
    font-family:" candara",sans-serif;mso-fareast-font-family:candara;=""
                                mso-bidi-font-family:candara;color:#305496"="">MULTI-GLOBAL SERVICES LIMITED</span>
                            </b><span style="font-size:6.0pt;line-height:115%"><o:p></o:p></span></p>
                        <p class="MsoHeader"><span style="font-size:6.0pt;
    font-family:" corbel",sans-serif;letter-spacing:2.5pt"="">Innovative Solutions
                            Provider…</span><span style="font-size:10.0pt;font-family:" corbel",sans-serif;=""
                            letter-spacing:2.5pt"="">
                            <o:p></o:p>
                            </span></p>
                    </td>
                </tr>
                </tbody>
            </table>
            <p class="MsoHeader"><span style="font-size:10.0pt;
  font-family:" corbel",sans-serif;letter-spacing:2.5pt"="">
                <o:p></o:p>
                </span></p>
        </td>
    </tr>
    <tr>
        <td width="352" style="width:263.9pt;padding:0in 5.4pt 0in 5.4pt">
            <p class="MsoHeader"><b><span style="font-size:16.0pt;mso-bidi-font-size:20.0pt;font-family:
  " calibri="" light",sans-serif;mso-ascii-theme-font:major-latin;mso-hansi-theme-font:=""
                    major-latin;mso-bidi-theme-font:major-latin;mso-no-proof:yes"="">PURCHASE ORDER/SUPPLIES</span>
                </b><b><span style="font-size:12.0pt;mso-bidi-font-size:
  20.0pt;font-family:" calibri="" light",sans-serif;mso-ascii-theme-font:major-latin;=""
                    mso-hansi-theme-font:major-latin;mso-bidi-theme-font:major-latin;mso-no-proof:="" yes"="">
                    <o:p></o:p>
                    </span></b></p>
        </td>
        <td width="368" valign="top" style="width:276.1pt;padding:0in 5.4pt 0in 5.4pt">
            <table class="MsoTable15Plain3" border="0" cellspacing="0" cellpadding="0" align="left" width="336"
                   style="width: 3.5in; margin-left: -2.25pt; margin-right: -2.25pt;">
                <tbody>
                <tr style="mso-yfti-irow:-1;mso-yfti-firstrow:yes;mso-yfti-lastfirstrow:
    yes;height:.2in">
                    <td width="132" valign="top" style="width:99.0pt;border:none;border-bottom:
    solid #7F7F7F 1.0pt;mso-border-bottom-themecolor:text1;mso-border-bottom-themetint:
    128;mso-border-bottom-alt:solid #7F7F7F .5pt;mso-border-bottom-themecolor:
    text1;mso-border-bottom-themetint:128;padding:0in 5.4pt 0in 5.4pt;
    height:.2in">
                        <p class="MsoNormal" style="margin-bottom:0in;margin-bottom:.0001pt;
    line-height:115%;mso-yfti-cnfc:517"><b><span style="font-size:9.0pt;
    mso-bidi-font-size:11.0pt;line-height:115%;text-transform:uppercase">Ref
    No:</span><span style="text-transform:uppercase"><o:p></o:p></span></b></p>
                    </td>
                    <td width="204" valign="top" style="width:153.0pt;border:none;border-bottom:
    solid #7F7F7F 1.0pt;mso-border-bottom-themecolor:text1;mso-border-bottom-themetint:
    128;mso-border-bottom-alt:solid #7F7F7F .5pt;mso-border-bottom-themecolor:
    text1;mso-border-bottom-themetint:128;padding:0in 5.4pt 0in 5.4pt;
    height:.2in">
                        <p class="MsoNormal" style="margin-bottom:0in;margin-bottom:.0001pt;
    line-height:115%;mso-yfti-cnfc:1"><b><span style="font-size:9.0pt;
    line-height:115%;text-transform:uppercase"><o:p>&nbsp;</o:p></span></b></p>
                    </td>
                </tr>
                <tr style="mso-yfti-irow:0;height:.2in">
                    <td width="132" valign="top" style="width:99.0pt;border:none;border-right:solid #7F7F7F 1.0pt;
    mso-border-right-themecolor:text1;mso-border-right-themetint:128;
    mso-border-right-alt:solid #7F7F7F .5pt;mso-border-right-themecolor:text1;
    mso-border-right-themetint:128;background:#F2F2F2;mso-background-themecolor:
    background1;mso-background-themeshade:242;padding:0in 5.4pt 0in 5.4pt;
    height:.2in">
                        <p class="MsoNormal" style="margin-top:0in;margin-right:.05pt;margin-bottom:
    0in;margin-left:0in;margin-bottom:.0001pt;line-height:115%;mso-yfti-cnfc:
    68"><b><span style="font-size:9.0pt;mso-bidi-font-size:11.0pt;line-height:
    115%;text-transform:uppercase">Submission Date:</span><span style="text-transform:uppercase"><o:p></o:p></span></b>
                        </p>
                    </td>
                    <td width="204" valign="top" style="width:153.0pt;background:#F2F2F2;
    mso-background-themecolor:background1;mso-background-themeshade:242;
    padding:0in 5.4pt 0in 5.4pt;height:.2in">
                        <p class="MsoNormal" style="margin-bottom:0in;margin-bottom:.0001pt;
    line-height:115%;mso-yfti-cnfc:64"><span style="font-size:9.0pt;line-height:
    115%"><o:p>&nbsp;</o:p></span></p>
                    </td>
                </tr>
                <tr style="mso-yfti-irow:1;mso-yfti-lastrow:yes;height:.2in">
                    <td width="132" valign="top" style="width:99.0pt;border:none;border-right:solid #7F7F7F 1.0pt;
    mso-border-right-themecolor:text1;mso-border-right-themetint:128;
    mso-border-right-alt:solid #7F7F7F .5pt;mso-border-right-themecolor:text1;
    mso-border-right-themetint:128;padding:0in 5.4pt 0in 5.4pt;height:.2in">
                        <p class="MsoNormal" style="margin-top:0in;margin-right:.05pt;margin-bottom:
    0in;margin-left:0in;margin-bottom:.0001pt;line-height:115%;mso-yfti-cnfc:
    4"><b><span style="font-size:9.0pt;mso-bidi-font-size:11.0pt;line-height:
    115%;text-transform:uppercase">Request Date:</span><span style="text-transform:
    uppercase"><o:p></o:p></span></b></p>
                    </td>
                    <td width="204" valign="top" style="width:153.0pt;padding:0in 5.4pt 0in 5.4pt;
    height:.2in">
                        <p class="MsoNormal" style="margin-bottom:0in;margin-bottom:.0001pt;
    line-height:115%"><span style="font-size:9.0pt;line-height:115%"><o:p>&nbsp;</o:p></span></p>
                    </td>
                </tr>
                </tbody>
            </table>
            <p class="MsoHeader">
                <o:p></o:p>
            </p>
        </td>
    </tr>
    </tbody>
</table>

<table class="TableGrid" border="0" cellspacing="0" cellpadding="0" width="720">
    <tbody>
    <tr style="mso-yfti-irow:0;mso-yfti-firstrow:yes;height:75.95pt">
        <td width="372" valign="top" style="width:279.0pt;padding:0in 0in 0in 0in;
  height:75.95pt">
            <p class="MsoNormal" style="margin-bottom:0in;margin-bottom:.0001pt;line-height:
  normal">
                <o:p>&nbsp;</o:p>
            </p>
            <table class="MsoTable15Grid4Accent5" border="1" cellspacing="0" cellpadding="0" width="351"
                   style="margin-left: 0.5pt; border: none;">
                <tbody>
                <tr style="mso-yfti-irow:-1;mso-yfti-firstrow:yes;mso-yfti-lastfirstrow:
    yes;mso-yfti-lastrow:yes;height:.2in">
                    <td width="351" style="width:263.55pt;border:solid #5B9BD5 1.0pt;mso-border-themecolor:
    accent5;mso-border-alt:solid #5B9BD5 .5pt;mso-border-themecolor:accent5;
    background:#5B9BD5;mso-background-themecolor:accent5;padding:0in 5.4pt 0in 5.4pt;
    height:.2in">
                        <p class="MsoNormal" style="margin-bottom:0in;margin-bottom:.0001pt;
    line-height:115%;mso-yfti-cnfc:5"><b><span style="font-size:9.0pt;
    line-height:115%;color:white;mso-themecolor:background1">Supplier</span></b><b><span style="font-size:9.0pt;mso-bidi-font-size:11.0pt;line-height:115%;
    color:white;mso-themecolor:background1"> </span></b><b><span style="font-size:9.0pt;mso-bidi-font-size:11.0pt;line-height:115%;
    color:white">Information</span>
                                <o:p></o:p>
                            </b></p>
                    </td>
                </tr>
                </tbody>
            </table>
            <table class="MsoTable15Plain4" border="0" cellspacing="0" cellpadding="0" width="351">
                <tbody>
                <tr style="mso-yfti-irow:-1;mso-yfti-firstrow:yes;mso-yfti-lastfirstrow:
    yes;height:.2in">
                    <td width="96" valign="top" style="width:1.0in;padding:0in 5.4pt 0in 5.4pt;
    height:.2in">
                        <p class="MsoNormal" style="margin-bottom:0in;margin-bottom:.0001pt;
    line-height:115%;mso-yfti-cnfc:5"><b><span style="font-size:9.0pt;
    mso-bidi-font-size:11.0pt;line-height:115%">Supplier Name:</span>
                                <o:p></o:p>
                            </b></p>
                    </td>
                    <td width="255" valign="top" style="width:191.55pt;padding:0in 5.4pt 0in 5.4pt;
    height:.2in">
                        <p class="MsoNormal" style="margin-bottom:0in;margin-bottom:.0001pt;
    line-height:115%;mso-yfti-cnfc:1"><span style="font-size:9.0pt;line-height:
    115%"><o:p>&nbsp;</o:p></span></p>
                    </td>
                </tr>
                <tr style="mso-yfti-irow:0;height:.2in">
                    <td width="96" valign="top" style="width:1.0in;background:#F2F2F2;mso-background-themecolor:
    background1;mso-background-themeshade:242;padding:0in 5.4pt 0in 5.4pt;
    height:.2in">
                        <p class="MsoNormal" style="margin-bottom:0in;margin-bottom:.0001pt;
    line-height:115%;mso-yfti-cnfc:68"><b><span style="font-size:9.0pt;
    mso-bidi-font-size:11.0pt;line-height:115%">Contact Name</span>
                                <o:p></o:p>
                            </b></p>
                    </td>
                    <td width="255" valign="top" style="width:191.55pt;background:#F2F2F2;
    mso-background-themecolor:background1;mso-background-themeshade:242;
    padding:0in 5.4pt 0in 5.4pt;height:.2in">
                        <p class="MsoNormal" style="margin-bottom:0in;margin-bottom:.0001pt;
    line-height:115%;mso-yfti-cnfc:64"><span style="font-size:9.0pt;line-height:
    115%"><o:p>&nbsp;</o:p></span></p>
                    </td>
                </tr>
                <tr style="mso-yfti-irow:1;height:.2in">
                    <td width="96" valign="top" style="width:1.0in;padding:0in 5.4pt 0in 5.4pt;
    height:.2in">
                        <p class="MsoNormal" style="margin-bottom:0in;margin-bottom:.0001pt;
    line-height:115%;mso-yfti-cnfc:4"><b><span style="font-size:9.0pt;
    mso-bidi-font-size:11.0pt;line-height:115%">Email Address:</span>
                                <o:p></o:p>
                            </b></p>
                    </td>
                    <td width="255" valign="top" style="width:191.55pt;padding:0in 5.4pt 0in 5.4pt;
    height:.2in">
                        <p class="MsoNormal" style="margin-bottom:0in;margin-bottom:.0001pt;
    line-height:115%"><span style="font-size:9.0pt;line-height:115%"><o:p>&nbsp;</o:p></span></p>
                    </td>
                </tr>
                <tr style="mso-yfti-irow:2;height:.2in">
                    <td width="96" valign="top" style="width:1.0in;background:#F2F2F2;mso-background-themecolor:
    background1;mso-background-themeshade:242;padding:0in 5.4pt 0in 5.4pt;
    height:.2in">
                        <p class="MsoNormal" style="margin-bottom:0in;margin-bottom:.0001pt;
    line-height:115%;mso-yfti-cnfc:68"><b><span style="font-size:9.0pt;
    mso-bidi-font-size:11.0pt;line-height:115%">Phone:<o:p></o:p></span></b></p>
                    </td>
                    <td width="255" valign="top" style="width:191.55pt;background:#F2F2F2;
    mso-background-themecolor:background1;mso-background-themeshade:242;
    padding:0in 5.4pt 0in 5.4pt;height:.2in">
                        <p class="MsoNormal" style="margin-bottom:0in;margin-bottom:.0001pt;
    line-height:115%;mso-yfti-cnfc:64"><span style="font-size:9.0pt;line-height:
    115%"><o:p>&nbsp;</o:p></span></p>
                    </td>
                </tr>
                <tr style="mso-yfti-irow:3;mso-yfti-lastrow:yes;height:.2in">
                    <td width="96" valign="top" style="width:1.0in;padding:0in 5.4pt 0in 5.4pt;
    height:.2in">
                        <p class="MsoNormal" style="margin-bottom:0in;margin-bottom:.0001pt;
    line-height:115%;mso-yfti-cnfc:4"><b><span style="font-size:9.0pt;
    mso-bidi-font-size:11.0pt;line-height:115%">Address:</span>
                                <o:p></o:p>
                            </b></p>
                    </td>
                    <td width="255" valign="top" style="width:191.55pt;padding:0in 5.4pt 0in 5.4pt;
    height:.2in">
                        <p class="MsoNormal" style="margin-bottom:0in;margin-bottom:.0001pt;
    line-height:115%;tab-stops:52.0pt"><span style="font-size:9.0pt;line-height:
    115%">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <o:p></o:p></span>
                        </p>
                    </td>
                </tr>
                </tbody>
            </table>
            <p class="MsoNormal" style="margin-bottom:0in;margin-bottom:.0001pt;line-height:
  115%;tab-stops:88.0pt">
                <o:p></o:p>
            </p>
        </td>
        <td width="348" valign="top" style="width:261.0pt;padding:0in 0in 0in 0in;
  height:75.95pt">
            <p class="MsoNormal" style="margin-bottom:0in;margin-bottom:.0001pt;line-height:
  normal">
                <o:p>&nbsp;</o:p>
            </p>
            <table class="MsoTable15Grid4Accent5" border="1" cellspacing="0" cellpadding="0" width="360"
                   style="border: none;">
                <tbody>
                <tr style="mso-yfti-irow:-1;mso-yfti-firstrow:yes;mso-yfti-lastfirstrow:
    yes;mso-yfti-lastrow:yes;height:.2in">
                    <td width="360" style="width:269.9pt;border:solid #5B9BD5 1.0pt;mso-border-themecolor:
    accent5;mso-border-alt:solid #5B9BD5 .5pt;mso-border-themecolor:accent5;
    background:#5B9BD5;mso-background-themecolor:accent5;padding:0in 5.4pt 0in 5.4pt;
    height:.2in">
                        <p class="MsoNormal" style="margin-bottom:0in;margin-bottom:.0001pt;
    line-height:115%;mso-yfti-cnfc:5"><b>&nbsp;</b></p>
                    </td>
                </tr>
                </tbody>
            </table>
            <table class="MsoTable15Plain4" border="0" cellspacing="0" cellpadding="0" width="360">
                <tbody>
                <tr style="mso-yfti-irow:-1;mso-yfti-firstrow:yes;mso-yfti-lastfirstrow:
    yes;height:.2in">
                    <td width="108" valign="top" style="width:80.85pt;padding:0in 5.4pt 0in 5.4pt;
    height:.2in">
                        <p class="MsoNormal" style="margin-bottom:0in;margin-bottom:.0001pt;
    line-height:115%;mso-yfti-cnfc:5"><b><span style="font-size:9.0pt;
    mso-bidi-font-size:11.0pt;line-height:115%">Delivery Location:</span>
                                <o:p></o:p>
                            </b></p>
                    </td>
                    <td width="252" valign="top" style="width:189.05pt;padding:0in 5.4pt 0in 5.4pt;
    height:.2in">
                        <p class="MsoNormal" style="margin-bottom:0in;margin-bottom:.0001pt;
    line-height:115%;mso-yfti-cnfc:1"><span style="font-size:9.0pt;line-height:
    115%"><o:p>&nbsp;</o:p></span></p>
                    </td>
                </tr>
                <tr style="mso-yfti-irow:0;height:.2in">
                    <td width="108" valign="top" style="width:80.85pt;background:#F2F2F2;
    mso-background-themecolor:background1;mso-background-themeshade:242;
    padding:0in 5.4pt 0in 5.4pt;height:.2in">
                        <p class="MsoNormal" style="margin-bottom:0in;margin-bottom:.0001pt;
    line-height:115%;mso-yfti-cnfc:68"><b><span style="font-size:9.0pt;
    mso-bidi-font-size:11.0pt;line-height:115%">Contact Name:</span>
                                <o:p></o:p>
                            </b></p>
                    </td>
                    <td width="252" valign="top" style="width:189.05pt;background:#F2F2F2;
    mso-background-themecolor:background1;mso-background-themeshade:242;
    padding:0in 5.4pt 0in 5.4pt;height:.2in">
                        <p class="MsoNormal" style="margin-bottom:0in;margin-bottom:.0001pt;
    line-height:115%;mso-yfti-cnfc:64"><span style="font-size:9.0pt;line-height:
    115%"><o:p>&nbsp;</o:p></span></p>
                    </td>
                </tr>
                <tr style="mso-yfti-irow:1;height:.2in">
                    <td width="108" valign="top" style="width:80.85pt;padding:0in 5.4pt 0in 5.4pt;
    height:.2in">
                        <p class="MsoNormal" style="margin-bottom:0in;margin-bottom:.0001pt;
    line-height:115%;mso-yfti-cnfc:4"><b><span style="font-size:9.0pt;
    mso-bidi-font-size:11.0pt;line-height:115%">Phone:</span>
                                <o:p></o:p>
                            </b></p>
                    </td>
                    <td width="252" valign="top" style="width:189.05pt;padding:0in 5.4pt 0in 5.4pt;
    height:.2in">
                        <p class="MsoNormal" style="margin-bottom:0in;margin-bottom:.0001pt;
    line-height:115%"><span style="font-size:9.0pt;line-height:115%"><o:p>&nbsp;</o:p></span></p>
                    </td>
                </tr>
                <tr style="mso-yfti-irow:2;mso-yfti-lastrow:yes;height:.2in">
                    <td width="108" valign="top" style="width:80.85pt;background:#F2F2F2;
    mso-background-themecolor:background1;mso-background-themeshade:242;
    padding:0in 5.4pt 0in 5.4pt;height:.2in">
                        <p class="MsoNormal" style="margin-bottom:0in;margin-bottom:.0001pt;
    line-height:115%;mso-yfti-cnfc:68"><b><span style="font-size:9.0pt;
    mso-bidi-font-size:11.0pt;line-height:115%">Address:</span>
                                <o:p></o:p>
                            </b></p>
                    </td>
                    <td width="252" valign="top" style="width:189.05pt;background:#F2F2F2;
    mso-background-themecolor:background1;mso-background-themeshade:242;
    padding:0in 5.4pt 0in 5.4pt;height:.2in">
                        <p class="MsoNormal" style="margin-bottom:0in;margin-bottom:.0001pt;
    line-height:115%;mso-yfti-cnfc:64"><span style="font-size:9.0pt;line-height:
    115%"><o:p>&nbsp;</o:p></span></p>
                    </td>
                </tr>
                </tbody>
            </table>
            <p class="MsoNormal" style="margin-bottom:0in;margin-bottom:.0001pt;line-height:
  115%">
                <o:p></o:p>
            </p>
        </td>
    </tr>
    <tr style="mso-yfti-irow:1;height:75.95pt">
        <td width="720" colspan="2" valign="top" style="width:7.5in;padding:0in 0in 0in 0in;
  height:75.95pt">
            <p class="MsoNormal" style="margin-bottom:0in;margin-bottom:.0001pt;line-height:
  normal">
                <o:p>&nbsp;</o:p>
            </p>
            <table class="MsoTable15Grid4Accent5" border="1" cellspacing="0" cellpadding="0" width="732"
                   style="border: none;">
                <tbody>
                <tr style="mso-yfti-irow:-1;mso-yfti-firstrow:yes;mso-yfti-lastfirstrow:
    yes;height:.2in">
                    <td width="42" style="width:31.5pt;border:solid #5B9BD5 1.0pt;mso-border-themecolor:
    accent5;border-right:none;mso-border-top-alt:solid #5B9BD5 .5pt;mso-border-top-themecolor:
    accent5;mso-border-left-alt:solid #5B9BD5 .5pt;mso-border-left-themecolor:
    accent5;mso-border-bottom-alt:solid #5B9BD5 .5pt;mso-border-bottom-themecolor:
    accent5;background:#5B9BD5;mso-background-themecolor:accent5;padding:0in 5.4pt 0in 5.4pt;
    height:.2in">
                        <p class="MsoNormal" align="center" style="margin-bottom:0in;margin-bottom:
    .0001pt;text-align:center;line-height:115%;mso-yfti-cnfc:5"><b><span
                                        style="font-size:9.0pt;line-height:115%;color:white;mso-themecolor:background1">ITEM<o:p></o:p></span></b>
                        </p>
                    </td>
                    <td width="354" style="width:265.5pt;border-top:solid #5B9BD5 1.0pt;
    mso-border-top-themecolor:accent5;border-left:none;border-bottom:solid #5B9BD5 1.0pt;
    mso-border-bottom-themecolor:accent5;border-right:none;mso-border-top-alt:
    solid #5B9BD5 .5pt;mso-border-top-themecolor:accent5;mso-border-bottom-alt:
    solid #5B9BD5 .5pt;mso-border-bottom-themecolor:accent5;background:#5B9BD5;
    mso-background-themecolor:accent5;padding:0in 5.4pt 0in 5.4pt;height:.2in">
                        <p class="MsoNormal" align="center" style="margin-bottom:0in;margin-bottom:
    .0001pt;text-align:center;line-height:115%;mso-yfti-cnfc:1"><b><span
                                        style="font-size:9.0pt;line-height:115%;color:white;mso-themecolor:background1">DESCRIPTION<o:p></o:p></span></b>
                        </p>
                    </td>
                    <td width="102" style="width:76.25pt;border-top:solid #5B9BD5 1.0pt;
    mso-border-top-themecolor:accent5;border-left:none;border-bottom:solid #5B9BD5 1.0pt;
    mso-border-bottom-themecolor:accent5;border-right:none;mso-border-top-alt:
    solid #5B9BD5 .5pt;mso-border-top-themecolor:accent5;mso-border-bottom-alt:
    solid #5B9BD5 .5pt;mso-border-bottom-themecolor:accent5;background:#5B9BD5;
    mso-background-themecolor:accent5;padding:0in 5.4pt 0in 5.4pt;height:.2in">
                        <p class="MsoNormal" align="center" style="margin-bottom:0in;margin-bottom:
    .0001pt;text-align:center;line-height:115%;mso-yfti-cnfc:1"><b><span
                                        style="font-size:9.0pt;line-height:115%;color:white;mso-themecolor:background1">QUANTITY<o:p></o:p></span></b>
                        </p>
                    </td>
                    <td width="126" style="width:94.5pt;border-top:solid #5B9BD5 1.0pt;
    mso-border-top-themecolor:accent5;border-left:none;border-bottom:solid #5B9BD5 1.0pt;
    mso-border-bottom-themecolor:accent5;border-right:none;mso-border-top-alt:
    solid #5B9BD5 .5pt;mso-border-top-themecolor:accent5;mso-border-bottom-alt:
    solid #5B9BD5 .5pt;mso-border-bottom-themecolor:accent5;background:#5B9BD5;
    mso-background-themecolor:accent5;padding:0in 5.4pt 0in 5.4pt;height:.2in">
                        <p class="MsoNormal" align="center" style="margin-bottom:0in;margin-bottom:
    .0001pt;text-align:center;line-height:115%;mso-yfti-cnfc:1"><b><span
                                        style="font-size:9.0pt;line-height:115%;color:white;mso-themecolor:background1">UNIT
    PRICE<o:p></o:p></span></b></p>
                    </td>
                    <td width="108" style="width:81.25pt;border:solid #5B9BD5 1.0pt;mso-border-themecolor:
    accent5;border-left:none;mso-border-top-alt:solid #5B9BD5 .5pt;mso-border-top-themecolor:
    accent5;mso-border-bottom-alt:solid #5B9BD5 .5pt;mso-border-bottom-themecolor:
    accent5;mso-border-right-alt:solid #5B9BD5 .5pt;mso-border-right-themecolor:
    accent5;background:#5B9BD5;mso-background-themecolor:accent5;padding:0in 5.4pt 0in 5.4pt;
    height:.2in">
                        <p class="MsoNormal" align="center" style="margin-bottom:0in;margin-bottom:
    .0001pt;text-align:center;line-height:115%;mso-yfti-cnfc:1"><b><span
                                        style="font-size:9.0pt;line-height:115%;color:white;mso-themecolor:background1">TOTAL
    PRICE<o:p></o:p></span></b></p>
                    </td>
                </tr>
                <tr style="mso-yfti-irow:0;height:.2in">
                    <td width="42" style="width:31.5pt;border:solid #9CC2E5 1.0pt;mso-border-themecolor:
    accent5;mso-border-themetint:153;border-top:none;mso-border-top-alt:solid #9CC2E5 .5pt;
    mso-border-top-themecolor:accent5;mso-border-top-themetint:153;mso-border-alt:
    solid #9CC2E5 .5pt;mso-border-themecolor:accent5;mso-border-themetint:153;
    background:#DEEAF6;mso-background-themecolor:accent5;mso-background-themetint:
    51;padding:0in 5.4pt 0in 5.4pt;height:.2in">
                        <p class="MsoNormal" align="center" style="margin-bottom:0in;margin-bottom:
    .0001pt;text-align:center;line-height:115%;mso-yfti-cnfc:68"><b><span
                                        style="font-size:9.0pt;line-height:115%;color:white;mso-themecolor:background1"><o:p>&nbsp;</o:p></span></b>
                        </p>
                    </td>
                    <td width="354" style="width:265.5pt;border-top:none;border-left:none;
    border-bottom:solid #9CC2E5 1.0pt;mso-border-bottom-themecolor:accent5;
    mso-border-bottom-themetint:153;border-right:solid #9CC2E5 1.0pt;
    mso-border-right-themecolor:accent5;mso-border-right-themetint:153;
    mso-border-top-alt:solid #9CC2E5 .5pt;mso-border-top-themecolor:accent5;
    mso-border-top-themetint:153;mso-border-left-alt:solid #9CC2E5 .5pt;
    mso-border-left-themecolor:accent5;mso-border-left-themetint:153;
    mso-border-alt:solid #9CC2E5 .5pt;mso-border-themecolor:accent5;mso-border-themetint:
    153;background:#DEEAF6;mso-background-themecolor:accent5;mso-background-themetint:
    51;padding:0in 5.4pt 0in 5.4pt;height:.2in">
                        <p class="MsoNormal" align="center" style="margin-bottom:0in;margin-bottom:
    .0001pt;text-align:center;line-height:115%;mso-yfti-cnfc:64"><span
                                    style="font-size:9.0pt;line-height:115%;color:white;mso-themecolor:background1"><o:p>&nbsp;</o:p></span>
                        </p>
                    </td>
                    <td width="102" style="width:76.25pt;border-top:none;border-left:none;
    border-bottom:solid #9CC2E5 1.0pt;mso-border-bottom-themecolor:accent5;
    mso-border-bottom-themetint:153;border-right:solid #9CC2E5 1.0pt;
    mso-border-right-themecolor:accent5;mso-border-right-themetint:153;
    mso-border-top-alt:solid #9CC2E5 .5pt;mso-border-top-themecolor:accent5;
    mso-border-top-themetint:153;mso-border-left-alt:solid #9CC2E5 .5pt;
    mso-border-left-themecolor:accent5;mso-border-left-themetint:153;
    mso-border-alt:solid #9CC2E5 .5pt;mso-border-themecolor:accent5;mso-border-themetint:
    153;background:#DEEAF6;mso-background-themecolor:accent5;mso-background-themetint:
    51;padding:0in 5.4pt 0in 5.4pt;height:.2in">
                        <p class="MsoNormal" align="center" style="margin-bottom:0in;margin-bottom:
    .0001pt;text-align:center;line-height:115%;mso-yfti-cnfc:64"><span
                                    style="font-size:9.0pt;line-height:115%;color:white;mso-themecolor:background1"><o:p>&nbsp;</o:p></span>
                        </p>
                    </td>
                    <td width="126" style="width:94.5pt;border-top:none;border-left:none;
    border-bottom:solid #9CC2E5 1.0pt;mso-border-bottom-themecolor:accent5;
    mso-border-bottom-themetint:153;border-right:solid #9CC2E5 1.0pt;
    mso-border-right-themecolor:accent5;mso-border-right-themetint:153;
    mso-border-top-alt:solid #9CC2E5 .5pt;mso-border-top-themecolor:accent5;
    mso-border-top-themetint:153;mso-border-left-alt:solid #9CC2E5 .5pt;
    mso-border-left-themecolor:accent5;mso-border-left-themetint:153;
    mso-border-alt:solid #9CC2E5 .5pt;mso-border-themecolor:accent5;mso-border-themetint:
    153;background:#DEEAF6;mso-background-themecolor:accent5;mso-background-themetint:
    51;padding:0in 5.4pt 0in 5.4pt;height:.2in">
                        <p class="MsoNormal" align="center" style="margin-bottom:0in;margin-bottom:
    .0001pt;text-align:center;line-height:115%;mso-yfti-cnfc:64"><span
                                    style="font-size:9.0pt;line-height:115%;color:white;mso-themecolor:background1"><o:p>&nbsp;</o:p></span>
                        </p>
                    </td>
                    <td width="108" style="width:81.25pt;border-top:none;border-left:none;
    border-bottom:solid #9CC2E5 1.0pt;mso-border-bottom-themecolor:accent5;
    mso-border-bottom-themetint:153;border-right:solid #9CC2E5 1.0pt;
    mso-border-right-themecolor:accent5;mso-border-right-themetint:153;
    mso-border-top-alt:solid #9CC2E5 .5pt;mso-border-top-themecolor:accent5;
    mso-border-top-themetint:153;mso-border-left-alt:solid #9CC2E5 .5pt;
    mso-border-left-themecolor:accent5;mso-border-left-themetint:153;
    mso-border-alt:solid #9CC2E5 .5pt;mso-border-themecolor:accent5;mso-border-themetint:
    153;background:#DEEAF6;mso-background-themecolor:accent5;mso-background-themetint:
    51;padding:0in 5.4pt 0in 5.4pt;height:.2in">
                        <p class="MsoNormal" align="center" style="margin-bottom:0in;margin-bottom:
    .0001pt;text-align:center;line-height:115%;mso-yfti-cnfc:64"><span
                                    style="font-size:9.0pt;line-height:115%;color:white;mso-themecolor:background1"><o:p>&nbsp;</o:p></span>
                        </p>
                    </td>
                </tr>
                <tr style="mso-yfti-irow:1;mso-yfti-lastrow:yes;height:.2in">
                    <td width="42" style="width:31.5pt;border:solid #9CC2E5 1.0pt;mso-border-themecolor:
    accent5;mso-border-themetint:153;border-top:none;mso-border-top-alt:solid #9CC2E5 .5pt;
    mso-border-top-themecolor:accent5;mso-border-top-themetint:153;mso-border-alt:
    solid #9CC2E5 .5pt;mso-border-themecolor:accent5;mso-border-themetint:153;
    padding:0in 5.4pt 0in 5.4pt;height:.2in">
                        <p class="MsoNormal" align="center" style="margin-bottom:0in;margin-bottom:
    .0001pt;text-align:center;line-height:115%;mso-yfti-cnfc:4"><b><span
                                        style="font-size:9.0pt;line-height:115%;color:white;mso-themecolor:background1"><o:p>&nbsp;</o:p></span></b>
                        </p>
                    </td>
                    <td width="354" style="width:265.5pt;border-top:none;border-left:none;
    border-bottom:solid #9CC2E5 1.0pt;mso-border-bottom-themecolor:accent5;
    mso-border-bottom-themetint:153;border-right:solid #9CC2E5 1.0pt;
    mso-border-right-themecolor:accent5;mso-border-right-themetint:153;
    mso-border-top-alt:solid #9CC2E5 .5pt;mso-border-top-themecolor:accent5;
    mso-border-top-themetint:153;mso-border-left-alt:solid #9CC2E5 .5pt;
    mso-border-left-themecolor:accent5;mso-border-left-themetint:153;
    mso-border-alt:solid #9CC2E5 .5pt;mso-border-themecolor:accent5;mso-border-themetint:
    153;padding:0in 5.4pt 0in 5.4pt;height:.2in">
                        <p class="MsoNormal" align="center" style="margin-bottom:0in;margin-bottom:
    .0001pt;text-align:center;line-height:115%"><span style="font-size:9.0pt;
    line-height:115%;color:white;mso-themecolor:background1"><o:p>&nbsp;</o:p></span></p>
                    </td>
                    <td width="102" style="width:76.25pt;border-top:none;border-left:none;
    border-bottom:solid #9CC2E5 1.0pt;mso-border-bottom-themecolor:accent5;
    mso-border-bottom-themetint:153;border-right:solid #9CC2E5 1.0pt;
    mso-border-right-themecolor:accent5;mso-border-right-themetint:153;
    mso-border-top-alt:solid #9CC2E5 .5pt;mso-border-top-themecolor:accent5;
    mso-border-top-themetint:153;mso-border-left-alt:solid #9CC2E5 .5pt;
    mso-border-left-themecolor:accent5;mso-border-left-themetint:153;
    mso-border-alt:solid #9CC2E5 .5pt;mso-border-themecolor:accent5;mso-border-themetint:
    153;padding:0in 5.4pt 0in 5.4pt;height:.2in">
                        <p class="MsoNormal" align="center" style="margin-bottom:0in;margin-bottom:
    .0001pt;text-align:center;line-height:115%"><span style="font-size:9.0pt;
    line-height:115%;color:white;mso-themecolor:background1"><o:p>&nbsp;</o:p></span></p>
                    </td>
                    <td width="126" style="width:94.5pt;border-top:none;border-left:none;
    border-bottom:solid #9CC2E5 1.0pt;mso-border-bottom-themecolor:accent5;
    mso-border-bottom-themetint:153;border-right:solid #9CC2E5 1.0pt;
    mso-border-right-themecolor:accent5;mso-border-right-themetint:153;
    mso-border-top-alt:solid #9CC2E5 .5pt;mso-border-top-themecolor:accent5;
    mso-border-top-themetint:153;mso-border-left-alt:solid #9CC2E5 .5pt;
    mso-border-left-themecolor:accent5;mso-border-left-themetint:153;
    mso-border-alt:solid #9CC2E5 .5pt;mso-border-themecolor:accent5;mso-border-themetint:
    153;padding:0in 5.4pt 0in 5.4pt;height:.2in">
                        <p class="MsoNormal" align="center" style="margin-bottom:0in;margin-bottom:
    .0001pt;text-align:center;line-height:115%"><span style="font-size:9.0pt;
    line-height:115%;color:white;mso-themecolor:background1"><o:p>&nbsp;</o:p></span></p>
                    </td>
                    <td width="108" style="width:81.25pt;border-top:none;border-left:none;
    border-bottom:solid #9CC2E5 1.0pt;mso-border-bottom-themecolor:accent5;
    mso-border-bottom-themetint:153;border-right:solid #9CC2E5 1.0pt;
    mso-border-right-themecolor:accent5;mso-border-right-themetint:153;
    mso-border-top-alt:solid #9CC2E5 .5pt;mso-border-top-themecolor:accent5;
    mso-border-top-themetint:153;mso-border-left-alt:solid #9CC2E5 .5pt;
    mso-border-left-themecolor:accent5;mso-border-left-themetint:153;
    mso-border-alt:solid #9CC2E5 .5pt;mso-border-themecolor:accent5;mso-border-themetint:
    153;padding:0in 5.4pt 0in 5.4pt;height:.2in">
                        <p class="MsoNormal" align="center" style="margin-bottom:0in;margin-bottom:
    .0001pt;text-align:center;line-height:115%"><span style="font-size:9.0pt;
    line-height:115%;color:white;mso-themecolor:background1"><o:p>&nbsp;</o:p></span></p>
                    </td>
                </tr>
                </tbody>
            </table>
            <p class="MsoNormal" style="margin-bottom:0in;margin-bottom:.0001pt;line-height:
  normal">
                <o:p>&nbsp;</o:p>
            </p>
            <table class="MsoTable15Plain4" border="0" cellspacing="0" cellpadding="0" width="732">
                <tbody>
                <tr style="mso-yfti-irow:-1;mso-yfti-firstrow:yes;mso-yfti-lastfirstrow:
    yes;height:.2in">
                    <td width="498" rowspan="3" valign="top" style="width:373.5pt;padding:0in 5.4pt 0in 5.4pt;
    height:.2in">
                        <p class="MsoNormal" style="margin-bottom:0in;margin-bottom:.0001pt;
    line-height:115%;mso-yfti-cnfc:5"><b><span style="font-size:9.0pt;
    line-height:115%">ADDITIONAL NOTE:</span></b><span style="font-size:9.0pt;
    line-height:115%"><o:p></o:p></span></p>
                        <p class="MsoNormal" style="margin-bottom:0in;margin-bottom:.0001pt;
    line-height:115%;mso-yfti-cnfc:5"><span style="font-size:9.0pt;line-height:
    115%"><o:p>&nbsp;</o:p></span></p>
                    </td>
                    <td width="123" valign="top" style="width:92.35pt;padding:0in 5.4pt 0in 5.4pt;
    height:.2in">
                        <p class="MsoNormal" style="margin-bottom:0in;margin-bottom:.0001pt;
    line-height:115%;mso-yfti-cnfc:1"><b><span style="font-size:9.0pt;
    line-height:115%">SUBTOTAL N<o:p></o:p></span></b></p>
                    </td>
                    <td width="111" valign="top" style="width:83.15pt;padding:0in 5.4pt 0in 5.4pt;
    height:.2in">
                        <p class="MsoNormal" style="margin-bottom:0in;margin-bottom:.0001pt;
    line-height:115%;mso-yfti-cnfc:1"><b><span style="font-size:9.0pt;
    line-height:115%"><o:p>&nbsp;</o:p></span></b></p>
                    </td>
                </tr>
                <tr style="mso-yfti-irow:0;height:.2in">
                    <td width="123" valign="top" style="width:92.35pt;background:#F2F2F2;
    mso-background-themecolor:background1;mso-background-themeshade:242;
    padding:0in 5.4pt 0in 5.4pt;height:.2in">
                        <p class="MsoNormal" style="margin-bottom:0in;margin-bottom:.0001pt;
    line-height:115%;mso-yfti-cnfc:64"><span style="font-size:9.0pt;line-height:
    115%">DISCOUNT N<o:p></o:p></span></p>
                    </td>
                    <td width="111" valign="top" style="width:83.15pt;background:#F2F2F2;
    mso-background-themecolor:background1;mso-background-themeshade:242;
    padding:0in 5.4pt 0in 5.4pt;height:.2in">
                        <p class="MsoNormal" style="margin-bottom:0in;margin-bottom:.0001pt;
    line-height:115%;mso-yfti-cnfc:64"><span style="font-size:9.0pt;line-height:
    115%"><o:p>&nbsp;</o:p></span></p>
                    </td>
                </tr>
                <tr style="mso-yfti-irow:1;mso-yfti-lastrow:yes;height:.2in">
                    <td width="123" valign="top" style="width:92.35pt;padding:0in 5.4pt 0in 5.4pt;
    height:.2in">
                        <p class="MsoNormal" style="margin-bottom:0in;margin-bottom:.0001pt;
    line-height:115%"><b><span style="font-size:9.0pt;line-height:115%">TOTAL<o:p></o:p></span></b></p>
                    </td>
                    <td width="111" valign="top" style="width:83.15pt;padding:0in 5.4pt 0in 5.4pt;
    height:.2in">
                        <p class="MsoNormal" style="margin-bottom:0in;margin-bottom:.0001pt;
    line-height:115%"><b><span style="font-size:9.0pt;line-height:115%"><o:p>&nbsp;</o:p></span></b></p>
                    </td>
                </tr>
                </tbody>
            </table>
            <p class="MsoNormal" style="margin-bottom:0in;margin-bottom:.0001pt;line-height:
  115%">
                <o:p></o:p>
            </p>
        </td>
    </tr>
    <tr style="mso-yfti-irow:2;mso-yfti-lastrow:yes;height:5.4pt">
        <td width="720" colspan="2" valign="top" style="width:7.5in;padding:0in 0in 0in 0in;
  height:5.4pt">
            <p class="MsoNormal" align="center" style="margin-bottom:0in;margin-bottom:.0001pt;
  text-align:center;line-height:normal"><b><span style="font-size:9.0pt"><o:p>&nbsp;</o:p></span></b></p>
            <p class="MsoNormal" align="center" style="margin-bottom:0in;margin-bottom:.0001pt;
  text-align:center;line-height:normal"><b><span style="font-size:9.0pt">We'll
  be glad to have you back. Thank you for your patronage<o:p></o:p></span></b></p>
            <p class="MsoNormal" align="center" style="margin-bottom:0in;margin-bottom:.0001pt;
  text-align:center;line-height:normal"><span style="font-family:" font="" awesome="" 5="" pro""=""></span><span
                        style="font-size:9.0pt;font-family:" cambria",serif"=""> </span><span style="font-size:9.0pt">contact@digitaltechz.com | digitaltechzgs@gmail.com </span><span
                        style="font-size:10.0pt;font-family:" font="" awesome="" 5="" pro""=""></span><span
                        style="font-size:10.0pt"> </span><span style="font-size:9.0pt">+234 808 000 0992
  | +234 814 322 5846<o:p></o:p></span></p>
        </td>
    </tr>
    </tbody>
</table>

<p class="MsoNormal"><span style="font-size:9.0pt;
line-height:107%"><o:p>&nbsp;</o:p></span></p>