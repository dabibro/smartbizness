<div class="row mb-3">
    <div class="col-12">
        <ul class="nav ml-auto modules-menu">
            <li class="nav-item ml-auto mb-1"><a
                        class="nav-link <?php if (@$view === "order/"): echo "active"; endif; ?> app-link"
                        href="#/purchase-order/order/"
                        onclick="fetchURL(this.href)"><i class="fal fa-plus-square"></i> Create
                    Order</a>
            </li>
            <li class="nav-item hide"><a class="nav-link" href="#/inventory/category/"
                                         onclick="fetchURL(this.href)"><i
                            class="fal fa-folder-tree"></i> Manage Category</a></li>
            <li class="nav-item app-collapse">
                <a class="nav-link dropdown-toggle" data-toggle="collapse"
                   href="#collapseUsersFilter"
                   aria-expanded="false" aria-controls="collapseUsersFilter">
                    <i class="fal fa-filter"></i> Advance Filter<span class="caret"></span>
                </a>
                <div class="collapse collapse-container right" id="collapseUsersFilter">
                    <div class="card-body elevation-1 bg-light left">
                        <form action="">
                            <div class="form-group">
                                <label for="">Users Group</label>
                                <select name="users_group" class="form-control form-control-sm select2">
                                    <option value="">-- Users Group --</option>
                                </select>
                            </div>
                            <div class="row">
                                <div class="col-6">
                                    <div class="form-group">
                                        <label for="">Users Store</label>
                                        <select name="users_location"
                                                class="form-control form-control-sm select2">
                                            <option value="">-- Users Store --</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-6">
                                    <div class="form-group">
                                        <label for="">Active Status</label>
                                        <select name="activation" class="form-control form-control-sm select2">
                                            <option value="">-- Active Status --</option>
                                        </select>
                                    </div>
                                </div>

                            </div>

                            <hr class="my-2">
                            <button class="btn btn-default btn-sm btn-block"><i class="fal fa-check-circle"></i>
                                Submit
                            </button>
                        </form>
                    </div>
                </div>
            </li>
        </ul>
    </div>
</div>
<?php
if ($view == "view/"):
    require "order-preview.php";
elseif ($view == "order/"):
    require "order_record.php";
else:
    require "order_list.php";
endif;
?>