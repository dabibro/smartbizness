<?php
/**
 * Created by PhpStorm.
 * User: Dauda Ibrahim
 * Date: 7/27/2020
 * Time: 5:43 PM
 */
@$getItemsParam = array(
    "tbl_scheme" => 'app_purchase_orders_item',
    "condition" => ['reference' => $reference],
);
//--------------------------------------------------
@$getItemArray = $module->getRecord($getItemsParam)['dataArray'];
if ($getItemArray != NULL):
    $index = 0;
    $total = 0;
    foreach ($getItemArray as $entry): $index++;
        extract($entry);
        $total = $total + $order_qty * $order_price;
        echo '<tr>';
        echo '<td>' . $index . '</td>';
        echo '<td>' . $item_description . '</td>';
        echo '<td>' . $order_qty . '</td>';
        echo '<td>' . number_format($order_price, 2) . '</td>';
        echo '<td>' . number_format($order_price * $order_qty, 2) . '</td>';
        echo '<td><div class="btn-group-justified btn-group"><a href=\'javascript:void(0)\' onclick=\'editEntryRows("' . $id . '")\' class="btn btn-sm p-1"><i class="fal fa-edit"></i></a> <a href=\'javascript:void(0)\' onclick="delEntryRows(' . $id . ')" class="btn btn-sm p-1"><i class="fal fa-trash"></i></a></div></td>';
        echo '</tr>';
    endforeach;
    if ($total > 0):
        echo '<tr><td colspan="4" class="text-right font-weight-bold">TOTAL</td><td colspan="2">' . number_format($total, 2) . '</td></tr>';
    endif;
else:
    echo '<tr><td colspan="6" align="center">No table data available</td></tr>';
endif;