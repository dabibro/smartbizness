<div class="row">
    <div class="col-md-5">
        <div class="card card-light elevation-2">
            <div class="card-header px-2 py-1">
                <i class="fal fa-cube"></i> Items Entry
            </div>
            <div class="card-body py-2 px-3">
                <div id="item-entry-response"></div>
                <div class="form-group">
                    <label><span class="spin-loader"></span> Inventory Lookup</label>
                    <div class="input-group">
                        <input class="form-control form-control-sm inventory-lookup" type="search"
                               name="item_description" placeholder="Name/SKU/Description"
                               id="inventory-lookup" form="item-entry-form" required autocomplete="off" tabindex="1">
                        <div class="input-group-append">
                            <span class="btn btn-sm btn-default pr-2"><i class="fal fa-search mr-0"></i></span>
                        </div>
                    </div>
                </div>
                <div id="computeArea">
                    <div class="row">
                        <div class="col-4">
                            <div class="form-group">
                                <label>Quantity</label>
                                <input class="form-control form-control-sm num" type="text" name="order_qty"
                                       id="order_qty" tabindex="2"
                                       placeholder="Quantity" autocomplete="off"
                                       form="item-entry-form" required>
                            </div>
                        </div>
                        <div class="col-4">
                            <div class="form-group">
                                <label>Stock Quantity</label>
                                <input class="form-control form-control-sm num" type="text" name="stock_qty"
                                       id="stock_qty"
                                       placeholder="Stock Qty" autocomplete="off" form="item-entry-form" readonly>
                            </div>
                        </div>
                        <div class="col-4">
                            <div class="form-group">
                                <label>New Quantity</label>
                                <input class="form-control form-control-sm num" type="text" name="new_qty" id="new_qty"
                                       placeholder="New Qty" autocomplete="off" form="item-entry-form" readonly>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-4">
                            <div class="form-group">
                                <label>Order Price</label>
                                <input class="form-control form-control-sm num" type="text" name="order_price"
                                       id="order_price" tabindex="3"
                                       placeholder="Order Price" autocomplete="off"
                                       form="item-entry-form" required>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label>Stock Price</label>
                                <input class="form-control form-control-sm num" type="text" name="stock_price"
                                       id="stock_price"
                                       placeholder="Stock Price" autocomplete="off" form="item-entry-form" readonly>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label>New Price</label>
                                <input class="form-control form-control-sm num" type="text" name="new_price"
                                       id="new_price"
                                       placeholder="New Price" autocomplete="off" form="item-entry-form" readonly>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group mb-0">
                            <label>New Sale Price</label>
                            <input class="form-control form-control-sm num" tabindex="4" type="text"
                                   name="new_sale_price" id="new_sale_price"
                                   placeholder="New Sale Price" autocomplete="off" form="item-entry-form">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group mb-0">
                            <label>Sale Price</label>
                            <input class="form-control form-control-sm num" type="text" name="stock_sale_price"
                                   id="stock_sale_price"
                                   placeholder="Sales Price" autocomplete="off" form="item-entry-form" readonly>
                        </div>
                    </div>
                </div>
                <hr>
                <input type="hidden" form="item-entry-form" name="item_appid" id="item-appid" readonly>
                <button class="btn btn-default btn-sm btn-block mb-2 itemActionButton" tabindex="5"
                        form="item-entry-form"><i
                            class="fal fa-plus-square"></i> Add Item
                </button>
            </div>
        </div>


    </div>
    <div class="col-md-7">
        <div class="table-responsive">
            <table class="table table-borderless table-sm table-striped data-tables">
                <thead>
                <tr>
                    <th width="20">#</th>
                    <th>Name/Description</th>
                    <th>Quantity</th>
                    <th>Price <?php echo $biz->currency['currency']; ?></th>
                    <th>Amount <?php echo $biz->currency['currency']; ?></th>
                    <th width="10"><i class="fal fa-trash-o fa-lg"></i></th>
                </tr>
                </thead>
                <tbody id="items-entry-table" class="card-body">
                <?php require 'order_item_tbl_rows.php'; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
