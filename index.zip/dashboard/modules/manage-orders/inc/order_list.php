<?php

@$requestArray = array(
    "tbl_scheme" => 'app_purchase_orders',
    "order" => 'order_date ASC');
@$recordRequest = $module->getRecord($requestArray);
@$recordsArray = $recordRequest['dataArray'];

?>
<div id="ModuleResponse"></div>
<div class="table-responsive">
    <table class="table data-tables dataTables-Sort table-sm elevation-1">
        <caption>View All Record</caption>
        <thead>
        <tr>
            <th>Reference</th>
            <th>Order Type</th>
            <th>Delivery Location</th>
            <th>Supplier Name</th>
            <th>Items #</th>
            <th>Amount <?php echo $biz->currency['currency']; ?></th>
            <th>Date</th>
            <th>Status</th>
            <th><i class="fal fa-cogs"></i></th>
        </tr>
        </thead>
        <tbody class="card-body">
        <?php
        if (isset($recordsArray)):
            $grand_total = 0;
            foreach (@$recordsArray as $order): extract($order);
                $total_amount = 0;
                @$items = $module->getRecord([
                    "tbl_scheme" => 'app_purchase_orders_item',
                    "condition" => [
                        "reference" => $reference,
                    ]
                ])['dataArray'];
                if ($items != NULL):
                    foreach ($items as $item_row):
                        $total_amount = $total_amount + $item_row['order_qty'] * $item_row['order_price'];
                    endforeach;
                endif;
                $grand_total = $grand_total + $total_amount;

                ?>
                <tr>
                    <td><?php echo @$reference; ?></td>
                    <td><?php echo @trim(@$order_type); ?></td>
                    <td><?php echo $app->truncateContent(@trim(@$module->getRecord(["tbl_scheme" => 'app_stores', "condition" => ["store_id" => @$store_id]])['dataArray'][0]['store_name']), 25); ?></td>
                    <td><?php echo $app->truncateContent(@trim(@$module->getRecord(["tbl_scheme" => 'app_vendors', "condition" => ["vendor_id" => @$vendor_id]])['dataArray'][0]['company_name']), 25); ?></td>
                    <td><?php echo @count($items); ?></td>
                    <td><?php echo @number_format($total_amount, 2); ?></td>
                    <td><?php echo @$order_date; ?></td>
                    <td><?php if (@$status == 1): if (@$approval == 1): if (@$post_status == 1): echo 'Posted'; else: echo 'Approved'; endif; else: echo 'Submitted'; endif; else: echo 'Pending'; endif; ?></td>
                    <td style="width:5%;" class="py-1" nowrap="nowrap">
                        <div class="btn-group-justify btn-group-sm float-right">
                            <button type="button" class="btn btn-default"
                                    onclick='javascript: location.replace("#/purchase-order/view/<?php echo $reference; ?>/"); fetchURL("")'
                                    title="View Record"><i
                                        class="fal fa-info-circle"></i>
                            </button>
                            <?php if (@$status === '1'): ?>
                                <?php if (@$approval !== '1'): ?>
                                    <button type="button" class="btn btn-default"
                                            onclick='javascript: var obj = "<?php echo urlencode('"className":"Module_Class","functionName":"updateRecord","tbl_scheme":"app_purchase_orders","approval":1,"pkField":"reference","pk":"' . $reference . '","callback":{"type":"self","redirect":""},"notification":{"message":"Are you sure to approve order for posting?","title":"Order Approval Alert"}'); ?>";  moduleRequest(obj);'
                                            title="Approve Order "><i
                                                class="fal fa-check-square"></i>
                                    </button>
                                <?php else: ?>
                                    <?php if (@$post_status === '0'): ?>
                                        <button type="button" class="btn btn-default"
                                                onclick='javascript: var obj = "<?php echo urlencode('"className":"Module_Class","orderPosting":"","tbl_scheme":"","pk":{"reference":"' . $reference . '"},"callback":{"type":"url","redirect":"#/purchase-order/view/' . $reference . '/"},"notification":{"message":"Are you sure to post this purchase order  to update inventory?","title":"Order Posting Alert"}'); ?>";  moduleRequest(obj);'
                                                title="Post Order"><i
                                                    class="fal fa-arrow-to-right"></i>
                                        </button>
                                    <?php endif; ?>
                                <?php endif; ?>

                            <?php endif; ?>
                            <?php if (@$post_status === '0'): ?>
                                <button type="button" class="btn btn-default"
                                        onclick='javascript: location.replace("#/purchase-order/order/<?php echo $reference; ?>/"); fetchURL("")'
                                        title=" Edit Record"><i class="fal fa-edit"></i>
                                </button>
                            <?php endif; ?>
                            <button type="button" class="btn btn-default"
                                    onclick='javascript: var obj = "<?php echo urlencode('"className":"Module_Class","deleteOrderRecord":"1","tbl_scheme":"","pk":{"reference":"' . $reference . '"},"callback":{"type":"self","redirect":""},"notification":{"message":"Are you sure to delete this purchase order record?","title":"Delete Warning"}'); ?>";  moduleRequest(obj);'
                                    title=" Edit Record"><i
                                        class="fal fa-trash-alt"></i>
                            </button>
                    </td>
                </tr>
            <?php endforeach;
        endif;
        ?>
        </tbody>
        <tfoot>
        <tr>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <th>TOTAL <?php echo $biz->currency['currency']; ?></th>
            <td><?php echo @number_format($grand_total, 2) ?></td>
            <td></td>
            <td></td>
            <td></td>
        </tr>
        </tfoot>
    </table>
</div>

