<?php

require "Module_Class.php";
$module = new Module_Class;
$modulePath = @$appSwitcher->modulePath($AppModule);
$req = $AppModuleRequest;
$view = $AppModuleView;

@$getAppId = explode('order/', $view);
if (isset($getAppId[1]) && $getAppId[1] != "") {
    @$view = 'order/';
    @$AppId = trim($getAppId[1], '/');
}

@$getViewAppId = explode('view/', $view);
if (isset($getViewAppId[1]) && $getViewAppId[1] != "") {
    @$view = 'view/';
    @$AppId = trim($getViewAppId[1], '/');
}


?>
<script src="<?php echo $modulePath ?>js.js"></script>
<input type="hidden" value="<?php echo $modulePath; ?>" id="ModulePath" readonly>
<div class="card card-primary card-outline card-outline-tabs">
    <div class="card-header p-0 border-bottom-0">
        <ul class="nav nav-tabs app-menu" id="manage-users-tabs" role="tablist">
            <li class="nav-item">
                <a class="nav-link <?php if ($req == 'purchase-order/'): echo 'active'; endif; ?>"
                   href="#/purchase-order/" onclick="fetchURL(this.href)"><i class="fal fa-chart-bar"></i> Purchase
                    Orders</a>
            </li>
            <li class="nav-item hide">
                <a class="nav-link <?php if ($req == 'create-store/'): echo 'active'; endif; ?>"
                   href="#/create-store/" onclick="fetchURL(this.href)"><i class="fal fa-truck"></i> Receive Order</a>
            </li>
            <li class="nav-item hide">
                <a class="nav-link <?php if ($req == 'create-store/'): echo 'active'; endif; ?>"
                   href="#/create-store/" onclick="fetchURL(this.href)"><i class="fal fa-file-search"></i> Inventory
                    History</a>
            </li>
        </ul>
    </div>
    <div class="card-body">
        <div class="tab-content" id="manage-users-tabContent">
            <div class="tab-pane fade <?php if ($req == 'purchase-order/'): echo 'active show'; endif; ?>"
                 id="users-tab" role="tabpanel" aria-labelledby="tabs-users-tabs">
                <?php if ($req == 'purchase-order/'): require "inc/orders.php";endif; ?>
            </div>
            <div class="tab-pane fade <?php if ($req == 'create-store/'): echo 'active show'; endif; ?>"
                 id="create-new-tab" role="tabpanel" aria-labelledby="tabs-create-new-tab">
                <?php if ($req == 'create-store/'): require "inc/create_store.php"; endif; ?>

            </div>
        </div>
    </div>
    <!-- /.card -->
</div>

          