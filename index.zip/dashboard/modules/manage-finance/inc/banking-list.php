<?php
//require queries file
require_once('inc/queries.php');
?>
<div class="card x_panel shadow-sm">
    <div class="x_title">
            <span class="title"><i class="fal fa-landmark"></i> Funds Banking History</h5>
    </div>
    <div class="x_content">
        <div id="responses"></div>
        <form method="post">
            <div class="row">
                <div class="col-md-2">
                    <div class="form-group input-group-sm select3">
                        <select class="form-control select2" name="banking_type" id="banking_type">
                            <option value="">-- Transact --</option>
                            <?php
                            $typeArray = array("Deposit", "Withdrawal");
                            $arrlength = count($typeArray);
                            $x = 0;
                            while ($x < $arrlength) {
                                ?>
                                <option value="<?php echo $typeArray[$x]; ?>" <?php if (@$edit['banking_type'] == @ $typeArray[$x]) {
                                    echo 'selected';
                                } ?>>
                                    <?php echo $typeArray[$x]; ?>
                                </option>
                                <?php $x++;
                            } ?>
                        </select>
                        <div class="invalid-feedback">Select type of expenditure</div>
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="form-group input-group-sm select3">
                        <select class="form-control br-0 select2" name="bank" id="bank">
                            <option value="">-- Select Bank --</option>
                            <?php
                            while ($dn = dbFetchAssoc($bank_query)):
                                ?>
                                <option value="<?php echo $dn['id']; ?>" <?php if (@$edit['bank'] == @$dn['id']) {
                                    echo 'selected';
                                } ?>>
                                    <?php echo $dn['acc_number'] . ' - ' . $dn['acc_name'] . ' (' . $dn['acc_bank'] . ')'; ?>
                                </option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="form-group" id="str">
                        <div class="input-group input-group-sm">
                            <input type="text" class="form-control input-sm datepicker" name="start_date"
                                   id="start_date" placeholder="Start Date" style="border-radius:0;">
                            <span class="input-group-prepend">
                                <span class="input-group-text"><i class="fal fa-calendar-minus"></i></span>
                            </span>
                        </div>
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="form-group" id="stp">
                        <div class="input-group input-group-sm">
                            <input type="text" class="form-control input-sm datepicker" name="stop_date" id="stop_date"
                                   placeholder="Stop Date" style="border-radius:0;">
                            <span class="input-group-prepend">
                                <span class="input-group-text"> <i class="fal fa-calendar-plus"></i></span>
                            </span>
                        </div>
                    </div>
                </div>
                <div class="col-md-2">
                    <button class="btn btn-primary pl-3 pr-3 btn-sm" type="submit" onClick=" return verifyQuery();"><i
                                class="fal fa-filter"></i> Apply Filter
                    </button>
                    <input type="hidden" name="filter" value="1">

                </div>

                <div class="col-md-2 text-right">

                    <?php if (@$access['new_deposit'] == 1) { ?>
                        <a href="?p=new-deposit" class="btn btn-sm btn-primary pl-3 pr-3" title="New Transaction"
                           data-toggle="tooltip"><i class="fal fa-plus"></i><span
                                    class="text"> New Transaction</span></a>
                    <?php } ?>
                </div>

            </div>
        </form>
        <div class="row mb-2">
            <div class="col-auto">
                <?php if (isset($_POST['filter']) && $_POST['filter'] == 1) { ?>
                    <small>Currently viewing filtered: [ <a href="?p=deposits">Reset Filter</a> ]</small>
                <?php } else {
                    echo "<small>Current Month record by default</small>";
                } ?>
            </div>
        </div>
        <div class="table-responsive">
            <table class="table table-hover table-striped datatable-btn" style="font-size:12px;">
                <thead>
                <tr>
                    <th width="20">#</th>
                    <th>Teller #</th>
                    <th>Transaction</th>
                    <th>Bank</th>
                    <th>Account #</th>
                    <th>Deposited Amount (N)</th>
                    <th>Withdrawed Amount (N)</th>
                    <th>Transact By</th>
                    <th>Transact Date</th>
                    <th class="opt"></th>
                </tr>
                </thead>
                <tbody>
                <?php
                $index = 0;
                $total_amount = 0;
                $total_withdrawal = 0;

                while ($dn = dbFetchAssoc($deposit_query)): $index++;
                    $bankInfo = getBankInfo($dn['bank']);

                    if ($dn['banking_type'] == 'Deposit') {
                        $total_amount = $total_amount + $dn['amount_paid'];
                    } else {
                        $total_withdrawal = $total_withdrawal + $dn['amount_paid'];
                    }
                    ?>
                    <tr>
                        <td>
                            <?php echo $index; ?>
                        </td>
                        <td>
                            <?php echo $dn['teller_no']; ?>
                        </td>
                        <td>
                            <?php echo $dn['banking_type']; ?>
                        </td>
                        <td>
                            <?php echo $bankInfo['acc_bank']; ?>
                        </td>

                        <td>
                            <?php echo $bankInfo['acc_number']; ?>

                        </td>
                        <td>
                            <?php if ($dn['banking_type'] == 'Deposit') {
                                echo number_format($dn['amount_paid'], 2);
                            } ?>
                        </td>

                        <td>
                            <?php if ($dn['banking_type'] != 'Deposit') {
                                echo number_format($dn['amount_paid'], 2);
                            } ?>
                        </td>
                        <td>
                            <?php echo $dn['depositor']; ?>
                        </td>
                        <td>
                            <?php echo $dn['payment_date']; ?>
                        </td>
                        <td width="2%" nowrap="nowrap">
                            <div class="btn-group">

                                <a class="btn btn-primary btn-sm" href="#<?php echo $dn['id'] ?>"
                                   onclick="javascript:$('#viewRecord').modal('show'); getFinanceInfo('<?php echo $dn['id']; ?>', 'deposit');"
                                   title="View Record" data-toggle="tooltip"><i class="fal fa-file"></i></a>
                                <?php if (@$access['edit_deposit']) { ?>
                                    <a class="btn btn-primary btn-sm" href="?p=new-deposit&edit=<?php echo $dn['id'] ?>"
                                       title=" Edit Record" data-toggle="tooltip"><i class="fal fa-edit"></i></a>
                                <?php }
                                if (@$access['delete_deposit'] == 1) { ?>
                                    <a href="#" class="btn btn-primary btn-sm"
                                       onClick="javascript:confirmRequest('<?php echo $dn['id'] . 'expense'; ?>', <?php echo $dn['id']; ?>, 'Are you sure you want to delete this record?', 'delete-deposit');"
                                       title="Delete Record" data-toggle="tooltip"><i class="fal fa-trash"></i></a>
                                <?php } ?>
                            </div>
                        </td>
                    </tr>
                <?php endwhile; ?>

                </tbody>
                <tfoot class="bg-light">
                <th colspan="5" class="text-right"><strong>TOTAL (N):</strong></th>
                <th colspan="">
                    <?php echo number_format($total_amount, 2); ?>
                </th>
                <th colspan="4">
                    <?php echo number_format($total_withdrawal, 2); ?>
                </th>
                </tfoot>
            </table>
        </div>
    </div>
</div>

<div class="modal fade" id="viewRecord">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content card x_panel">
            <div class="modal-header x_title">
                <span class="modal-title title"><i class="fal fa-file"></i> Banking Record</span>
            </div>
            <div class="modal-body x_content" id="finance-details">

            </div>
            <div class="modal-footer">
                <button class="btn btn-sm btn-primary" onclick="javascript:printDiv('finance-details');"><i
                            class="fal fa-print"></i> Print
                </button>
                <button type="button" class="btn btn-danger btn-sm" data-dismiss="modal"
                        onclick="$('#viewRecord').modal('hide');"><i class="fal fa-times"></i> Close
                </button>
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->


<script>
    function verifyQuery() {
        var bank = $('#bank').val();
        var type = $('#banking_type').val();
        var start_date = $('#start_date').val();
        var stop_date = $('#stop_date').val();

        if (bank == "" type == "" && start_date == "" && stop_date == ""
    )
        {
            $('#bank').addClass('is-invalid');
            $('#banking_type').addClass('is-invalid');
            $('#start_date').addClass('is-invalid');
            $('#stop_date').addClass('is-invalid');
            return false;
        }
    else
        if (bank != "" && start_date != "" && stop_date == "") {
//$('#bank').addClass('is-invalid');
//$('#start_date').addClass('is-invalid');
            $('#stop_date').addClass('is-invalid');
            return false;
        } else if (bank != "" && start_date == "" && stop_date != "") {
//$('#bank').addClass('is-invalid');
            $('#start_date').addClass('is-invalid');
//$('#stop_date').addClass('is-invalid');
            return false;
        } else if (bank == "" && start_date != "" && stop_date == "") {
//$('#bank').addClass('is-invalid');
//$('#start_date').addClass('is-invalid');
            $('#stop_date').addClass('is-invalid');
            return false;
        } else if (bank == "" && start_date == "" && stop_date != "") {
//$('#bank').addClass('is-invalid');
            $('#start_date').addClass('is-invalid');
//$('#stop_date').addClass('is-invalid');
            return false;
        }
    }
</script>
