<div class="card card-primary card-outline card-outline-tabs">
    <div class="card-header p-0 border-bottom-0">
        <ul class="nav nav-tabs" id="manage-finance-tabs" role="tablist">
            <li class="nav-item">
                <a class="nav-link active" id="tabs-expenses-tabs" data-toggle="pill" href="#expenses-tab" role="tab"
                   aria-controls="expenses-tab" aria-selected="true">Expenses/Expenditure</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" id="tabs-banking-list-tabs" data-toggle="pill" href="#banking-list-tab" role="tab"
                   aria-controls="banking-list-tab" aria-selected="false">Banking</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" id="tabs-payslip-tab" data-toggle="pill" href="#payslip-tab" role="tab"
                   aria-controls="payslip-tab" aria-selected="false">Payslip</a>
            </li>


        </ul>
    </div>
    <div class="card-body">
        <div class="tab-content" id="manage-finance-tabContent">
            <div class="tab-pane fade active show" id="expenses-tab" role="tabpanel"
                 aria-labelledby="tabs-expenses-tabs">
                <?php require_once "inc/expenses-list.php"; ?>

            </div>
            <div class="tab-pane fade " id="banking-list-tab" role="tabpanel" aria-labelledby="tabs-banking-list-tab">
                <?php require_once "inc/banking-list.php"; ?>

            </div>
            <div class="tab-pane fade" id="payslip-tab" role="tabpanel" aria-labelledby="tabs-payslip-tab">

            </div>


        </div>
    </div>
    <!-- /.card -->
</div>
