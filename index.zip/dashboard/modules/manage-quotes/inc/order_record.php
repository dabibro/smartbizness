<?php
if (isset($AppId) && @$AppId['pk'] != ""):
    $pk = $AppId;
    $pkField = 'reference';
    $getUpdateArray = array(
        "tbl_scheme" => 'app_purchase_orders',
        "condition" => [$pkField => $pk],
        "limit" => 1
    );
    $getUpdate = $module->getRecord($getUpdateArray);
    if ($getUpdate['response'] != '200'): echo '<script>location.replace("#/purchase-order/order/"); fetchURL("");</script>';endif;
    @extract($getUpdate['dataArray'][0]);
    $update = 1;
    @$app_id = $reference;
else:
    $app_id = $app->generateAppId('ORD', '', 4, '1234567890');
endif;


?>
<div class="position-relative">
    <form method="post" class="AppForm" id="inventory-item-form">
        <div class="row">
            <div class="col-2">
                <div class="nav flex-column nav-tabs h-100" id="vert-tabs-tab" role="tablist"
                     aria-orientation="vertical">
                    <a class="nav-link active" id="basic-tabs" data-toggle="pill" href="#basic-tabs-panel" role="tab"
                       aria-controls="basic-tabs-panel" aria-selected="false"><i class="fal fa-info-circle mr-1"></i>
                        Basics Data
                        <hr class="my-1">
                        <small class="text-muted">Fill in the item basic details.
                        </small>
                    </a>
                    <a class="nav-link <?php if (@$update != 1):echo "disabled"; endif; ?>" id="advance-tabs"
                       data-toggle="pill" href="#advance-tabs-panel"
                       role="tab"
                       aria-controls="advance-tabs-panel" aria-selected="false"><i class="fal fa-file-edit mr-1"></i>
                        Order Items Entry
                        <hr class="my-1">
                        <small class="text-muted">Advance item attributes
                        </small>
                    </a>
                    <a class="nav-link <?php if (@$update != 1):echo "disabled"; endif; ?>" id="preview-tabs"
                       data-toggle="pill" href="#preview-tabs-panel" onclick="loadOrderPreview();"
                       role="tab"
                       aria-controls="preview-tabs-panel" aria-selected="false"><i class="fal fa-file-search mr-1"></i>
                        Preview Order
                        <hr class="my-1">
                        <small class="text-muted">Preview template entry
                        </small>
                    </a>
                </div>
            </div>
            <div class="col-10">
                <div class="tab-content" id="add-item-tabContent">
                    <div class="row">
                        <div class="col-md-3 col-lg-2"></div>
                        <div class="col-md-9 col-lg-8">
                            <div id="ModuleResponse"></div>
                        </div>
                    </div>
                    <div class="tab-pane text-left fade active show" id="basic-tabs-panel" role="tabpanel"
                         aria-labelledby="basic-tabs">
                        <div class="row">
                            <div class="col-md-9 col-lg-10">
                                <div class="row">
                                    <div class="col-4 ml-auto">
                                        <div class="form-group">
                                            <label for=""> <span class="required">*</span> Reference/Order No.:</label>
                                            <input type="text" name="reference" class="form-control form-control-sm"
                                                   value="<?php echo @$app_id; ?>">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-9 col-lg-10">
                                <div class="row">
                                    <div class="col-3">
                                        <div class="form-group">
                                            <label for=""><span class="required">*</span> Purchase Order Type</label>
                                            <select name="order_type"
                                                    class="form-control form-control-sm select2"
                                                    id="order_type" required>
                                                <option value="">-- Select --</option>
                                                <?php
                                                $orderTypeArray = array("Requisition", "Supply");
                                                foreach ($orderTypeArray as $orderType):
                                                    echo $app->dropDownList($orderType, $orderType, @$order_type);
                                                endforeach; ?>
                                            </select>
                                            <div class="invalid-feedback">* Required field</div>
                                        </div>
                                    </div>
                                    <div class="col-4">
                                        <div class="form-group">
                                            <label for=""><span class="required">*</span> Supplier Name</label>
                                            <select name="vendor_id"
                                                    class="form-control form-control-sm select2"
                                                    id="vendor_id" required>
                                                <option value="">-- Select --</option>
                                                <?php
                                                $tempParam = array("tbl_scheme" => 'app_vendors');
                                                $listArray = $module->getRecord($tempParam);
                                                $dropDownArray = array();
                                                foreach ($listArray['dataArray'] as $temps):
                                                    echo $app->dropDownList($temps['vendor_id'], $temps['company_name'], @$vendor_id);
                                                endforeach; ?>
                                            </select>
                                            <div class="invalid-feedback">* Required field</div>
                                        </div>
                                    </div>
                                    <div class="col-4">
                                        <div class="form-group">
                                            <label for=""><span class="required">*</span> Store</label>
                                            <select name="store_id"
                                                    class="form-control form-control-sm select2"
                                                    id="store" required
                                                    onchange='dropDownList("{\"request\":\"dropDownList\",\"pkField\":\"store_id\",\"pk\":"+ this.value +",\"target_scheme\":\"app_storage_location\",\"key\":\"id\",\"label\":\"name\",\"target\":\"storage_location\"}")'
                                                    tabindex="7">
                                                <option value="">-- Store --</option>
                                                <?php
                                                $storeParam = array("tbl_scheme" => 'app_stores', "condition" => ["active_status" => 1]);
                                                $listArray = $module->getRecord($storeParam);
                                                $dropDownArray = array();
                                                foreach ($listArray['dataArray'] as $store):
                                                    echo $app->dropDownList($store['store_id'], $store['store_name'], @$store_id);
                                                endforeach; ?>
                                            </select>
                                            <div class="invalid-feedback">* Required field</div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-4">
                                        <div class="form-group">
                                            <label for="">Storage Location</label>
                                            <select name="storage_id"
                                                    class="form-control form-control-sm select2"
                                                    id="storage_location" tabindex="8">
                                                <option value="">-- Storage Location --</option>
                                                <?php if (@$getUpdate['response'] === "200"):
                                                    $listArray = $module->getRecord(["tbl_scheme" => 'app_storage_location', "condition" => ["active_status" => 1]]);
                                                    foreach ($listArray['dataArray'] as $storage_location):
                                                        echo $app->dropDownList($storage_location['id'], $storage_location['name'], @$storage_id);
                                                    endforeach; endif; ?>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-3">
                                        <div class="form-group">
                                            <label><span class="required">*</span> Date</label>
                                            <input type="text" name="order_date"
                                                   class="form-control form-control-sm datepicker"
                                                   autocomplete="off"
                                                   placeholder="Date" required
                                                   value="<?php echo @$order_date; ?>">
                                            <div class="invalid-feedback">* This field is required</div>
                                        </div>
                                    </div>
                                    <div class="col-4">
                                        <div class="form-group">
                                            <label><span class="required">*</span> Purchase Order By</label>
                                            <input type="text" name="order_by"
                                                   class="form-control form-control-sm"
                                                   autocomplete="off"
                                                   placeholder="Date" required
                                                   value="<?php echo @$order_by; ?>">
                                            <div class="invalid-feedback">* This field is required</div>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label>Additional Note</label>
                                    <textarea class="text-editor" name="additional_note"
                                              placeholder="Additional Description"
                                              style="width: 100%; height: 250px; font-size: 14px; line-height: 18px; border: 1px solid #dddddd; padding: 10px;"><?php echo @$additional_note; ?></textarea>
                                </div>

                            </div>
                        </div>
                        <input type="hidden" name="className" value="Module_Class" readonly>
                        <?php if (@$getUpdate['response'] === "200"): ?>
                            <input type="hidden" name="functionName" value="updateRecord" readonly>
                            <input type="hidden" name="pk" value="<?php echo @$pk; ?>" readonly>
                            <input type="hidden" name="pkField" value="<?php echo @$pkField; ?>" readonly>
                        <?php else: ?>
                            <input type="hidden" name="functionName" value="createRecord" readonly>
                            <input type="hidden" name="pk" value="reference" readonly>
                        <?php endif; ?>
                        <input type="hidden" name="callback[type]" value="actionEvent" readonly>
                        <input type="hidden" name="callback[redirect]" value="itemCallback()" readonly>
                        <input type="hidden" name="tbl_scheme" value="app_purchase_orders" readonly>
                        <input type="hidden" name="created_by"
                               value="<?php echo trim(@$auth['firstname'] . ' ' . @$auth['lastname']); ?>" readonly>
                        <hr class="my-3">
                        <div class="row">
                            <div class="col-md-9 col-lg-10">
                                <button class="btn btn-default btn-sm actionButton"><i class="fal fa-check-circle"></i>
                                    Submit
                                </button>
                                <div class="float-right text-muted py-2"><i class="fal fa-info-circle"></i> Submit
                                    basics
                                    data to enable template entry page
                                </div>
                            </div>
                        </div>

                    </div>
                    <div class="tab-pane text-left fade" id="advance-tabs-panel" role="tabpanel"
                         aria-labelledby="advance-tabs">
                        <div class="row">
                            <div class="col-md-9 col-lg-12">
                                <?php require "order_item_entry.php"; ?>
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane text-left fade" id="preview-tabs-panel" role="tabpanel"
                         aria-labelledby="preview-tabs">
                        <div id="preview-template"></div>
                        <hr>
                        <div class="row">
                            <div class="col-md-9 col-lg-10">
                                <?php if (@$status == 1): ?>
                                    <button class="btn btn-default btn-sm" type="button"
                                            onclick="printTemplate('<?php echo $app_id; ?>', '<?php echo $temp; ?>')"><i
                                                class="fal fa-print"></i> Print
                                        Purchase Order
                                    </button>

                                <?php else: ?>
                                    <button class="btn btn-default btn-sm" type="button"
                                            onclick='javascript: var obj = "<?php echo urlencode('"className":"Module_Class","functionName":"updateRecord","tbl_scheme":"app_purchase_orders","status":1,"pkField":"reference","pk":"' . $app_id . '","callback":{"type":"self","redirect":""},"notification":{"message":"Are you sure to submit?","title":"Order Submission"}'); ?>";  moduleRequest(obj);'>
                                        <i class="fal fa-check-circle"></i> Submit
                                        Purchase Order
                                    </button>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </form>
</div>
<form id="item-entry-form" method="post">
    <input type="hidden" name="reference" value="<?php echo $app_id; ?>" readonly>
    <input type="hidden" id="SubmitOrderItem" name="SubmitOrderItem" value="1" readonly>
</form>
<div id="actionEvents"></div>
<script>
    function itemCallback() {
        location.replace("#/purchase-order/order/<?php echo @$app_id; ?>/");
        fetchURL("");
    }

    //-------------------------------------------------
    $("#item-entry-form").on('submit', function (e) {
        e.preventDefault();
        $(".itemActionButton").html('<i class="fal fa-spin fa-spinner"></i> Processing...');
        $.ajax({
            url: modulePath + "ajaxRequest.php",
            type: "POST",
            data: new FormData(this),
            contentType: false,
            cache: false,
            processData: false,
            success: function (data) {
                $("#item-entry-response").html(data);
                $(".itemActionButton").html('<i class="fal fa-plus-square"></i> Add Item');
            },
            error: function () {
            }
        });
    });

    //--------------------------------------------------
    function loadEntryRows() {
        $.post(modulePath + "ajaxRequest.php",
            {
                fetchEntryRows: 1,
                reference: "<?php echo $app_id; ?>",
            }, function (response) {
                $("#items-entry-table").html(response);
            });
    }

    function delEntryRows(row_id) {
        $.post(modulePath + "ajaxRequest.php",
            {
                className: 'Module_Class',
                delEntryRows: row_id,
                callback: {type: "self", redirect: ""},
                notification: {message: "Are you sure to delete?", title: "Delete Warning"},
            }, function (response) {
                $("#item-entry-response").html(response);
            });
    }

    function editEntryRows(id) {
        $.post(modulePath + "ajaxRequest.php",
            {
                fetchInvItemEdit: 1,
                row_id: id,
            }, function (response) {
                $("#item-entry-response").html(response);
                $("#SubmitOrderItem").val('2');
            });
    }

    //--------------------------------------------------
    function loadOrderPreview() {
        $.post(modulePath + "ajaxRequest.php",
            {
                orderPreview: 1,
                ref_no: "<?php echo $app_id;?>",
            }, function (response) {
                $("#preview-template").html(response);
            });
    }

    //--------------------------------------------------
    $('#inventory-lookup').on('keyup', function () {
        $(".inventory-lookup").autocomplete({
            source: 'modules/manage-inventory/src/ajaxInventoryLookup.php'
        });
    });
    //--------------------------------------------------
    $('#inventory-lookup').on('change', function () {
        var elem = this.value;
        var split = elem.split(' -> ');
        var app_id = split[0];
        $.post(modulePath + "ajaxRequest.php",
            {
                fetchInvItem: 1,
                app_id: app_id,
            }, function (response) {
                $("#item-entry-response").html(response);
            });
    });
    //--------------------------------------------------
    $("#computeArea input").on('keyup', function () {
        entryCalc();
    });

    function entryCalc() {
        var qty = $("#order_qty").val();
        var stock_qty = $("#stock_qty").val();
        var new_qty = $("#new_qty");
        var nQty = (qty - 0) + (stock_qty - 0);

        if (qty !== "" && nQty !== 'NaN') {
            new_qty.val(nQty);
        } else {
            new_qty.val('');
        }

        var order_price = $("#order_price").val();
        var stock_price = $("#stock_price").val();
        var new_price = $("#new_price");

        var nPrice = (order_price - 0) + (stock_price - 0);

        if (qty !== "" && order_price !== "") {
            var av1 = qty * order_price;
            var av2 = stock_qty * stock_price;
            var av3 = av1 + av2;
            var av4 = av3 / new_qty.val();
            new_price.val(av4);
        } else {
            // new_qty.val('');
        }

    }
</script>