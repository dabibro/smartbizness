<div class="row mb-3">
    <div class="col-12">
        <ul class="nav ml-auto modules-menu">
            <li class="nav-item col-lg-auto col-12">
                <div class="form-group position-relative">
                    <div class="input-group">
                        <input type="search" class="form-control-sm form-control" id="inventory_lookup"
                               autocomplete="off"
                               placeholder="Purchase Order Lookup ..." style="min-width: 300px"
                               onkeyup='recordFormLookup("{\"request\":\"search\",\"target_scheme\":\"app_products\",\"term\":\"" + this.value + "\",\"fields\":[\"app_id\",\"sku_barcode\",\"batch_sku_barcode\",\"name\",\"description\"],\"condition\":{\"active_status\":\"1\"},\"limit\":\"10\",\"order\":{\"order_fields\":[\"name\"],\"sort\":\"ASC\"}, \"key\":\"app_id\",\"labels\":[\"name\"],\"target\":\"lookup_response\",\"destination\":\"inventory_lookup\",\"callback\":\"self\",\"action_button\":\"inventory_lookup_btn\"}");'>
                        <div class="input-group-append">
                            <button class="btn btn-default btn-sm pr-2" type="button" id="inventory_lookup_btn"
                                    onclick='javascript:var obj; obj = $("#inventory_lookup").val(); obj = obj.split("]"); obj = obj[0].split("["); moduleEditRequest("\"request\":\"update\",\"pkField\":\"app_id\",\"pk\":\""+obj[1]+"\",\"view\":\"/#/inventory/add-item/\"")'>
                                <i class="fal fa-search m-0"></i>
                            </button>
                        </div>
                    </div>
                    <div class="lookup_response app-autolookup"></div>
                </div>
            </li>

            <li class="nav-item ml-auto"><a class="nav-link active app-link" href="#/purchase-order/order/"
                                            onclick="fetchURL(this.href)"><i class="fal fa-plus-square"></i> Create
                    Order</a>
            </li>
            <li class="nav-item hide"><a class="nav-link" href="#/inventory/category/"
                                     onclick="fetchURL(this.href)"><i
                            class="fal fa-folder-tree"></i> Manage Category</a></li>
            <li class="nav-item app-collapse">
                <a class="nav-link dropdown-toggle" data-toggle="collapse"
                   href="#collapseUsersFilter"
                   aria-expanded="false" aria-controls="collapseUsersFilter">
                    <i class="fal fa-filter"></i> Advance Filter<span class="caret"></span>
                </a>
                <div class="collapse collapse-container right" id="collapseUsersFilter">
                    <div class="card-body elevation-1 bg-light left">
                        <form action="">
                            <div class="form-group">
                                <label for="">Users Group</label>
                                <select name="users_group" class="form-control form-control-sm select2">
                                    <option value="">-- Users Group --</option>
                                </select>
                            </div>
                            <div class="row">
                                <div class="col-6">
                                    <div class="form-group">
                                        <label for="">Users Store</label>
                                        <select name="users_location"
                                                class="form-control form-control-sm select2">
                                            <option value="">-- Users Store --</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-6">
                                    <div class="form-group">
                                        <label for="">Active Status</label>
                                        <select name="activation" class="form-control form-control-sm select2">
                                            <option value="">-- Active Status --</option>
                                        </select>
                                    </div>
                                </div>

                            </div>

                            <hr class="my-2">
                            <button class="btn btn-default btn-sm btn-block"><i class="fal fa-check-circle"></i>
                                Submit
                            </button>
                        </form>
                    </div>
                </div>
            </li>
        </ul>
    </div>
</div>
<?php
if ($view == "view/"):
    require "order-preview.php";
elseif ($view == "order/"):
    require "order_record.php";
else:
    require "order_list.php";
endif;
?>