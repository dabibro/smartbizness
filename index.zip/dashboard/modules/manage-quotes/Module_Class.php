<?php
/**
 * Created by PhpStorm.
 * User: Dauda Ibrahim
 * Date: 6/23/2020
 * Time: 10:14 PM
 */

class Module_Class extends Data_Access
{
    protected $engine;

    public function __construct()
    {
        $this->initials();
        $this->dbConnect();
        $this->engine = new SMBEngine;

    }

    private $table_name;
    private $product_table;
    private $inventory_table;

    private $pk;

    public function createRecord($varParam = NULL)
    {

        $this->table_name = $varParam['tbl_scheme'];
        if (isset($varParam['pk']) && $varParam['pk'] !== "") {
            $this->pk = $varParam['pk'];
            $pkVal = $varParam[$this->pk];
            $getArray = array(
                "tbl_scheme" => $this->table_name,
                "condition" => [
                    $this->pk => $pkVal
                ]);
            $getRecord = $this->getRecord($getArray);
            if ($getRecord['response'] === "200"):
                $responseArray = App_Response::getResponse('000');
                $responseArray['message'] = "Record already exist";
                return $responseArray;
                exit;
            endif;
        }

        $fields = "";
        $values = "";
        foreach ($varParam as $field => $val):
            if ($field != "tbl_scheme" && $field !== "pk"):
                $fields .= $field . ', ';
                $values .= "'" . $this->engine->verify_input($val) . "'" . ',';
            endif;
        endforeach;
        $fields = rtrim($fields, ', ');
        $values = rtrim($values, ', ');

        $query = "INSERT INTO " . $this->dbScheme . "." . $this->table_name;
        $query .= " (" . $fields . ") VALUES (" . $values . ");";

        $res = $this->insertIntoDatabase($query);
        if ($res['response'] !== '200') {
            $responseArray = App_Response::getResponse('000');
            $responseArray['message'] = "Could'nt process request";
        } else {
            $res['message'] = "Request processed successfully";
            $responseArray = $res;
        }
        return $responseArray;
    }

    public function getRecord($varParam = NULL)
    {
        $this->table_name = $varParam['tbl_scheme'];
        $condition = "";
        $orders = "";
        $limits = "";
        if ($varParam['condition'] != NULL) {
            foreach ($varParam['condition'] as $field => $val):
                $condition .= '(' . $field . "= '" . $val . "')" . ' AND ';
            endforeach;
            $condition = " WHERE " . rtrim($condition, "AND ");
        }
        if (isset($varParam['order']) && $varParam['order'] !== "") {
            $orders = "ORDER BY " . $varParam['order'] . " ";
        }

        $query = "SELECT * FROM " . $this->dbScheme . "." . $this->table_name;
        $query .= $condition . " " . $orders . " ;";

        $res = $this->getResultSetArray($query);
        if ($res['response'] === '200') {
            $responseArray = $res;
        } else {
            $responseArray = App_Response::getResponse('000');
            $responseArray['message'] = "No record found for query";
        }
        return $responseArray;

    }

    public function updateRecord($varParam = NULL)
    {
        //print_r($varParam);
        $this->table_name = $varParam['tbl_scheme'];
        $fields = "";
        $pk_field = "";
        if ($varParam != NULL) {
            foreach ($varParam as $field => $val):
                if ($field != "tbl_scheme" && $field != "pk" && $field != "pkField")
                    $fields .= $field . " = '" . $val . "'" . ', ';
            endforeach;
            $fields = rtrim($fields, ", ");
            $pk_field = $varParam['pkField'] . "='" . $varParam['pk'] . "'";
        }
        $query = "UPDATE " . $this->dbScheme . "." . $this->table_name;
        $query .= " SET " . $fields . " WHERE " . $pk_field . ";";

        $res = $this->updateDatabaseTable($query);
        if ($res['response'] !== '200') {
            $responseArray = App_Response::getResponse('000');
            $responseArray['message'] = "Couldn't update record";
        } else {
            $res['message'] = "Update request successfully";
            $responseArray = $res;
        }
        return $responseArray;
    }

    public function deleteRecord($varParam = NULL)
    {
        $this->table_name = $varParam['tbl_scheme'];
        $pk = "";
        $fk = "";
        if (isset($varParam['pk']) && $varParam['pk'] != NULL) {
            foreach ($varParam['pk'] as $pkField => $pkVal):
                $pk .= $pkField . " = '" . $pkVal . "', ";
            endforeach;
            $pk = rtrim($pk, ', ');

            if (isset($varParam['fk']) && $varParam['fk'] != NULL) {
                foreach ($varParam['pk'] as $fkField => $fkVal):
                    foreach ($varParam['fk'] as $fk2):
                        $fk .= $fk2 . " = '" . $fkVal . "', ";
                    endforeach;
                endforeach;
                $fk = trim($fk, ', ');
                $fk_query = "DELETE FROM " . $this->dbScheme . "." . $this->table_name;
                $fk_query .= " WHERE (" . $fk . ");";
                @$this->deleteTableRecord($fk_query);

            }

            $query = "DELETE FROM " . $this->dbScheme . "." . $this->table_name;
            $query .= " WHERE (" . $pk . ");";

            $res = $this->deleteTableRecord($query);
            if ($res['response'] !== '200') {
                $responseArray = App_Response::getResponse('000');
                $responseArray['message'] = "Could'nt process request";
            } else {
                $res['message'] = "Delete request completed";
                $responseArray = $res;
            }
            return $responseArray;
        }
    }

    public function searchRecord($varParam = NULL)
    {
        $fields = "";
        $condition = "";
        $order = "";
        $order_fields = "";
        $order_sort = "";
        $limit = "";

        $this->table_name = $varParam['tbl_scheme'];
        $term = $varParam['term'];
        if (isset($varParam['condition'])) {
            foreach ($varParam['condition'] as $tag => $tagVal):
                $condition .= " AND " . $tag . "='" . $tagVal . "'";
            endforeach;
            $condition = " AND " . ltrim($condition, ' AND ');
        }
        foreach ($varParam['fields'] as $field) {
            $fields .= " OR " . $field . " LIKE '%" . $term . "%'" . $condition;
        }
        $condition = ltrim($fields, ' OR ');
        if (isset($varParam['order']) && $varParam['order'] !== NULL):
            $order_sort = $varParam['order']['sort'];
            foreach ($varParam['order']['order_fields'] as $order_field):
                $order_fields .= $order_field . ', ';
            endforeach;
            $order_fields = trim($order_fields, ', ');
            $order = ' ORDER BY ' . $order_fields . ' ' . $order_sort;
        endif;
        if (isset($varParam['limit']) && $varParam['limit'] != ""):
            $limit = ' LIMIT ' . $varParam['limit'];
        endif;
        $query = "SELECT * FROM " . $this->dbScheme . "." . $this->table_name;
        $query .= " WHERE " . $condition . " " . $order . " " . $limit . " ;";

        $res = $this->getResultSetArray($query);
        if ($res['response'] === '200') {
            $responseArray = $res;
        } else {
            $responseArray = App_Response::getResponse('000');
        }
        return $responseArray;

    }

    //-----------------------------------------------------------------------------------
    public function createInventoryItem($varParam = NULL)
    {
        $this->product_table = $varParam['app_products']['tbl_scheme'];
        $this->inventory_table = $varParam['app_inventory']['tbl_scheme'];

        if (isset($varParam['pk']) && $varParam['pk'] !== "") {
            $this->pk = $varParam['pk'];
            $pkVal = $varParam['app_products'][$this->pk];
            $getArray = array(
                "tbl_scheme" => $this->product_table,
                "condition" => [
                    $this->pk => $pkVal
                ]);
            $getRecord = $this->getRecord($getArray);
            if ($getRecord['response'] === "200"):
                $responseArray = App_Response::getResponse('000');
                $responseArray['message'] = "Record already exist";
                return $responseArray;
                exit;
            endif;
        }
        //--------------------------------------------------------------------
        $tbl_fields = "";
        $tbl_values = "";
        foreach ($varParam['app_products'] as $tbl_field => $field_val):
            if ($tbl_field != "tbl_scheme" && $tbl_field !== "pk"):
                $tbl_fields .= $tbl_field . ', ';
                if (is_array($field_val)):
                    $tbl_values .= "'" . json_encode($field_val) . "'" . ',';
                else:
                    if ($tbl_field == 'batch_sku_barcode'):
                        $tbl_values .= "'" . $this->engine->verify_input(rtrim($field_val, ',')) . "'" . ',';
                    else:
                        $tbl_values .= "'" . $this->engine->verify_input($field_val) . "'" . ',';
                    endif;
                endif;
            endif;
        endforeach;
        $tbl_fields = rtrim($tbl_fields, ', ');
        $tbl_values = rtrim($tbl_values, ', ');
        $query = "INSERT INTO " . $this->dbScheme . "." . $this->product_table;
        $query .= " (" . $tbl_fields . ") VALUES (" . $tbl_values . ");";
        $productInsert = $this->insertIntoDatabase($query);
        if ($productInsert['response'] !== '200') {
            $responseArray = App_Response::getResponse('000');
            $responseArray['message'] = "Could'nt process request";
        } else {
            $tbl_insert['message'] = "Request processed successfully";
            $responseArray = $productInsert;
        }

        //--------------------------------------------------------------------
        if ($productInsert['response'] === "200") {

            //print_r($varParam['app_inventory']);

            $tbl_fields = "";
            $tbl_values = "";
            foreach ($varParam['app_inventory'] as $tbl_field => $field_val):
                if ($tbl_field != "tbl_scheme" && $tbl_field !== "pk"):
                    $tbl_fields .= $tbl_field . ', ';
                    if (is_array($field_val)):
                        $tbl_values .= "'" . json_encode($field_val) . "'" . ',';
                    else:
                        $tbl_values .= "'" . $this->engine->verify_input($field_val) . "'" . ',';
                    endif;
                endif;
            endforeach;
            $tbl_fields = rtrim($tbl_fields, ', ');
            $tbl_values = rtrim($tbl_values, ', ');
            $query = "INSERT INTO " . $this->dbScheme . "." . $this->inventory_table;
            $query .= " (" . $tbl_fields . ") VALUES (" . $tbl_values . ");";
            $inventoryInsert = $this->insertIntoDatabase($query);
            if ($productInsert['response'] !== '200') {
                $responseArray = App_Response::getResponse('000');
                $responseArray['message'] = "Could'nt process request";
            } else {
                $tbl_insert['message'] = "Request processed successfully";
                $responseArray = $inventoryInsert;
            }

        }
        //print_r($responseArray);
        //exit;
        return $responseArray;
    }

    public function updateInventoryItem($varParam = NULL)
    {
        $this->product_table = $varParam['app_products']['tbl_scheme'];
        $this->inventory_table = $varParam['app_inventory']['tbl_scheme'];
        $fields = "";
        $pk_field = "";
        if ($varParam['app_products'] != NULL) {
            foreach ($varParam['app_products'] as $field => $val):
                if ($field != "tbl_scheme" && $field != "pk" && $field != "pkField")
                    if (is_array($val)):
                        $fields .= "'" . json_encode($val) . "'" . ',';
                    else:
                        if ($field == 'batch_sku_barcode'):
                            $fields .= $field . " = '" . $this->engine->verify_input(rtrim($val, ',')) . "'" . ', ';
                        else:
                            $fields .= $field . " = '" . $this->engine->verify_input($val) . "'" . ', ';
                        endif;
                    endif;
            endforeach;
            $fields = rtrim($fields, ", ");
            $pk_field = $varParam['app_products']['pkField'] . "='" . $varParam['app_products']['pk'] . "'";
        }
        $query = "UPDATE " . $this->dbScheme . "." . $this->product_table;
        $query .= " SET " . $fields . " WHERE " . $pk_field . ";";
        $productUpdate = $this->updateDatabaseTable($query);
        if ($productUpdate['response'] === '200') {
            $fields = "";
            $pk_field = "";
            if ($varParam['app_inventory'] != NULL) {
                foreach ($varParam['app_inventory'] as $field => $val):
                    if ($field != "tbl_scheme" && $field != "pk" && $field != "pkField")
                        if (is_array($val)):
                            $fields .= "'" . json_encode($val) . "'" . ',';
                        else:
                            $fields .= $field . " = '" . $this->engine->verify_input($val) . "'" . ', ';
                        endif;
                endforeach;
                $fields = rtrim($fields, ", ");
                $pk_field = $varParam['app_inventory']['pkField'] . "='" . $varParam['app_inventory']['pk'] . "'";
            }
            $query = "UPDATE " . $this->dbScheme . "." . $this->inventory_table;
            $query .= " SET " . $fields . " WHERE " . $pk_field . ";";
            $inventoryUpdate = $this->updateDatabaseTable($query);
            if ($inventoryUpdate['response'] !== '200') {
                $responseArray = App_Response::getResponse('000');
                $responseArray['message'] = "Could'nt process request";
            } else {
                $tbl_insert['message'] = "Request processed successfully";
                $responseArray = $inventoryUpdate;
            }
        }
        return $responseArray;
    }

    public function deleteInventoryItem($varParam = NULL)
    {
        $this->product_table = 'app_products';
        $this->inventory_table = 'app_inventory';
        $app_id = $varParam['pk']['app_id'];
        $query = "DELETE FROM " . $this->dbScheme . "." . $this->inventory_table;
        $query .= " WHERE app_id = ('" . $app_id . "');";
        $this->deleteTableRecord($query);
        $query2 = "DELETE FROM " . $this->dbScheme . "." . $this->product_table;
        $query2 .= " WHERE app_id = ('" . $app_id . "');";
        $res2 = $this->deleteTableRecord($query2);
        if ($res2['response'] !== '200') {
            $responseArray = App_Response::getResponse('000');
            $responseArray['message'] = "Could'nt process request";
        } else {
            $res['message'] = "Delete request completed";
            $responseArray = $res2;
        }
        return $responseArray;
    }

    //-----------------------------------------------------------------------------------
    public function execCommand($varFunctionName, $varFunctionParams)
    {
        $returnArray = $this->getCommand($varFunctionName);
        if ($returnArray['success'] == FALSE) {
            return $returnArray;
        }
        $class = $returnArray['dataArray']['class'];
        $functionName = $returnArray['dataArray']['function_name'];
        $cObjectClass = new $class();
        $returnArray = $cObjectClass->$functionName($varFunctionParams);
        return $returnArray;
    }

    private function loadFunctionMap($varParam)
    {
        return $this->function_map = [
            $varParam[0]['function_name'] => ['class' => $varParam[0]['class'], 'function_name' => $varParam[0]['function_name']],
        ];
    }

    public function getCommand($varFunctionName)
    {
        $this->function_map = $this->loadFunctionMap([$varFunctionName]);
        if (isset($this->function_map)) {
            $dataArray['class'] = $this->function_map[$varFunctionName['function_name']]['class'];
            $dataArray['function_name'] = $this->function_map[$varFunctionName['function_name']]['function_name'];

            $returnArray = App_Response::getResponse('200');
            $returnArray['dataArray'] = $dataArray;
        } else {
            $returnArray = App_Response::getResponse('405');
        }
        return $returnArray;

    }

}