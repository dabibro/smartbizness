<?php
if (isset($customer_folder) && $customer_folder != ""):
    $requestMethodArray = [
        "request" => 'update',
        "pk" => $customer_folder,
        "pkField" => 'app_id'
    ];
endif;
if (@$requestMethodArray['request'] == "update" && @$requestMethodArray['pk'] != "" && @$requestMethodArray['pkField'] != ""):
    $pk = $requestMethodArray['pk'];
    $pkField = $requestMethodArray['pkField'];
    $getUpdateArray = array(
        "tbl_scheme" => 'app_customers',
        "condition" => [$pkField => $pk],
        "limit" => 1
    );
    $getUpdate = $module->getRecord($getUpdateArray);
    extract($getUpdate['dataArray'][0]);
else:
    $app_id = $app->generateAppId('C', '', 6, '1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZ');
endif;


?>
<style>
    .select2-selection--multiple .select2-selection__rendered {
        min-height: 64px;
        max-height: 64px;
        overflow-x: hidden;
        overflow-y: auto !important;
    }
</style>
<div class="position-relative">
    <div class="row">
        <div class="col-2"></div>
        <div class="col-10">
            <div class="row">
                <div class="col-md-9 col-lg-8">
                    <div class="col-6 ml-auto">
                        <div class="form-group position-relative mb-0">
                            <div class="input-group">
                                <input type="search" class="form-control-sm form-control" id="customer_lookup"
                                       autocomplete="off"
                                       placeholder="Customer Lookup..."
                                       onkeyup='recordFormLookup("{\"request\":\"search\",\"target_scheme\":\"app_customers\",\"term\":\"" + this.value + "\",\"fields\":[\"app_id\",\"customer_id\",\"customer_name\",\"contact_name\",\"contact_phone\",\"contact_email\",\"address_1\",\"address_2\",\"contact_fax\"],\"condition\":{\"active_status\":\"1\"},\"limit\":\"10\",\"order\":{\"order_fields\":[\"customer_name\",\"contact_name\"],\"sort\":\"ASC\"}, \"key\":\"app_id\",\"labels\":[\"customer_name\"],\"target\":\"lookup_response\",\"destination\":\"customer_lookup\",\"callback\":\"self\"}");'>
                                <div class="input-group-append">
                                    <button class="btn btn-default btn-sm pr-2" type="button"
                                            onclick='javascript:var obj; obj = $("#customer_lookup").val(); obj = obj.split("]"); obj = obj[0].split("["); moduleEditRequest("\"request\":\"update\",\"pkField\":\"app_id\",\"pk\":\""+obj[1]+"\",\"view\":\"/#/customers/record/\"")'>
                                        <i class="fal fa-search m-0"></i>
                                    </button>
                                </div>
                            </div>
                            <div class="lookup_response app-autolookup"></div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
    <hr class="my-2">
    <form method="post" class="AppForm" id="create-customer-form">
        <div class="row">
            <div class="col-3 px-0 mr-3"></div>
            <div class="col-8 pl-5">
                <div id="ModuleResponse"></div>
            </div>
        </div>
        <div class="row">
            <div class="col-2">
                <div class="nav flex-column nav-tabs h-100" id="vert-tabs-tab" role="tablist"
                     aria-orientation="vertical">
                    <a class="nav-link active" id="basic-tabs" data-toggle="pill" href="#basic-tabs-panel" role="tab"
                       aria-controls="basic-tabs-panel" aria-selected="false"><i class="fal fa-info-circle"></i>
                        Customer Data
                        <hr class="my-1">
                        <small class="text-muted">Fill in the customer details.
                        </small>
                    </a>
                    <?php if (isset($customer_folder)): ?>
                        <a class="nav-link" id="basic-tabs" data-toggle="pill" href="#basic-tabs-panel"
                           role="tab"
                           aria-controls="basic-tabs-panel" aria-selected="false"><i class="fal fa-shopping-basket"></i>
                            Purchases
                            <hr class="my-1">
                            <small class="text-muted">Fill in the customer details.
                            </small>
                        </a>
                        <a class="nav-link " id="basic-tabs" data-toggle="pill" href="#basic-tabs-panel"
                           role="tab"
                           aria-controls="basic-tabs-panel" aria-selected="false"><i class="fal fa-money-check"></i>
                            Payments
                            <hr class="my-1">
                            <small class="text-muted">Fill in the customer details.
                            </small>
                        </a>
                        <a class="nav-link" id="basic-tabs" data-toggle="pill" href="#basic-tabs-panel"
                           role="tab"
                           aria-controls="basic-tabs-panel" aria-selected="false"><i class="fal fa-file-invoice"></i>
                            Quotations
                            <hr class="my-1">
                            <small class="text-muted">Fill in the customer details.
                            </small>
                        </a>
                    <?php endif; ?>
                </div>
            </div>
            <div class="col-10">
                <div class="tab-content" id="add-item-tabContent">
                    <div class="tab-pane text-left fade active show" id="basic-tabs-panel" role="tabpanel"
                         aria-labelledby="basic-tabs">
                        <div class="row">
                            <div class="col-md-9 col-lg-8">
                                <div class="row">
                                    <div class="col-4">
                                        <div class="form-group">
                                            <label class="w-100"><span class="required">*</span> Customer Type
                                                <a title="Individual/Organization/Internal"
                                                   class="text-muted pointer float-right"><i
                                                            class="fal fa-question-circle"></i></a></label>
                                            <select name="customer_type"
                                                    class="form-control form-control-sm select2" required>
                                                <option value="">-- Select --</option>
                                                <?php $itemArray = array("Individual", "Organization", "Internal");
                                                foreach ($itemArray as $item): ?>
                                                    <option value="<?php echo $item ?>" <?php if (@$customer_type == $item): echo 'selected';endif; ?>><?php echo $item; ?></option>
                                                <?php endforeach; ?>
                                            </select>

                                            <div class="invalid-feedback">* Required field</div>
                                        </div>
                                    </div>
                                    <div class="col-4">
                                        <div class="form-group">
                                            <label for="" class="w-100"> <span class="required">*</span> Customer ID <a
                                                        title="Customer Unique Identification"
                                                        class="text-muted  pointer float-right"><i
                                                            class="fal fa-question-circle"></i></a></label>
                                            <div class="input-group input-group-sm">
                                                <input type="text" name="customer_id" id="customer_id"
                                                       class="form-control focus_customer_id"
                                                       value="<?php echo @$customer_id; ?>"
                                                       required placeholder="Customer ID"
                                                       autocomplete="off">
                                                <div class="btn-group">
                                                    <button class="btn btn-default btn-sm appAutoIDGen pr-2"
                                                            type="button"
                                                            AppId-AutoGen='{"prefix":"","suffix":"<?php echo date('d', time()) ?>", "strlen":"6","pattern":"0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ","target":"customer_id"}'
                                                            id="customerIdGen"
                                                            title="Auto Generate" data-toggle="tooltip"><i
                                                                class="fal fa-barcode m-0"></i></button>
                                                </div>
                                                <div class="invalid-feedback">* This field is required</div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-auto ml-auto">
                                        <?php if (@$getUpdate['response'] === "200"): ?>
                                            <div class="form-group">
                                                <div class="custom-control custom-switch">
                                                    <input type="checkbox" <?php if (@$active_status == 1): echo 'checked';endif; ?>
                                                           class="custom-control-input propToggle" id="active_status">
                                                    <label class="custom-control-label" for="active_status"> Active
                                                        Status</label>
                                                    <input type="hidden" readonly name="active_status"
                                                           class="active_status"
                                                           value="<?php if (@$active_status == 1): echo 1; else: echo 0;endif; ?>">
                                                </div>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-12">
                                        <div class="form-group">
                                            <label><span class="required">*</span> Customer Name</label>
                                            <input type="text" name="customer_name"
                                                   class="form-control form-control-sm"
                                                   autocomplete="off"
                                                   placeholder="Customer Name" required
                                                   value="<?php echo @$customer_name ?>">
                                            <div class="invalid-feedback">* This field is required</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-9 col-lg-8">
                                <div class="row">
                                    <div class="col-3">
                                        <div class="form-group">
                                            <label for="">Title</label>
                                            <select name="contact_title" class="form-control form-control-sm select2">
                                                <option value="">-- Title --</option>
                                                <?php $itemArray = array("Mr", "Mrs", "Miss");
                                                foreach ($itemArray as $item): ?>
                                                    <option value="<?php echo $item ?>" <?php if (@$contact_title == $item): echo 'selected';endif; ?>><?php echo $item; ?></option>
                                                <?php endforeach; ?>
                                            </select>
                                            <small class="text-muted">(Optional)</small>
                                        </div>
                                    </div>
                                    <div class="col-5">
                                        <div class="form-group">
                                            <label for="contact_name"> Contact Name</label>
                                            <input name="contact_name" type="text"
                                                   class="form-control form-control-sm " placeholder="Contact Name"
                                                   value="<?php echo @$contact_name; ?>" autocomplete="off">
                                            <small class="text-muted">(Optional)</small>

                                        </div>
                                    </div>
                                    <div class="col-4">
                                        <div class="form-group">
                                            <label><span class="required">*</span> Contact Phone</label>
                                            <input name="contact_phone" type="text" required
                                                   class="form-control form-control-sm" placeholder="Contact Phone"
                                                   value="<?php echo @$contact_phone; ?>" autocomplete="off">
                                            <div class="invalid-feedback">* Required field</div>

                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-4">
                                        <div class="form-group">
                                            <label>Email Address</label>
                                            <div class="controls">
                                                <input name="contact_email" type="email"
                                                       class="form-control form-control-sm"
                                                       value="<?php echo @$contact_email; ?>"
                                                       placeholder="Email Address"
                                                       autocomplete="off">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-4">
                                        <div class="form-group">
                                            <label>Fax</label>
                                            <input name="contact_fax" type="text"
                                                   class="form-control form-control-sm" placeholder="Fax"
                                                   value="<?php echo @$contact_fax; ?>" autocomplete="off">
                                        </div>
                                    </div>
                                    <div class="col-4">
                                        <div class="form-group">
                                            <label>Web URL</label>
                                            <div class="controls">
                                                <input name="website_address" type="text"
                                                       class="form-control form-control-sm"
                                                       value="<?php echo @$website_address; ?>"
                                                       placeholder="Web Address"
                                                       autocomplete="off">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label> Country</label>
                                            <select name="country" class="form-control form-control-sm select2"
                                                    id="country"
                                                    onchange='dropDownList("{\"request\":\"dropDownList\",\"pkField\":\"country_id\",\"pk\":"+ this.value +",\"target_scheme\":\"app_states\",\"key\":\"id\",\"label\":\"name\",\"target\":\"states\"}")'>
                                                <option>-- Country --</option>
                                                <?php
                                                $countryParam = array("tbl_scheme" => 'app_countries');
                                                $listArray = $module->getRecord($countryParam);
                                                $dropDownArray = array();
                                                foreach ($listArray['dataArray'] as $countries):
                                                    echo $app->dropDownList($countries['id'], $countries['name'], @$country);
                                                endforeach; ?>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label>State</label>
                                            <select name="state" class="form-control form-control-sm select2"
                                                    id="states"
                                                    onchange='dropDownList("{\"request\":\"dropDownList\",\"pkField\":\"state_id\",\"pk\":"+ this.value +",\"target_scheme\":\"app_cities\",\"key\":\"id\",\"label\":\"name\",\"target\":\"cities\"}")'>
                                                <option>-- State --</option>
                                                <?php if (@$getUpdate['response'] === "200"):
                                                    $listArray = $module->getRecord(["tbl_scheme" => 'app_states', "condition" => ["country_id" => $country]]);
                                                    foreach ($listArray['dataArray'] as $states):
                                                        echo $app->dropDownList($states['id'], $states['name'], $state);
                                                    endforeach; endif; ?>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label>City</label>
                                            <select name="city" class="form-control form-control-sm select2"
                                                    id="cities">
                                                <option>-- City --</option>
                                                <<?php if (@$getUpdate['response'] === "200"):
                                                    $listArray = $module->getRecord(["tbl_scheme" => 'app_cities', "condition" => ["state_id" => $state]]);
                                                    foreach ($listArray['dataArray'] as $cities):
                                                        echo $app->dropDownList($cities['id'], $cities['name'], $city);
                                                    endforeach; endif; ?>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-6">
                                        <div class="form-group">
                                            <label><span class="required">*</span> Address 1</label>
                                            <textarea name="address_1" required class="form-control form-control-sm"
                                                      rows="2"
                                                      placeholder="Address 1"
                                                      autocomplete="off"><?php echo @$address_1; ?></textarea>
                                            <div class="invalid-feedback">* Required field</div>

                                        </div>
                                    </div>
                                    <div class="col-6">
                                        <div class="form-group">
                                            <label>Address 2
                                                <small class="text-muted">(Optional)</small>
                                            </label>
                                            <textarea name="address_2" class="form-control form-control-sm" rows="2"
                                                      placeholder="Address 2"
                                                      autocomplete="off"><?php echo @$address_2; ?></textarea>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-4">
                                        <div class="form-group">
                                            <label>Postal Code
                                                <small class="text-muted">(Optional)</small>
                                            </label>
                                            <div class="controls">
                                                <input name="postal_code" type="text"
                                                       class="form-control form-control-sm"
                                                       value="<?php echo @$postal_code; ?>"
                                                       placeholder="Postal Code"
                                                       autocomplete="off">

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <input type="hidden" name="className" value="Module_Class" readonly>
        <?php if (@$getUpdate['response'] === "200"): ?>
            <input type="hidden" name="functionName" value="updateRecord" readonly>
            <input type="hidden" name="pk" value="<?php echo @$pk; ?>" readonly>
            <input type="hidden" name="pkField" value="<?php echo @$pkField; ?>" readonly>
        <?php else: ?>
            <input type="hidden" name="functionName" value="createRecord" readonly>
            <input type="hidden" name="pk" value="customer_id" readonly>
        <?php endif; ?>
        <input type="hidden" name="callback[type]" value="actionEvent" readonly>
        <input type="hidden" name="callback[redirect]" value="formEditCallback()" readonly>
        <input type="hidden" name="tbl_scheme" value="app_customers" readonly>
        <input type="hidden" name="created_by"
               value="<?php echo trim(@$auth['firstname'] . ' ' . @$auth['lastname']); ?>" readonly>
        <input type="hidden" name="store_id" value="<?php echo trim(@$auth['store_id']); ?>" readonly>
        <input type="hidden" name="app_id" value="<?php echo $app_id; ?>" readonly>
        <hr class="my-2">
        <div class="row">
            <div class="col-2"></div>
            <div class="col-10">
                <div class="col-md-9 col-lg-10 pl-0">
                    <button class="btn btn-default actionButton"><i class="fal fa-check-circle"></i> Submit
                    </button>
                </div>
            </div>
        </div>
    </form>
</div>

<div id="actionEvents"></div>
<script>
    $('.focus_customer_id').focus();

    function reloadCategory() {
        dropDownList("{\"request\":\"dropDownList\",\"pkField\":\"parent_id\",\"pk\":\"0\",\"target_scheme\":\"app_category\",\"key\":\"id\",\"label\":\"name\",\"target\":\"category_id\"}");
    };

    function reloadSubcategory() {
        dropDownList("{\"request\":\"dropDownList\",\"pkField\":\"parent_id\",\"pk\":" + $("#category_id").val() + ",\"target_scheme\":\"app_category\",\"key\":\"id\",\"label\":\"name\",\"target\":\"subcategory\"}")
    }

    function formEditCallback() {
        location.replace("#/customers/record/<?php echo @$app_id; ?>/");
        fetchURL('')
        //var obj = "<?php //echo urlencode('"pkField":"app_id","pk":"' . $app_id . '","view":"/#/customers/record/","request":"update"'); ?>";
        //moduleEditRequest(obj);

    }
</script>