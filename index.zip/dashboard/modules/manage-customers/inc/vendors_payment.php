<?php
//require
require_once('inc/queries.php');
?>
<div id="responses"></div>
<div class="card x_panel shadow-sm">
    <div class="x_title">
        <span class="title"><i class="fal fa-money-bill"></i> Vendors Payment</span>
    </div>
    <div class="x_content">
        <div class="row mb-3">
            <div class="col-6">
                <button type="button" class="btn btn-primary dropdown-toggle px-4" data-toggle="collapse"
                        aria-expanded="false" data-target="#filterCriteria" aria-controls="filterCriteria">
                    <i class="fal fa-filter"></i> Filter Report
                </button>
                <div class="collapse px-3 py-3 card br-0 shadow-sm" aria-labelledby="dLabel" id="filterCriteria"
                     style="z-index: 1 !important; position: absolute;">
                    <form method="post">
                        <div class="row">
                            <div class="col-6">
                                <div class="form-group">
                                    <div class="input-group">
                                        <select name="vendor_id" id="vendor_id" class="form-control select2"
                                                style="width: 100%;">
                                            <option value="">-- Vendor --</option>
                                            <?php
                                            while ($dn = dbFetchAssoc($vendors)): ?>
                                                <option value="<?php echo $dn['id']; ?>">
                                                    <?php echo $dn['name']; ?>
                                                </option>
                                            <?php endwhile; ?>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="form-group">
                                    <select name="pay_mode" id="pay_mode" class="form-control select2"
                                            style="width: 100%;">
                                        <option value="">-- Payment Option --</option>
                                        <?php
                                        while ($dn = dbFetchAssoc($payment_options)):
                                            ?>
                                            <option value="<?php echo $dn['id']; ?>">
                                                <?php echo $dn['mode_name']; ?>
                                            </option>
                                        <?php endwhile; ?>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group " id="str">
                                    <div class="input-group input-group-sm">
                                        <input type="text" class="form-control datepicker border-right-0"
                                               name="start_date"
                                               id="start_date" placeholder="Start Date" style="border-radius:0;"
                                               autocomplete="off">
                                        <span class="input-group-prepend">
                                <span class="input-group-text"><i class="fal fa-calendar-minus"></i></span>
                            </span>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group" id="stp">
                                    <div class="input-group input-group-sm">
                                        <input type="text" class="form-control datepicker border-right-0"
                                               name="stop_date"
                                               id="stop_date" placeholder="Stop Date" style="border-radius:0;"
                                               autocomplete="off">
                                        <span class="input-group-prepend">
                                <span class="input-group-text"> <i class="fal fa-calendar-plus"></i></span>
                            </span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <button class="btn btn-primary btn-block" type="submit"> Apply
                            Filter <i class="fal fa-angle-double-right"></i>
                        </button>
                        <input type="hidden" name="filter-payments" value="1">
                    </form>
                </div>
            </div>
            <div class="col-md-2 text-right ml-auto">
                <?php if (@$access['new_vendor_payment'] == 1) { ?>
                    <button class="btn btn-primary px-4" type="button"
                            onClick="javascript:location.replace('?p=new-vendor-payment')"><i
                                class="fal fa-plus-square"></i>
                        New Payment
                    </button>
                <?php } ?>
            </div>
        </div>
        <div id="transReport" class="table-responsive datatable-buttons">
            <table class="table table-hover table-striped datatable-btn" style="font-size:12px;">
                <?php if (isset($_POST['filter-payments']) && $_POST['filter-payments'] == 1) { ?>
                    <caption>Currently viewing filtered: [ <a href="?p=vendors-payments">Reset Filter</a> ]</caption>
                <?php } else {
                    echo "<caption>Currently viewing current month payments</caption>";
                } ?>
                <thead>
                <tr>
                    <th width="10">#</th>
                    <th>Ref #</th>
                    <th>Vendor</th>
                    <th>Payment Option</th>
                    <th>Paid Amount N</th>
                    <th>Entry By</th>
                    <th>Date</th>
                    <th>Entry Date</th>
                    <th width="20" nowrap></th>
                </tr>
                </thead>
                <tbody>
                <?php $index = 0;
                $grand_total = 0;
                while ($dn = dbFetchAssoc($payment_results)): $index++;
                    $grand_total = $grand_total + $dn['amount_deposited'];
                    $vendor = getVendor($dn['vendor_id']);
                    $clerk = getUser($dn['received_by']);
                    $pay_option = getPaymentSettings($dn['payment_method']);
                    ?>
                    <tr>
                        <td>
                            <?php echo $index; ?>
                        </td>
                        <td>
                            <?php echo $dn['ref_no'] ?></td>
                        <td>
                            <?php
                            if ($dn['vendor_id'] != 0) {
                                echo $vendor['name'];
                            } else {
                                echo $dn['other_vendor'];
                            }
                            ?>
                            <?php if ($dn['remark'] != "") { ?>
                                <p class="small"><?php echo truncateContent(htmlspecialchars_decode($dn['remark']), 40); ?></p>
                            <?php } ?>
                        </td>
                        <td>
                            <?php echo $pay_option['mode_name']; ?>
                        </td>
                        <td>
                            <?php echo number_format($dn['amount_deposited'], 2); ?>
                        </td>
                        <td>
                            <?php echo $clerk['firstname'] . ' ' . $clerk['lastname']; ?>
                        </td>
                        <td>
                            <?php echo $dn['deposite_date']; ?>
                        </td>
                        <td>
                            <?php echo $dn['entry_date']; ?>
                        </td>
                        <td>
                            <div class="btn-group btn-group-sm">
                                <a href="#"
                                   onclick="javascript:getVendorPaymentInfo(<?php echo $dn['id']; ?>);"
                                   class="btn btn-primary" title="View Receipt" data-toggle="tooltip"><i
                                            class="fal fa-file"></i></a>
                                <?php if (@$access['edit_vendor_payment'] == 1) { ?>
                                    <a class="btn btn-primary btn-sm"
                                       href="?p=new-vendor-payment&edit=<?php echo $dn['id'] ?>" title=" Edit Record"
                                       data-toggle="tooltip"><i class="fal fa-edit"></i></a>
                                <?php }
                                if (@$access['delete_vendor_payment'] == 1) { ?>
                                    <a href="#" class="btn btn-primary"
                                       onClick="javascript:confirmRequest('<?php echo $dn['id'] . 'payment'; ?>', <?php echo $dn['id']; ?>, 'Are you sure you want to delete this record?', 'delete-payment');"
                                       title="Delete Record" data-toggle="tooltip"><i class="fal fa-trash"></i></a>
                                <?php } ?>
                            </div>
                        </td>
                    </tr>
                <?php endwhile ?>
                </tbody>
                <tfoot>
                <th colspan="4" style="text-align: right">Grand Total</th>
                <th colspan="5">
                    <?php echo number_format($grand_total, 2); ?>
                </th>
                </tfoot>
            </table>
        </div>
    </div>
    <!--Main content-->
</div>
