<?php
if (isset($_GET['print-request']) && $_GET['query'] != ""):
    if (file_exists("../../../../helpers/config/config.inc.php")):
        require "../../../../helpers/config/config.inc.php";
    endif;
    require "../../../../helpers/handlers/app_autoloader.php";
    require '../../../../helpers/handlers/classes/BIZConfig.php';
    require "../Module_Class.php";
    $module = new Module_Class;
    $biz = new BIZConfig();
    $app = new SMBEngine();
    $sql = base64_decode($_GET['query']);
    if (isset($_GET['params']) && $_GET['params'] != NULL) {
        extract(json_decode($_GET['params'], true));
    }
    $printing = 1;
    echo '<link rel="stylesheet" href="' . $app->vendors . 'bootstrap/css/bootstrap.min.css">';
//echo '<link rel="stylesheet" href="' . $app->assets . 'css/dashboard.css">';

else:
    $store = "";
    if (isset($auth['store_id']) && $auth['store_id'] != ""):
        $store = " AND store_id = '" . $auth['store_id'] . "' ";
    endif;
//------------------------------------------------------------------------------------
    $default = " delete_status = '0' " . $store;
    $condition = @$default;
//------------------------------------------------------------------------------------
    if (isset($_POST['filterRequest']) && $_POST['filterRequest'] !== NULL):
        $filterParam = $_POST['filterRequest'];
        if ($filterParam['search'] != ""):
            $condition = "";
            $search_query = trim($filterParam['search']);
            $condition = $default . " AND app_id LIKE '%" . $search_query . "%'";
            $condition .= "OR " . $default . " AND customer_id LIKE '%" . $search_query . "%' ";
            $condition .= "OR " . $default . " AND customer_name LIKE '%" . $search_query . "%' ";
            $condition .= "OR " . $default . " AND customer_type LIKE '%" . $search_query . "%' ";
            $condition .= "OR " . $default . " AND contact_name LIKE '%" . $search_query . "%' ";
            $condition .= "OR " . $default . " AND contact_phone LIKE '%" . $search_query . "%' ";
            $condition .= "OR " . $default . " AND contact_email LIKE '%" . $search_query . "%' ";
            $condition .= "OR " . $default . " AND contact_fax LIKE '%" . $search_query . "%' ";
            $condition .= "OR " . $default . " AND website_address LIKE '%" . $search_query . "%' ";
            $condition .= "OR " . $default . " AND store_id LIKE '%" . $search_query . "%' ";
            $condition .= "OR " . $default . " AND address_1 LIKE '%" . $search_query . "%' ";
            $condition .= "OR " . $default . " AND created_by LIKE '%" . $search_query . "%' ";
        else:
            @$store_id = @$filterParam['store_id'];
            @$type = @$filterParam['customer_type'];
            @$active_status = @$filterParam['active_status'];
            @$start_date = @$filterParam['start_date'];
            @$end_date = @$filterParam['end_date'];
            if ($store_id != "" || $type != "" || $active_status != ""):
                $condition = "";
            endif;
            if (@$store_id != ""):
                $condition .= $default . " AND store_id = '$store_id'";
            endif;
            if (@$type != ""):
                $condition .= $default . " AND customer_type = '$type'";
            endif;
            if (@$active_status != ""):
                $condition .= $default . " AND active_status = '$active_status'";
            endif;
            if (@$start_date != "" && $end_date != ""):
                $date_tx = " AND transact_date BETWEEN '" . $start_date . "' AND DATE_ADD('$end_date', INTERVAL 1 DAY)";
                $date_px = " AND received_date BETWEEN '" . $start_date . "' AND DATE_ADD('$end_date', INTERVAL 1 DAY)";
            endif;
        endif;
    endif;
    $owner = explode('o/', @$subview);
    if (isset($owner[1]) && @$owner[1] != ""):
        @$owner_id = trim(@$owner[1], '/');
        $condition = $default . " AND app_vehicles.ownership = '$owner_id'";
    endif;
//------------------------------------------------------------------------------------
    @$paginate_exp = explode('?page=', @$url);
    if (isset($paginate_exp[1]) && $paginate_exp[1] != ""):
        $ipp_exp = explode('&ipp=', $paginate_exp[1]);
        if (isset($ipp_exp[0]) && $ipp_exp[0] != ""):
            define('page', $ipp_exp[0]);
        else:
        endif;
        if (isset($ipp_exp[1]) && $ipp_exp[1] != ""):
            define('ipp', $ipp_exp[1]);
        else:
        endif;
    else:
        define('page', '');
        define('ipp', '');
    endif;
    define('self', '#/' . @$req . @$view);
    $pages = new Paginator_Class;
    if (ipp != ""):
        $pages->default_ipp = ipp;
    else:
        $pages->default_ipp = 2;
    endif;
    $sql_forms = Data_Access::execSQL("SELECT app_customers.app_id FROM app_customers WHERE  " . $condition . "");
    @$pages->items_total = $sql_forms['dataArray']->num_rows;
    $pages->mid_range = 4;
    $pages->paginate();
    $sql = "SELECT * FROM app_customers WHERE  " . $condition . " ORDER BY app_customers.customer_name, app_customers.created_on ASC " . $pages->limit . " ";
endif;
if (!($result = Data_Access::execSQL($sql))) {
    die(mysqli_error());
} else {
    @$recordsArray = Data_Access::fetchAssoc($result['dataArray'])['dataArray'];
}
?>

<?php if (@$printing != 1): ?>
    <div id="ModuleResponse"></div>
    <div class="row mb-3">
        <div class="col-12">
            <ul class="nav ml-auto modules-menu">
                <li class="nav-item">
                    <a href="javascript:void(0);" class="nav-link app-link"
                       onclick="printDataTable({query:'<?php echo base64_encode($sql); ?>',dataTable:'manage-customers/inc/customers_list.php',params:{view:'accounts/'}})">
                        <i class="fal fa-print"></i> Print Records</a>
                </li>
                <li class="nav-item app-collapse  ml-auto">
                    <div class="form-group mb-1">
                        <div class="input-group input-group-sm">
                            <input type="search" class="form-control form-control-sm border-right-0" name="search"
                                   placeholder="Search keyword..."
                                   style="border-radius: 0;" form="vehicle-filter">
                            <div class="btn-group">
                                <button class="btn mr-2 btn-default btn-sm pr-2" form="vehicle-filter"
                                        style="height: 31px" type="button"
                                        onclick="javascript:$('#appFilterBtn').click();">
                                    <i class="fal fa-search m-0" style="font-size: 0.70rem;"></i>
                                </button>
                                <a class="nav-link dropdown-toggle" data-toggle="collapse"
                                   href="#collapseSalesFilter"
                                   aria-expanded="false" aria-controls="collapseSalesFilter">
                                    <i class="fal fa-filter"></i> Advance Filter<span class="caret"></span>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="collapse collapse-container right" id="collapseSalesFilter">
                        <div class="card-body elevation-1 bg-light left p-3">
                            <form method="post" action="#" id="vehicle-filter">
                                <?php if ($auth['store_id'] === ""): ?>
                                    <div class="form-group">
                                        <label for="">Registered Location</label>
                                        <select name="store_id"
                                                class="form-control form-control-sm select2"
                                                id="store_id"
                                                tabindex="7" style="width: 100%">
                                            <option value="">-- Registered Location --</option>
                                            <?php
                                            $storeParam = array("tbl_scheme" => 'app_stores', "condition" => ["active_status" => 1]);
                                            $listArray = $module->getRecord($storeParam);
                                            $dropDownArray = array();
                                            foreach ($listArray['dataArray'] as $store):
                                                echo $app->dropDownList($store['app_id'], $store['store_name'], '');
                                            endforeach; ?>
                                        </select>
                                    </div>
                                <?php endif; ?>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group mb-0">
                                            <label for="" class="w-100">Type</label>
                                            <select name="customer_type"
                                                    class="form-control form-control-sm select2"
                                                    style="width:100%">
                                                <option value="">-- Select --</option>
                                                <?php
                                                $listArray = array("Individual" => 'Individual', "Organization" => 'Organization', "Internal" => 'Internal');
                                                foreach ($listArray as $fleet => $label):
                                                    echo $app->dropDownList($fleet, $label, '');
                                                endforeach; ?>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group mb-0">
                                            <label for="" class="w-100">Active Status</label>
                                            <select name="active_status"
                                                    class="form-control form-control-sm select2"
                                                    style="width:100%">
                                                <option value="">-- Select --</option>
                                                <?php
                                                $listArray = array("Active" => "1", "Inactive" => "0");
                                                foreach ($listArray as $status => $label):
                                                    echo $app->dropDownList($label, $status, '');
                                                endforeach; ?>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <?php if (@$view === "accounts/"): ?>
                                    <div class="row">
                                        <div class="col-6">
                                            <div class="form-group mb-0 mt-2">
                                                <label for="">Start Date</label>
                                                <input type="text" name="start_date"
                                                       class="form-control form-control-sm datepicker"
                                                       placeholder="Start Date">
                                            </div>
                                        </div>
                                        <div class="col-6">
                                            <div class="form-group mb-0 mt-2">
                                                <label for="">End Date</label>
                                                <input type="text" name="end_date"
                                                       class="form-control form-control-sm datepicker"
                                                       placeholder="End Date">
                                            </div>
                                        </div>
                                    </div>
                                <?php endif; ?>
                                <hr class="my-3">
                                <button class="btn btn-default btn-sm btn-block" id="appFilterBtn">
                                    <i class="fal fa-check-circle"></i>
                                    Submit
                                </button>
                                <input type="hidden" readonly name="view" value="/#/<?php echo @$req . @$view; ?>">
                            </form>
                        </div>
                    </div>
                </li>

            </ul>
        </div>
    </div>
    <div class="row marginTop mx-0">
        <div class="col-12 pl-0 paddingLeft pagerfwt">
            <?php if ($pages->items_total > 0) { ?>
                <?php echo $pages->display_pages(); ?>
                <?php echo $pages->display_items_per_page(); ?>
                <?php echo $pages->display_jump_menu(); ?>
            <?php } ?>
        </div>
        <div class="clearfix"></div>
        <hr>
    </div>
<?php else: ?>
    <h5>Customers <?php if (@$view === "accounts/"): echo 'Account Balance'; else: echo "Records"; endif; ?></h5>
<?php endif; ?>
    <div class="table-responsive">
        <table class="table data-tables  table-sm elevation-1">
            <?php if (@$filterParam != NULL): ?>
                <caption>View filtered record [ <a class="small text-muted" href="javascript:void(0);"
                                                   onclick="fetchURL('');">Reset Filter </a>]
                </caption>
            <?php else: ?>
                <caption>View all customers record(s)</caption>
            <?php endif; ?>
            <thead>
            <tr>
                <th>Customer ID</th>
                <th>Customer Name</th>
                <?php if (@$view === "accounts/"): ?>
                    <th>Total Purchases <?php echo $biz->currency['currency']; ?></th>
                    <th>Paid Purchases <?php echo $biz->currency['currency']; ?></th>
                    <th>Credit Balance <?php echo $biz->currency['currency']; ?></th>
                <?php else: ?>
                    <th>Contact Number</th>
                    <th>Customer Type</th>
                    <th>Registered Store</th>
                <?php endif; ?>
                <th>Active Status</th>
                <?php if (@$printing != 1): ?>
                    <th><i class="fal fa-cogs"></i></th>
                <?php endif; ?>
            </tr>
            </thead>
            <tbody class="card-body">
            <?php
            if (isset($recordsArray) && $recordsArray != NULL):
                $total_purchase = 0;
                $total_payment = 0;
                $total_credit = 0;
                foreach (@$recordsArray as $user): extract($user);
                    if (@$view === "accounts/"):
                        @$purchases = Data_Access::fetchAssoc(Data_Access::execSQL("SELECT SUM(app_transactions.subtotal) as purchases FROM app_transactions WHERE customer_id = '" . $app_id . "' " . @$date_tx . " ")['dataArray'])['dataArray'][0];
                        @$payments = Data_Access::fetchAssoc(Data_Access::execSQL("SELECT SUM(app_payments.amount_tendered) as payments FROM app_payments WHERE customer_id = '" . $app_id . "' " . @$date_px . " ")['dataArray'])['dataArray'][0];
                        @$credits = @$purchases['purchases'] - @$payments['payments'];
                        @$total_purchase = @$total_purchase + @$purchases['purchases'];
                        @$total_payment = @$total_payment + @$payments['payments'];
                        @$total_credit = @$total_credit + @$credits;
                    else:
                        @$store = $module->getRecord(["tbl_scheme" => 'app_stores', "condition" => ["app_id" => @$store_id]])['dataArray'][0]['store_name'];
                    endif;
                    ?>
                    <tr>
                        <td><?php echo @$customer_id; ?></td>
                        <td><?php echo trim(@$customer_name); ?></td>
                        <?php if (@$view === "accounts/"): ?>
                            <td><?php echo @number_format(@$purchases['purchases'], 2); ?></td>
                            <td><?php echo @number_format(@$payments['payments'], 2); ?></td>
                            <td><?php echo @number_format(@$credits, 2); ?></td>
                        <?php else: ?>
                            <td><?php echo @$contact_phone; ?></td>
                            <td><?php echo @$customer_type; ?></td>
                            <td><?php echo @$store; ?></td>
                        <?php endif; ?>
                        <td><?php if (@$active_status == 1):echo 'Active'; else:echo 'Inactive'; endif; ?></td>
                        <?php if (@$printing != 1): ?>
                            <td style="width:5%;" class="py-1" nowrap="nowrap">
                                <div class="btn-group-justify btn-group-sm float-right">
                                    <?php if (@$access['access_right'] = 1): ?>
                                        <button class="btn btn-default" href="#"
                                                onclick="location.replace('#/customers/record/<?php echo @$app_id ?>/'); fetchURL('')"
                                                title="Transactions"><i
                                                    class="fal fa-folder-open"></i>
                                        </button>

                                    <?php endif;
                                    if (@$view !== "accounts/"):
                                        if (@$access['edit_user'] = 1): ?>
                                            <button type="button" class="btn btn-default"
                                                    onclick='javascript: var obj = "<?php echo urlencode('"pkField":"app_id","pk":"' . $app_id . '","view":"/#/customers/record/","request":"update"'); ?>"; moduleEditRequest(obj)'
                                                    title=" Edit Record"><i
                                                        class="fal fa-edit"></i>
                                            </button>
                                        <?php endif;
                                        if (@$access['delete_user'] = 1) : ?>
                                            <button type="button" class="btn btn-default"
                                                    onclick='javascript: var obj = "<?php echo urlencode('"className":"Module_Class","functionName":"updateRecord","tbl_scheme":"app_customers","delete_status":1,"pkField":"app_id","pk":"' . $app_id . '","callback":{"type":"self","redirect":""},"notification":{"message":"Are you sure to delete this record?","title":"Delete Warning"}'); ?>";  moduleRequest(obj);'
                                                    title=" Edit Record"><i
                                                        class="fal fa-trash-alt"></i>
                                            </button>
                                        <?php endif;
                                    endif; ?>

                                </div>
                            </td>
                        <?php endif; ?>
                    </tr>
                <?php endforeach; else: ?>
                <tr>
                    <td colspan="7" class="text-center"> No data available in table</td>
                </tr>
            <?php endif;
            ?>
            </tbody>
            <?php if (@$view === "accounts/"): ?>
                <tfoot>
                <tr class="bg-light">
                    <th colspan="2" class="text-right">TOTALS <?php echo $biz->currency['currency']; ?></th>
                    <th><?php echo number_format(@$total_purchase, 2) ?></th>
                    <th><?php echo number_format(@$total_payment, 2) ?></th>
                    <th><?php echo number_format(@$total_credit, 2) ?></th>
                    <th colspan="2"></th>
                </tr>
                </tfoot>
            <?php endif; ?>
        </table>
    </div>
<?php if (@$printing != 1): ?>
    <div class="row marginTop mx-0">
        <div class="col-12 pl-0 paddingLeft pagerfwt">
            <?php if ($pages->items_total > 0) { ?>
                <?php echo $pages->display_pages(); ?>
                <?php echo $pages->display_items_per_page(); ?>
                <?php echo $pages->display_jump_menu(); ?>
            <?php } ?>
        </div>
        <div class="clearfix"></div>
        <hr>
    </div>
<?php else: ?>
    <script>window.print();</script>
<?php endif; ?>