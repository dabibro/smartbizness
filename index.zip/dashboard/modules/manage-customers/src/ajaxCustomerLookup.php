<?php

//--------------------------------------------------------------------
if (file_exists("../../../../helpers/config/config.inc.php")):
    require "../../../../helpers/config/config.inc.php";
endif;
require "../../../../helpers/handlers/app_autoloader.php";
require "../Module_Class.php";
//--------------------------------------------------------------------
$module = new Module_Class;
$search_term = $_GET['term'];
$sql = "SELECT app_customers.app_id, app_customers.customer_name  
        FROM " . $module->dbScheme . ".app_customers WHERE 
        app_customers.active_status = 1 AND app_customers.delete_status = 0 AND app_customers.app_id LIKE '%" . $search_term . "%'
        OR app_customers.active_status = 1 AND app_customers.delete_status = 0 AND app_customers.customer_type LIKE '%" . $search_term . "%' 
        OR app_customers.active_status = 1 AND app_customers.delete_status = 0  AND app_customers.customer_name LIKE '%" . $search_term . "%'  
        OR app_customers.active_status = 1 AND app_customers.delete_status = 0  AND app_customers.contact_phone LIKE '%" . $search_term . "%'  
        OR app_customers.active_status = 1 AND app_customers.delete_status = 0  AND app_customers.contact_email LIKE '%" . $search_term . "%'  
        ORDER BY app_customers.customer_name ASC LIMIT 25";
$query = $module->exeSQL($sql);
if (@$query['dataArray']->num_rows === 0):
    $data[] = 'No record found';
else:
    foreach ($query['dataArray'] as $field):
        $data[] = '' . $field['app_id'] . ' -> ' . $field['customer_name'];
    endforeach;
endif;
echo json_encode($data);
