<?php
//----------------------------------------------------------------------------------
require "Module_Class.php";
$module = new Module_Class;
$modulePath = @$appSwitcher->modulePath($AppModule);
$req = $AppModuleRequest;
$view = $AppModuleView;
//----------------------------------------------------------------------------------
@$getView = explode('?page', @$url);
if (isset($getView[1]) && $getView[1] != ""):
    @$getView2 = explode('accounts/', @$getView[0]);
    if (isset($getView2[1])) :
        @$view = 'accounts/';
    else:
        $view = "";
    endif;
endif;
@$getRecord = explode('record/', $view);
if (isset($getRecord[1]) && $getRecord[1] != ""):
    @$view = 'record/';
    @$customer_folder = trim($getRecord[1], '/');
endif;
//----------------------------------------------------------------------------------
?>
<input type="hidden" value="<?php echo $modulePath; ?>" id="ModulePath" readonly>
<div class="card card-primary card-outline card-outline-tabs">
    <div class="card-header p-0 border-bottom-0">
        <ul class="nav nav-tabs app-menu" id="manage-vendors-tabs" role="tablist">
            <li class="nav-item">
                <a class="nav-link <?php if ($view == 'record/'): echo 'active'; endif; ?>"
                   href="#/customers/record/" onclick="fetchURL(this.href)"> <i class="fal fa-file-edit"></i>
                    Create/Update
                    Customer</a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php if ($req === 'customers/' && @$view != "record/" && @$view != "accounts/"): echo 'active'; endif; ?>"
                   href="#/customers/" onclick="fetchURL(this.href)"><i class="fal fa-file-user"></i> Customers
                    Records</a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php if ($view == 'accounts/'): echo 'active'; endif; ?>"
                   href="#/customers/accounts/" onclick="fetchURL(this.href)"> <i class="fal fa-money-check"></i>
                    Customers Accounts</a>
            </li>
        </ul>
    </div>
    <div class="card-body">
        <div class="tab-content" id="manage-vendors-tabContent">
            <div class="tab-pane fade <?php if ($req == 'customers/' && @$view != "record/" && @$view != "accounts/"): echo 'active show'; endif; ?>"
                 id="vendors-tab" role="tabpanel" aria-labelledby="tabs-vendors-tabs">
                <?php if ($req == 'customers/' && @$view != "record/" && @$view != "accounts/"): require "inc/customers_list.php";endif; ?>
            </div>
            <div class="tab-pane fade <?php if ($view == 'record/'): echo 'active show'; endif; ?>"
                 id="create-new-tab" role="tabpanel" aria-labelledby="tabs-create-new-tab">
                <?php if ($view == 'record/'): require "inc/customer_record.php"; endif; ?>
            </div>
            <div class="tab-pane fade <?php if ($view == 'accounts/'): echo 'active show'; endif; ?>"
                 id="payment-tab"
                 role="tabpanel" aria-labelledby="tabs-payment-tab">
                <?php if ($view == 'accounts/'): require_once "inc/customers_list.php"; endif; ?>
            </div>
        </div>
    </div>
</div>
<script src="<?php echo $modulePath ?>js.js"></script>