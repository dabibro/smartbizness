<?php

require "Module_Class.php";
$module = new Module_Class;
$modulePath = @$appSwitcher->modulePath($AppModule);
$req = $AppModuleRequest;
$view = $AppModuleView;

@$getView = explode('announcements/', $view);
if (isset($getView[1]) && $getView[1] != "") {
    @$view = 'announcements/';
}

@$getViewAppId = explode('view/', $view);
if (isset($getViewAppId[1]) && $getViewAppId[1] != "") {
    @$view = 'view/';
    @$AppId = trim($getViewAppId[1], '/');
}


?>
<script src="<?php echo $modulePath ?>js.js"></script>
<input type="hidden" value="<?php echo $modulePath; ?>" id="ModulePath" readonly>
<div class="card card-primary card-outline card-outline-tabs" id="app-messaging">
    <div class="card-header p-0 border-bottom-0">
        <ul class="nav nav-tabs app-menu" id="manage-users-tabs" role="tablist">
            <li class="nav-item">
                <a class="nav-link <?php if ($view == 'announcements/'): echo 'active'; endif; ?>"
                   href="#/app-messaging/announcements/" onclick="fetchURL(this.href)"><i class="fal fa-newspaper"></i>
                    Manage
                    Announcements</a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php if ($view == 'sms/'): echo 'active'; endif; ?>"
                   href="#/app-messaging/sms/" onclick="fetchURL(this.href)"><i class="fal fa-sms"></i> SMS
                    Messaging</a>
            </li>
            <li class="nav-item hide">
                <a class="nav-link <?php if ($req == 'create-store/'): echo 'active'; endif; ?>"
                   href="#/create-store/" onclick="fetchURL(this.href)"><i class="fal fa-file-search"></i> Inventory
                    History</a>
            </li>
        </ul>
    </div>
    <div class="card-body">
        <div class="tab-content" id="manage-users-tabContent">
            <div class="tab-pane fade <?php if ($view == 'announcements/'): echo 'active show'; endif; ?>"
                 id="users-tab" role="tabpanel" aria-labelledby="tabs-users-tabs">
                <?php if ($view == 'announcements/'): require "inc/announcements.php";endif; ?>
            </div>
            <div class="tab-pane fade <?php if ($view == 'sms/'): echo 'active show'; endif; ?>"
                 id="create-new-tab" role="tabpanel" aria-labelledby="tabs-create-new-tab">
                <?php if ($view == 'sms/'): require "inc/sms_messaging.php"; endif; ?>

            </div>
        </div>
    </div>
    <!-- /.card -->
</div>

          