<?php
//--------------------------------------------------------------------------------------------------
$store = "";
if (isset($auth['store_id']) && $auth['store_id'] != ""):
    $store = "AND store_id = '" . $auth['store_id'] . "' ";
endif;
//--------------------------------------------------------------------------------------------------
$condition = "";
//--------------------------------------------------------------------------------------------------
if (isset($_POST['filterRequest']) && $_POST['filterRequest'] !== NULL):
    $filterParam = $_POST['filterRequest'];
    if ($filterParam['search'] != "" && @$filterParam['category_type'] == ""):
        $search_query = trim($filterParam['search']);
        $condition = "AND contact_name LIKE '%" . $search_query . "%'";
        $condition .= "OR contact_number LIKE '%" . $search_query . "%' ";
        $condition .= "OR created_by LIKE '%" . $search_query . "%' ";
        $condition .= "OR created_on LIKE '%" . $search_query . "%'";
    elseif (@$filterParam['category_type'] != ""):
        $tbl_scheme = $filterParam['category_type'];

        if ($tbl_scheme === "app_users"):
            if ($filterParam['search'] != ""):
                $search_query = trim($filterParam['search']);
                $condition = "AND CONCAT(firstname,' ',lastname) LIKE '%" . $search_query . "%'";
                $condition .= "OR contact_phone LIKE '%" . $search_query . "%' ";
                $condition .= "OR created_by LIKE '%" . $search_query . "%' ";
                $condition .= "OR created_on LIKE '%" . $search_query . "%'";
            endif;
            $name = "CONCAT(firstname,' ',lastname) as contact_name,";
        elseif ($tbl_scheme === "app_customers"):
            if ($filterParam['search'] != ""):
                $search_query = trim($filterParam['search']);
                $condition = "AND customer_name LIKE '%" . $search_query . "%'";
                $condition .= "OR contact_phone LIKE '%" . $search_query . "%' ";
                $condition .= "OR created_by LIKE '%" . $search_query . "%' ";
                $condition .= "OR created_on LIKE '%" . $search_query . "%'";
            endif;
            $name = "customer_name as contact_name, ";
        elseif ($tbl_scheme === "app_vendors"):
            if ($filterParam['search'] != ""):
                $search_query = trim($filterParam['search']);
                $condition = "AND company_name LIKE '%" . $search_query . "%'";
                $condition .= "OR contact_phone LIKE '%" . $search_query . "%' ";
                $condition .= "OR created_by LIKE '%" . $search_query . "%' ";
                $condition .= "OR created_on LIKE '%" . $search_query . "%'";
            endif;
            $name = "company_name as contact_name, ";
        endif;
        $field = @$name . " contact_phone as contact_number, created_by, created_on";

    endif;
endif;

$paginate_exp = explode('?page=', @$url);
if (isset($paginate_exp[1]) && $paginate_exp[1] != ""):
    $ipp_exp = explode('&ipp=', $paginate_exp[1]);
    if (isset($ipp_exp[0]) && $ipp_exp[0] != ""):
        define('page', $ipp_exp[0]);
    else:
    endif;
    if (isset($ipp_exp[1]) && $ipp_exp[1] != ""):
        define('ipp', $ipp_exp[1]);
    else:
    endif;
else:
    define('page', '');
    define('ipp', '');
endif;
define('self', '#/sales-point/quotations/');
$pages = new Paginator_Class;
if (ipp != ""):
    $pages->default_ipp = ipp;
else:
    $pages->default_ipp = 50;
endif;
if (isset($filterParam) && $filterParam['category_type'] != "") {
    $sql_forms = Data_Access::execSQL("SELECT * FROM " . $app->dbScheme . "." . $tbl_scheme . " WHERE 1 " . $condition . " ");
} else {
    $sql_forms = Data_Access::execSQL("SELECT * FROM " . $app->dbScheme . ".app_quotations WHERE 1 " . $condition . " ");
}
@$pages->items_total = $sql_forms['dataArray']->num_rows;
$pages->mid_range = 4;
$pages->paginate();
if (isset($filterParam) && $filterParam['category_type'] != "") {
    $sql = "SELECT " . $field . " FROM " . $app->dbScheme . "." . $tbl_scheme . " WHERE 1 " . $condition . " ORDER BY created_on DESC " . $pages->limit . " ";
} else {
    $sql = "SELECT * FROM " . $app->dbScheme . ".app_contact_list WHERE 1 " . $condition . " ORDER BY created_on DESC " . $pages->limit . " ";
}
if (!($result = Data_Access::execSQL($sql))) {
    die(mysqli_error());
} else {
    @$recordsArray = Data_Access::fetchAssoc($result['dataArray'])['dataArray'];
}
?>
<div id="ModuleResponse"></div>
<div class="row marginTop mx-0">
    <div class="col-12 pl-0 paddingLeft pagerfwt">
        <?php if ($pages->items_total > 0) { ?>
            <?php echo $pages->display_pages(); ?>
            <?php echo $pages->display_items_per_page(); ?>
            <?php echo $pages->display_jump_menu(); ?>
        <?php } ?>
    </div>
    <div class="clearfix"></div>
    <hr>
</div>
<div class="table-responsive">
    <table class="table data-tables table-sm elevation-1">
        <?php if (@$filterParam != NULL): ?>
            <caption>Currently viewing filtered contact(s) list [ <a href="javascript:void(0);"
                                                                     onclick="loadContacts();"
                                                                     class="small">Reset Filter</a> ]
            </caption>
        <?php else: ?>
            <caption>Viewing unfiltered contact(s) list</caption>
        <?php endif; ?>
        <thead>
        <tr>
            <th>Contact/Group Name</th>
            <th>Contact(s) Numbers</th>
            <th>Created By</th>
            <th><i class="fal fa-cogs"></i></th>
        </tr>
        </thead>
        <tbody class="card-body">
        <?php
        if (isset($recordsArray) && $recordsArray != NULL):
            $cost_total = 0;
            $grand_total = 0;
            $profit_total = 0;
            foreach (@$recordsArray as $contacts): extract($contacts);
                ?>
                <tr>
                    <td><?php echo @trim(@$contact_name); ?></td>
                    <td><?php echo @$contact_number; ?></td>
                    <td style="line-height: 15px;"><?php echo @$created_by; ?>
                        <div class="small text-muted"><?php echo @$created_on; ?></div>
                    </td>
                    <td style="width:5%;" class="py-1" nowrap="nowrap">
                        <div class="btn-group-justify btn-group-sm float-right">
                            <button type="button" class="btn btn-default"
                                    onclick='javascript: contactEdit("<?php echo @$app_id; ?>");'
                                    title=" Edit Record"><i class="fal fa-edit"></i>
                            </button>
                            <button type="button" class="btn btn-default"
                                    onclick='javascript: var obj = "<?php echo urlencode('"className":"Module_Class","functionName":"deleteRecord","tbl_scheme":"app_contact_list","pk":{"app_id":"' . @$app_id . '"},"callback":{"type":"actionEvent","redirect":"loadContacts()"},"notification":{"message":"Are you sure to delete contact/group record?","title":"Delete Warning"}'); ?>";  moduleRequest(obj);'
                                    title=" Edit Record"><i
                                        class="fal fa-trash-alt"></i>
                            </button>
                    </td>
                </tr>
            <?php endforeach; else: ?>
            <tr>
                <td colspan="9" align="center">No data available</td>
            </tr>
        <?php endif; ?>
        </tbody>
    </table>
</div>
<div class="row marginTop mx-0">
    <div class="col-12 pl-0 paddingLeft pagerfwt">
        <?php if ($pages->items_total > 0) { ?>
            <?php echo $pages->display_pages(); ?>
            <?php echo $pages->display_items_per_page(); ?>
            <?php echo $pages->display_jump_menu(); ?>
        <?php } ?>
    </div>
    <div class="clearfix"></div>
    <hr>
</div>
