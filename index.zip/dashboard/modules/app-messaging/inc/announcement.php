<?php
if ( @$modalRequestParam !== null ) :
	extract( @$modalRequestParam );
	@$getRecord = $module->getRecord( [
		"tbl_scheme" => 'app_announcements',
		"condition"  => [ "id" => $rec_id ],
		"limit"      => 1
	] )['dataArray'][0];
	@extract( $getRecord );

	if ( @$viewers === "" || $viewers === "null" ) {
		@$viewer = array( @$auth['user_id'] );
		@$viewers = json_encode( @$viewer );
	} else {
		@$viewerArray = json_decode( htmlspecialchars_decode( @$viewers ), true );
		@array_push( $viewerArray, @$auth['user_id'] );
		@$viewerArray = json_encode( @array_unique( $viewerArray ) );
		@$viewers = ( $viewerArray );
	};

	@$module->updateRecord( [
		"tbl_scheme" => 'app_announcements',
		"pk"         => @$rec_id,
		"pkField"    => 'id',
		"viewers"    => @$viewers,
	] )['dataArray'][0];

endif;
?>

<h6><?php echo $brief_description; ?></h6>
<div class="small text-muted">
    <label class="m-0">Created by: </label> <?php echo @$created_by; ?>| <?php echo @$app->formatDate( $created_on ); ?>
</div>
<hr>
<div>
	<?php echo @htmlspecialchars_decode( $contents ); ?>
</div>
