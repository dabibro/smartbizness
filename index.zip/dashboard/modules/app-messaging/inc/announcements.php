<?php
$store = "";
if ( isset( $auth['store_id'] ) && $auth['store_id'] != "" ):
	$store = " AND app_inventory.store_id = '" . $auth['store_id'] . "' ";
endif;
//------------------------------------------------------------------------------------
//$default      = "app_products.app_id = app_inventory.app_id " . $store;
$default   = "1 ";
$condition = $default;
if ( isset( $_POST['filterRequest'] ) && $_POST['filterRequest'] !== null ):
	$filterParam = $_POST['filterRequest'];
	if ( $filterParam['search'] != "" ):
		$condition    = "";
		$search_query = trim( $filterParam['search'] );
		$condition    = $default . "AND brief_description LIKE '%" . $search_query . "%'";
		$condition    .= "OR " . $default . " AND contents LIKE '%" . $search_query . "%' ";
		$condition    .= "OR " . $default . " AND created_by LIKE '%" . $search_query . "%' ";
		$condition    .= "OR " . $default . " AND created_on LIKE '%" . $search_query . "%' ";
	else:
		$creator    = @$filterParam['created_by'];
		$start_date = @$filterParam['start_date'];
		$end_date   = @$filterParam['end_date'];
		if ( $creator != "" ):
			$condition .= " AND created_by = '$creator'";
		endif;
		if ( $start_date != "" && $end_date != "" ):
			$condition .= " AND created_on BETWEEN '$start_date' AND DATE_ADD('$end_date', INTERVAL 1 DAY)";
		endif;
	endif;
endif;
$paginate_exp = explode( '?page=', $url );
if ( isset( $paginate_exp[1] ) && $paginate_exp[1] != "" ):
	$ipp_exp = explode( '&ipp=', $paginate_exp[1] );
	if ( isset( $ipp_exp[0] ) && $ipp_exp[0] != "" ):
		define( 'page', $ipp_exp[0] );
	else:
	endif;
	if ( isset( $ipp_exp[1] ) && $ipp_exp[1] != "" ):
		define( 'ipp', $ipp_exp[1] );
	else:
	endif;
else:
	define( 'page', '' );
	define( 'ipp', '' );
endif;
define( 'self', '#/app-messaging/announcements/' );
$pages = new Paginator_Class;
if ( ipp != "" ):
	$pages->default_ipp = ipp;
else:
	$pages->default_ipp = 10;
endif;
$sql_forms = Data_Access::execSQL( "SELECT * FROM " . $app->dbScheme . ".app_announcements WHERE " . $condition . " " );
@$pages->items_total = $sql_forms['dataArray']->num_rows;
$pages->mid_range = 4;
$pages->paginate();

$sql = "SELECT * FROM " . $app->dbScheme . ".app_announcements WHERE  " . $condition . " ORDER BY created_on DESC" . $pages->limit . " ";
if ( ! ( $result = Data_Access::execSQL( $sql ) ) ) {
	die( mysqli_error() );
} else {
	@$recordsArray = Data_Access::fetchAssoc( $result['dataArray'] )['dataArray'];
}
//--------------------------------------------------------------------------------------
if ( @$requestMethodArray['request'] == "update" && @$requestMethodArray['pk'] != "" && @$requestMethodArray['pkField'] != "" ):
	$pk             = $requestMethodArray['pk'];
	$pkField        = $requestMethodArray['pkField'];
	$getUpdateArray = array(
		"tbl_scheme" => 'app_announcements',
		"condition"  => [ $pkField => $pk ],
		"limit"      => 1
	);
	$getUpdate      = $module->getRecord( $getUpdateArray );
	$ann            = ( $getUpdate['dataArray'][0] );
endif;
//--------------------------------------------------------------------------------------
?>
<style>
    .note-editable {
        height: 180px !important;
    }

    .note-editor {
        margin-bottom: 0;
    }
</style>
<div class="row">
    <div class="col-5">
        <form method="post" class="AppForm" id="announcement-form">
            <div id="ModuleResponse"></div>
            <div class="form-group">
                <label for=""><span class="required">*</span> Description/Title</label>
                <input type="text" name="brief_description" class="form-control form-control-sm"
                       placeholder="Description/Title"
                       value="<?php echo @$ann['brief_description']; ?>" required>
                <div class="invalid-feedback">* This field is required</div>
            </div>
            <div class="form-group">
                <textarea class="text-editor"
                          name="contents" required><?php echo @$ann['contents']; ?></textarea>
            </div>
            <div class="form-group mb-3">
                <div class="custom-control custom-switch">
                    <input type="checkbox" <?php if ( @$ann['active_status'] == 1 ): echo 'checked';endif; ?>
                           class="custom-control-input propToggle" id="active_status">
                    <label class="custom-control-label" for="active_status"> Published</label>
                    <input type="hidden" readonly name="active_status"
                           class="active_status"
                           value="<?php if ( @$ann['active_status'] == 1 ): echo 1; else: echo 0;endif; ?>">
                </div>
            </div>

            <hr class="my-3">
            <input type="hidden" name="className" value="Module_Class" readonly>
			<?php if ( @$getUpdate['response'] === "200" ): ?>
                <input type="hidden" name="functionName" value="updateRecord" readonly>
                <input type="hidden" name="pk" value="<?php echo @$pk; ?>" readonly>
                <input type="hidden" name="pkField" value="<?php echo @$pkField; ?>" readonly>
			<?php else:$uArr = htmlspecialchars( json_encode( array( $auth['user_id'] ) ) ); ?>
                <input type="hidden" name="functionName" value="createRecord" readonly>
                <input type="hidden" name="viewers" value="<?php echo $uArr; ?>" readonly>
			<?php endif; ?>
            <input type="hidden" name="callback[type]" value="self" readonly>
            <input type="hidden" name="callback[redirect]" value="" readonly>
            <input type="hidden" name="tbl_scheme" value="app_announcements" readonly>
            <input type="hidden" name="created_by"
                   value="<?php echo trim( @$auth['firstname'] . ' ' . @$auth['lastname'] ); ?>" readonly>
            <button type="submit" class="btn btn-sm btn-default" data-toogle="tooltip"
                    title="Save Note (ALT+S)"><i class="fal fa-check-circle"></i> Submit
            </button>
			<?php if ( @$getUpdate['response'] === "200" ): ?>
                <button type="button" name="button" class="btn btn-sm btn-danger  pl-3 pr-3"
                        onclick="fetchURL('')"><i class="fal fa-times"></i> Cancel Edit
                </button>
			<?php endif; ?>
        </form>
    </div>
    <div class="col-7">
        <ul class="nav ml-auto modules-menu mb-2">
            <li class="nav-item  ml-auto app-collapse">
                <div class="form-group mb-1">
                    <div class="input-group input-group-sm">
                        <input type="search" class="form-control form-control-sm border-right-0" name="search"
                               placeholder="Search keyword..."
                               style="border-radius: 0;" form="announcement-filter">
                        <div class="btn-group">
                            <button class="btn mr-2 btn-default btn-sm pr-2" form="announcement-filter"
                                    style="height: 31px" type="button"
                                    onclick="javascript:$('#appFilterBtn').click();">
                                <i
                                        class="fal fa-search m-0"
                                        style="font-size: 0.70rem;"></i>
                            </button>
                            <a class="nav-link dropdown-toggle" data-toggle="collapse"
                               href="#collapseSalesFilter"
                               aria-expanded="false" aria-controls="collapseSalesFilter">
                                <i class="fal fa-filter"></i> Advance Filter<span class="caret"></span>
                            </a>
                        </div>
                    </div>
                </div>
                <div class="collapse collapse-container right" id="collapseSalesFilter">
                    <div class="card-body elevation-1 bg-light left p-3">
                        <form method="post" action="#" id="announcement-filter">
                            <div class="form-group">
                                <label for="">Creator Name</label>
                                <select name="created_by"
                                        class="form-control form-control-sm select2">
                                    <option value="">-- Select --</option>
									<?php
									$cashiersArray = $module->getRecord( [
										"tbl_scheme" => 'app_users',
										"condition"  => [ 'delete_status' => 0 ]
									] );
									foreach ( $cashiersArray['dataArray'] as $cashiers ):
										echo $app->dropDownList( $cashiers['firstname'] . ' ' . $cashiers['lastname'], '' );
									endforeach; ?>
                                </select>
                            </div>
                            <label for="" class="small text-muted">Transaction Date Range</label>
                            <div class="row">
                                <div class="col-6">
                                    <div class="form-group mb-0">
                                        <label for="">Start Date</label>
                                        <input type="text" name="start_date"
                                               class="form-control form-control-sm datepicker"
                                               placeholder="Start Date">
                                    </div>
                                </div>
                                <div class="col-6">
                                    <div class="form-group mb-0">
                                        <label for="">End Date</label>
                                        <input type="text" name="end_date"
                                               class="form-control form-control-sm datepicker"
                                               placeholder="End Date">
                                    </div>
                                </div>
                            </div>
                            <input type="hidden" readonly name="delete_status" value="0">
                            <hr class="my-3">
                            <button class="btn btn-default btn-sm btn-block" id="appFilterBtn">
                                <i class="fal fa-check-circle"></i>
                                Submit
                            </button>
                            <input type="hidden" readonly name="view"
                                   value="/#/app-messaging/announcements/">
                        </form>
                    </div>
                </div>
            </li>
        </ul>
        <div class="row marginTop mx-0">
            <div class="col-12 pl-0 paddingLeft pagerfwt">
				<?php if ( $pages->items_total > 0 ) { ?>
					<?php echo $pages->display_pages(); ?>
					<?php echo $pages->display_items_per_page(); ?>
					<?php echo $pages->display_jump_menu(); ?>
				<?php } ?>
            </div>
            <div class="clearfix"></div>
            <hr>
        </div>
        <div class="table-responsive">
            <table class="table data-tables table-sm elevation-1">
				<?php if ( @$filterParam != null ): ?>
                    <caption>Currently viewing filter record(s) [ <a href="javascript:void(0);" onclick="fetchURL('');"
                                                                     class="small">Reset Filter</a> ]
                    </caption>
				<?php else: ?>
                    <caption>Current viewing all record(s)</caption>
				<?php endif; ?>
                <thead>
                <tr>
                    <th>Title/Description</th>
                    <th>Status</th>
                    <th>Created By</th>
                    <th>Created On</th>
                    <th><i class="fal fa-cogs"></i></th>
                </tr>
                </thead>
                <tbody class="card-body">
				<?php
				if ( isset( $recordsArray ) && $recordsArray != null ):
					foreach ( @$recordsArray as $announ ): extract( $announ );
						?>
                        <tr>
                            <td><?php echo @trim( @$brief_description ); ?></td>
                            <td><?php if ( @$active_status == 1 ):echo 'Published'; else:echo 'Drafted'; endif; ?></td>
                            <td><?php echo @trim( @$created_by ); ?></td>
                            <td><?php echo @trim( @$app->formatDate( $created_on ) ); ?></td>
                            <td style="width:5%;" class="py-1" nowrap="nowrap">
                                <div class="btn-group-justify btn-group-sm float-right">
                                    <button type="button" class="btn btn-default"
                                            onclick="AppModalLoader({modalId:'ModuleModal', modalSize:'modal-lg', modalTitle:'Announcement', required:'inc/announcement', modalRequest:{rec_id:'<?php echo $id; ?>'}, afterEvent:''});"
                                            title="View"><i
                                                class="fal fa-newspaper"></i>
                                    </button>
                                    <button type="button" class="btn btn-default"
                                            onclick='javascript: var obj = "<?php echo urlencode( '"pkField":"id","pk":"' . $id . '","view":"/#/app-messaging/announcements/","request":"update"' ); ?>"; moduleEditRequest(obj)'
                                            title=" Edit Record"><i
                                                class="fal fa-edit"></i>
                                    </button>
                                    <button type="button" class="btn btn-default"
                                            onclick='javascript: var obj = "<?php echo urlencode( '"className":"Module_Class","functionName":"deleteRecord","tbl_scheme":"app_announcements","pk":{"id":"' . $id . '"},"callback":{"type":"self","redirect":""},"notification":{"message":"Are you sure to delete announcement record?","title":"Delete Warning"}' ); ?>";  moduleRequest(obj);'
                                            title=" Edit Record"><i
                                                class="fal fa-trash-alt"></i>
                                    </button>
                            </td>
                        </tr>
					<?php endforeach; else: ?>
                    <tr>
                        <td colspan="9" align="center">No data available</td>
                    </tr>
				<?php endif; ?>
                </tbody>
            </table>
        </div>
        <div class="row marginTop mx-0">
            <div class="col-12 pl-0 paddingLeft pagerfwt">
				<?php if ( $pages->items_total > 0 ) { ?>
					<?php echo $pages->display_pages(); ?>
					<?php echo $pages->display_items_per_page(); ?>
					<?php echo $pages->display_jump_menu(); ?>
				<?php } ?>
            </div>
            <div class="clearfix"></div>
            <hr>
        </div>
    </div>
</div>

