<?php
/**
 * Created by PhpStorm.
 * User: Dauda Ibrahim
 * Date: 8/30/2020
 * Time: 6:22 PM
 */

?>


<script src="<?php echo $modulePath ?>js.js"></script>
<input type="hidden" value="<?php echo $modulePath; ?>" id="ModulePath" readonly>
<div class="card card-primary card-outline card-outline-tabs h-100">
    <div class="card-body">
        <label class="text-muted"><i class="fal fa-bars mr-2"></i> SMS MESSAGING MENU</label>
        <div class="row">
            <div class="col-3 col-sm-2">
                <div class="nav flex-column nav-tabs h-100" id="vert-tabs-tab" role="tablist"
                     aria-orientation="vertical">
                    <a class="nav-link active" id="vert-tabs-send-sms-tab" data-toggle="pill" href="#vert-tabs-send-sms"
                       role="tab" aria-controls="vert-tabs-home" aria-selected="true"><i
                                class="fal fa-envelope"></i> Send SMS
                        <hr class="my-2">
                        <small class="text-muted"> Send to single or multiple contact</small>
                    </a>
                    <a class="nav-link" id="vert-tabs-contact-tab" data-toggle="pill" href="#vert-tabs-contact"
                       role="tab" aria-controls="vert-tabs-contact" aria-selected="false"><i
                                class="fal fa-address-book"></i>
                        Contacts List
                        <hr class="my-2">
                        <small class="text-muted">Manage contact list</small>
                    </a>
                    <a class="nav-link" id="vert-tabs-import-export-tab" data-toggle="pill"
                       href="#vert-tabs-import-export"
                       role="tab" aria-controls="vert-tabs-import-export" aria-selected="false"><i
                                class="fal fa-text"></i> Manage SMS Templates
                        <hr class="my-2">
                        <small class="text-muted">Manage message templates</small>
                    </a>
                    <a class="nav-link" id="vert-tabs-settings-tab" data-toggle="pill" href="#vert-tabs-settings"
                       role="tab" aria-controls="vert-tabs-settings" aria-selected="false"><i
                                class="fal fa-sliders-h-square"></i>
                        SMS API Configuration
                        <hr class="my-2">
                        <small class="text-muted">Configure SMS API/Gateway</small>
                    </a>
                </div>
            </div>
            <div class="col-9 col-sm-10">
                <div class="tab-content" id="vert-tabs-tabContent">
                    <div class="tab-pane text-left fade" id="vert-tabs-send-sms" role="tabpanel"
                         aria-labelledby="vert-tabs-home-tab">
                        <label class="w-100 mb-0"> <i class="fal fa-envelope-open-text"></i> Send SMS
                            <span class="float-right font-weight-light">
                                [ <a href="javascript:void(0);"
                                     onclick="SMSUnits('sms-unit-balance')"> <i class="fal fa-coins"></i> Check Balance </a>]
                                <span class="" id="sms-unit-balance"></span>
                            </span>
                        </label>
                        <hr class="my-2">
                        <form method="post" id="sms-form">
                            <div class="row">
                                <div class="col-6">
                                    <div class="form-group">
                                        <label for="" class="w-100"><span class="required">*</span> Destination
                                            Number(s)
                                            <span class="float-right">
                                                [ <a href="javascript:void(0)"><i class="fal fa-address-card"></i> Select Contacts</a> ]</span></label>
                                        <textarea name="recipient" id="recipient" class="form-control form-control-sm"
                                                  rows="4"
                                                  placeholder="Destination Number(s)" required></textarea>
                                        <small class="text-muted">For multiple destinations, separate number(s) with
                                            comma
                                            (,)
                                        </small>
                                        <div class="invalid-feedback">* Required field: Recipient is empty</div>
                                    </div>
                                    <div class="form-group">
                                        <label for="" class="w-100"><span class="required">*</span> Message Content
                                            <span class="float-right">[ <a
                                                        href="javascript:void(0)"> <i class="fal fa-file-alt"></i> Load Template</a> ]</span></label>
                                        <textarea name="message" id="message" rows="6"
                                                  class="form-control form-control-sm"
                                                  placeholder="Message Content" required></textarea>
                                        <div class="invalid-feedback">* Required field: message is empty</div>

                                    </div>
                                </div>
                                <div class="col-6">
                                    <label class="text-muted mb-0">Message Options</label>
                                    <hr class="my-2">
                                    <div class="row">
                                        <div class="col-8">
                                            <div class="form-group">
                                                <label class="mb-1">Sender ID</label>
                                                <input type="text" name="sender" class="form-control form-control-sm"
                                                       placeholder="Sender ID" maxlength="11">
                                                <small class="text-muted">Sender ID: Max 11 character(s) including
                                                    space.
                                                </small>
                                            </div>
                                            <label for="" class="text-muted mb-1 w-100">Delivery Schedule
                                                <span class="float-right">
                                        <div class="custom-control custom-switch">
                                        <input type="checkbox"
                                               class="custom-control-input propToggle" id="schedule_delivery">
                                        <label class="custom-control-label" for="schedule_delivery"> </label>
                                        <input type="hidden" readonly name="schedule_delivery"
                                               class="schedule_delivery" value="0">
                                    </div>
                                    </span>
                                            </label>
                                            <div class="row">
                                                <div class="col-5 mb-2">
                                                    <input type="text" name="schedule_date"
                                                           class="form-control form-control-sm datepicker"
                                                           placeholder="Schedule Date">
                                                </div>
                                                <div class="col-4">
                                                    <input type="text" name="schedule_time"
                                                           class="form-control form-control-sm timepicker"
                                                           placeholder="Schedule Time">
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-auto">
                                                    <div class="form-group text-left">
                                                        <div class="custom-control custom-switch">
                                                            <input type="checkbox"
                                                                   class="custom-control-input propToggle"
                                                                   id="save_contacts">
                                                            <label class="custom-control-label" for="save_contacts">
                                                                Save
                                                                contacts</label>
                                                            <input type="hidden" readonly name="save_contacts"
                                                                   class="save_contacts" value="0">
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col">
                                                    <input type="text" name="contact_names"
                                                           class="form-control form-control-sm"
                                                           placeholder="Contact Group Name">
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-auto">
                                                    <div class="form-group text-left mb-0">
                                                        <div class="custom-control custom-switch">
                                                            <input type="checkbox"
                                                                   class="custom-control-input propToggle"
                                                                   id="add_template">
                                                            <label class="custom-control-label" for="add_template"> Add
                                                                to
                                                                Template</label>
                                                            <input type="hidden" readonly name="add_template"
                                                                   class="add_template" value="0">
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col">
                                                    <input type="text" name="template_name"
                                                           class="form-control form-control-sm"
                                                           placeholder="Template Name">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <hr class="my-2">
                                    <button class="btn btn-default btn-sm actionButton"><i
                                                class="fal fa-paper-plane"></i> Send SMS
                                    </button>
                                    <button class="btn btn-default btn-sm"><i class="fal fa-save"></i> Draft SMS
                                    </button>
                                    <div id="SMSResponse" class="pt-2"></div>
                                </div>
                            </div>
                            <input type="hidden" name="SendSMSForm">
                        </form>
                    </div>
                    <div class="tab-pane fade  show active" id="vert-tabs-contact" role="tabpanel"
                         aria-labelledby="vert-tabs-contact-tab">
                        <label class="text-muted mb-0"><i class="fal fa-address-book"></i> Contact List</label>
                        <hr class="my-2">
                        <div class="row">
                            <div class="col-lg-4">
                                <div class="card card-light elevation-2">
                                    <div class="card-header px-2 pb-1">
                                        <i class="fal fa-user-edit"></i> Contact
                                    </div>
                                    <div class="card-body p-2">
                                        <form method="post" id="contact-form">
                                            <div id="contactResponse"></div>
                                            <div class="form-group">
                                                <label class="mb-1"><span class="required">*</span> Contact/Group
                                                    Name</label>
                                                <input type="text" name="contact_name" id="contact_name"
                                                       class="form-control form-control-sm"
                                                       placeholder="Contact/Group Name" required>
                                                <div class="invalid-feedback">* Required field: contact/group name is
                                                    empty
                                                </div>
                                            </div>
                                            <div class="form-group mb-0">
                                                <label for="" class="w-100 mb-1"><span class="required">*</span> Contact
                                                    Number(s)</label>
                                                <textarea name="contact_number" id="contact_number"
                                                          class="form-control form-control-sm"
                                                          rows="4"
                                                          placeholder="Destination Number(s)" required></textarea>
                                                <small class="text-muted">For multiple destinations, separate number(s)
                                                    with
                                                    comma
                                                    (,)
                                                </small>
                                                <div class="invalid-feedback">* Required field: contact number(s) is
                                                    empty
                                                </div>
                                            </div>
                                            <hr class="my-2">
                                            <button class="btn btn-default btn-sm contactButton"><i
                                                        class="fal fa-save"></i> Save Contact
                                            </button>
                                            <input type="hidden" name="SaveContact" id="SaveContact" value="1">
                                            <input type="hidden" name="created_by"
                                                   value="<?php echo trim(@$auth['firstname'] . ' ' . @$auth['lastname']); ?>">
                                            <input type="hidden" name="app_id" id="app_id"
                                                   value="<?php echo $app->generateAppId('', '', '8', 'ABCDEFGH0123456789') ?>">
                                        </form>
                                    </div>
                                </div>
                            </div>
                            <div class="col-8">
                                <div class="row">
                                    <div class="col-lg-8 ml-auto">
                                        <form method="post" action="#" id="contact-filter">
                                            <div class="form-group mb-1">
                                                <div class="input-group input-group-sm">
                                                    <input type="search"
                                                           class="form-control form-control-sm border-right-0 mr-1"
                                                           name="search"
                                                           placeholder="Search keyword..."
                                                           style="border-radius: 0;">
                                                    <select name="category_type"
                                                            class="form-control form-control-sm select2">
                                                        <option value="">-- Contact Type --</option>
                                                        <?php
                                                        $cateArray = ["app_users" => "System Users", "app_customers" => "Customers Contact", "app_vendors" => "Vendors/Suppliers"];
                                                        foreach ($cateArray as $cattype => $label):
                                                            echo $app->dropDownList($cattype, $label, '');
                                                        endforeach; ?>
                                                    </select>
                                                    <div class="btn-group">
                                                        <button class="btn mr-2 btn-default btn-sm pr-2"
                                                                form="contact-filter" id="contactFilterBtn"
                                                                style="height: 31px" type="submit">
                                                            <i
                                                                    class="fal fa-search m-0"
                                                                    style="font-size: 0.70rem;"></i>
                                                        </button>
                                                    </div>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                                <div id="contact-list">
                                    <?php require 'contact_list.php'; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane fade" id="vert-tabs-import-export" role="tabpanel"
                         aria-labelledby="vert-tabs-import-export-tab">

                        <h4 class="text-muted">Import/Export Data(CSV)</h4>
                        <hr>
                        <blockquote class="border-light elevation-1 small mx-0"><i class="fal fa-info-circle"></i>
                            Import and Export feature is very useful for the data management section. The Import
                            functionality allows the user to upload and insert multiple data in the database. Using the
                            Import feature, the bulk data can be inserted in the database on a single click. The export
                            functionality allows the user to download the table data list and save in a file for offline
                            use. Using the Export feature, multiple records can be downloaded in a file format.
                        </blockquote>
                        <ul class="nav nav-pills ml-auto mb-3 p-2 modules-menu">
                            <li class="nav-item"><a class="nav-link" href="#tab_1" data-toggle="tab"><i
                                            class="fal fa-upload"></i> Import
                                    Data</a></li>
                            <li class="nav-item"><a class="nav-link" href="#tab_2" data-toggle="tab"><i
                                            class="fal fa-download"></i> Export Data</a>
                            </li>
                            <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle" data-toggle="dropdown" href="#">
                                    <i class="fal fa-cogs"></i> Options <span class="caret"></span>
                                </a>
                                <div class="dropdown-menu">
                                    <a class="dropdown-item" tabindex="-1" href="#">Action</a>
                                    <a class="dropdown-item" tabindex="-1" href="#">Another action</a>
                                    <a class="dropdown-item" tabindex="-1" href="#">Something else here</a>
                                    <div class="dropdown-divider"></div>
                                    <a class="dropdown-item" tabindex="-1" href="#">Separated link</a>
                                </div>
                            </li>

                        </ul>

                        <div class="position-relative">
                            <form class="import-data-from" id="app-data-import-form" enctype="multipart/form-data">
                                <div id="data-import-response"></div>
                                <div class="row">
                                    <div class="col-5 col-sm-4">
                                        <div class="card card-light">
                                            <div class="card-header p-2">
                                                <label for="" class="mb-0">Import CSV file</label>
                                            </div>
                                            <div class="card-body py-2 px-3 pb-3">
                                                <div class="row">
                                                    <div class="col-12">
                                                        <label for="">
                                                            <span class="required">*</span> Table
                                                        </label>
                                                    </div>
                                                    <div class="col-12">
                                                        <div class="form-group">
                                                            <select name="tbl_scheme" id="" required
                                                                    class="form-control form-control-sm select2">
                                                                <option value="">-- Select Table --</option>
                                                                <option value="app_products" selected>Inventory</option>
                                                            </select>
                                                            <div class="invalid-feedback">* Select table scheme</div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-12">
                                                        <label for="">
                                                            <span class="required">*</span> Store
                                                        </label>
                                                    </div>
                                                    <div class="col-12">
                                                        <div class="form-group">
                                                            <select name="store_id"
                                                                    class="form-control form-control-sm select2"
                                                                    id="store" required>
                                                                <option value="">-- Select Store --</option>
                                                                <?php
                                                                $storeParam = array("tbl_scheme" => 'app_stores', "condition" => ["active_status" => 1]);
                                                                $listArray = $module->getRecord($storeParam);
                                                                $dropDownArray = array();
                                                                foreach ($listArray['dataArray'] as $store):
                                                                    echo $app->dropDownList($store['store_id'], $store['store_name'], 1);
                                                                endforeach; ?>
                                                            </select>
                                                            <div class="invalid-feedback">* Select store</div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-12">
                                                        <label for="">
                                                            <span class="required">*</span> Data File
                                                        </label>
                                                    </div>
                                                    <div class="col-12">
                                                        <div class="form-group" id="import-data-file">
                                                            <div class="custom-file">
                                                                <input type="file" name="import-data-file"
                                                                       class="custom-file-input item-image pointer form-control"
                                                                       id="dataFile" form="app-data-import-form">
                                                                <label class="custom-file-label" for="dataFile">Select
                                                                    csv file</label>
                                                            </div>
                                                            <div class="small required"></div>
                                                            <small class="text-muted">Only supports csv formats</small>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-12">
                                                        <label for="" class="small text-muted">Import Options</label>
                                                        <div class="form-group mr-2">
                                                            <div class="custom-control custom-switch">
                                                                <input type="checkbox"
                                                                       class="custom-control-input propToggle"
                                                                       id="update">
                                                                <label class="custom-control-label small"
                                                                       for="update">
                                                                    Update Records</label>
                                                                <input type="hidden" readonly value="0"
                                                                       name="update-request" class="update"></div>
                                                        </div>
                                                        <div class="form-group">
                                                            <label for=""><span class="required">*</span> Select Primary
                                                                Key</label>
                                                            <select name="primary-key"
                                                                    class="form-control form-control-sm select2">
                                                                <option value="">-- Select --</option>
                                                                <?php
                                                                $sql = "SELECT * FROM  app_products";
                                                                $query = $bizD = Data_Access::execSQL($sql);
                                                                $fieldinfo = mysqli_fetch_fields($query);
                                                                foreach ($fieldinfo as $val): ?>
                                                                    <option value="<?php echo($val->name); ?>"> <?php echo($val->name); ?></option>
                                                                <?php endforeach;
                                                                ?>
                                                            </select>
                                                        </div>
                                                        <div class="form-group mr-2">
                                                            <div class="custom-control custom-switch">
                                                                <input type="checkbox"
                                                                       class="custom-control-input propToggle"
                                                                       id="column-name">
                                                                <label class="custom-control-label small"
                                                                       for="column-name">
                                                                    Columns names in the first row</label>
                                                                <input type="hidden" readonly value="0"
                                                                       name="remove-col-name" class="column-name"></div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <hr class="my-3">
                                                <button class="btn btn-default btn-sm"><i
                                                            class="fal fa-check-circle"></i>
                                                    Import
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-7 col-sm-8">
                                        <label for="" class="text-muted mb-0"><i class="fal fa-history"></i>
                                            Import History </label>
                                        <hr>
                                        <label for="" class="small text-muted w-100">Table Column Mapping <span
                                                    id="import-response" class="float-right required"></span></label>
                                        <div class="row">
                                            <div class="col-3">
                                                <label for="" class="w-100 small"><span class="required">*</span> Table
                                                    field <a
                                                            href="javascript:void(0);" class="float-right"><i
                                                                class="fal fa-question-circle"></i></a></label>
                                                <select name="" id="import-scheme-field"
                                                        class="h-100 form-control form-control-sm text-uppercase"
                                                        multiple
                                                        style="min-height:260px; font-size: 0.68rem !important;">
                                                    <?php
                                                    $sql = "SELECT app_products.sku_barcode,
                                            app_products.name,
                                            app_products.description,
                                            app_products.price,
                                            app_products.sale_price,
                                            app_products.wholesale_price, 
                                            app_products.category_id, 
                                            app_products.subcategory,                                              
                                            app_inventory.store_id, 
                                            app_inventory.storage_id,
                                            app_inventory.stock_qty, 
                                            app_inventory.packaging, 
                                            app_inventory.warning_level, 
                                            app_inventory.expiry_date, 
                                            app_inventory.measure_unit, 
                                            app_inventory.vendor_id,
                                            app_inventory.shipping,
                                            app_inventory.back_order,                                                                                        
                                            app_inventory.active_status                                                                                        
                                            FROM  app_products, app_inventory";
                                                    $query = $bizD = Data_Access::execSQL($sql);
                                                    $fieldinfo = mysqli_fetch_fields($query);
                                                    foreach ($fieldinfo as $val): ?>
                                                        <option id="<?php echo($val->name); ?>"
                                                                value="<?php echo($val->name); ?>"> <?php echo($val->name); ?></option>
                                                    <?php endforeach;
                                                    ?>
                                                </select>
                                            </div>
                                            <div class="col-2">
                                                <label for="" class="small"><span class="required">*</span>
                                                    Column</label>
                                                <select name="" id="import-data-file-column"
                                                        class="h-100 form-control form-control-sm" multiple role="menu"
                                                        style="font-size: 0.68rem !important;">
                                                    <?php
                                                    $strings = str_split("ABCDEFGHIJKLMNOPQRSTUVWXYZ");
                                                    foreach ($strings as $str):
                                                        echo '<option id="' . $str . '" value="' . $str . '">' . $str . '</option>';
                                                    endforeach;
                                                    ?>
                                                </select>
                                            </div>
                                            <div class="col-1 pt-5">
                                                <button class="btn btn-default btn-sm pr-2 mb-3 mt-5"
                                                        app-import-button="select">
                                                    <i
                                                            class="fal fa-arrow-alt-from-left m-0"></i></button>
                                                <button class="btn btn-default btn-sm pr-2"
                                                        app-import-button="deselect"><i
                                                            class="fal fa-arrow-alt-from-right m-0"></i></button>
                                            </div>
                                            <div class="col-6">
                                                <div class="form-group h-100">
                                                    <input type="text" id="import-object" name="data-import-mapping"
                                                           readonly>
                                                    <label for="" class="w-100 small"><span class="required">*</span>
                                                        Field
                                                        Mapping <a
                                                                href="javascript:void(0);" class="float-right"><i
                                                                    class="fal fa-question-circle"></i></a></label>
                                                    <select name="import-mapping" id="import-field-mapping" required
                                                            class="h-100 form-control form-control-sm" multiple
                                                            form="app-data-import-form"
                                                            style="font-size: 0.68rem !important; text-transform: uppercase">
                                                        <option value="" selected>--- Selected Import Mapping ---
                                                        </option>
                                                    </select>
                                                    <div class="invalid-feedback">* Select table scheme</div>
                                                </div>

                                            </div>
                                        </div>

                                        <div class="hide">

                                            <table class="table data-tables datatables-search table-sm">
                                                <thead>
                                                <tr>
                                                    <th>Date</th>
                                                    <th>Table Name</th>
                                                    <th>Import By</th>
                                                    <th></th>
                                                </tr>
                                                </thead>
                                                <tbody>
                                                <tr>
                                                    <td></td>
                                                    <td></td>
                                                    <td></td>
                                                    <td></td>
                                                </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                                <input type="hidden" name="created_by"
                                       value="<?php echo trim(@$auth['firstname'] . ' ' . @$auth['lastname']); ?>"
                                       readonly>
                                <input type="text" name="AppDataImport">
                            </form>
                        </div>

                    </div>
                    <div class="tab-pane fade" id="vert-tabs-settings" role="tabpanel"
                         aria-labelledby="vert-tabs-settings-tab">
                        <label class="text-muted mb-0"><i class="fal fa-sliders-h-square"></i> SMS API
                            Configuration</label>
                        <hr class="my-2">
                        <form method="post" id="gateway-config-form">
                            <?php
                            extract(@$module->getRecord(["tbl_scheme" => "app_sms_gateway"])['dataArray'][0]);
                            ?>
                            <div class="row">
                                <div class="col-lg-8">

                                    <div class="form-group text-right mb-0">
                                        <div class="custom-control custom-switch">
                                            <input type="checkbox" <?php if (@$active_status == 1): echo 'checked';endif; ?>
                                                   class="custom-control-input propToggle" id="active_status">
                                            <label class="custom-control-label" for="active_status"> Active
                                                Status</label>
                                            <input type="hidden" readonly name="active_status"
                                                   class="active_status"
                                                   value="<?php if (@$active_status == 1): echo 1; else: echo 0;endif; ?>">
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-lg-6">
                                            <div class="form-group">
                                                <label class="mb-1"><span class="required"></span> Gateway Name</label>
                                                <input type="text" name="gateway_name"
                                                       class="form-control form-control-sm"
                                                       placeholder="Gateway Name" required
                                                       value="<?php echo @$gateway_name; ?>">
                                                <div class="invalid-feedback">* Provide provider name</div>
                                            </div>
                                        </div>
                                        <div class="col-lg-6">
                                            <div class="form-group">
                                                <label class="mb-1">Gateway Web URL</label>
                                                <input type="text" name="gateway_url"
                                                       class="form-control form-control-sm"
                                                       placeholder="Gateway Web URL"
                                                       value="<?php echo @$gateway_url; ?>">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-9">
                                            <div class="form-group">
                                                <label class="mb-1"><span class="required">*</span> Gateway API</label>
                                                <input type="text" name="gateway_api"
                                                       class="form-control form-control-sm"
                                                       placeholder="Gateway API" value="<?php echo @$gateway_api; ?>"
                                                       required>
                                                <div class="invalid-feedback">* Provide Gateway API link</div>
                                            </div>
                                        </div>
                                        <div class="col-3">
                                            <div class="form-group">
                                                <label class="mb-1"><span class="required">*</span> API Protocol</label>
                                                <select name="api_protocol" class="form-control form-control-sm select2"
                                                        style="width: 100%" required>
                                                    <option value="">-Protocol-</option>
                                                    <?php
                                                    $protocols = ["GET", "POST"];
                                                    foreach ($protocols as $protocol):
                                                        echo $app->dropDownList($protocol, $protocol, @$api_protocol);
                                                    endforeach;
                                                    ?>
                                                </select>
                                                <div class="invalid-feedback">* Select Gateway API protocol</div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-lg-6">
                                            <div class="form-group">
                                                <label class="mb-1"><span class="required">*</span> API Username</label>
                                                <input type="text" name="api_username"
                                                       class="form-control form-control-sm"
                                                       placeholder="API Username" value="<?php echo @$api_username; ?>"
                                                       required>
                                                <div class="invalid-feedback">* Provide API Username</div>

                                            </div>
                                        </div>
                                        <div class="col-lg-6">
                                            <div class="form-group">
                                                <label class="mb-1"><span class="required">*</span> API Password</label>
                                                <input type="password" name="api_password"
                                                       class="form-control form-control-sm"
                                                       placeholder="API Password" value="<?php echo @$api_password; ?>"
                                                       required>
                                                <div class="invalid-feedback">* Provide API Password</div>

                                            </div>
                                        </div>
                                    </div>
                                    <label class="text-muted mb-2">API Response(s)</label>
                                    <div class="row">
                                        <div class="col-4">
                                            <div class="form-group">
                                                <label class="w-100 mb-1">
                                                    <span class="required">*</span> Response Code</label>
                                                <input type="text" name="api_response[response_code]"
                                                       class="form-control form-control-sm"
                                                       placeholder="Response Code"
                                                       form="api-responses">
                                                <div class="invalid-feedback">* Required</div>
                                            </div>
                                        </div>
                                        <div class="col-8">
                                            <div class="form-group">
                                                <label class="mb-1"><span class="required">*</span> Response
                                                    Description</label>
                                                <div class="input-group">
                                                    <input type="text" name="api_response[description]"
                                                           class="form-control form-control-sm"
                                                           placeholder="Response Description"
                                                           form="api-responses">
                                                    <button class="btn btn-default btn-sm pr-2 apiRepBtn"
                                                            type="submit"
                                                            form="api-responses"><i
                                                                class="fal fa-plus-square m-0"></i></button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div id="APIResponse"></div>
                                    <div style="min-height: 145px; max-height: 145px; overflow: auto"
                                         id="api-responses-container"
                                         class="card-body p-1 elevation-1">
                                        <?php require "sms_gateway_response.php"; ?>
                                    </div>
                                    <div id="gateway-config-response" class="mt-2"></div>
                                    <div id="ModuleResponse"></div>
                                </div>

                            </div>

                            <hr class="my-2">
                            <input type="hidden" name="SMBSMSConfig">
                            <button class="btn btn-default btn-sm actionButton" tabindex="13"><i
                                        class="fal fa-check-circle"></i>
                                Save Configurations
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- /.card -->
</div>
<div id="actionEvents"></div>
<form method="post" id="api-responses">
    <input type="hidden" name="AddAPIResponse" value="1" readonly>
</form>
<script>
    $('#sms-form').bootstrap3Validate(function (e, data) {
        "use strict";
        e.preventDefault();
        var actionButton = $("#" + this.id + ' .actionButton').html();
        var formId = this.id;
        $("#" + this.id + ' .actionButton').html('<i class="fal fa-spin fa-spinner"></i> Sending SMS...');
        $.ajax({
            url: modulePath + "ajaxRequest.php",
            type: "POST",
            data: new FormData(this),
            contentType: false,
            cache: false,
            processData: false,
            success: function (data) {
                $("#SMSResponse").html(data);
                $("#" + formId + ' .actionButton').html(actionButton);
            },
            error: function () {
            }
        });

    });
    //----------------------------------------------------------------------
    $('#contact-form').bootstrap3Validate(function (e, data) {
        "use strict";
        e.preventDefault();
        var actionButton = $("#" + this.id + ' .contactButton').html();
        var formId = this.id;
        $("#" + this.id + ' .actionButton').html('<i class="fal fa-spin fa-spinner"></i> Saving Contact...');
        $.ajax({
            url: modulePath + "ajaxRequest.php",
            type: "POST",
            data: new FormData(this),
            contentType: false,
            cache: false,
            processData: false,
            success: function (data) {
                $("#contactResponse").html(data);
                $("#" + formId + ' .contactButton').html(actionButton);
            },
            error: function () {
            }
        });

    });

    //----------------------------------------------------------------------
    function contactEdit(id) {
        if (id !== "") {
            $.post(modulePath + 'ajaxRequest.php', {
                EditContact: id,
            }, function (response) {
                $("#contactResponse").html(response);
            });
        }
    }

    //----------------------------------------------------------------------
    function loadContacts() {
        $.post(modulePath + 'ajaxRequest.php', {
            loadContacts: 1,
        }, function (response) {
            $("#contact-list").html(response);
        });
    }

    //----------------------------------------------------------------------
    $('#gateway-config-form').bootstrap3Validate(function (e, data) {
        "use strict";
        e.preventDefault();
        var actionButton = $("#" + this.id + ' .actionButton').html();
        var formId = this.id;
        $("#" + this.id + ' .actionButton').html('<i class="fal fa-spin fa-spinner"></i> Processing...');
        $.ajax({
            url: modulePath + "ajaxRequest.php",
            type: "POST",
            data: new FormData(this),
            contentType: false,
            cache: false,
            processData: false,
            success: function (data) {
                $("#gateway-config-response").html(data);
                $("#" + formId + ' .actionButton').html(actionButton);
            },
            error: function () {
            }
        });

    });
    //----------------------------------------------------------------------
    $('').bootstrap3Validate(function (e, data) {
        "use strict";
        e.preventDefault();
        var actionButton = $("#" + this.id + ' #contactFilterBtn').html();
        var formId = this.id;
        $("#" + this.id + ' #contactFilterBtn').html('<i class="fal fa-spin fa-spinner"></i>');
        $.ajax({
            url: modulePath + "ajaxRequest.php",
            type: "POST",
            data: new FormData(this),
            contentType: false,
            cache: false,
            processData: false,
            success: function (data) {
                $("#contact-list").html(data);
                $("#" + formId + ' #contactFilterBtn').html(actionButton);
            },
            error: function () {
            }
        });

    });
    $("#contact-filter").submit(function (e) {
        e.preventDefault();
        var filterRequest = ($("#contact-filter").serializeArray());
        var obj = [];
        $.each(filterRequest, function (i, field) {
            obj.push('"' + field.name + '"' + ":" + '"' + field.value + '"' + "");
        });
        var objJSON = JSON.parse(('{' + decodeURIComponent(obj) + '}'));
        $.post(modulePath + 'ajaxRequest.php', {
                filterRequest: objJSON,
                loadContacts: 1,
            },
            function (response) {
                $("#contact-list").html(response);
            });
    });
    //----------------------------------------------------------------------
    $("#api-responses").on('submit', function (e) {
        e.preventDefault();
        $(".apiRepBtn").html('<i class="fal fa-spin fa-spinner"></i>');
        $.ajax({
            url: modulePath + "ajaxRequest.php",
            type: "POST",
            data: new FormData(this),
            contentType: false,
            cache: false,
            processData: false,
            success: function (data) {
                $("#APIResponse").html(data);
                $(".apiRepBtn").html('<i class="fal fa-plus-square m-0"></i>');
            },
            error: function () {
            }
        });
    });

    //----------------------------------------------------------------------
    function APIResponsesList() {
        $.post(modulePath + "ajaxRequest.php",
            {
                APIResponsesList: 1,
            }, function (response) {
                $("#api-responses-container").html(response);
            });
    }

    function SMSUnits(display) {
        $("#" + display).html("<i class='fal fa-spin fa-spinner'></i>");
        $.post(modulePath + "ajaxRequest.php",
            {
                SMSUnits: 1,
            }, function (response) {
                $("#" + display).html(response);
            });
    }

    //----------------------------------------------------------------------

</script>