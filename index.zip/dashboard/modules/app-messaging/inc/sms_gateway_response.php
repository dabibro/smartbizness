<?php
if (@$loader == 1):
    @$decode_responses = @json_decode(@htmlspecialchars_decode(@$response_array), true);
else:
    @$decode_responses = @json_decode(@htmlspecialchars_decode(@$response_array), true);
endif;
@ksort($decode_responses);
?>
<div class="table-responsive">
    <table class="data-tables table table-striped table-borderless table-sm elevation-1">
        <thead>
        <tr>
            <th>#</th>
            <th>Response Code</th>
            <th>Description</th>
            <?php if (!@$modalRequest): ?>
                <th></th>
            <?php endif; ?>
        </tr>
        </thead>
        <tbody id="attrib-list" class="card-body">
        <?php
        if ($decode_responses != NULL):
            $index = 0;
            foreach ($decode_responses as $code => $description): $index++;
                ?>
                <tr>
                    <td><?php echo @$index; ?></td>
                    <td><?php echo @$code; ?></td>
                    <td><?php echo @$description; ?></td>
                    <td>
                        <div class="btn-group-justify btn-group-sm float-right">
                            <button type="button" class="btn btn-default"
                                    onclick='javascript: var obj = "<?php echo urlencode('"className":"Module_Class","deleteAPIResponse":"' . @$code . '","callback":{"type":"actionEvent","redirect":"PackagingList()"},"notification":{"message":"Are you sure to delete this response?","title":"Delete Warning"}'); ?>";  moduleRequest(obj);'
                                    title="Delete"><i
                                        class="fal fa-trash-alt"></i>
                            </button>
                        </div>
                    </td>
                </tr>
            <?php endforeach; else: ?>
            <tr>
                <td colspan="4" class="text-center"> No API response(s) Added</td>
            </tr>
        <?php endif; ?>
        </tbody>
    </table>
</div>
