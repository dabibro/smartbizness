<?php
/**
 * Created by PhpStorm.
 * User: Dauda Ibrahim
 * Date: 8/31/2020
 * Time: 7:33 PM
 */

class SMSMessaging extends Data_Access
{
    protected $gateway_api;
    protected $tbl_scheme = "app_sms_gateway";
    protected $app;
    protected $gateway;

    public function __construct()
    {
        $this->initials();
        $this->dbConnect();
        $app = new AppConfig();
        $this->app = $app;
        $this->gateway = self::SMSGateway();
        $this->gateway_api = htmlspecialchars_decode($this->gateway['gateway_api']);
    }

    public function APIConnect()
    {
        $parse_url = parse_url($this->gateway_api);
        $host = $parse_url['host'];
        @$fp = fsockopen($host, 80);
        if (!$fp) {
            die("Error: Connection problem, check your internet!");
        }
    }

    public function SMSGateway()
    {
        @$config = @Data_Access::fetchAssoc(@Data_Access::execSQL("SELECT  * FROM " . $this->dbScheme . "." . $this->tbl_scheme . " ")['dataArray'])['dataArray'][0];
        if (@$config == NULL) {
            die("Error fetching sms gateway configuration SELECT  * FROM " . $this->dbScheme . "." . $this->tbl_scheme . " ");
        }
        return $config;
    }

    public function BalanceRequest()
    {
        $param = $this->gateway_api;
        $param .= "&username=" . $this->gateway['api_username'];
        $param .= "&password=" . $this->gateway['api_password'];
        $param .= "&balance=true";

        return $param;
    }

    public function PrepareSMS($params)
    {
        $param = $this->gateway_api;
        $param .= "&username=" . $this->gateway['api_username'];
        $param .= "&password=" . $this->gateway['api_password'];
        if ($params != NULL):
            foreach (@$params as $field => $value):
                if ($field !== "schedule")
                    $param .= '&' . $field . '=' . urlencode($value) . '';
            endforeach;
        endif;
        if (isset($params['schedule']) && $params['schedule'] != ""):
            $param .= "&schedule=" . urlencode($params['schedule']);
        endif;
        $param .= '&';
        return $param;

    }

    public function APIRequests($varParam = NULL)
    {
        if (@$varParam == NULL) {
            die("Error: API Request missing parameter");
        }
        extract(@$varParam);
        if (@$request === "Balance"):
            echo "<span style='font-weight: bold'>Your SMS Balance is: " . self::GatewayAccess(self::BalanceRequest()) . '</span>';
        else:
            //echo self::PrepareSMS($params);
            $sendSMS = self::GatewayAccess(self::PrepareSMS($params));
            if ($sendSMS != "OK"):
                echo App_Response::alertResponse("SMS Successfully sent.", 'success');
            else:
                echo App_Response::alertResponse($sendSMS, 'danger');
            endif;
        endif;
    }

    public function GatewayAccess($requestParam)
    {
        if (@$requestParam == "") {
            die("Error:Gateway Request missing parameter");
        }
        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => $requestParam,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HEADER => 0,
        ));
        $response = curl_exec($curl);
        $err = curl_error($curl);
        if ($err) {
            die('Internal server error: ' . $err);
        }
        $getResp = $this->GatewayResponse($response);
        if ($getResp != "" && $response != "OK") {
            die(App_Response::alertResponse($getResp, 'danger'));
        }
        return $response;
    }

    public function GatewayResponse($code = "")
    {
        $code = str_replace('-', '', $code);
        $responses = $this->gateway['response_array'];
        $decrypt = json_decode(htmlspecialchars_decode($responses), true);
        foreach ($decrypt as $resp_code => $description):
            if ($resp_code == $code):
                @$response = $description;
            endif;
        endforeach;
        return @$response;

    }
}