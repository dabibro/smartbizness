<?php
/**
 * Created by DTMGS Limited.
 * User: Dauda Ibrahim
 * Date: 6/23/2020
 * Time: 9:40 PM
 * File: Module Classes
 */
if (file_exists("../../../helpers/config/config.inc.php")):
    require "../../../helpers/config/config.inc.php";
endif;
require "../../../helpers/handlers/app_autoloader.php";
require "Module_Class.php";
require "SMSMessaging.php";
$engine = new SMBEngine;
$AppResponse = new App_Response;
$detect = new Detect;
$requestMethod = $_SERVER['REQUEST_METHOD'];
if (in_array($requestMethod, ["GET", "POST", "PUT", "DELETE", "OPTIONS"])):
    $requestMethodArray = array();
    $requestMethodArray = $_REQUEST;
    //print_r($requestMethodArray);
    if (isset($requestMethodArray['notification']) && !isset($requestMethodArray['confirmed'])):
        $tmpl = "../../tmpl/notification.html";
        echo $engine->fileTempParse($tmpl, $requestMethodArray);
        exit;
    endif;
    //--------------------------------------------------------------------------
    if (isset($requestMethodArray['className']) && isset($requestMethodArray['functionName'])):
        $getCommandArray = array(
            "class" => $requestMethodArray['className'],
            "function_name" => $requestMethodArray['functionName']);
        $functionArray = [];
        foreach ($requestMethodArray as $key => $val):
            if ($key !== "className" && $key !== "functionName" && $key !== "callback")
                $functionArray += array($key => $val);
        endforeach;
        $module = new $requestMethodArray['className'];

        $execution = $module->execCommand($getCommandArray, $functionArray);

        if ($execution['response'] === "200"):
            $responseMessage = App_Response::alertResponse(@$execution['message'], 'success');
            if (@$requestMethodArray['callback']['type'] == 'actionEvent'):
                $requestMethodArray['callback'] += array("event" => '<script>' . $requestMethodArray['callback']['redirect'] . '</script>');
            endif;
            $responseArray = array("success" => 1, "message" => (@$responseMessage), "dataArray" => @$execution['dataArray'], "callback" => @$requestMethodArray['callback']);
        else:
            $responseMessage = App_Response::alertResponse(@$execution['message'], 'danger');
            $responseArray = array("success" => 0, "message" => (@$responseMessage), "callback" => @$requestMethodArray['callback']);
        endif;
        echo @json_encode($responseArray);
    endif;
    //--------------------------------------------------------------------------
    if (isset($requestMethodArray['dropDownRequest'])):
        $module = new Module_Class;
        $tbl_scheme = $requestMethodArray['dropDownRequest']['target_scheme'];
        $pkField = $requestMethodArray['dropDownRequest']['pkField'];
        $pk = $requestMethodArray['dropDownRequest']['pk'];
        $key = $requestMethodArray['dropDownRequest']['key'];
        $label = $requestMethodArray['dropDownRequest']['label'];

        $listParam = array(
            "tbl_scheme" => $tbl_scheme,
            "condition" => [$pkField => $pk]);
        $listArray = $module->getRecord($listParam);
        echo '<option value="">-- Select --</option>';
        foreach ($listArray['dataArray'] as $list):
            if (isset($key) && $key != ""):
                echo $engine->dropDownList($list[$key], $list[$label]);
            else:
                echo $engine->dropDownList($list[$label]);
            endif;
        endforeach;
    endif;
    //---------------------------------------------------------------------------
    if (isset($requestMethodArray['formLookupRequest']) && $requestMethodArray['formLookupRequest']['term'] != ""):
        $module = new Module_Class;
        $request = $requestMethodArray['formLookupRequest']['request'];
        $tbl_scheme = $requestMethodArray['formLookupRequest']['target_scheme'];
        $field = $requestMethodArray['formLookupRequest']['fields'];
        $term = $requestMethodArray['formLookupRequest']['term'];
        $key = $requestMethodArray['formLookupRequest']['key'];
        $label = $requestMethodArray['formLookupRequest']['labels'];
        $condition = $requestMethodArray['formLookupRequest']['condition'];
        $order = $requestMethodArray['formLookupRequest']['order'];
        $limit = $requestMethodArray['formLookupRequest']['limit'];
        $lookupDestination = $requestMethodArray['formLookupRequest']['destination'];
        $target = $requestMethodArray['formLookupRequest']['target'];
        $actionButton = $requestMethodArray['formLookupRequest']['action_button'];

        if ($request == "search"):
            $searchParam = [
                "tbl_scheme" => $tbl_scheme,
                "fields" => $field,
                "term" => $term,
                "condition" => $condition,
                "order" => $order,
                "limit" => $limit,
            ];
            $query = $module->searchRecord($searchParam);
            if ($query['response'] == "200"):
                $dataArray = $query['dataArray'];
                if (count($dataArray) === 0):

                else:
                    echo '<div class="search-result position-relative">';
                    echo '<a class="small text-right result-close text-muted" href="javasctipy:void(0)" onclick=\'$("."+"' . $target . '").html("");\'>[ x close ]</a>';
                    $index = 0;
                    foreach ($dataArray as $results): $index++;
                        $labels = "";
                        foreach ($label as $lbl):
                            $labels .= $results[$lbl] . ' ';
                        endforeach;
                        echo '<button tabindex = "' . $index . '"  type="button" class="list-group-item" onclick=\'javascript:$("#"+"' . $lookupDestination . '").val(this.innerHTML); $("."+"' . $target . '").html(""); $("#"+"' . $actionButton . '").click()\'>[' . $results[$key] . '] ' . $labels . '</a>';
                    endforeach;
                    echo '</div>';
                endif;
            else:
                echo '<li class="list-group-item">No result(s) found lookup</li>';
            endif;

        else:

        endif;
    endif;
    //---------------------------------------------------------------------------
    if (isset($requestMethodArray['AppModalLoader'])):
        $required = $requestMethodArray['AppModalLoader'];
        $modulePath = str_ireplace($engine->dashboard, '', $required['path']);
        $modalRequest = 1;
        $modalRequestParam = "";
        if ($required['modalRequestParam'] != NULL):
            $modalRequestParam = $required['modalRequestParam'];
        endif;
        $app = $engine;
        if (@$required['DataTable'] == 1):
            require '../../includes/dataTables.php';
        endif;
        $module = new Module_Class;
        require $required['required'] . '.php';
    endif;
    //---------------------------------------------------------------------------
    if (isset($requestMethodArray['AppIDAutoGen'])):
        if ($requestMethodArray['AppIDAutoGen'] != NULL):
            extract($requestMethodArray['AppIDAutoGen']);
            echo $appIdGen = $engine->generateAppId($prefix, $suffix, $strlen, $pattern);
        endif;
    endif;
    //---------------------------------------------------------------------------
    if (isset($requestMethodArray['SMBSMSConfig'])):
        $module = new Module_Class;
        $functionArray = [
            "tbl_scheme" => "app_sms_gateway",
            "pk" => 1,
            "pkField" => "id",
        ];
        foreach ($requestMethodArray as $key => $val):
            if ($key !== "SMBSMSConfig")
                $functionArray += array($key => $val);
        endforeach;
        $response = $module->updateRecord($functionArray);
        if ($response['response'] === "200"):
            echo App_Response::alertResponse("SMS API Configuration saved", 'success');
        endif;
    endif;
    //---------------------------------------------------------------------------
    if (isset($requestMethodArray['AddAPIResponse']) && $requestMethodArray['AddAPIResponse'] === '1'):
        if ($requestMethodArray['api_response'] != NULL):
            extract($requestMethodArray['api_response']);
            $module = new Module_Class;
            @$config = $module->getRecord([
                "tbl_scheme" => "app_sms_gateway",
            ])['dataArray'][0];
            if ($config == NULL):
                echo "Missing configuration!!";
            else:
                $responses = $config['response_array'];
                if ($responses == ""):
                    $response = array($response_code => $description);
                else:
                    $responseArr = json_decode(htmlspecialchars_decode($config['response_array']), true);
                    $responseArr += array($response_code => $description);
                    $response = $responseArr;
                endif;
                $updateResponses = $module->updateRecord([
                    "tbl_scheme" => "app_sms_gateway",
                    "pkField" => 'id',
                    "pk" => $config['id'],
                    "response_array" => json_encode($response)
                ]);
                if ($updateResponses['response'] === "200"):
                    echo '<script>$("#api-responses")[0].reset(); APIResponsesList();</script>';
                endif;
            endif;
        endif;
    endif;
    //---------------------------------------------------------------------------
    if (isset($requestMethodArray['APIResponsesList'])):
        @$module = new Module_Class;
        @$loader = 1;
        @$response_array = $module->getRecord([
            "tbl_scheme" => "app_sms_gateway",
        ])['dataArray'][0]['response_array'];
        require "inc/sms_gateway_response.php";
    endif;
    //---------------------------------------------------------------------------
    if (isset($requestMethodArray['deleteAPIResponse']) && $requestMethodArray['deleteAPIResponse'] != ""):
        $module = new Module_Class;
        $code = $requestMethodArray['deleteAPIResponse'];
        $newArray = [];
        @$response_array = $module->getRecord([
            "tbl_scheme" => "app_sms_gateway",
        ])['dataArray'][0];
        @$decode_responses = @json_decode(@htmlspecialchars_decode(@$response_array['response_array']), true);
        foreach ($decode_responses as $c => $d):
            if ($c != $code) $newArray += array($c => $d);
        endforeach;
        $updateResponse = $module->updateRecord([
            "tbl_scheme" => "app_sms_gateway",
            "pkField" => 'id',
            "pk" => $response_array['id'],
            "response_array" => json_encode($newArray)
        ]);
        if ($updateResponse['response'] === "200"):
            $callback = [
                "type" => "actionEvent",
                "event" => '<script>APIResponsesList()</script>',
            ];
            $responseArray = array("success" => 1, "message" => (@$responseMessage), "dataArray" => "", "callback" => @$callback);
            echo @json_encode($responseArray);
        endif;
    endif;
    //---------------------------------------------------------------------------
    if (isset($requestMethodArray['SMSUnits'])):
        @$sms = new SMSMessaging;
        $connect = $sms->APIConnect();
        $APIRequest = $sms->APIRequests([
            "request" => "Balance",
        ]);
    endif;
    //---------------------------------------------------------------------------
    if (isset($requestMethodArray['SendSMSForm'])):
        @$sms = new SMSMessaging;
        $request = $requestMethodArray;
        $functionArray = [];
        if ($request['schedule_delivery'] == 1):
            if ($request['schedule_date'] == "" || $request['schedule_time'] == ""):
                die(App_Response::alertResponse("Specify delivery schedule date and time", 'danger'));
            else:
                $time_in_24_hour_format = date("H:i", strtotime($request['schedule_time']));
                $prepare_time = new DateTime($request['schedule_date'] . ' ' . $time_in_24_hour_format);
                $schedule = $prepare_time->format('Y-m-d H:i:s');
                $functionArray = [
                    "schedule" => $schedule
                ];
            endif;
        endif;
        foreach ($requestMethodArray as $key => $val):
            if ($key !== "SendSMSForm" && $key !== "save_contacts" && $key !== "schedule_delivery" && $key !== "schedule_date" && $key !== "schedule_time")
                $functionArray += array($key => $val);
        endforeach;
        $connect = $sms->APIConnect();
        $APIRequest = $sms->APIRequests([
            "request" => "SendMessage",
            "params" => $functionArray,
        ]);
    endif;
    //---------------------------------------------------------------------------
    if (isset($requestMethodArray['SaveContact'])):
        $module = new Module_Class;
        $request = $requestMethodArray['SaveContact'];
        if ($request == 1):
            $functionArray = [
                "tbl_scheme" => 'app_contact_list',
            ];
        else:
            $functionArray = [
                "tbl_scheme" => 'app_contact_list',
                "pkField" => "app_id",
                "pk" => $requestMethodArray['app_id']];
        endif;
        foreach ($requestMethodArray as $key => $val):
            if ($key !== "SaveContact")
                $functionArray += array($key => $val);
        endforeach;
        if ($request == 1):
            $submit = $module->createRecord($functionArray);
        else:
            $submit = $module->updateRecord($functionArray);
        endif;
        if ($submit['response'] === "200"):
            echo '<script>$("#contact-form")[0].reset();</script>';
            echo '<script>$("#SaveContact").val("1");</script>';
            echo '<script>loadContacts();</script>';
            echo App_Response::alertResponse("Contact successfully saved!!", "success");
        else:
            echo App_Response::alertResponse("Error saving contact, try again!!", "danger");
        endif;
    endif;
    //---------------------------------------------------------------------------
    if (isset($requestMethodArray['EditContact'])):
        $module = new Module_Class;
        $app_id = $requestMethodArray['EditContact'];
        @$contact = $module->getRecord([
            "tbl_scheme" => "app_contact_list",
            "condition" => ["app_id" => $app_id]
        ])['dataArray'][0];
        if (@$contact != NULL):
            echo '<script>$("#contact_name").val("' . $contact['contact_name'] . '");</script>';
            echo '<script>$("#contact_number").val("' . $contact['contact_number'] . '");</script>';
            echo '<script>$("#SaveContact").val("2");</script>';
            echo '<script>$("#app_id").val("' . $contact['app_id'] . '");</script>';
        endif;
    endif;
    //---------------------------------------------------------------------------
    if (isset($requestMethodArray['loadContacts'])):
        $app = $engine;
        $module = new Module_Class;
        require 'inc/contact_list.php';
    endif;
    //---------------------------------------------------------------------------

    //---------------------------------------------------------------------------
    //---------------------------------------------------------------------------

endif;