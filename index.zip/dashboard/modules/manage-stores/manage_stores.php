<?php

require "Module_Class.php";
$module = new Module_Class;
$modulePath = @$appSwitcher->modulePath($AppModule);
$req = $AppModuleRequest;

//$appUsers = new App_Users;
//$req = $AppModuleRequest;
//$modulePath = @$appSwitcher->modulePath($AppModule);
?>
<script src="<?php echo $modulePath ?>js.js"></script>
<input type="hidden" value="<?php echo $modulePath; ?>" id="ModulePath" readonly>
<div class="card card-primary card-outline card-outline-tabs">
    <div class="card-header p-0 border-bottom-0">
        <ul class="nav nav-tabs app-menu" id="manage-users-tabs" role="tablist">
            <li class="nav-item">
                <a class="nav-link <?php if ($req == 'stores/'): echo 'active'; endif; ?>"
                   href="#/stores/" onclick="fetchURL(this.href)"> <i class="fal fa-store"></i> Stores List</a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php if ($req == 'create-store/'): echo 'active'; endif; ?>"
                   href="#/create-store/" onclick="fetchURL(this.href)"> <i class="fal fa-edit"></i> Create/Update Store</a>
            </li>
        </ul>
    </div>
    <div class="card-body">
        <div class="tab-content" id="manage-users-tabContent">
            <div class="tab-pane fade <?php if ($req == 'stores/'): echo 'active show'; endif; ?>"
                 id="users-tab" role="tabpanel" aria-labelledby="tabs-users-tabs">
                <?php if ($req == 'stores/'): require "inc/stores_list.php";endif; ?>
            </div>
            <div class="tab-pane fade <?php if ($req == 'create-store/'): echo 'active show'; endif; ?>"
                 id="create-new-tab" role="tabpanel" aria-labelledby="tabs-create-new-tab">
                <?php if ($req == 'create-store/'): require "inc/create_store.php"; endif; ?>

            </div>
        </div>
    </div>
    <!-- /.card -->
</div>

          