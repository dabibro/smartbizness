<?php

@$requestArray = array(
    "tbl_scheme" => 'app_stores',
    "order" => 'store_name ASC');
@$recordRequest = $module->getRecord($requestArray);
@$recordsArray = $recordRequest['dataArray'];
if (@$requestMethodArray['request'] == "update" && @$requestMethodArray['pk'] != "" && @$requestMethodArray['pkField'] != ""):
    $pk = $requestMethodArray['pk'];
    $pkField = $requestMethodArray['pkField'];
    $getUpdateArray = array(
        "tbl_scheme" => 'app_store',
        "condition" => [$pkField => $pk],
        "limit" => 1
    );
    $getUpdate = $module->getRecord($getUpdateArray);
    extract($getUpdate['dataArray'][0]);
endif;
?>
<div class="row mb-3">
    <div class="col-6">
        <div class="row">
            <div class="col ml-auto hide">
                <div class="input-group input-group-sm mr-2">
                    <input type="search" class="form-control border-right-0 dataTables_filter"
                           placeholder="Search keyword..">
                    <div class="input-group-append">
                        <span class="input-group-text border-left-0 bg-transparent"><i class="fal fa-search"></i></span>
                    </div>

                </div>
            </div>
            <div class="col-auto">
                <div class="app-collapse">
                    <button class="btn btn-default btn-sm dropdown-toggle" data-toggle="collapse"
                            href="#collapseUsersFilter"
                            aria-expanded="false" aria-controls="collapseUsersFilter"><i
                                class="fal fa-filter"></i> Advance Filter
                    </button>
                    <div class="collapse collapse-container left" id="collapseUsersFilter">
                        <div class="card-body elevation-1 bg-light left">
                            <form action="">
                                <div class="form-group">
                                    <label for="">Users Group</label>
                                    <select name="users_group" class="form-control form-control-sm select2">
                                        <option value="">-- Users Group --</option>
                                    </select>
                                </div>
                                <div class="row">
                                    <div class="col-6">
                                        <div class="form-group">
                                            <label for="">Users Store</label>
                                            <select name="users_location" class="form-control form-control-sm select2">
                                                <option value="">-- Users Store --</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-6">
                                        <div class="form-group">
                                            <label for="">Active Status</label>
                                            <select name="activation" class="form-control form-control-sm select2">
                                                <option value="">-- Active Status --</option>
                                            </select>
                                        </div>
                                    </div>

                                </div>

                                <hr class="my-2">
                                <button class="btn btn-default btn-sm btn-block"><i class="fal fa-check-circle"></i>
                                    Submit
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>


    </div>
    <div class="col-6">
        <div id="ModuleResponse"></div>
    </div>
</div>
<div class="table-responsive">
    <table class="table data-tables dataTables-Sort table-sm elevation-1">
        <caption>View All Record</caption>
        <thead>
        <tr>
            <th>Reference</th>
            <th>Store Name</th>
            <th>Store Type</th>
            <th>Contact Person</th>
            <th>Contact Number</th>
            <th>Location</th>
            <th>Status</th>
            <th><i class="fal fa-cogs"></i></th>
        </tr>
        </thead>
        <tbody class="card-body">
        <?php
        if (isset($recordsArray)):
            foreach (@$recordsArray as $store): extract($store);
                $location = "";
                $location .= @$module->getRecord(["tbl_scheme" => 'app_cities', "condition" => ["id" => @$city]])['dataArray'][0]['name'];
                $location .= ", " . @$module->getRecord(["tbl_scheme" => 'app_states', "condition" => ["id" => @$state]])['dataArray'][0]['name'];
                $location .= ", " . @$module->getRecord(["tbl_scheme" => 'app_countries', "condition" => ["id" => @$country]])['dataArray'][0]['name'];
                $location = trim($location, ', ');
                ?>
                <tr>
                    <td><?php echo @$reference; ?></td>
                    <td><?php echo @trim($store_name); ?></td>
                    <td><?php echo @trim($store_type); ?></td>
                    <td><?php echo @trim($contact_name); ?></td>
                    <td><?php echo @$contact_phone; ?></td>
                    <td><?php echo @$location; ?></td>
                    <td><?php if (@$active_status == 1):echo 'Active'; else:echo 'Inactive'; endif; ?></td>
                    <td style="width:5%;" class="py-1" nowrap="nowrap">
                        <div class="btn-group-justify btn-group-sm float-right">
                            <button type="button" class="btn btn-default"
                                    onclick='javascript: var obj = "<?php echo urlencode('"pkField":"store_id","pk":' . $store_id . ',"view":"/#/create-store/","request":"update"'); ?>"; moduleEditRequest(obj)'
                                    title=" Edit Record"><i
                                        class="fal fa-edit"></i>
                            </button>
                            <button type="button" class="btn btn-default"
                                    onclick='javascript: var obj = "<?php echo urlencode('"className":"Module_Class","functionName":"deleteRecord","tbl_scheme":"app_stores","pk":{"store_id":' . $store_id . '},"callback":{"type":"self","redirect":""},"notification":{"message":"Are you sure to delete this store record?","title":"Delete Warning"}'); ?>";  moduleRequest(obj);'
                                    title=" Edit Record"><i
                                        class="fal fa-trash-alt"></i>
                            </button>
                    </td>
                </tr>
            <?php endforeach;
        endif;
        ?>
        </tbody>
    </table>
</div>
