<?php
if (@$requestMethodArray['request'] == "update" && @$requestMethodArray['pk'] != "" && @$requestMethodArray['pkField'] != ""):
    $pk = $requestMethodArray['pk'];
    $pkField = $requestMethodArray['pkField'];

    $getUpdateArray = array(
        "tbl_scheme" => 'app_stores',
        "condition" => [$pkField => $pk],
        "limit" => 1
    );
    $getUpdate = $module->getRecord($getUpdateArray);
    @extract($getUpdate['dataArray'][0]);
else:
    $app_id = $app->generateAppId('ST', '', 8, 'ABCDEFGHIJKLMNOPQ0123456789');
endif;
?>
<div class="position-relative">
    <form method="post" class="AppForm" id="store-form" novalidate>
        <div class="row">
            <div class="col-2">
                <div class="nav flex-column nav-tabs h-100" id="vert-tabs-tab" role="tablist"
                     aria-orientation="vertical">
                    <a class="nav-link active" id="basic-tabs" data-toggle="pill" href="#basic-tabs-panel" role="tab"
                       aria-controls="basic-tabs-panel" aria-selected="false"><i class="fal fa-info-circle"></i> Basics
                        Data
                        <hr class="my-1">
                        <small class="text-muted">Fill in the store basic details.
                        </small>
                    </a>
                    <a class="nav-link <?php if (@$update == 1):echo "disabled"; endif; ?>" id="contact-tabs"
                       data-toggle="pill" href="#contact-tabs-panel" role="tab" aria-controls="contact-tabs-panel"
                       aria-selected="false"><i class="fal fa-cog"></i> Contact
                        Details
                        <hr class="my-1">
                        <small class="text-muted">Store contact details
                        </small>
                    </a>
                </div>
            </div>
            <div class="col-10">
                <div class="tab-content" id="add-item-tabContent">
                    <div class="row">
                        <div class="col-md-3 col-lg-2"></div>
                        <div class="col-md-9 col-lg-8">
                            <div id="ModuleResponse"></div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-9 col-lg-10">
                            <div class="row">
                                <div class="col-lg-4 col-12 ml-auto">
                                    <div class="form-group position-relative">
                                        <div class="input-group">
                                            <input type="search" class="form-control-sm form-control" id="store_lookup"
                                                   autocomplete="off"
                                                   placeholder="Store Lookup..."
                                                   onkeyup='recordFormLookup("{\"request\":\"search\",\"target_scheme\":\"app_stores\",\"term\":\"" + this.value + "\",\"fields\":[\"reference\",\"store_name\"],\"condition\":{\"active_status\":\"1\"},\"limit\":\"10\",\"order\":{\"order_fields\":[\"store_name\"],\"sort\":\"ASC\"}, \"key\":\"reference\",\"labels\":[\"store_name\"],\"target\":\"lookup_response\",\"destination\":\"store_lookup\",\"callback\":\"self\",\"action_button\":\"store_lookup_btn\"}");'>
                                            <div class="input-group-append">
                                                <button class="btn btn-default btn-sm pr-2" type="button"
                                                        id="store_lookup_btn"
                                                        onclick='javascript:var obj; obj = $("#store_lookup").val(); obj = obj.split("]"); obj = obj[0].split("["); moduleEditRequest("\"request\":\"update\",\"pkField\":\"reference\",\"pk\":\""+obj[1]+"\",\"view\":\"/#/create-store/\"")'>
                                                    <i class="fal fa-search m-0"></i>
                                                </button>
                                            </div>
                                        </div>
                                        <div class="lookup_response app-autolookup"></div>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                    <div class="tab-pane text-left fade  active show" id="basic-tabs-panel" role="tabpanel"
                         aria-labelledby="basic-tabs">
                        <div class="col-md-9 col-lg-10">
                            <label class="text-muted">Store Information</label>
                            <div class="row">
                                <div class="col-lg-4 col-6 ml-auto">
                                    <div class="form-group">
                                        <label class="ml-auto"><span class="required">*</span> Reference Code</label>
                                        <div class="input-group">
                                            <input type="text" class="form-control form-control-sm "
                                                   name="reference" id="store_ref"
                                                   value="<?php echo @$reference; ?>"
                                                   required autofocus
                                                   placeholder="Reference Code" autocomplete="off">
                                            <div class="btn-group">
                                                <button class="btn btn-default btn-sm appAutoIDGen pr-2"
                                                        type="button"
                                                        AppId-AutoGen='{"prefix":"STR","suffix":"<?php echo date('my', time()) ?>", "strlen":"4","pattern":"0123456789","target":"store_ref"}'
                                                        id="vendorIdGen"
                                                        title="Auto Generate" data-toggle="tooltip"><i
                                                            class="fal fa-barcode m-0"></i></button>
                                            </div>
                                            <div class="invalid-feedback">* Required field</div>
                                        </div>

                                    </div>
                                </div>
                                <div class="col-lg-8">
                                    <div class="form-group">
                                        <label for="store_name"><span class="required">*</span> Store Name</label>
                                        <input name="store_name" type="text" required
                                               class="form-control form-control-sm " placeholder="Store Name"
                                               value="<?php echo @$store_name; ?>" autocomplete="off">
                                        <div class="invalid-feedback">* Required field</div>
                                    </div>
                                </div>
                            </div>

                            <div class="form-group">
                                <label>Additional Description</label>
                                <textarea name="description" class="form-control form-control-sm text-editor" rows="4"
                                          style="min-height: 4rem; max-height: 5.45rem"
                                          placeholder="Additional Description"
                                          autocomplete="off"><?php echo @$description; ?></textarea>
                            </div>
                            <div class="row">
                                <div class="col-6">
                                    <div class="form-group mb-0">
                                        <label>Store Type</label>
                                        <select name="store_type" class="form-control form-control-sm select2">
                                            <option value="">-- Select --</option>
                                            <?php $itemArray = array("Physical Structure", "Online Store");
                                            foreach ($itemArray as $item): ?>
                                                <option value="<?php echo $item ?>" <?php if (@$store_type == $item): echo 'selected';endif; ?>><?php echo $item; ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-6">
                                    <div class="form-group mb-0">
                                        <label>Building Ownership</label>
                                        <select name="building_ownership" class="form-control form-control-sm select2">
                                            <option value="">-- Select --</option>
                                            <?php $itemArray = array("Owned", "Rental");
                                            foreach ($itemArray as $item): ?>
                                                <option value="<?php echo $item ?>" <?php if (@$building_ownership == $item): echo 'selected';endif; ?>><?php echo $item; ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane text-left fade" id="contact-tabs-panel" role="tabpanel"
                         aria-labelledby="contact-tabs">
                        <div class="col-md-9 col-lg-10">
                            <label class="text-muted">Contact Information</label>
                            <div class="row">
                                <div class="col-3">
                                    <div class="form-group">
                                        <label for="">Title</label>
                                        <select name="contact_title" class="form-control form-control-sm select2">
                                            <option value="">-- Title --</option>
                                            <?php $itemArray = array("Mr", "Mrs", "Miss");
                                            foreach ($itemArray as $item): ?>
                                                <option value="<?php echo $item ?>" <?php if (@$contact_title == $item): echo 'selected';endif; ?>><?php echo $item; ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>

                                </div>
                                <div class="col-9">
                                    <div class="form-group">
                                        <label for="contact_name"> Contact Name</label>
                                        <input name="contact_name" type="text"
                                               class="form-control form-control-sm " placeholder="Contact Name"
                                               value="<?php echo @$contact_name; ?>" autocomplete="off">
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Contact Phone</label>
                                        <input name="contact_phone" type="text"
                                               class="form-control form-control-sm" placeholder="Contact Phone"
                                               value="<?php echo @$contact_phone; ?>" autocomplete="off">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Email Address</label>
                                        <div class="controls">
                                            <input name="contact_email" type="email"
                                                   class="form-control form-control-sm"
                                                   value="<?php echo @$contact_email; ?>"
                                                   placeholder="Email Address"
                                                   autocomplete="off">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label> Country</label>
                                        <select name="country" class="form-control form-control-sm select2"
                                                id="country"
                                                onchange='dropDownList("{\"request\":\"dropDownList\",\"pkField\":\"country_id\",\"pk\":"+ this.value +",\"target_scheme\":\"app_states\",\"key\":\"id\",\"label\":\"name\",\"target\":\"states\"}")'>
                                            <option value="">-- Country --</option>
                                            <?php
                                            $countryParam = array("tbl_scheme" => 'app_countries', "condition" => '');
                                            $listArray = $module->getRecord($countryParam);
                                            $dropDownArray = array();
                                            foreach ($listArray['dataArray'] as $countries):
                                                echo $app->dropDownList($countries['id'], $countries['name'], @$country);
                                            endforeach; ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>State</label>
                                        <select name="state" class="form-control form-control-sm select2"
                                                id="states"
                                                onchange='dropDownList("{\"request\":\"dropDownList\",\"pkField\":\"state_id\",\"pk\":"+ this.value +",\"target_scheme\":\"app_cities\",\"key\":\"id\",\"label\":\"name\",\"target\":\"cities\"}")'>
                                            <option value="">-- State --</option>
                                            <?php if (@$getUpdate['response'] === "200"):
                                                $listArray = $module->getRecord(["tbl_scheme" => 'app_states', "condition" => ["country_id" => $country]]);
                                                foreach ($listArray['dataArray'] as $states):
                                                    echo $app->dropDownList($states['id'], $states['name'], $state);
                                                endforeach; endif; ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>City</label>
                                        <select name="city" class="form-control form-control-sm select2"
                                                id="cities">
                                            <option value="">-- City --</option>
                                            <<?php if (@$getUpdate['response'] === "200"):
                                                $listArray = $module->getRecord(["tbl_scheme" => 'app_cities', "condition" => ["state_id" => $state]]);
                                                foreach ($listArray['dataArray'] as $cities):
                                                    echo $app->dropDownList($cities['id'], $cities['name'], $city);
                                                endforeach; endif; ?>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group">
                                <label>Contact Address</label>
                                <textarea name="contact_address" class="form-control form-control-sm" rows="4"
                                          style="min-height: 3.9rem; max-height: 3.9rem"
                                          placeholder="Contact Address"
                                          autocomplete="off"><?php echo @$contact_address; ?></textarea>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Web Address</label>
                                        <div class="controls">
                                            <input name="website_address" type="text"
                                                   class="form-control form-control-sm"
                                                   value="<?php echo @$website_address; ?>"
                                                   placeholder="Web Address"
                                                   autocomplete="off">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
        <hr class="my-3">
        <div class="row">
            <div class="col-10 ml-auto pl-3">
                <button class="btn btn-default btn-sm px-4" type="submit"><i
                            class="fal fa-check-circle"></i>
                    Submit
                </button>
            </div>
        </div>
        <input type="hidden" name="className" value="Module_Class" readonly>
        <input type="hidden" name="app_id" value="<?php echo @$app_id; ?>" readonly>
        <?php if (@$getUpdate['response'] === "200"): ?>
            <input type="hidden" name="functionName" value="updateRecord" readonly>
            <input type="hidden" name="pk" value="<?php echo @$pk; ?>" readonly>
            <input type="hidden" name="pkField" value="<?php echo @$pkField; ?>" readonly>
        <?php else: ?>
            <input type="hidden" name="functionName" value="createRecord" readonly>
        <?php endif; ?>
        <input type="hidden" name="callback[type]" value="self" readonly>
        <input type="hidden" name="callback[redirect]" value="" readonly>
        <input type="hidden" name="tbl_scheme" value="app_stores" readonly>
        <input type="hidden" name="created_by"
               value="<?php echo trim(@$auth['firstname'] . ' ' . @$auth['lastname']); ?>" readonly>

    </form>
</div>