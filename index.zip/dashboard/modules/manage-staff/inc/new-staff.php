<?php
//if(@$rol['emp_mgmt'] != 1 || @$rol['new_employee'] != 1 && @$rol['edit_employee'] !=1 ){echo '<script>location.replace("'.WEB_ROOT.'")</script>';}
//require queries
//require_once('inc/queries.php');
?>

<div class="x_panel">
    <div class="x_title">
        <h5 class="title"><i class="fal fa-edit"></i> Staff Record</h5>
    </div>
    <div class="x_content">
        <div class="row">
            <div class="col-md-12 col-lg-12 m-auto">
                <div id="result"></div>
                <form method="post" enctype="multipart/form-data" class="submit-employee">

                    <div class="row">
                        <div class="col-md-3" style="max-width: 240px !important;">
                            <div class="form-group mb-0">
                                <label>Passport Photograph</label>
                            </div>
                            <div class="passport-holder" style="width: 230px;">
                                <div class="" style="width:100%; height: 180px !important;  overflow: hidden">
                                    <img src="<?php if (@$edit && @$edit['passport'] != "" && file_exists(PASSPORTS . $edit['passport'])) {
                                        //echo displayPassport(@$edit['id'], 'employee');
                                    } else {
                                        echo AVATAR;
                                    } ?>"
                                         style="cursor: pointer; width: auto; max-width: 100%; height: auto; max-height: 100%"
                                         id="passport" alt="passport" class="img-thumbnail"
                                         onClick='javascript:$("#imageFile").click()'>
                                </div>

                                <div class="form-group ">
                                    <button type="button" class="btn btn-primary mt-3"
                                            onclick="$('#imageFile').click();"><i class="fal fa-image"></i> Select
                                        Passport
                                    </button>
                                    <input type="file" name="imageFile" id="imageFile" class="mt-3 hide"
                                           onchange="readURL(this);">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-9">
                            <div class="form-group ">
                                <div class="row">
                                    <div class="col-md-4 ml-auto">
                                        <div class="form-group ">
                                            <label><span class="required">*</span> Staff ID</label>
                                            <input name="emp_id" id="emp_id" class="form-control"
                                                   value="<?php echo @$edit['emp_id']; ?>" required
                                                   placeholder="Staff ID">

                                        </div>
                                    </div>
                                </div>
                                <div class="invalid-feedback">* Enter Staff ID</div>
                            </div>
                            <div class="">
                                <div class="row">
                                    <div class="col-md-4 col-xs-6">
                                        <div class="form-group ">
                                            <label for="fname"><span class="required">*</span> First Name</label>
                                            <input name="fname" type="text" required
                                                   class="form-control " id="fname" placeholder="First Name"
                                                   value="<?php echo @$edit['fname'] ?>">
                                            <div class="invalid-feedback">* Enter First Name</div>
                                        </div>
                                    </div>
                                    <div class="col-md-4 col-xs-6">
                                        <div class="form-group ">
                                            <label><span class="required">*</span> Last Name</label>
                                            <input name="sname" type="text" required
                                                   class="form-control " id="sname" placeholder="Last Name"
                                                   value="<?php echo @$edit['sname'] ?>">
                                            <div class="invalid-feedback">* Enter Last Name</div>
                                        </div>
                                    </div>
                                    <div class="col-md-4 col-xs-6">
                                        <div class="form-group ">
                                            <label>Other Name</label>
                                            <input name="oname" type="text" data-title=" Enter Other Name"
                                                   class="form-control " id="oname" placeholder="Other Name"
                                                   value="<?php echo @$edit['oname'] ?>">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="">
                                <div class="row">
                                    <div class="col-md-4 col-xs-6">
                                        <div class="form-group ">
                                            <label><span class="required">*</span> Date of Birth</label>
                                            <input name="dob" type="text" required
                                                   class="form-control datepicker" id="dob" placeholder="Date of Birth"
                                                   autocomplete="off" value="<?php echo @$edit['dob'] ?>">
                                            <div class="invalid-feedback">* Enter Date of Birth</div>
                                        </div>
                                    </div>
                                    <div class="col-md-4 col-xs-6">
                                        <div class="form-group ">
                                            <label><span class="required">*</span> Gender</label>
                                            <select name="gender" required data-title=" Select Gender"
                                                    class="form-control select2" id="gender"
                                            <option value="">-- Select --</option>
                                            <?php
                                            $typeArray = array("Male", "Female");
                                            $arrlength = count($typeArray);
                                            $x = 0;
                                            while ($x < $arrlength) {
                                                ?>
                                                <option value="<?php echo $typeArray[$x]; ?>" <?php
                                                if (@$edit['gender'] == @$typeArray[$x]) {
                                                    echo 'selected';
                                                }
                                                ?>><?php echo $typeArray[$x]; ?></option>
                                                <?php
                                                $x++;
                                            }
                                            ?>

                                            </select>
                                            <div class="invalid-feedback">* Select Gender</div>
                                        </div>
                                    </div>
                                    <div class="col-md-4 col-xs-6">
                                        <div class="form-group ">
                                            <label><span class="required">*</span> Marital Status</label>
                                            <select name="marital_status" required
                                                    class="form-control select2" id="marital_status"
                                                    data-title="Select Marital Status">
                                                <option value="">-- Select --</option>
                                                <?php
                                                $typeArray = array("Single", "Married", "Divorced", "Widow");
                                                $arrlength = count($typeArray);
                                                $x = 0;
                                                while ($x < $arrlength) {
                                                    ?>
                                                    <option value="<?php echo $typeArray[$x]; ?>" <?php
                                                    if (@$edit['marital_status'] == @$typeArray[$x]) {
                                                        echo 'selected';
                                                    }
                                                    ?>><?php echo $typeArray[$x]; ?></option>
                                                    <?php
                                                    $x++;
                                                }
                                                ?>

                                            </select>
                                            <div class="invalid-feedback">* Enter Marital Status</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="">
                                <div class="row">
                                    <div class="col-md-4 col-xs-6">
                                        <div class="form-group ">
                                            <label><span class="required">*</span> Date of Employment</label>
                                            <input name="doe" type="text" required="required" required

                                                   class="form-control datepicker " id="doe"
                                                   placeholder="Date of Employment" autocomplete="off"
                                                   value="<?php echo @$edit['doe'] ?>">
                                            <div class="invalid-feedback">* Select Date of Employment</div>
                                        </div>
                                    </div>
                                    <div class="col-md-4 col-xs-6">
                                        <div class="form-group ">
                                            <label><span class="required">*</span> Department</label>
                                            <select name="dept" required
                                                    class="form-control select2" id="dept" required
                                                    data-title="Select Department">
                                                <option value="">-- Select --</option>
                                                <?php
                                                //$depts_query = dbQuery($departments);
                                                while ($depts = dbFetchAssoc($depts_query)):
                                                    ?>
                                                    <option value="<?php echo $depts['id'] ?>" <?php
                                                    if (@$edit['dept'] == $depts['id']) {
                                                        echo 'selected';
                                                    }
                                                    ?>><?php echo $depts['dept'] ?></option>
                                                <?php endwhile; ?>
                                                <div class="invalid-feedback">* Select Department</div>
                                            </select>
                                        </div>

                                    </div>
                                    <div class="col-md-4 col-xs-6">
                                        <div class="form-group ">
                                            <label><span class="required">*</span> Designation</label>
                                            <input name="designation" type="text" required="required" required
                                                   class="form-control " id="designation"
                                                   placeholder="Enter Designation" autocomplete="off"
                                                   value="<?php echo @$edit['designation'] ?>">
                                            <div class="invalid-feedback">* Enter Designation</div>
                                        </div>
                                    </div>

                                </div>
                                <div class="row">
                                    <div class="col-md-4 col-xs-6">
                                        <div class="form-group ">
                                            <label><span class="required">*</span> Basic Salary</label>
                                            <input name="basic_salary" type="text" required="required" required
                                                   class="form-control num"
                                                   id="basic_salary" placeholder="Enter Basic Salry" autocomplete="off"
                                                   value="<?php echo @$edit['basic_salary'] ?>">
                                            <div class="invalid-feedback">* Enter Basic Salary</div>
                                        </div>
                                    </div>
                                    <div class="col-md-4 col-xs-6">
                                        <div class="form-group ">
                                            <label><span class="required">*</span> Payee %</label>
                                            <input name="payee" type="text" required
                                                   class="form-control num" id="payee" placeholder="Enter Payee"
                                                   autocomplete="off" value="<?php echo @$edit['payee'] ?>">
                                            <div class="invalid-feedback">* Enter Payee</div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-4">
                                        <div class="form-group ">
                                            <label>Phone No.</label>
                                            <input name="phone" type="text" class="form-control" id="phone"
                                                   placeholder="Phone No." autocomplete="off"
                                                   value="<?php echo @$edit['phone_no'] ?>"
                                                   data-title="Enter Phone Number">
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group ">
                                            <label>E-mail</label>
                                            <input name="email" type="email" class="form-control" id="email"
                                                   placeholder="E-mail" autocomplete="off"
                                                   value="<?php echo @$edit['email'] ?>">
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group ">
                                    <label>Contact Address</label>
                                    <textarea name="contact_address" rows="3" required
                                              class="form-control" id="address"
                                              placeholder="Contact Address"><?php echo @$edit['contact_address'] ?></textarea>
                                    <div class="invalid-feedback">* Enter Contact Address</div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <hr>

                    <button class="btn btn-primary px-4 save-btn" type="submit"><i class="fal fa-check-circle"></i>
                        Submit
                    </button>
                    <button type="button" class="btn btn-danger px-4" onclick="location.replace('?p=employee')"><i
                                class="fal fa-times-circle"></i> Close
                    </button>


                    <?php if (!@$edit) { ?>
                        <input type="hidden" name="submit-employee" value="1">
                    <?php } else { ?>
                        <input type="hidden" name="id" value="<?php echo @$edit['id']; ?>">
                        <input type="hidden" name="submit-employee" value="2">
                    <?php } ?>


                </form>
            </div>
        </div>
    </div>
</div>
