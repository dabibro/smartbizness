<!--<?php
//if (@$access['departments'] != 1) {
    //echo '<script>location.replace("' . WEB_ROOT . '");</script>';
}
//require queries file
//require_once('inc/queries.php');

//if (isset($_GET['edit-department'])) {
    //$edit = getDept($_GET['edit-department']);
}

//deleting department
//if (isset($_POST['delete-department']) && $_POST['delete-department'] != "") {
    //$id = $_POST['delete-department'];
    //$row = getDept($id);
    //if (!$row) {
        //echo '<script>location.replace("' . WEB_ROOT . '")</script>';
    //} else {
        //dbQuery("DELETE FROM app_departments WHERE id = '" . $row['id'] . "'");
        /// echo '<script>location.replace("?p=app-mgmt&&dept")</script>';
    }
}

?>-->
<div id="responses"></div>

<div class="x_panel">
    <div class="x_title">
        <h5 class="title"><i class="fal fa-home-alt"></i> Departments Management</h5>
    </div>
    <div class="x_content">
        <div class="row">
            <?php if (@$access['new_department'] == 1 || @$access['edit_department'] == 1) { ?>
            <div class="col-md-5 col-lg-4">
                <div id="result"></div>
                <div class=" shadow border-0 p-3 br-0">
                    <h6 class="m-0"><i class="fal fa-edit"></i> Department Record</h6>
                    <hr>
                    <form class="submit-settings" method="post" novalidate>

                        <div class="form-group">
                            <label for="">Department Name</label>
                            <input type="text" name="dept" autocomplete="off" class="form-control"
                                   data-title="Enter department name" required placeholder="Department Name"
                                   value="<?php echo @$edit['dept']; ?>">
                        </div>
                        <div class="form-group">
                            <label for="">Description</label>
                            <textarea class="form-control" name="description" rows="3"
                                      placeholder="Description"><?php echo @$edit['description']; ?></textarea>
                        </div>
                        <hr>

                        <?php if (@$edit) { ?>
                    <input name="submit-department" type="hidden" value="2"/>
                        <input type="hidden" name="id" value="<?php echo @$edit['id']; ?>">
                        <?php } else { ?>
                            <input name="submit-department" type="hidden" value="1"/>
                        <?php } ?>

                            <button class="btn btn-primary px-4"><i class="fal fa-check-circle"></i> Submit</button>
                        <?php if (@$edit) { ?>
                            <a class="btn btn-danger px-4" href="?p=departments"><i class="fal fa-times-circle"></i>
                                Close </a>
                        <?php } ?>
                    </form>
                </div>
            </div>
            <?php } ?>
            <div class="  <?php
            if (@$access['new_department'] == 1 || @$access['edit_department'] == 1) {
            echo 'col-md-7 col-lg-8';
            } else {
            echo 'col-md-12';
            }
            ?>">


                <table class="table table-hover table-striped dataTable" style="font-size:12px;">
                    <thead>
                    <tr>
                        <th>Department/Description</th>
                        <th>Staff</th>
                        <th></th>
                    </tr>
                    </thead>
                    <tbody>

                    <?php
                    //dept_query = dbQuery($departments);
                    //while ($department = dbFetchAssoc($dept_query)):
                    //$employee = dbNumRows(dbQuery("SELECT id FROM app_employees WHERE dept = '" . $department['id'] . "'")); ?>
                    <tr class="data-btn">
                        <td>
                            <?php echo $department['dept']; ?>
                            <div class="small">  <?php echo $department['description']; ?></div>
                        </td>
                        <td><?php echo $employee; ?></td>
                        <td align="right">
                            <div class="btn-group btn-group-sm">
                                <?php if (@$access['edit_department'] == 1) { ?>
                                <a href="#" class="btn btn-primary" title="Edit Record" data-toggle="tooltip"
                                   onClick="location.replace('?p=departments&edit-department=<?php echo $department['id'] ?>')">&nbsp;<i
                                            class="fal fa-edit"></i>&nbsp;</a>
                                <?php } ?>
                                    <?php if (@$access['delete_department'] == 1) { ?>
                                <a href="#" class="btn btn-primary" title="Delete Record" data-toggle="tooltip"
                                   onClick="confirmRequest('<?php echo $department['id'] ?>department', '<?php echo $department['id'] ?>', 'Are you sure you want to delete this record?', 'delete-department')">&nbsp;<i
                                            class="fal fa-trash"></i>&nbsp;</a>
                                <?php } ?>
                            </div>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                    </tbody>
                </table>

            </div>
        </div>
    </div>

</div>
