<?php
if (@$access['payroll'] != 1) {
    echo '<script>location.replace("' . WEB_ROOT . '");</script>';
}
//require modelu query files
require_once('inc/queries.php');
?>
<div id="responses"></div>

<div class="x_panel">
    <div class="x_title">
        <h5 class="title"><i class="fal fa-calculator"></i> Staff Payroll</h5>
    </div>
    <div class="x_content" id="printArea">
        <div class="row mb-3">
            <div class="col-6">
                <button type="button" class="btn btn-primary dropdown-toggle" data-toggle="collapse"
                        aria-expanded="false" data-target="#filterCriteria" aria-controls="filterCriteria">
                    <i class="fal fa-filter"></i> Filter Report
                </button>
                <div class="collapse px-3 py-3 card br-0 shadow-sm" aria-labelledby="dLabel" id="filterCriteria"
                     style="z-index: 1 !important; position: absolute;">
                    <form method="post">
                        <div class="form-group input-group-sm">
                            <select name="dept" id="dept" class="form-control select2"
                                    style="border-radius:0; width: 100%">
                                <option value="">-- Department --</option>
                                <?php
                                $dept_query = dbQuery($departments);
                                while ($dn = dbFetchAssoc($dept_query)): ?>
                                    <option value="<?php echo $dn['id']; ?>">
                                        <?php echo $dn['dept']; ?>
                                    </option>
                                <?php endwhile; ?>
                            </select>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group " id="str">
                                    <div class="input-group input-group-sm">
                                        <input type="text" class="form-control form-control-sm datepicker"
                                               name="start_date"
                                               id="start_date" placeholder="Start Date" style="border-radius:0;"
                                               autocomplete="off">
                                        <span class="input-group-prepend">
                                <span class="input-group-text"><i class="fal fa-calendar-minus"></i></span>
                            </span>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group" id="stp">
                                    <div class="input-group">
                                        <input type="text" class="form-control form-control-sm datepicker"
                                               name="stop_date"
                                               id="stop_date" placeholder="Stop Date" style="border-radius:0;"
                                               autocomplete="off">
                                        <span class="input-group-prepend">
                                <span class="input-group-text"> <i class="fal fa-calendar-plus"></i></span>
                            </span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <button class="btn btn-primary btn-block" type="submit" onClick=" return verifyQuery();"><i
                                    class="fal fa-filter"></i> Apply Filter
                        </button>
                        <input type="hidden" name="filter-payroll" value="1">
                    </form>

                </div>
            </div>
            <div class="col-auto ml-auto text-right">
                <?php if (@$access['new_advance'] == 1) { ?><a href="#" class="btn btn-primary px-4"
                                                               onClick="javascript:location.replace('?p=new-advance')"
                                                               title="New Advance" data-toggle="tooltip"><i
                            class="fal fa-plus-square"></i> <span class="text">New Advance</span> </a>
                <?php }
                if (@$access['advance_history'] == 1) { ?>
                    <a href="#" class="btn btn-primary px-4" onClick="javascript:location.replace('?p=advance-history')"
                       title="Advance Records" data-toggle="tooltip"><i class="fal fa-table"></i> <span class="text">Advance Records</span>
                    </a>
                <?php } ?>
            </div>
        </div>

        <div class="table-responsive datatable-buttons">
            <table class="table table-striped datatable-btn" style="font-size: 12px">
                <?php if (!isset($_POST['filter-payroll'])) { ?>
                    <caption>Table displaying current month report(s)</caption>
                <?php } else if (isset($_POST['dept']) && $_POST['dept'] != "") {
                    $dept = getDept($_POST['dept']);
                    ?>
                    <caption style="margin-bottom: 10px;">
                        <strong>Viewing</strong>:
                        <?php echo $dept['dept']; ?> Department |
                        <small>[ <a href="?p=payroll">View All</a> ]</small>
                    </caption>
                <?php } else { ?>
                    <caption>Currently viewing filtered: [ <a href="?p=payroll">Reset Filter</a> ]</caption>
                <?php } ?>
                <thead>
                <tr>
                    <th>#</th>
                    <th> Staff ID</th>
                    <th> Full Name</th>
                    <th>Gender</th>
                    <th>Department</th>
                    <th>Payee <?php echo $currency; ?></th>
                    <th> Basic Salary
                        <small>Payee Inc</small>
                        <?php echo $currency; ?>
                    </th>
                    <th> Advance Collected <?php echo $currency; ?></th>
                    <th> Net Balance <?php echo $currency; ?></th>
                </tr>
                </thead>
                <tbody>
                <?php
                $index = 0;
                $total_salary = 0;
                $total_advance = 0;
                $total_net = 0;
                $total_payee = 0;

                while ($dn = dbFetchAssoc($payroll_result)): $index++;

                    $dept = getDept($dn['dept']);

                    if (isset($_POST['filter-payroll'])) {
                        if ($start != "" && $stop != "") {
                            $get_advance = dbFetchAssoc(dbQuery("SELECT SUM(amount_paid) as amount_paid FROM app_payroll_advance WHERE emp_id = '" . $dn['id'] . "' AND collection_date >= '$start' AND collection_date <= '$stop' "));
                        } else {
                            $get_advance = dbFetchAssoc(dbQuery("SELECT SUM(amount_paid) as amount_paid FROM app_payroll_advance WHERE emp_id = '" . $dn['id'] . "'"));
                        }
                    } else {
                        $get_advance = dbFetchAssoc(dbQuery("SELECT SUM(amount_paid) as amount_paid FROM app_payroll_advance WHERE emp_id = '" . $dn['id'] . "' AND MONTH(collection_date) = MONTH(CURRENT_TIMESTAMP)"));
                    }
                    //salary computation
                    $salary = $dn['basic_salary'] - ($dn['basic_salary'] * ($dn['payee'] / 100));
                    $total_payee = $total_payee + ($dn['basic_salary'] * ($dn['payee'] / 100));
                    $total_salary = $total_salary + $salary;
                    $total_advance = $total_advance + $get_advance['amount_paid'];
                    $total_net = ($total_salary - $total_advance);

                    ?>
                    <tr class="data-btn">
                        <td> <?php echo $index; ?> </td>
                        <td> <?php echo $dn['emp_id'] ?> </td>
                        <td> <?php echo $dn['fname'] . ' ' . $dn['sname'] . ' ' . $dn['oname'] ?> </td>
                        <td> <?php echo $dn['gender'] ?> </td>
                        <td> <?php echo $dept['dept'] ?> </td>
                        <td><?php echo number_format(($dn['basic_salary'] * ($dn['payee'] / 100)), 2); ?></td>
                        <td> <?php echo number_format($salary, 2); ?> </td>
                        <td><?php echo number_format($get_advance['amount_paid'], 2); ?></td>
                        <td> <?php echo number_format($salary - $get_advance['amount_paid'], 2); ?> </td>
                    </tr>
                <?php endwhile ?> </tbody>
                <tfoot>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th class="text-right">TOTAL <?php echo $currency; ?></th>
                <th><?php echo number_format($total_payee, 2) ?></th>
                <th><?php echo number_format($total_salary, 2) ?></th>
                <th><?php echo number_format($total_advance, 2) ?></th>
                <th><?php echo number_format($total_net, 2) ?></th>
                </tfoot>
            </table>
        </div>
    </div>
</div>
