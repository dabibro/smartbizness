<table id="example2" class="table table-bordered table-hover">
    <thead>
    <tr>
        <th>Staff ID</th>
        <th>Full Name</th>
        <th>Gender</th>
        <th>Phone Number</th>
        <th>Department</th>
        <th>Designation</th>
    </tr>
    </thead>
    <tbody>
    <tr>
        <td>Trident</td>
        <td>Internet
            Explorer 4.0
        </td>
        <td>Win 95+</td>
        <td> 4</td>
        <td>X</td>
        <td>X</td>
    </tr>
    <tr>
        <td>Trident</td>
        <td>Internet
            Explorer 5.0
        </td>
        <td>Win 95+</td>
        <td>5</td>
        <td>C</td>
        <td>X</td>

    </tr>

    <tr>
        <td>Other browsers</td>
        <td>All others</td>
        <td>-</td>
        <td>-</td>
        <td>U</td>
        <td>X</td>
    </tr>
    </tbody>
    <tfoot>

    </tfoot>
</table>
                  