<div class="card card-primary card-outline card-outline-tabs">
    <div class="card-header p-0 border-bottom-0">
        <ul class="nav nav-tabs" id="manage-staff-tabs" role="tablist">
            <li class="nav-item">
                <a class="nav-link active" id="tabs-staff-list-tabs" data-toggle="pill" href="#staff-list-tab"
                   role="tab" aria-controls="staff-list-tab" aria-selected="true">Staff List</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" id="tabs-create-new-tabs" data-toggle="pill" href="#create-new-tab" role="tab"
                   aria-controls="create-new-tab" aria-selected="false">New Staff</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" id="tabs-staff-payroll-tab" data-toggle="pill" href="#staff-payroll-tab" role="tab"
                   aria-controls="staff-payroll-tab" aria-selected="false">Staff Payroll</a>
            </li>

            <li class="nav-item">
                <a class="nav-link" id="tabs-department-tab" data-toggle="pill" href="#department-tab" role="tab"
                   aria-controls="department-tab" aria-selected="false">Department</a>
            </li>

        </ul>
    </div>
    <div class="card-body">
        <div class="tab-content" id="manage-staff-tabContent">
            <div class="tab-pane fade" id="staff-list-tab" role="tabpanel" aria-labelledby="tabs-staff-list-tabs">
                <?php require_once "inc/staff-list.php"; ?>

            </div>
            <div class="tab-pane fade active show" id="create-new-tab" role="tabpanel"
                 aria-labelledby="tabs-create-new-tab">
                <?php require_once "inc/new-staff.php"; ?>

            </div>
            <div class="tab-pane fade" id="staff-payroll-tab" role="tabpanel" aria-labelledby="tabs-staff-payroll-tab">
                <?php require_once "inc/staff-payroll.php"; ?>
            </div>

            <div class="tab-pane fade" id="department-tab" role="tabpanel" aria-labelledby="tabs-department-tab">
                <?php require_once "inc/department.php"; ?>

            </div>

        </div>
    </div>
    <!-- /.card -->
</div>
