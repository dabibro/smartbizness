<style>
    .user-info-tbl .fal {
        width: 16px;
        position: relative;
        margin-right: 3px;
        text-align: center;
        font-size: 1rem;
    }

    .note-editable {
        min-height: 210px !important;
        max-height: 210px !important;
    }

    .note-editor {
        margin-bottom: 0;
    }

    .PHPPagination {
        margin-bottom: 0;
    }
</style>
<?php
@$getView = explode('news/', $url);
if (isset($getView[1])) {
    @$view = 'news/';
}
if (isset($view) && @$view === "news/"):
    $default = "1 ";
    $condition = $default;
    if (isset($_POST['filterRequest']) && $_POST['filterRequest'] !== null):
        $filterParam = $_POST['filterRequest'];
        if ($filterParam['search'] != ""):
            $condition = "";
            $search_query = trim($filterParam['search']);
            $condition = $default . "AND brief_description LIKE '%" . $search_query . "%'";
            $condition .= "OR " . $default . " AND contents LIKE '%" . $search_query . "%' ";
            $condition .= "OR " . $default . " AND created_by LIKE '%" . $search_query . "%' ";
            $condition .= "OR " . $default . " AND created_on LIKE '%" . $search_query . "%' ";
        else:
            $creator = @$filterParam['created_by'];
            $start_date = @$filterParam['start_date'];
            $end_date = @$filterParam['end_date'];
            if ($creator != ""):
                $condition .= " AND created_by = '$creator'";
            endif;
            if ($start_date != "" && $end_date != ""):
                $condition .= " AND created_on BETWEEN '$start_date' AND DATE_ADD('$end_date', INTERVAL 1 DAY)";
            endif;
        endif;
    endif;
    $paginate_exp = explode('?page=', $url);
    if (isset($paginate_exp[1]) && $paginate_exp[1] != ""):
        $ipp_exp = explode('&ipp=', $paginate_exp[1]);
        if (isset($ipp_exp[0]) && $ipp_exp[0] != ""):
            define('page', $ipp_exp[0]);
        else:
        endif;
        if (isset($ipp_exp[1]) && $ipp_exp[1] != ""):
            define('ipp', $ipp_exp[1]);
        else:
        endif;
    else:
        define('page', '');
        define('ipp', '');
    endif;
    define('self', '#/news/');
    $pages = new Paginator_Class;
    if (ipp != ""):
        $pages->default_ipp = ipp;
    else:
        $pages->default_ipp = 10;
    endif;
    $sql_forms = Data_Access::execSQL("SELECT * FROM " . $app->dbScheme . ".app_announcements WHERE " . $condition . " ");
    @$pages->items_total = $sql_forms['dataArray']->num_rows;
    $pages->mid_range = 4;
    $pages->paginate();

    $sql = "SELECT * FROM " . $app->dbScheme . ".app_announcements WHERE  " . $condition . " ORDER BY created_on DESC" . $pages->limit . " ";
    if (!($result = Data_Access::execSQL($sql))) {
        die(mysqli_error());
    } else {
        @$recordsArray = Data_Access::fetchAssoc($result['dataArray'])['dataArray'];
    }
    ?>
    <div class="card elevation-2">
        <div class="card-header px-2 pt-2 pb-1">
            <div class="card-title text-muted"><i class="fal fa-newspaper"></i> Announcements</div>
        </div>
        <div class="card-body p-2">
            <ul class="nav ml-auto modules-menu mb-2">
                <li class="nav-item order-column order-1 order-lg-0 order-md-0 rw-100">
                    <?php if (@$filterParam != null): ?>
                        <span class="nav-link bg-transparent">Currently viewing filter announcement(s) [ <a
                                    href="javascript:void(0);"
                                    onclick="fetchURL('');"
                                    class="small">Reset Filter</a> ]
                        </span>
                    <?php else: ?>
                        <span class="nav-link bg-transparent">Current viewing all announcement(s)</span>
                    <?php endif; ?>
                </li>
                <li class="nav-item m-0 ml-md-auto ml-lg-auto app-collapse rw-100">
                    <div class="form-group mb-1">
                        <div class="input-group input-group-sm">
                            <input type="search" class="form-control form-control-sm border-right-0" name="search"
                                   placeholder="Search keyword..."
                                   style="border-radius: 0;" form="announcement-filter">
                            <div class="btn-group">
                                <button class="btn mr-2 btn-default btn-sm pr-2" form="announcement-filter"
                                        style="height: 31px" type="button"
                                        onclick="javascript:$('#appFilterBtn').click();">
                                    <i
                                            class="fal fa-search m-0"
                                            style="font-size: 0.70rem;"></i>
                                </button>
                                <a class="nav-link dropdown-toggle d-block" data-toggle="collapse"
                                   href="#collapseSalesFilter"
                                   aria-expanded="false" aria-controls="collapseSalesFilter">
                                    <i class="fal fa-filter"></i><span class="d-none d-lg-inline d-md-inline"> Advance Filter<span
                                                class="caret"></span></span>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="collapse collapse-container right" id="collapseSalesFilter">
                        <div class="card-body elevation-1 bg-light left p-3">
                            <form method="post" action="#/news/" id="announcement-filter">

                                <label for="" class="small text-muted">Transaction Date Range</label>
                                <div class="row">
                                    <div class="col-6">
                                        <div class="form-group mb-0">
                                            <label for="">Start Date</label>
                                            <input type="text" name="start_date"
                                                   class="form-control form-control-sm datepicker"
                                                   placeholder="Start Date">
                                        </div>
                                    </div>
                                    <div class="col-6">
                                        <div class="form-group mb-0">
                                            <label for="">End Date</label>
                                            <input type="text" name="end_date"
                                                   class="form-control form-control-sm datepicker"
                                                   placeholder="End Date">
                                        </div>
                                    </div>
                                </div>
                                <input type="hidden" readonly name="delete_status" value="0">
                                <hr class="my-3">
                                <button class="btn btn-default btn-sm btn-block" id="appFilterBtn">
                                    <i class="fal fa-check-circle"></i>
                                    Submit
                                </button>
                                <input type="hidden" readonly name="view"
                                       value="/#/news/">
                            </form>
                        </div>
                    </div>
                </li>
            </ul>

            <div class="table-responsive">
                <ul class="products-list product-list-in-card">
                    <?php if (@$recordsArray == null): ?>
                        <li class="item bg-transparent">
                            <div class="text-center">
                                <h3 class="text-muted"><i class="fal fa-newspaper fa-2x"></i></h3>
                                <h6>No Announcement!</h6>
                            </div>
                        </li>
                    <?php else:
                        foreach (@$recordsArray as $ann): ?>
                            <li class="item bg-transparent">
                                <div class="product-info mx-4">
                                    <a href="javascript:void(0)"
                                       onclick="AppModalLoader({modalId:'ModuleModal', modalSize:'modal-lg', modalTitle:'Announcement', required:'../app-messaging/inc/announcement', modalRequest:{rec_id:'<?php echo $ann['id']; ?>'}, afterEvent:''});"
                                       class="product-title"><?php echo @$app->truncateContent(@$ann['brief_description'], 45) ?>
                                    </a>
                                    <div>
                                        <?php echo @$app->truncateContent(strip_tags(htmlspecialchars_decode(@$ann['contents'])), 320) ?>
                                    </div>
                                    <div class="small text-muted"><label class="m-0">Created
                                            by: </label> <?php echo @$ann['created_by']; ?>
                                        | <?php echo @$app->formatDate(@$ann['created_on']); ?>
                                    </div>
                                </div>
                            </li>
                        <?php endforeach;
                    endif; ?>


                </ul>

            </div>

        </div>
        <div class="card-footer text-center">
            <div class="row mx-0">
                <div class="col-12 pl-0 paddingLeft pagerfwt">
                    <?php if ($pages->items_total > 0) { ?>
                        <?php echo $pages->display_pages(); ?>
                        <?php echo $pages->display_items_per_page(); ?>
                        <?php echo $pages->display_jump_menu(); ?>
                    <?php } ?>
                </div>
            </div>
        </div>
    </div>
<?php else: ?>

    <div class="row">
        <!--logged user information-->
        <div class="col-lg-7 order-column order-1 order-lg-0">
            <table border="0" class="table table-striped table-borderless table-sm user-info-tbl"
                   style="font-size: 0.85rem !important;">
                <tbody class="card-body">
                <tr>
                    <th scope="row"><i class="fal fa-user"></i> <span>Full Name:</span></th>
                    <td>
                        <?php echo trim(@$auth['firstname'] . ' ' . @$auth['lastname']); ?>
                        <small class="text-muted">[
                            <?php echo @$auth['username'] ?> ]
                        </small>
                    </td>
                </tr>
                <?php if (@$auth['contact_email'] != ""): ?>
                    <tr>
                        <th scope="row"><i class="fal fa-envelope"></i> <span>Email Address:</span></th>
                        <td>  <?php echo @$auth['contact_email'] ?>  </td>
                    </tr>
                <?php endif; ?>
                <tr>
                    <th scope="row"><i class="fal fa-phone-square"></i> <span>Phone Number:</span></th>
                    <td>  <?php echo @$auth['contact_phone'] ?>  </td>
                </tr>
                <tr>
                    <th scope="row"><i class="fal fa-desktop"></i> <span>System Info:</span></th>
                    <td>
                        <?php @$exp_logonWorkstation = json_decode(@$auth['logon_workstation'], true);
                        echo "Device Name: " . @$exp_logonWorkstation['device_name']; ?> | IP:
                        <?php echo @$exp_logonWorkstation['ip'] . ' <small>[ Browser: ' . @$exp_logonWorkstation['browser'] . ' ]</small>'; ?>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><i class="fal fa-clock"></i> <span>Last Login:</span></th>
                    <td>
                        <?php echo @$auth['last_login']; ?>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><i class="fal fa-user-clock"></i> <span>Last Seen:</span></th>
                    <td>
                        <?php echo @$auth['last_seen']; ?>
                    </td>
                </tr>
                </tbody>
            </table>
            <div class="row mb-1">
                <div class="col ml-auto text-right">
                    <button type="submit" class="btn btn-default btn-sm" form="iNote"
                            title="Save Note"><i class="fal fa-save"></i> Save Note
                    </button>
                    <button type="button" name="button" class="btn btn-danger btn-sm"
                            onclick='javascript: var obj = "<?php echo urlencode('"className":"Module_Class","functionName":"deleteRecord","tbl_scheme":"app_inotes","pk":{"user_id":"' . @$auth['user_id'] . '"},"callback":{"type":"self","redirect":""},"notification":{"message":"Are you sure to clear notes/reminder?","title":"Warning"}'); ?>";  moduleRequest(obj);'>
                        <i
                                class="fal fa-eraser"></i> Clear Note
                    </button>
                </div>
            </div>
            <form method="post" class="AppForm elevation-2 mb-4" id="iNote">
                <div id="ModuleResponse"></div>
                <?php
                @$getNote = Data_Access::fetchAssoc(Data_Access::execSQL("SELECT * FROM " . @$app->dbScheme . ".app_inotes WHERE user_id = '" . @$auth['user_id'] . "'")['dataArray'])['dataArray'][0];
                ?>
                <input type="hidden" name="className" value="Module_Class" readonly>
                <?php if (@$getNote !== null): ?>
                    <input type="hidden" name="functionName" value="updateRecord" readonly>
                    <input type="hidden" name="pk" value="<?php echo @$auth['user_id']; ?>" readonly>
                    <input type="hidden" name="pkField" value="user_id" readonly>
                <?php else: ?>
                    <input type="hidden" name="functionName" value="createRecord" readonly>
                <?php endif; ?>
                <input type="hidden" name="callback[type]" value="self" readonly>
                <input type="hidden" name="callback[redirect]" value="" readonly>
                <input type="hidden" name="tbl_scheme" value="app_inotes" readonly>
                <input type="hidden" name="user_id" value="<?php echo @$auth['user_id']; ?>" readonly>
                <textarea class="text-editor" name="notes"><?php echo @$getNote['notes']; ?></textarea>
            </form>
        </div>
        <!--INote Keeping-->
        <div class="col-lg-5 ">
            <div class="card elevation-2">
                <div class="card-header px-2 pt-2 pb-1">
                    <div class="card-title text-muted"><i class="fal fa-bullhorn"></i> Announcements</div>
                </div>
                <div class="card-body p-0"
                     style="min-height: 180px;max-height: 180px; overflow-x: hidden; overflow-y: auto">
                    <?php
                    @$annSQL = Data_Access::execSQL("SELECT * FROM " . @$app->dbScheme . ".app_announcements WHERE active_status = 1 ORDER BY created_on DESC LIMIT 6");
                    if (@$annSQL):
                        @$annArray = Data_Access::fetchAssoc($annSQL['dataArray'])['dataArray'];
                    endif;
                    ?>
                    <ul class="products-list product-list-in-card">
                        <?php if (@$annArray == null): ?>
                            <li class="item bg-transparent">
                                <div class="text-center">
                                    <h3 class="text-muted"><i class="fal fa-bullhorn fa-2x"></i></h3>
                                    <h6>No Announcement!</h6>
                                </div>
                            </li>
                        <?php else:
                            foreach (@$annArray as $ann): ?>
                                <li class="item">
                                    <div class="product-info mx-4" style="font-size: 0.78rem !important;">
                                        <a href="javascript:void(0)"
                                           onclick="AppModalLoader({modalId:'ModuleModal', modalSize:'modal-lg', modalTitle:'Announcement', required:'../app-messaging/inc/announcement', modalRequest:{rec_id:'<?php echo $ann['id']; ?>'}, afterEvent:''});"
                                           class="product-title"><?php echo @$app->truncateContent(@$ann['brief_description'], 45) ?>
                                        </a>
                                        <div>
                                            <?php echo @$app->truncateContent(strip_tags(htmlspecialchars_decode(@$ann['contents'])), 130) ?>
                                        </div>
                                        <div class="small text-muted"><label class="m-0">Created
                                                by: </label> <?php echo @$ann['created_by']; ?>
                                            | <?php echo @$app->formatDate(@$ann['created_on']); ?>
                                        </div>
                                    </div>
                                </li>
                            <?php endforeach;
                        endif; ?>


                    </ul>
                </div>
                <div class="card-footer text-center">
                    <a href="javascript:void(0)" onclick="location.replace('#/news/'); fetchURL('')" class="uppercase">View
                        All Announcements</a>
                </div>
            </div>
        </div>
    </div>
<?php endif; ?>
<input type="hidden" value="<?php echo @$app->dashboard . 'modules/manage-app/'; ?>" id="ModulePath" readonly>
<script src="<?php echo @$app->dashboard . 'modules/manage-app/'; ?>js.js"></script>
<script>
    var modulePath = $("#ModulePath").val();
    $("#appFilterBtn").click(function (e) {
        e.preventDefault();
        var filterRequest = ($("#" + this.form.id).serializeArray());
        var obj = [];
        $.each(filterRequest, function (i, field) {
            obj.push('"' + field.name + '"' + ":" + '"' + field.value + '"' + "");
        });
        var moduleRequest = ('{' + decodeURIComponent(obj) + '}');
        var objJSON = JSON.parse(moduleRequest);
        //return false;
        AppRequestPath = "handlers/AppAjaxRequest.php"
        $.post(AppRequestPath, {
                filterRequest: objJSON,
                AppRequest: encodeURIComponent(objJSON['view'])
            },
            function (response) {
                // if (confirmation != 1) {
                $("#app-loader").html(response);
                //} else {
                //alert(response);
                //return false;
                response = JSON.parse(response);
                var success = response['success'];
                var message = response['message'];
                if (success && success == 1) {
                    $("#ModuleResponse").html(message);
                    //$("#" + formId + ' .actionButton').html(actionButton);
                    if (response['callback'] === 'self') {
                        //  $("#" + formId)[0].reset();
                        fetchURL("");
                    }
                } else {
                    //$("#" + formId + " #ModuleResponse").html(data);
                }
                //}
            });
    });
</script>


