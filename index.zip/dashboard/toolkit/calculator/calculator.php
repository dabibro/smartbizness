<?php
$PATH = $app->webRoot . str_ireplace($app->srvRoot, '', str_ireplace("\\", "/", __DIR__));
?>
<link rel="stylesheet" href="<?php echo $PATH ?>/css.css">
<script src="<?php echo $PATH ?>/jquery.min.js"></script>
<script src="<?php echo $PATH ?>/js.js"></script>
<div class="calculator">
    <p>SmartBizness Calculator</p>
    <div class="calc-row">
        <div class="screen">0123456789</div>
    </div>
    <hr>
    <div class="calc-row">
        <div class="button">C</div>
        <div class="button">CE</div>
        <div class="button backspace">back</div>
        <div class="button plus-minus">+/-</div>
        <div class="button">%</div>
    </div>

    <div class="calc-row">
        <div class="button">7</div>
        <div class="button">8</div>
        <div class="button">9</div>
        <div class="button divice">/</div>
        <div class="button root">sqrt</div>
    </div>

    <div class="calc-row">
        <div class="button">4</div>
        <div class="button">5</div>
        <div class="button">6</div>
        <div class="button multiply">*</div>
        <div class="button inverse">1/x</div>
    </div>

    <div class="calc-row">
        <div class="button">1</div>
        <div class="button">2</div>
        <div class="button">3</div>
        <div class="button">-</div>
        <div class="button pi">pi</div>
    </div>

    <div class="calc-row">
        <div class="button zero">0</div>
        <div class="button decimal">.</div>
        <div class="button">+</div>
        <div class="button equal">=</div>
    </div>
</div>
