<nav aria-label="breadcrumb" role="navigation" class="pt-0 mt-2 mb-3 ">
    <ol class="breadcrumb float-sm-right">
        <li class="breadcrumb-item"><a href="#/" onclick="fetchURL(this.href);"> <span> Home </span></a>
        </li>
        <?php
        if (isset($AppModuleBreadcrumb) && $AppModuleBreadcrumb != NULL):
            foreach ($AppModuleBreadcrumb as $breadcrumb => $link):
                ?>
                <li class="breadcrumb-item">
                    <a href="<?php if (@$link !== ""):echo $link; else: echo "#/" . $AppModuleRequest; endif; ?>" <?php if (@$link !== ""): echo "fetchURL(this.href)"; endif; ?> ><?php echo @$breadcrumb; ?></a>
                </li>
            <?php endforeach;
        endif;
        ?>

    </ol>
</nav>
