<?php if (@$modalRequest !== 1): ?>
    <script src="<?php echo $app->vendors; ?>datatable/DataTables-1.10.18/js/jquery.dataTables.min.js"></script>
    <script src="<?php echo $app->vendors; ?>datatable/DataTables-1.10.18/js/dataTables.bootstrap4.min.js"></script>
    <script src="<?php echo $app->vendors; ?>datatable/Buttons-1.5.2/js/dataTables.buttons.min.js"></script>
    <script src="<?php echo $app->vendors; ?>datatable/Buttons-1.5.2/js/buttons.bootstrap4.min.js"></script>
    <script src="<?php echo $app->vendors; ?>datatable/Buttons-1.5.2/js/buttons.flash.min.js"></script>
    <script src="<?php echo $app->vendors; ?>datatable/Buttons-1.5.2/js/buttons.html5.min.js"></script>
    <script src="<?php echo $app->vendors; ?>datatable/Buttons-1.5.2/js/buttons.print.min.js"></script>
    <script src="<?php echo $app->vendors; ?>datatable/Responsive-2.2.2/js/dataTables.responsive.min.js"></script>
    <script src="<?php echo $app->vendors; ?>datatable/Responsive-2.2.2/js/responsive.bootstrap4.min.js"></script>
    <script src="<?php echo $app->vendors; ?>datatable/pdfmake-0.1.36/pdfmake.min.js"></script>
    <script src="<?php echo $app->vendors; ?>datatable/pdfmake-0.1.36/vfs_fonts.js"></script>
<?php endif; ?>
<script>
    $(document).ready(function () {
        <?php if(@$modalRequest == 1): ?>

        $(".dataTables_filter  :input").attr('placeholder', 'Search');

        $('.dataTables_Modal').dataTable({
            "lengthMenu": [
                [10, 25, 50, -1],
                [10, 25, 50, "All"]
            ],
            order: false,
            sort: false,
            language: {
                paginate: {
                    next: '<i class="fal fa-angle-double-right">',
                    previous: '<i class="fal fa-angle-double-left">'
                }
            }
        });
        $('.dataTables-Sort_Modal').dataTable({
            "lengthMenu": [
                [10, 25, 50, -1],
                [10, 25, 50, "All"]
            ],
            order: false,
            language: {
                paginate: {
                    next: '<i class="fal fa-angle-double-right">',
                    previous: '<i class="fal fa-angle-double-left">'
                }
            }
        });

        //datatable buttons
        $('.datatable-btn_Modal').dataTable({
            dom: "lfBrtip",
            buttons: [
                {
                    extend: "copy",
                    className: "btn-dark",
                    text: '<i class="fal fa-copy"></i> Copy',
                    titleAttr: 'Copy',
                    footer: true,
                    title: $('.print-title').text(),
                    orientation: 'landscape',
                    pageSize: 'A4'
                },
                {
                    extend: "csv",
                    className: "btn-dark",
                    text: '<i class="fal fa-file-csv"></i> CSV',
                    titleAttr: 'CSV',
                    footer: true
                },
                //{
                //  extend: "excel",
                //  className: "btn-sm"
                //},
                {
                    responsive: false,
                    extend: "pdfHtml5",
                    className: "btn-dark",
                    text: '<i class="fal fa-file-pdf"></i> PDF',
                    titleAttr: 'PDF',
                    footer: true,
                    title: $('.print-title').text(),
                    orientation: 'landscape',
                    pageSize: 'A4'
                },
                {
                    extend: "print",
                    className: "btn-dark",
                    text: '<i class="fal fa-print"></i> Print',
                    titleAttr: 'Print',
                    footer: true,
                    title: $('.print-title').text(),
                    orientation: 'landscape',
                    pageSize: 'A4'
                },
            ],
            "lengthMenu": [[10, 25, 50, 100, -1], [10, 25, 50, 100, "All"]],
            language: {
                paginate: {
                    next: '<i class="fal fa-angle-double-right m-0">',
                    previous: '<i class="fal fa-angle-double-left m-0">',
                }
            }

        });

        //datatable search only
        $('.datatables-search_Modal').dataTable({
            paging: false,
            language: {
                paginate: {
                    next: '<i class="fal fa-angle-double-right">',
                    previous: '<i class="fal fa-angle-double-left">'
                }
            }
        });

        <?php else:?>

        $(".dataTables_filter  :input").attr('placeholder', 'Search');

        $('.dataTables').dataTable({
            "lengthMenu": [
                [10, 25, 50, -1],
                [10, 25, 50, "All"]
            ],
            order: false,
            sort: false,
            language: {
                paginate: {
                    next: '<i class="fal fa-angle-double-right">',
                    previous: '<i class="fal fa-angle-double-left">'
                }
            }
        });
        $('.dataTables-Sort').dataTable({
            "lengthMenu": [
                [10, 25, 50, -1],
                [10, 25, 50, "All"]
            ],
            order: false,
            language: {
                paginate: {
                    next: '<i class="fal fa-angle-double-right">',
                    previous: '<i class="fal fa-angle-double-left">'
                }
            }
        });

        //datatable buttons
        $('.datatable-btn').dataTable({
            dom: "lfBrtip",
            buttons: [
                {
                    extend: "copy",
                    className: "btn-dark",
                    text: '<i class="fal fa-copy"></i> Copy',
                    titleAttr: 'Copy',
                    footer: true,
                    title: $('.print-title').text(),
                    orientation: 'landscape',
                    pageSize: 'A4'
                },
                {
                    extend: "csv",
                    className: "btn-dark",
                    text: '<i class="fal fa-file-csv"></i> CSV',
                    titleAttr: 'CSV',
                    footer: true
                },
                //{
                //  extend: "excel",
                //  className: "btn-sm"
                //},
                {
                    responsive: false,
                    extend: "pdfHtml5",
                    className: "btn-dark",
                    text: '<i class="fal fa-file-pdf"></i> PDF',
                    titleAttr: 'PDF',
                    footer: true,
                    title: $('.print-title').text(),
                    orientation: 'landscape',
                    pageSize: 'A4'
                },
                {
                    extend: "print",
                    className: "btn-dark",
                    text: '<i class="fal fa-print"></i> Print',
                    titleAttr: 'Print',
                    footer: true,
                    title: $('.print-title').text(),
                    orientation: 'landscape',
                    pageSize: 'A4'
                },
            ],
            "lengthMenu": [[10, 25, 50, 100, -1], [10, 25, 50, 100, "All"]],
            language: {
                paginate: {
                    next: '<i class="fal fa-angle-double-right m-0">',
                    previous: '<i class="fal fa-angle-double-left m-0">',
                }
            }

        });

        //datatable search only
        $('.datatables-search').dataTable({
            paging: false,
            language: {
                paginate: {
                    next: '<i class="fal fa-angle-double-right">',
                    previous: '<i class="fal fa-angle-double-left">'
                }
            }
        });

        <?php endif;?>
    });
</script>