<?php
//------------------------------------------------------
if (file_exists("../helpers/config/config.inc.php")):
    require "../helpers/config/config.inc.php";
endif;
require "../helpers/handlers/app_autoloader.php";
//------------------------------------------------------
$appAuth = new Auth_Access;
$auth = $appAuth->AppAuthChecker();
$app = new AppConfig;
$biz = new BIZConfig();
$SMBEngine = new SMBEngine();

?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>SmartBizness | Dashboard</title>
    <link rel="icon" href="<?php echo $app->webRoot; ?>favicon.png" type="image/x-icon">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="<?php echo $app->vendors; ?>bootstrap/css/bootstrap.min.css">-
    <link rel="stylesheet" href="<?php echo $app->vendors; ?>fontawesome/css/all.min.css">
    <link rel="stylesheet" href="<?php echo $app->vendors; ?>jquery-ui/jquery-ui.min.css">
    <link rel="stylesheet"
          href="<?php echo $app->vendors; ?>tempusdominus-bootstrap-4/css/tempusdominus-bootstrap-4.min.css">
    <link rel="stylesheet" href="<?php echo $app->vendors; ?>ekko-lightbox/ekko-lightbox.css">
    <link rel="stylesheet" href="<?php echo $app->vendors; ?>icheck-bootstrap/icheck-bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo $app->vendors; ?>animate/animate.min.css">
    <link rel="stylesheet" href="<?php echo $app->vendors; ?>overlayScrollbars/css/OverlayScrollbars.min.css">
    <link rel="stylesheet" href="<?php echo $app->vendors; ?>daterangepicker/daterangepicker.css">
    <link rel="stylesheet" href="<?php echo $app->vendors; ?>timepicker/bootstrap-timepicker.min.css">
    <link rel="stylesheet" href="<?php echo $app->vendors; ?>select2/css/select2.min.css">
    <link rel="stylesheet" href="<?php echo $app->vendors; ?>select2-bootstrap4-theme/select2-bootstrap4.min.css">
    <link rel="stylesheet" href="<?php echo $app->vendors; ?>summernote/summernote-bs4.css">
    <link rel="stylesheet"
          href="<?php echo $app->vendors; ?>datatable/DataTables-1.10.18/css/dataTables.bootstrap4.min.css">
    <link rel="stylesheet" href="<?php echo $app->vendors; ?>datatable/Buttons-1.5.2/css/buttons.bootstrap4.min.css">
    <link rel="stylesheet" href="<?php echo $app->vendors; ?>croppie/croppie.css">
    <link rel="stylesheet" href="<?php echo $app->assets; ?>css/bootstrap-datepicker3.css">
    <link rel="stylesheet" href="<?php echo $app->assets; ?>css/bootstrap-iso.css">
    <link rel="stylesheet" href="<?php echo $app->assets; ?>css/adminlte.min.css">
    <link rel="stylesheet" href="<?php echo $app->assets; ?>css/dashboard.css">
</head>
<body class="hold-transition sidebar-mini layout-fixed" id="dashboard-page">
<div class="wrapper">
    <?php require $app->navbar; ?>
    <?php require $app->sidebar; ?>
    <div class="content-wrapper" id="app-loader">
    </div>
    <?php require $app->footer; ?>
    <?php require $app->asidepanel; ?>

</div>
<div id="AppLoader" class="hide">
    <div id="page-loader" class="text-center content animated fadeIn">
        <img src="<?php echo $app->assets; ?>img/startup-logo.png" alt="SmartBizness" width="160">
        <h6 class="font-weight-bold my-1 please-wait">
            <img src="<?php echo $app->assets; ?>img/h_loader.gif" alt="Loader" width="260"><br>
            <div class="mt-2">Please Wait, Initializing Module...</div>
        </h6>
    </div>
</div>
<div id="trackerResponses"></div>
<input type="hidden" id="SMBTracker" value="<?php echo(@$biz->gps_tracker['SMBTracker']); ?>">
<script src="<?php echo $app->vendors; ?>jquery/jquery.min.js"></script>
<script src="<?php echo $app->vendors; ?>jquery-ui/jquery-ui.min.js"></script>
<script>
    $.widget.bridge('uibutton', $.ui.button)
</script>
<script src="<?php echo $app->vendors; ?>bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="<?php echo $app->vendors; ?>chart.js/Chart.min.js"></script>
<script src="<?php echo $app->vendors; ?>sparklines/sparkline.js"></script>
<script src="<?php echo $app->vendors; ?>moment/moment.min.js"></script>
<script src="<?php echo $app->vendors; ?>daterangepicker/daterangepicker.js"></script>
<script src="<?php echo $app->vendors; ?>timepicker/bootstrap-timepicker.js"></script>
<script src="<?php echo $app->vendors; ?>select2/js/select2.full.min.js"></script>
<script src="<?php echo $app->vendors; ?>tempusdominus-bootstrap-4/js/tempusdominus-bootstrap-4.min.js"></script>
<script src="<?php echo $app->vendors; ?>summernote/summernote-bs4.min.js"></script>
<script src="<?php echo $app->vendors; ?>overlayScrollbars/js/jquery.overlayScrollbars.min.js"></script>
<script src="<?php echo $app->vendors; ?>croppie/croppie.min.js"></script>
<script src="<?php echo $app->assets; ?>js/adminlte.js"></script>
<script src="<?php echo $app->vendors; ?>ekko-lightbox/ekko-lightbox.min.js"></script>
<script src="<?php echo $app->assets; ?>js/bootstrap.validator.js"></script>
<script src="<?php echo $app->assets; ?>js/bootstrap-datepicker.min.js"></script>
<?php
$directory = ['../plugins/gps-tracker/' => 'gpsTrackerPath', '../plugins/messenger/' => 'messengerPath'];
$extension = '.js';
$varPath = "";
$varFiles = array();
foreach ($directory as $plugin_dir => $path_name):
    if (@file_exists($plugin_dir)):
        $varPath .= 'var ' . $path_name . ' = "' . $app->webRoot . str_replace('../', '', $plugin_dir) . '"; ';
        foreach (glob($plugin_dir . '*' . $extension) as $file):
            array_push($varFiles, $app->webRoot . str_replace('../', '', $file));
        endforeach;
    endif;
endforeach;
echo '<script>' . $varPath . '</script>';
foreach ($varFiles as $plugin_js):
    echo '<script src="' . $plugin_js . '"></script>';
endforeach;
?>
<script src="<?php echo $app->assets; ?>js/app.js"></script>
</body>
</html>