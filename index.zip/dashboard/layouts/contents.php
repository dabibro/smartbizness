<?php
/**
 * Created by DTMGS Limited.
 * User: Dauda Ibrahim
 * Date: 6/22/2020
 * Time: 4:27 PM
 * File: App Module Request Template
 */
if ($appSwitcher->AppAuth->AppAuthChecker() === NULL) {
    $exit = $appSwitcher->AppAuth->AppExit();
    if ($exit === 'exitApp'):
        echo '<script> location.replace("../")</script>';
    endif;
}
extract($AppRequest);
?>
<div class="content-header pb-2">
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-6">
                <h1 class="m-0 text-muted"><?php echo $AppModuleTitle; ?></h1>
            </div>
            <div class="col-sm-6">
                <?php require "../includes/breadcrumb.php"; ?>
            </div>
        </div>
    </div>
</div>
<section class="content">
    <div class="container-fluid px-2">
        <?php
        if (isset($AppModule) && $AppModule != NULL):
            require @$AppModule;
        endif;
        ?>
    </div>
</section>
<script>
    //----------------------------------------------------
    var AppDashboard = document.getElementById("dashboard-page");

    if (AppDashboard) {
        $('.text-editor').summernote();
        $('.select2').select2();
        $('[data-toggle="tooltip"]').tooltip({
            delay: {"hide": 500}
        });
        $('[data-toggle="popover"]').popover();
        $('.form-control').attr('autocomplete', 'off');
        $('.num').keyup(function () {
            this.value = this.value.replace(/[^0-9\.]/g, '');
        });
        var date_input = $('.datepicker'); //our date input has the name "date"
        var container = $('.bootstrap-iso form').length > 0 ? $('.bootstrap-iso form').parent() : "body";
        date_input.datepicker({format: 'yyyy-mm-dd', container: container, todayHighlight: true, autoclose: true,});
        $(".timepicker").timepicker();
        if (SMBTracker === '1') {
            var intVal = 1000;
            console.log(setInterval(SMSTrackerUpdate("CheckIn", ''), intVal));
        }

    }
</script>

<div class="modal fade animated zoomIn" id="ModuleModal" tabindex="-1" role="dialog">
    <div class="modal-dialog" role="document">
        <div class="modal-content card card-light border-0 elevation-2">
            <div class="modal-header card-header">
                <h6 class="modal-title mb-0"></h6>
                <button id="modal-close" type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div id="modal-response"></div>
                <div class="load-content"></div>
            </div>
        </div>
    </div>
</div>