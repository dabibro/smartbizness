<aside class="main-sidebar sidebar-light-gray-dark elevation-4 animated fadeInLeft">
    <!-- Sidebar -->
    <div class="sidebar">
        <!-- Sidebar user panel (optional) -->
        <div class="user-panel mt-2 mb-2 d-flex">
            <div class="image">
                <img src="<?php echo $app->uploads . 'passports/' . @$auth['passport']; ?>"
                     class="img-circle elevation-2"
                     alt="User Image" onerror="passport_handler(this);">
                <script>
                    function passport_handler(elem) {
                        elem.setAttribute('src', '<?php echo $app->uploads . 'passports/avatar.jpeg'; ?>');
                    }
                </script>
            </div>
            <div class="info" style="width: 100%">
                <div class=""><?php echo trim(@$auth['firstname'] . ' ' . @$auth['lastname']); ?>
                    <button class="position-absolute bg-transparent pointer border-0 text-muted" style="right:0"><i
                                class="fal fa-edit small" title="Edit Profile"
                                onclick="AppModalLoader({modalId:'ModuleModal', modalSize:'modal-lg', modalTitle:'My Profile', required:'../manage-users/inc/user_profile', afterEvent:'reloadApp()'});"></i>
                    </button>
                </div>
                <small style="font-size: 0.6rem" class="font-weight-bold text-muted">Last
                    Login: <?php echo @$SMBEngine->formatDate(@$auth['last_login']); ?></small>
            </div>
        </div>
        <!-- Sidebar Menu -->
        <nav class="mt-2 ">
            <ul class="nav nav-pills nav-sidebar flex-column app-menu" data-widget="treeview" role="menu"
                data-accordion="true">
                <li class="nav-header">People</li>
                <li class="nav-item has-treeview  menu-open">
                    <button type="button" class="nav-link">
                        <i class="nav-icon fal fa-users"></i>
                        <p>
                            Manage Users
                            <i class="right fas fa-angle-left"></i>
                        </p>
                    </button>
                    <ul class="nav nav-treeview">
                        <li class="nav-item">
                            <a href="#/create-user/" class="nav-link app-link">
                                <i class="fal fa-user-edit"></i>
                                <p>Create User</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="#/users-account/" class="nav-link app-link">
                                <i class="fal fa-user-circle"></i>
                                <p>Users Account</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="#/users-group/" class="nav-link app-link">
                                <i class="fal fa-users-cog"></i>
                                <p>Users Group</p>
                            </a>
                        </li>
                    </ul>
                </li>
                <li class="nav-item has-treeview menu-open">
                    <button href="#" class="nav-link">
                        <i class="nav-icon fal fa-user-friends"></i>
                        <p>
                            Manage Customers
                            <i class="right fas fa-angle-left"></i>
                        </p>
                    </button>
                    <ul class="nav nav-treeview">
                        <li class="nav-item">
                            <a href="#/customers/record/" class="nav-link app-link">
                                <i class="fal fa-file-plus"></i>
                                <p>Create Customer</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="#/customers/" class="nav-link app-link">
                                <i class="fal fa-file-user"></i>
                                <p>Customers Records</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="#/customers/accounts/" class="nav-link app-link">
                                <i class="fal fa-money-check"></i>
                                <p>Customers Accounts</p>
                            </a>
                        </li>
                    </ul>
                </li>
                <li class="nav-item has-treeview menu-open">
                    <button href="#" class="nav-link">
                        <i class="nav-icon fal fa-book-user"></i>
                        <p>
                            Manage Vendors
                            <i class="right fas fa-angle-left"></i>
                        </p>
                    </button>
                    <ul class="nav nav-treeview">
                        <li class="nav-item">
                            <a href="#/vendors/record/" class="nav-link app-link">
                                <i class="fal fa-file-edit"></i>
                                <p>Create Vendor</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="#/vendors/" class="nav-link  app-link">
                                <i class="fal fa-folder"></i>
                                <p>Vendors Records</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="#/vendors/accounts/" class="nav-link  app-link">
                                <i class="fal fa-money-check"></i>
                                <p>Vendors Accounts</p>
                            </a>
                        </li>
                    </ul>
                </li>
                <li class="nav-header">Stores</li>
                <li class="nav-item has-treeview menu-open">
                    <button href="#" class="nav-link">
                        <i class="nav-icon fal fa-store-alt"></i>
                        <p>
                            Manage Stores
                            <i class="right fas fa-angle-left"></i>
                        </p>
                    </button>
                    <ul class="nav nav-treeview">
                        <li class="nav-item">
                            <a href="#/create-store/" class="nav-link app-link">
                                <i class="fal fa-edit"></i>
                                <p>Create Store</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="#/stores/" class="nav-link app-link">
                                <i class="fal fa-store"></i>
                                <p>Stores List</p>
                            </a>
                        </li>
                    </ul>
                </li>
                <li class="nav-header">Inventory</li>
                <li class="nav-item has-treeview menu-open">
                    <button href="#" class="nav-link">
                        <i class="nav-icon fal fa-inventory"></i>
                        <p>
                            Manage Inventory
                            <i class="right fas fa-angle-left"></i>
                        </p>
                    </button>
                    <ul class="nav nav-treeview">
                        <li class="nav-item">
                            <a href="#/inventory/category/" class="nav-link app-link">
                                <i class="fal fa-folder-tree"></i>
                                <p>Inventory Category</p>
                            </a>
                            <a href="#/inventory/add-item/" class="nav-link app-link">
                                <i class="fal fa-plus-square"></i>
                                <p>Add Item</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="#/inventory/" class="nav-link app-link">
                                <i class="fal fa-th-list"></i>
                                <p>Products Inventory</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="#/inventory/transfer/" class="nav-link app-link">
                                <i class="fal fa-exchange-alt"></i>
                                <p>Stock Transfer</p>
                            </a>
                        </li>

                        <li class="nav-item">
                            <a href="#/inventory/import/" class="nav-link app-link">
                                <i class="fal fa-file-csv"></i>
                                <p>Import/Export Data (CSV)</p>
                            </a>
                        </li>
                    </ul>
                </li>
                <li class="nav-item has-treeview menu-open">
                    <button href="#" class="nav-link">
                        <i class="nav-icon fal fa-truck-loading"></i>
                        <p>
                            Purchase Order
                            <i class="right fas fa-angle-left"></i>
                        </p>
                    </button>
                    <ul class="nav nav-treeview">
                        <li class="nav-item">
                            <a href="#/purchase-order/order/" class="nav-link app-link">
                                <i class="fal fa-cart-plus"></i>
                                <p>Create/Receive Order</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="#/purchase-order/" class="nav-link app-link">
                                <i class="fal fa-chart-bar"></i>
                                <p>Purchase Orders History</p>
                            </a>
                        </li>
                    </ul>
                </li>
                <li class="nav-header">SALES</li>
                <li class="nav-item has-treeview menu-open">
                    <button href="#" class="nav-link">
                        <i class="nav-icon fal fa-cash-register"></i>
                        <p>
                            Manage Sales
                            <i class="right fas fa-angle-left"></i>
                        </p>
                    </button>
                    <ul class="nav nav-treeview">
                        <li class="nav-item">
                            <a href="#/sales-point/items/" class="nav-link app-link">
                                <i class="fal fa-table"></i>
                                <p>Products Record</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="#/sales-point/items/stocking/" class="nav-link app-link">
                                <i class="fal fa-boxes-alt"></i>
                                <p>Products Stocking</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="#/sales-point/sales-transacts/" class="nav-link app-link">
                                <i class="fal fa-chart-line"></i>
                                <p>Sales Transactions</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="#/sales-point/items/promo/" class="nav-link app-link">
                                <i class="fal fa-gifts"></i>
                                <p>Special Prices/Promo</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="#/sales-point/quotations/" class="nav-link app-link">
                                <i class="fal fa-file-invoice"></i>
                                <p>Manage Quotations</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="#/promo/" class="nav-link app-link">
                                <i class="fal fa-cog"></i>
                                <p>Sales Point Options</p>
                            </a>
                        </li>
                    </ul>
                </li>
                <!--
                <li class="nav-header hide">Finance</li>
                <li class="nav-item has-treeview hide">
                    <button href="#" class="nav-link">
                        <i class="nav-icon fal fa-coins"></i>
                        <p>
                            Manage Finance
                            <i class="right fas fa-angle-left"></i>
                        </p>
                    </button>
                    <ul class="nav nav-treeview">
                        <li class="nav-item">
                            <a href="#/expenses/" class="nav-link app-link">
                                <i class="fal fa-angle-right"></i>
                                <p>Expenses/Expenditure</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="#/deposits/" class="nav-link app-link">
                                <i class="fal fa-angle-right"></i>
                                <p>Deposits History</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="#/remittance/" class="nav-link app-link">
                                <i class="fal fa-angle-right"></i>
                                <p>Funds Remittance</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="#/cash-in-out/" class="nav-link app-link">
                                <i class="fal fa-angle-right"></i>
                                <p>Cash In/Out</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="#/banking/" class="nav-link app-link">
                                <i class="fal fa-angle-right"></i>
                                <p>Banking History</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="#/wallets/" class="nav-link app-link">
                                <i class="fal fa-angle-right"></i>
                                <p>eWallets</p>
                            </a>
                        </li>

                    </ul>
                </li>
               -->
                <li class="nav-header">Reports</li>
                <li class="nav-item has-treeview">
                    <button href="#" class="nav-link">
                        <i class="nav-icon fal fa-file-spreadsheet"></i>
                        <p>
                            Report Generation
                            <i class="right fas fa-angle-left"></i>
                        </p>
                    </button>
                    <ul class="nav nav-treeview">
                        <li class="nav-item">
                            <a href="#/staff-report/" class="nav-link app-link">
                                <i class="fal fa-angle-right"></i>
                                <p>Staff Report</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="#/customer-report/" class="nav-link app-link">
                                <i class="fal fa-angle-right"></i>
                                <p>Customer Report</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="#/vendors-report/" class="nav-link app-link">
                                <i class="fal fa-angle-right"></i>
                                <p>Vendors Report</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="#/stores-report/" class="nav-link app-link">
                                <i class="fal fa-angle-right"></i>
                                <p>Stores Report</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="#/inventory-report/" class="nav-link app-link">
                                <i class="fal fa-angle-right"></i>
                                <p>Inventory Report</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="#/sales-report/" class="nav-link app-link">
                                <i class="fal fa-angle-right"></i>
                                <p>Sales Report</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="#/finance-report/" class="nav-link app-link">
                                <i class="fal fa-angle-right"></i>
                                <p>Finance Report</p>
                            </a>
                        </li>
                    </ul>
                </li>
                <li class="nav-header">MAP</li>
                <li class="nav-item">
                    <a href="#/SMBTracker/" class="nav-link app-link">
                        <i class="fal fa-map"></i>
                        <p>Location Tracker</p>
                    </a>
                </li>
                <li class="nav-header">MESSAGES</li>
                <li class="nav-item has-treeview menu-open">
                    <button href="#" class="nav-link">
                        <i class="nav-icon fal fa-comments"></i>
                        <p>
                            Message Centre
                            <i class="right fas fa-angle-left"></i>
                        </p>
                    </button>
                    <ul class="nav nav-treeview">
                        <li class="nav-item">
                            <a href="#/app-messaging/notifications/" class="nav-link app-link">
                                <i class="fal fa-bell"></i>
                                <p>Notifications</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="#/app-messaging/announcements/" class="nav-link app-link">
                                <i class="fal fa-newspaper"></i>
                                <p>Announcements</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="#/app-messaging/sms/" class="nav-link app-link">
                                <i class="fal fa-sms"></i>
                                <p>SMS Messaging</p>
                            </a>
                        </li>

                    </ul>
                </li>
                <li class="nav-header">APP MENU</li>
                <li class="nav-item has-treeview menu-open">
                    <button href="#" class="nav-link">
                        <i class="nav-icon fal fa-sliders-h"></i>
                        <p>
                            Manage App
                            <i class="right fas fa-angle-left"></i>
                        </p>
                    </button>
                    <ul class="nav nav-treeview">
                        <li class="nav-item">
                            <a href="#/department-unit/" class="nav-link app-link">
                                <i class="fal fa-building"></i>
                                <p>Department/Unit</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="#/storage-location/" class="nav-link app-link">
                                <i class="fal fa-dolly"></i>
                                <p>Storage Location</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="#/discount-vat/" class="nav-link app-link">
                                <i class="fal fa-badge-percent"></i>
                                <p>Discounts/VAT</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="#/measure-unit/" class="nav-link app-link">
                                <i class="fal fa-balance-scale"></i>
                                <p>Measure Units</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="#/delivery-option/" class="nav-link app-link">
                                <i class="fal fa-angle-right"></i>
                                <p>Delivery Option</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="#/payment-settings/" class="nav-link app-link">
                                <i class="fal fa-angle-right"></i>
                                <p>Payment Settings</p>
                            </a>
                        </li>
                    </ul>
                </li>
                <li class="nav-item has-treeview menu-open">
                    <button href="#" class="nav-link">
                        <i class="nav-icon fal fa-cogs"></i>
                        <p>
                            App Control Panel
                            <i class="right fas fa-angle-left"></i>
                        </p>
                    </button>
                    <ul class="nav nav-treeview">
                        <li class="nav-item">
                            <a href="#/configuration/" class="nav-link">
                                <i class="fal fa-sliders-v-square"></i>
                                <p>Configurations</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="#/app-backup/" class="nav-link">
                                <i class="fal fa-archive"></i>
                                <p>App Backup</p>
                            </a>
                        </li>

                        <li class="nav-item">
                            <a href="#/import-data/" class="nav-link app-link">
                                <i class="fal fa-file-csv"></i>
                                <p>Import/Export Data (CSV)</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="#/app-backup/" class="nav-link">
                                <i class="fal fa-cloud"></i>
                                <p>Cloud Synchronization</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="?p=settings&items-location" class="nav-link">
                                <i class="fal fa-shield-check"></i>
                                <p>Licences</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="?p=settings&discount" class="nav-link">
                                <i class="fal fa-books"></i>
                                <p>Documentation</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="?p=settings&payment-option" class="nav-link">
                                <i class="fal fa-life-ring"></i>
                                <p>Support/Feedback</p>
                            </a>
                        </li>
                    </ul>
                </li>
            </ul>
        </nav>
        <!-- /.sidebar-menu -->
    </div>
    <div class="app-logo">
        <div class="logo"></div>
    </div>
    <!-- /.sidebar -->


</aside>