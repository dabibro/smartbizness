<!--
 * Created by DTMGS Limited.
 * User: Dauda Ibrahim
 * Date: 6/22/2020
 * Time: 5:15 PM
 * File: App NavBar
-->
<!-- Navbar -->
<nav class="main-header navbar navbar-expand navbar-white navbar-light animated fixed-top fadeInDown py-0">
    <!-- Left navbar links -->
    <ul class="navbar-nav app-menu">
        <li class="nav-item">
            <a class="nav-link sidebar-collapse-btn" data-widget="pushmenu" href="javascript:void(0)" role="button"><i
                        class="fas fa-bars"></i></a>
        </li>
        <li class="nav-item d-none d-sm-inline-block">
            <a href="#/" class="nav-link app-link"><i class="fal fa-home"></i> Home</a>
        </li>
        <li class="nav-item d-none d-sm-inline-block">
            <a href="#/analytics/" class="nav-link app-link" title="Analytics Report" data-toggle="tooltip"><i
                        class="fal fa-analytics"></i> Analytics</a>
        </li>


    </ul>

    <!-- Right navbar links -->
    <ul class="navbar-nav ml-auto app-menu">
        <li class="nav-item">
            <a href="javascript:void(0)" onclick="location.reload();" class="nav-link" title="Refresh Application"
               data-toggle="tooltip"><i
                        class="fal fa-sync fa-spin"></i></a>
        </li>
        <li class="nav-item">
            <a href="#/sales-point/pos/" class="nav-link app-link" title="Sales Point" data-toggle="tooltip"><i
                        class="fal fa-shopping-cart"></i></a>
        </li>
        <a class="nav-link" data-widget="control-sidebar" data-slide="true" href="javascript:void(0)" role="button"
           title="Tool Box" data-toggle="tooltip">
            <i class="fal fa-toolbox"></i>
        </a>
        <!--  -->
        <li class="nav-item">
            <a class="nav-link app-link" href="#/news/" title="Announcements" data-toggle="tooltip">
                <i class="fal fa-bullhorn"></i>
                <span id="announcement-flag"></span>

            </a>
        </li>
        <!-- Notifications Dropdown Menu -->
        <li class="nav-item dropdown">
            <a class="nav-link" data-toggle="dropdown" href="#">
                <i class="fal fa-bell"></i>
                <span class="badge badge-warning navbar-badge">15</span>
            </a>
            <div class="dropdown-menu dropdown-menu-lg dropdown-menu-right">
                <span class="dropdown-item dropdown-header">15 Notifications</span>
                <div class="dropdown-divider"></div>
                <a href="#" class="dropdown-item">
                    <i class="fas fa-envelope mr-2"></i> 4 new messages
                    <span class="float-right text-muted text-sm">3 mins</span>
                </a>
                <div class="dropdown-divider"></div>
                <a href="#" class="dropdown-item">
                    <i class="fas fa-users mr-2"></i> 8 friend requests
                    <span class="float-right text-muted text-sm">12 hours</span>
                </a>
                <div class="dropdown-divider"></div>
                <a href="#" class="dropdown-item">
                    <i class="fas fa-file mr-2"></i> 3 new reports
                    <span class="float-right text-muted text-sm">2 days</span>
                </a>
                <div class="dropdown-divider"></div>
                <a href="#" class="dropdown-item dropdown-footer">See All Notifications</a>
            </div>
        </li>

        <!-- User Dropdown Menu -->
        <li class="nav-item dropdown">
            <a class="nav-link" data-toggle="dropdown" href="#">
                <i class="fal fa-user-circle"></i>
            </a>
            <div class="dropdown-menu dropdown-menu-lg dropdown-menu-right">
                <div class="dropdown-divider"></div>
                <a href="javascript:void(0);" class="dropdown-item"
                   onclick="AppModalLoader({modalId:'ModuleModal', modalTitle:'Change Password', required:'../manage-users/inc/change_password', afterEvent:''});">
                    <i class="fal fa-lock-alt"></i> Change Password
                </a>
                <div class="dropdown-divider"></div>
                <a href="#" class="dropdown-item">
                    <i class="fal fa-question-circle"></i> About SmartBizness
                </a>
                <div class="dropdown-divider"></div>
                <a href="#" class="dropdown-item">
                    <i class="fal fa-book"></i> Documentation
                </a>
                <div class="dropdown-divider"></div>
                <a href="#/sign-out/" onclick="fetchURL(this.href)" class="dropdown-item">
                    <i class="fal fa-power-off"></i> SignOut?
                </a>
            </div>
        </li>

    </ul>
    <div class="progress navbar-nav block position-relative">
        <div class="progress-bar progress-bar-striped progress-bar-animated" role="progressbar" aria-valuenow="75"
             aria-valuemin="0" aria-valuemax="100" style="width: 75%"></div>
    </div>
</nav>
<!-- /.navbar -->
