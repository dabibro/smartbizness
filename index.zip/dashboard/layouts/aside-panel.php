<?php
/**
 * Created by PhpStorm.
 * User: Dauda Ibrahim
 * Date: 6/26/2020
 * Time: 12:27 AM
 */

?>

<aside class="control-sidebar control-sidebar-light">
    <div style="overflow:auto;">
        <a href="#" class="text-right text-muted small float-right" data-widget="control-sidebar" data-slide="true"
           role="button">[ x close ]</a>
    </div>
    <?php require "toolkit/calculator/calculator.php"; ?>
</aside>
