<?php
$messengerPath = $app->plugins . 'messenger/';
require '../plugins/messenger/SMBMessenger.php'; ?>
<footer class="main-footer animated fadeInUp py-2 small">
    <div>Copyright &copy; <?php echo date( 'Y', time() ); ?> <?php echo $biz->biz['business_name']; ?>. All rights
        reserved. | <b>v</b> 2.0.0 - Powered By <a href="https://digitaltechz.com.ng" target="_blank">DTMGS LIMITED</a>.
    </div>
</footer>