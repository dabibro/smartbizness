<?php
/**
 * Created by DTMGS Limited.
 * User: Dauda Ibrahim
 * Date: 6/23/2020
 * Time: 10:50 AM
 * FIle: App Ajax Request Processor
 */
if ( file_exists( "../../helpers/config/config.inc.php" ) ):
	require "../../helpers/config/config.inc.php";
endif;
require "../../helpers/handlers/app_autoloader.php";
//---------------------------------------------------------------------------

$app         = new SMBEngine;
$appSwitcher = new App_Switcher;
$appConfig   = new AppConfig;
//---------------------------------------------------------------------------

$requestMethod = $_SERVER['REQUEST_METHOD'];
if ( in_array( $requestMethod, [ "GET", "POST", "PUT", "DELETE", "OPTIONS" ] ) ):
	//---------------------------------------------------------------------------
	$requestMethodArray = array();
	$requestMethodArray = $_REQUEST;
	//---------------------------------------------------------------------------
	if ( isset( $requestMethodArray['AppRequest'] ) ):
		$switchRequest = $appSwitcher->moduleSwitcher( $requestMethodArray['AppRequest'] );
		if ( $switchRequest['AppRequest'] == 1 && isset( $switchRequest['AppModule'] ) ):
			@$auth = @$appSwitcher->auth;
			@$store_id = @$auth['store_id'];
			$biz        = new BIZConfig;
			$AppRequest = $switchRequest;
			if ( @$switchRequest['AppModuleDataTable'] == 1 ):
				require '../includes/dataTables.php';
			endif;
			require '../layouts/contents.php';
			$appSwitcher->AppAuth->UpdateLastSeen( $auth['user_id'] );
		endif;
	endif;
	//---------------------------------------------------------------------------
	if ( isset( $requestMethodArray['AppExitRequest'] ) && $requestMethodArray['AppExitRequest'] === '1' ):
		echo $appSwitcher->AppAuth->AppExit( $appSwitcher->biz['app_session'] );
	endif;
	if ( isset( $requestMethodArray['AnnouncementChecker'] ) && $requestMethodArray['AnnouncementChecker'] === '1' ):
		@$auth = @$appSwitcher->auth;
		$flag = 0;
		@$list = @Data_Access::fetchAssoc( @Data_Access::execSQL( "SELECT viewers FROM app_announcements WHERE active_status = 1 AND  YEAR(created_on) = YEAR (CURRENT_DATE ) AND MONTH (CURRENT_DATE ) = MONTH (created_on)" )['dataArray'] )['dataArray'];
		if ( @$list != null ):
			foreach ( $list as $ann ):
				$viewers = json_decode( htmlspecialchars_decode( $ann['viewers'] ), true );
				if ( ! in_array( $auth['user_id'], $viewers ) ) {
					$flag ++;
				}
			endforeach;
		endif;
		echo $flag;
	endif;
endif;