<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>SMARTBIZNESS | Business Management Software</title>
    <link rel="icon" href="<?php echo $this->webRoot; ?>favicon.png" type="image/x-icon">
    <link rel="stylesheet" href="<?php echo $this->vendors; ?>bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo $this->vendors; ?>fontawesome/css/all.min.css">
    <link rel="stylesheet" href="<?php echo $this->vendors; ?>animate/animate.min.css">
    <link rel="stylesheet" href="<?php echo $this->assets; ?>css/adminlte.min.css">
    <link rel="stylesheet" href="<?php echo $this->assets; ?>css/unified.css">
    <link rel="stylesheet" href="<?php echo $this->assets; ?>css/login.css">

</head>
<body id="start-page">
<div id="main-content">
    <div id="app-loader">
        <div id="page-loader" class="text-center container animated fadeIn">
            <img src="<?php echo $this->assets; ?>img/startup-logo.png" alt="SmartBizness" width="160">
            <h6 class="font-weight-bold my-1 please-wait">
                <img src="<?php echo $this->assets; ?>img/h_loader.gif" alt="Loader" width="260"><br>
                <div class="mt-2">Please Wait, Initializing Core..</div>
            </h6>
        </div>
    </div>
</div>
<div id="location"></div>
<input type="hidden" id="SMBTracker" value="<?php echo(@$this->gps_tracker['SMBTracker']); ?>">
<script src="<?php echo $this->vendors; ?>jquery/jquery.min.js"></script>
<script src="<?php echo $this->vendors; ?>popper/umd/popper.min.js"></script>
<script src="<?php echo $this->vendors; ?>bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="<?php echo $this->assets; ?>js/bootstrap.validator.js"></script>
<script src="<?php echo $this->assets; ?>js/adminlte.min.js"></script>
<?php
$directory = '../plugins/gps-tracker/';
$extension = '.js';
if (file_exists($directory)) {
    foreach (glob($directory . '*' . $extension) as $file) { ?>
        <script>
            var gpsTrackerPath = '<?php echo $this->webRoot . str_replace('../', '', $directory);?>';
        </script>
        <script src="<?php echo $this->webRoot . str_replace('../', '', $file); ?>" type="text/javascript"></script>
    <?php }
}
?>
<script src="<?php echo $this->assets; ?>js/app.js"></script>


</body>
</html>