<div class="login-page">
    <div class="login-box animated zoomIn">
        <div class="login-logo">
            <div><b>SMART</b>BIZNESS <sup>&trade;</sup></div>
            <div class="small">BUSINESS MANAGEMENT SOFTWARE</div>
        </div>
        <div class="card  elevation-2 bg-transparent">
            <div class="card-body login-card-body">
                <div class="text-center mb-3">
                    <img src="<?php echo $SMBEngine->assets; ?>img/startup-logo.png" class="logo-img"
                         alt="SmartBizness Logo" width="140">
                </div>
                <p class="login-box-msg p-0"></p>
                <form method="post" id="login-form"> `
                    <div class="input-group input-group-lg mb-3 elevation-2">
                        <div class="input-group-prepend">
                            <div class="input-group-text"><span class="fal fa-user"></span></div>
                        </div>
                        <input type="text" name="AuthId" class="form-control" placeholder="Username/Email"
                               autocomplete="off" autofocus value="support">
                    </div>
                    <div class="input-group input-group-lg mb-3 elevation-2">
                        <div class="input-group-prepend">
                            <div class="input-group-text"><span class="fal fa-lock"></span></div>
                        </div>
                        <input type="password" name="AuthPassword" class="form-control" placeholder="Password"
                               autocomplete="off" value="12345678">
                    </div>
                    <button type="submit" class="btn btn-primary btn-block btn-lg elevation-2" id="login-btn" disabled>
                        <i
                                class="fal fa-sign-in-alt"></i> Sign In
                    </button>
                    <input type="hidden" name="doAppAuth" value="1">
                    <div class="row mt-3">
                        <div class="col-8">
                            <div class="icheck-primary hide">
                                <input type="checkbox" id="remember" name="RememberMe">
                                <label for="remember"> Remember Me </label>
                            </div>
                        </div>
                        <div class="col-lg-4"><a href="#" class="small"
                                                 title="Contact system administrator for supports "
                                                 data-toggle="tooltip"
                                                 data-placement="top"><i
                                        class="fal fa-question-circle"></i> Need help? </a></div>
                    </div>
                </form>
            </div>
        </div>
        <div class="small text-muted text-center copyright">Copyright
            &copy; <?php echo date('Y', time()); ?>. All right reserved. <br> Powered By <a
                    href="https://digitaltechz.com.ng/" target="_blank">DTMGS
                LIMITED</a></div>
    </div>
</div>

<script src="<?php echo $SMBEngine->webRoot; ?>auth/js.js" type="text/javascript"></script>
