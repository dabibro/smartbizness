$(document).ready(function () {
    $('[data-toggle="tooltip"]').tooltip();
    $('#login-btn').removeAttr('disabled');
    $('#login-form').bootstrap3Validate(function (e, data) {
        e.preventDefault();
        $('#login-btn').html('<i class="fal fa-spin fa-spinner fa-lg"></i> Processing...');
        $.ajax({
            url: authPath + "ajaxRequest.php",
            type: "POST",
            data: new FormData(this),
            contentType: false,
            cache: false,
            processData: false,
            success: function (data) {
                $(".login-box-msg").html(data);
                $('#login-btn').html('Sign In <i class="fal fa-sign-in-alt"></i>');
            },
            error: function () {
            }
        });

    });
});


function multiLoginSignOut(userId) {
    $.post(authPath + "ajaxRequest.php",
        {
            doMultiLoginSignOut: 1,
            user_id: userId
        },
        function (data, status) {
            $(".login-box-msg").html(data);
        });
}
