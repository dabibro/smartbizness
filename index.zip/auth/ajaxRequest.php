<?php
/**
 * Created by DTMGS Limited.
 * User: Dauda Ibrahim
 * Date: 6/22/2020
 * Time: 3:41 AM
 * File: login ajax request
 */
//-----------------------------------------------------------------
if (file_exists("../helpers/config/config.inc.php")):
    require "../helpers/config/config.inc.php";
endif;
require_once "../helpers/handlers/app_autoloader.php";
//-----------------------------------------------------------------
$AppAuth = new Auth_Access;
$biz = new BIZConfig;
//-----------------------------------------------------------------
$requestMethod = $_SERVER['REQUEST_METHOD'];
if (in_array($requestMethod, ["GET", "POST", "PUT", "DELETE", "OPTIONS"])):
    $requestMethodArray = array();
    $requestMethodArray = $_REQUEST;
    if (isset($requestMethodArray['doAppAuth'])):
        $tracker = $biz->gps_tracker['SMBTracker'];
        if ($tracker === '1'):
            $requestMethodArray += ["gps_tracker" => 1];
        endif;
        $auth = $AppAuth->AppAuth($requestMethodArray);
        if ($auth['response'] !== '200'):
            if (isset($auth['dataArray']['login_attempts'])):
                if ($auth['dataArray']['login_attempts'] > $biz->biz['login_trail']):
                    $message = "Account deactivated";
                    echo App_Response::alertResponse(@$message, "danger");
                else:
                    echo App_Response::alertResponse(@$auth['message'], "danger");
                endif;
            else:
                echo App_Response::alertResponse(@$auth['message'], "danger");
            endif;
        else:
            if ($biz->biz['multiple_login'] == 1 && $auth['dataArray']['login_status'] == 1):
                $message = "Multiple Login, <button type='button' onclick=\"multiLoginSignOut('" . $biz->engine->base64_url_encryption($auth['dataArray']['user_id']) . "'); \">[ SignOut Now? ] </button>";
                echo App_Response::alertResponse(@$message, "danger");
            else:
                echo App_Response::alertResponse(@$auth['message'], "success");
                $session = $biz->biz['app_session'];
                $_SESSION[$session] = $biz->engine->base64_url_encryption($auth['dataArray']['user_id']);
                echo '<script>location.reload();</script>';
            endif;
        endif;
    endif;
    if (isset($requestMethodArray['doMultiLoginSignOut'])):
        $userId = $requestMethodArray['user_id'];
        $exitReq = $AppAuth->AppExit($biz->biz['app_session'], $userId);
        if (@$exitReq['response'] === '200'):
            echo '<script>location.reload();</script>';
        endif;

    endif;
endif;