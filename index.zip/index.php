<?php
/**
 * Created by DTMGS Limited.
 * User: Dauda Ibrahim
 * Date: 6/21/2020
 * Time: 10:09 PM
 * File: App Launcher
 */
if (file_exists("helpers/config/config.inc.php")):
    require "helpers/config/config.inc.php";
endif;
require_once "helpers/handlers/app_autoloader.php";
define('SMBPrivateKey', '');
$api = new SMBAPI();
echo $api->LaunchEngine();
